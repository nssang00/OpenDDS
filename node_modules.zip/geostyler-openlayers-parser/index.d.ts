declare module '@terrestris/ol-util/dist/MapUtil/MapUtil';
declare module 'color-name';
