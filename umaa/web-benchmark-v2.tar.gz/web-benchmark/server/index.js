/**
 * Web Protocol Benchmark - Server (v2)
 *
 * 수정 사항:
 *   - 페이로드 크기 지원: 1KB / 10KB / 100KB
 *   - SSE: 영속 연결 유지 + /trigger POST로 서버 푸시
 *   - gRPC: bytes 타입으로 실제 직렬화/역직렬화 포함
 *
 * REST      → http://localhost:3001
 * WebSocket → ws://localhost:3002
 * SSE       → http://localhost:3003
 * gRPC      → localhost:3004
 */

const express = require('express');
const WebSocket = require('ws');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');

// ============================================================
// 공통: 페이로드 미리 생성
// ============================================================
const PAYLOADS = {
  '1KB':   Buffer.alloc(1024,   'x'),
  '10KB':  Buffer.alloc(10240,  'x'),
  '100KB': Buffer.alloc(102400, 'x'),
};

// JSON 응답용 (REST / WebSocket / SSE)
const JSON_PAYLOADS = {
  '1KB':   'x'.repeat(1024),
  '10KB':  'x'.repeat(10240),
  '100KB': 'x'.repeat(102400),
};

function getPayload(size) {
  return JSON_PAYLOADS[size] || JSON_PAYLOADS['1KB'];
}

// ============================================================
// 1. REST Server (Port 3001)
// ============================================================
const restApp = express();
restApp.use(express.json({ limit: '200kb' }));

// POST /ping: 요청 파싱 → 동일 사이즈 JSON 응답
restApp.post('/ping', (req, res) => {
  const { id, payloadSize } = req.body;   // express.json()이 이미 파싱함
  res.json({
    id,
    timestamp: Date.now(),
    payload: getPayload(payloadSize),
  });
});

restApp.listen(3001, () => console.log('✅ REST      → http://localhost:3001'));

// ============================================================
// 2. WebSocket Server (Port 3002)
// ============================================================
const wss = new WebSocket.Server({ port: 3002 }, () =>
  console.log('✅ WebSocket → ws://localhost:3002')
);

wss.on('connection', (ws) => {
  ws.on('message', (raw) => {
    // 서버 측에서도 JSON 파싱 (공정한 파싱 비용 포함)
    const msg = JSON.parse(raw);
    ws.send(JSON.stringify({
      id: msg.id,
      timestamp: Date.now(),
      payload: getPayload(msg.payloadSize),
    }));
  });
  ws.on('error', (err) => console.error('WS error:', err.message));
});

// ============================================================
// 3. SSE Server (Port 3003)
//
// 구조:
//   GET  /events?clientId=xxx → 영속 SSE 연결 유지
//   POST /trigger              → 특정 클라이언트에 이벤트 푸시
//
// 클라이언트는 연결 1개를 열어두고, 측정마다 /trigger를 호출.
// → 매 요청마다 TCP 연결을 새로 맺는 기존 방식의 문제 해결.
// ============================================================
const sseApp = express();
sseApp.use(express.json({ limit: '200kb' }));
sseApp.use((_, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  next();
});

// clientId → SSE response 객체
const sseClients = new Map();

// SSE 영속 연결
sseApp.get('/events', (req, res) => {
  const { clientId } = req.query;
  if (!clientId) return res.status(400).end('clientId required');

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();  // 즉시 헤더 전송 → 클라이언트가 연결 확인

  sseClients.set(clientId, res);

  // 연결 끊기면 제거
  req.on('close', () => sseClients.delete(clientId));
});

// 서버 푸시 트리거
sseApp.post('/trigger', (req, res) => {
  const { clientId, id, payloadSize } = req.body;
  const client = sseClients.get(clientId);

  if (!client) return res.status(404).json({ error: 'Client not found' });

  // SSE 이벤트 푸시
  client.write(
    `data: ${JSON.stringify({
      id,
      timestamp: Date.now(),
      payload: getPayload(payloadSize),
    })}\n\n`
  );

  res.json({ ok: true });
});

sseApp.listen(3003, () => console.log('✅ SSE       → http://localhost:3003'));

// ============================================================
// 4. gRPC Server (Port 3004)
// ============================================================
const PROTO_PATH = path.join(__dirname, 'proto/service.proto');
const packageDef = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true, longs: String, enums: String, defaults: true, oneofs: true,
});
const proto = grpc.loadPackageDefinition(packageDef).benchmark;

const grpcServer = new grpc.Server();
grpcServer.addService(proto.BenchmarkService.service, {
  ping(call, callback) {
    const size = call.request.payloadSize || '1KB';
    callback(null, {
      id:        call.request.id,
      timestamp: Date.now(),
      payload:   PAYLOADS[size] || PAYLOADS['1KB'],  // bytes → proto 직렬화됨
    });
  },
});

grpcServer.bindAsync(
  '0.0.0.0:3004',
  grpc.ServerCredentials.createInsecure(),
  (err) => {
    if (err) { console.error('gRPC bind error:', err); return; }
    console.log('✅ gRPC      → localhost:3004');
  }
);
