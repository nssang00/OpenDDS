/**
 * Web Protocol Benchmark - Client (v2)
 *
 * 수정 사항:
 *   [1] 페이로드 크기별 측정: 1KB / 10KB / 100KB
 *   [2] 모든 프로토콜에서 응답 파싱 포함
 *       - REST      : await response.json()
 *       - WebSocket : JSON.parse(raw)
 *       - SSE       : JSON.parse(line) (스트림 파싱 포함)
 *       - gRPC      : proto 역직렬화 (기존과 동일, 이미 포함)
 *   [3] SSE: 영속 연결 1개 유지 + POST /trigger로 측정
 *       - 기존: 매 요청마다 TCP 새 연결 (TCP 핸드셰이크 비용이 측정에 포함됨)
 *       - 수정: 연결 1개 열어두고 서버가 push → 순수 이벤트 전송 latency 측정
 *
 * 실행: node client/benchmark.js
 */

const http = require('http');
const { EventEmitter } = require('events');
const WebSocket = require('ws');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');

// ============================================================
// 설정
// ============================================================
const CONFIG = {
  PAYLOAD_SIZES:      ['1KB', '10KB', '100KB'],
  LATENCY_ITERATIONS: 200,   // 순차 요청 수
  CONCURRENCY:        30,    // 동시 연결 수 (throughput)
  THROUGHPUT_TOTAL:   300,   // throughput 총 요청 수
  WARMUP:             10,    // 통계 제외 워밍업 횟수
};

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ============================================================
// 통계
// ============================================================
function calcStats(latencies) {
  if (!latencies.length) return null;
  const s = [...latencies].sort((a, b) => a - b);
  const sum = s.reduce((a, b) => a + b, 0);
  return {
    avg: sum / s.length,
    min: s[0],
    max: s[s.length - 1],
    p50: s[Math.floor(s.length * 0.50)],
    p95: s[Math.floor(s.length * 0.95)],
    p99: s[Math.floor(s.length * 0.99)],
  };
}

// ============================================================
// 출력
// ============================================================
const COL = 9;
function fmt(n) { return n.toFixed(2).padStart(COL); }

function printLatencyTable(payloadSize, results) {
  const div = '─'.repeat(78);
  console.log(`\n  📦 Payload: ${payloadSize}`);
  console.log('  ' + div);
  console.log(
    '  ' + 'Protocol'.padEnd(12) +
    '│' + ' Avg(ms)'.padStart(COL) +
    '│' + ' Min'.padStart(COL) +
    '│' + ' P50'.padStart(COL) +
    '│' + ' P95'.padStart(COL) +
    '│' + ' P99'.padStart(COL) +
    '│' + ' Max'.padStart(COL)
  );
  console.log('  ' + div);
  for (const [name, stats] of Object.entries(results)) {
    if (!stats) { console.log(`  ${name.padEnd(12)}│  ERROR`); continue; }
    console.log(
      '  ' + name.padEnd(12) +
      '│' + fmt(stats.avg) +
      '│' + fmt(stats.min) +
      '│' + fmt(stats.p50) +
      '│' + fmt(stats.p95) +
      '│' + fmt(stats.p99) +
      '│' + fmt(stats.max)
    );
  }
  console.log('  ' + div);
}

function printThroughputTable(payloadSize, results) {
  const div = '─'.repeat(44);
  console.log(`\n  📦 Payload: ${payloadSize}`);
  console.log('  ' + div);
  console.log('  ' + 'Protocol'.padEnd(12) + '│' + ' Req/sec'.padStart(12) + '│' + ' Total(ms)'.padStart(14));
  console.log('  ' + div);
  for (const [name, r] of Object.entries(results)) {
    if (!r) { console.log(`  ${name.padEnd(12)}│  ERROR`); continue; }
    console.log(
      '  ' + name.padEnd(12) +
      '│' + r.rps.toFixed(0).padStart(11) + ' ' +
      '│' + (r.total.toFixed(0) + 'ms').padStart(13) + ' '
    );
  }
  console.log('  ' + div);
}

// ============================================================
// [1] REST
// ============================================================
async function restLatency(n, warmup, payloadSize) {
  const latencies = [];
  for (let i = 0; i < n + warmup; i++) {
    const start = performance.now();
    const res = await fetch('http://localhost:3001/ping', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: i, payloadSize }),
    });
    await res.json();                           // ✅ 파싱 포함
    if (i >= warmup) latencies.push(performance.now() - start);
  }
  return calcStats(latencies);
}

async function restThroughput(total, concurrency, payloadSize) {
  const start = performance.now();
  let done = 0;
  async function worker() {
    while (done < total) {
      const id = done++;
      const res = await fetch('http://localhost:3001/ping', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, payloadSize }),
      });
      await res.json();                         // ✅ 파싱 포함
    }
  }
  await Promise.all(Array.from({ length: concurrency }, worker));
  const elapsed = performance.now() - start;
  return { rps: total / (elapsed / 1000), total: elapsed };
}

// ============================================================
// [2] WebSocket
// ============================================================
async function wsLatency(n, warmup, payloadSize) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket('ws://localhost:3002');
    const latencies = [];
    let count = 0;
    let start;

    ws.on('error', reject);
    ws.on('open', () => {
      start = performance.now();
      ws.send(JSON.stringify({ id: 0, payloadSize }));
    });
    ws.on('message', (raw) => {
      JSON.parse(raw);                          // ✅ 파싱 포함
      if (count >= warmup) latencies.push(performance.now() - start);
      count++;
      if (count >= n + warmup) { ws.close(); resolve(calcStats(latencies)); return; }
      start = performance.now();
      ws.send(JSON.stringify({ id: count, payloadSize }));
    });
  });
}

async function wsThroughput(total, concurrency, payloadSize) {
  const start = performance.now();
  const perConn = Math.ceil(total / concurrency);

  async function runConn() {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket('ws://localhost:3002');
      let count = 0;
      ws.on('error', reject);
      ws.on('open', () => ws.send(JSON.stringify({ id: 0, payloadSize })));
      ws.on('message', (raw) => {
        JSON.parse(raw);                        // ✅ 파싱 포함
        count++;
        if (count >= perConn) { ws.close(); resolve(); return; }
        ws.send(JSON.stringify({ id: count, payloadSize }));
      });
    });
  }

  await Promise.all(Array.from({ length: concurrency }, runConn));
  const elapsed = performance.now() - start;
  return { rps: total / (elapsed / 1000), total: elapsed };
}

// ============================================================
// [3] SSE - 영속 연결 유지
// ============================================================

/**
 * SSE 연결 1개를 열고, 이벤트 수신 시 EventEmitter로 알림.
 * 클라이언트는 연결을 유지한 채 /trigger POST로 측정.
 */
function openSSEConnection(clientId) {
  return new Promise((resolve, reject) => {
    const emitter = new EventEmitter();
    let buffer = '';

    const req = http.get(
      `http://localhost:3003/events?clientId=${encodeURIComponent(clientId)}`,
      (res) => {
        // 헤더 수신 완료 = 서버가 clientId 등록 완료 → 측정 시작 가능
        resolve({
          emitter,
          close: () => req.destroy(),
        });

        res.on('data', (chunk) => {
          buffer += chunk.toString();
          // SSE는 \n\n으로 이벤트 구분
          const parts = buffer.split('\n\n');
          buffer = parts.pop(); // 마지막 불완전 조각 보관

          for (const part of parts) {
            for (const line of part.split('\n')) {
              if (line.startsWith('data: ')) {
                try {
                  // ✅ SSE 스트림 파싱 포함
                  const parsed = JSON.parse(line.slice(6));
                  emitter.emit('message', parsed);
                } catch { /* 불완전 청크 무시 */ }
              }
            }
          }
        });
        res.on('error', (e) => emitter.emit('error', e));
      }
    );
    req.on('error', reject);
  });
}

function waitForSSEEvent(emitter, timeoutMs = 5000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error('SSE event timeout')), timeoutMs);
    emitter.once('message', (data) => { clearTimeout(timer); resolve(data); });
  });
}

async function sseLatency(n, warmup, payloadSize) {
  const clientId = `lat-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const { emitter, close } = await openSSEConnection(clientId);
  await sleep(50); // 서버 등록 안정화 대기

  const latencies = [];

  for (let i = 0; i < n + warmup; i++) {
    const start = performance.now();

    // trigger POST 전송과 SSE 이벤트 대기를 동시에 시작
    const [, ] = await Promise.all([
      fetch('http://localhost:3003/trigger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ clientId, id: i, payloadSize }),
      }),
      waitForSSEEvent(emitter),   // ✅ 파싱까지 완료 후 resolve
    ]);

    if (i >= warmup) latencies.push(performance.now() - start);
  }

  close();
  return calcStats(latencies);
}

async function sseThroughput(total, concurrency, payloadSize) {
  // 각 worker에 독립 SSE 연결 1개씩
  const connections = await Promise.all(
    Array.from({ length: concurrency }, (_, i) =>
      openSSEConnection(`tp-${Date.now()}-${i}`)
    )
  );
  await sleep(100); // 전체 연결 안정화

  const start = performance.now();
  const perConn = Math.ceil(total / concurrency);

  async function worker({ emitter, close }, clientId) {
    for (let i = 0; i < perConn; i++) {
      await Promise.all([
        fetch('http://localhost:3003/trigger', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ clientId, id: i, payloadSize }),
        }),
        waitForSSEEvent(emitter),
      ]);
    }
    close();
  }

  const clientIds = connections.map((_, i) => `tp-${Date.now()}-${i}`);
  // clientId가 openSSEConnection에서 생성되므로 재생성
  // → 실제로는 연결할 때의 clientId와 trigger의 clientId가 일치해야 함
  // 아래 sseThroughput2에서 올바르게 처리
  await Promise.all(connections.map((conn) => worker(conn, clientIds[connections.indexOf(conn)])));

  const elapsed = performance.now() - start;
  connections.forEach((c) => c.close());
  return { rps: total / (elapsed / 1000), total: elapsed };
}

// sseThroughput을 clientId 매핑 포함하여 올바르게 재구현
async function sseThroughputFixed(total, concurrency, payloadSize) {
  const workers = await Promise.all(
    Array.from({ length: concurrency }, async (_, i) => {
      const clientId = `tp-${Date.now()}-${i}-${Math.random().toString(36).slice(2)}`;
      const conn = await openSSEConnection(clientId);
      return { clientId, ...conn };
    })
  );
  await sleep(100);

  const start = performance.now();
  const perConn = Math.ceil(total / concurrency);

  await Promise.all(
    workers.map(async ({ clientId, emitter, close }) => {
      for (let i = 0; i < perConn; i++) {
        await Promise.all([
          fetch('http://localhost:3003/trigger', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ clientId, id: i, payloadSize }),
          }),
          waitForSSEEvent(emitter),
        ]);
      }
      close();
    })
  );

  const elapsed = performance.now() - start;
  return { rps: total / (elapsed / 1000), total: elapsed };
}

// ============================================================
// [4] gRPC
// ============================================================
function makeGrpcClient() {
  const PROTO_PATH = path.join(__dirname, '../server/proto/service.proto');
  const pkg = grpc.loadPackageDefinition(
    protoLoader.loadSync(PROTO_PATH, {
      keepCase: true, longs: String, enums: String, defaults: true, oneofs: true,
    })
  ).benchmark;
  return new pkg.BenchmarkService('localhost:3004', grpc.credentials.createInsecure());
}

function grpcPing(client, id, payloadSize) {
  return new Promise((resolve, reject) => {
    const start = performance.now();
    client.ping({ id, payloadSize }, (err, res) => {
      if (err) return reject(err);
      // res.payload는 Buffer (proto bytes → 역직렬화 완료) ✅
      void res.payload;
      resolve(performance.now() - start);
    });
  });
}

async function grpcLatency(n, warmup, payloadSize) {
  const client = makeGrpcClient();
  const latencies = [];
  for (let i = 0; i < n + warmup; i++) {
    const elapsed = await grpcPing(client, i, payloadSize);
    if (i >= warmup) latencies.push(elapsed);
  }
  client.close();
  return calcStats(latencies);
}

async function grpcThroughput(total, concurrency, payloadSize) {
  const clients = Array.from({ length: concurrency }, makeGrpcClient);
  const start = performance.now();
  let done = 0;

  await Promise.all(
    clients.map(async (client) => {
      while (done < total) {
        const id = done++;
        await grpcPing(client, id, payloadSize);
      }
      client.close();
    })
  );

  const elapsed = performance.now() - start;
  return { rps: total / (elapsed / 1000), total: elapsed };
}

// ============================================================
// 메인
// ============================================================
async function runForPayload(payloadSize) {
  const { LATENCY_ITERATIONS: LN, WARMUP, CONCURRENCY, THROUGHPUT_TOTAL: TN } = CONFIG;

  // -- Latency --
  const latResults = {};
  process.stdout.write(`    REST      `); latResults['REST']      = await restLatency(LN, WARMUP, payloadSize);      console.log('done');
  process.stdout.write(`    WebSocket `); latResults['WebSocket'] = await wsLatency(LN, WARMUP, payloadSize);        console.log('done');
  process.stdout.write(`    SSE       `); latResults['SSE']       = await sseLatency(LN, WARMUP, payloadSize);       console.log('done');
  process.stdout.write(`    gRPC      `); latResults['gRPC']      = await grpcLatency(LN, WARMUP, payloadSize);      console.log('done');
  printLatencyTable(payloadSize, latResults);

  // -- Throughput --
  const tpResults = {};
  process.stdout.write(`    REST      `); tpResults['REST']      = await restThroughput(TN, CONCURRENCY, payloadSize);          console.log('done');
  process.stdout.write(`    WebSocket `); tpResults['WebSocket'] = await wsThroughput(TN, CONCURRENCY, payloadSize);            console.log('done');
  process.stdout.write(`    SSE       `); tpResults['SSE']       = await sseThroughputFixed(TN, CONCURRENCY, payloadSize);      console.log('done');
  process.stdout.write(`    gRPC      `); tpResults['gRPC']      = await grpcThroughput(TN, CONCURRENCY, payloadSize);          console.log('done');
  printThroughputTable(payloadSize, tpResults);
}

async function main() {
  console.log('');
  console.log('╔══════════════════════════════════════════════════════════════╗');
  console.log('║       Web Protocol Performance Benchmark  v2                 ║');
  console.log('║   REST │ WebSocket │ SSE │ gRPC  ×  1KB / 10KB / 100KB     ║');
  console.log('╚══════════════════════════════════════════════════════════════╝');
  console.log(`\n  설정: Latency=${CONFIG.LATENCY_ITERATIONS}회, Throughput=${CONFIG.THROUGHPUT_TOTAL}req (동시=${CONFIG.CONCURRENCY}), Warmup=${CONFIG.WARMUP}회`);
  console.log(`  파싱: 모든 프로토콜 응답 파싱 포함`);
  console.log(`  SSE:  영속 연결 유지 + /trigger POST 방식`);

  for (const size of CONFIG.PAYLOAD_SIZES) {
    console.log(`\n${'═'.repeat(66)}`);
    console.log(`  페이로드: ${size}`);
    console.log(`${'═'.repeat(66)}`);
    console.log(`\n  [Latency] 순차 ${CONFIG.LATENCY_ITERATIONS}회`);
    await runForPayload(size);
    await sleep(500); // 포트 안정화
  }

  console.log('\n✅ Benchmark complete!\n');
}

main().catch((err) => {
  console.error('\n❌ Error:', err.message);
  console.error('서버가 실행 중인지 확인하세요: npm run server');
  process.exit(1);
});
