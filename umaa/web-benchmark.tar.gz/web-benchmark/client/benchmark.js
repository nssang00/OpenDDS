/**
 * Web Protocol Benchmark - Client
 *
 * 측정 방식:
 *   - Latency Test  : 요청 1개씩 순차 전송 → 응답까지 걸린 시간 측정
 *   - Throughput Test : N개 동시 요청 → 초당 처리량 측정
 *
 * 실행: node client/benchmark.js
 */

const http = require('http');
const WebSocket = require('ws');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');

// ============================================================
// 설정
// ============================================================
const CONFIG = {
  LATENCY_ITERATIONS: 500,    // 순차 요청 수 (latency 측정)
  CONCURRENCY: 50,            // 동시 요청 수 (throughput 측정)
  THROUGHPUT_TOTAL: 1000,     // throughput 측정 총 요청 수
  WARMUP: 20,                 // 워밍업 횟수 (통계에서 제외)
};

// ============================================================
// 유틸리티
// ============================================================
function calcStats(latencies) {
  if (latencies.length === 0) return null;
  const sorted = [...latencies].sort((a, b) => a - b);
  const sum = sorted.reduce((a, b) => a + b, 0);
  return {
    avg:  sum / sorted.length,
    min:  sorted[0],
    max:  sorted[sorted.length - 1],
    p50:  sorted[Math.floor(sorted.length * 0.50)],
    p95:  sorted[Math.floor(sorted.length * 0.95)],
    p99:  sorted[Math.floor(sorted.length * 0.99)],
  };
}

function fmt(ms) {
  return ms.toFixed(2).padStart(7);
}

function printTable(results) {
  const divider = '─'.repeat(75);
  console.log('\n' + divider);
  console.log(
    'Protocol'.padEnd(12) +
    '│' + ' Avg(ms)'.padStart(9) +
    '│' + ' Min(ms)'.padStart(9) +
    '│' + ' P50(ms)'.padStart(9) +
    '│' + ' P95(ms)'.padStart(9) +
    '│' + ' P99(ms)'.padStart(9) +
    '│' + ' Max(ms)'.padStart(9)
  );
  console.log(divider);
  for (const [name, stats] of Object.entries(results)) {
    if (!stats) { console.log(`${name.padEnd(12)}│  ERROR`); continue; }
    console.log(
      name.padEnd(12) +
      '│' + fmt(stats.avg) + ' ' +
      '│' + fmt(stats.min) + ' ' +
      '│' + fmt(stats.p50) + ' ' +
      '│' + fmt(stats.p95) + ' ' +
      '│' + fmt(stats.p99) + ' ' +
      '│' + fmt(stats.max) + ' '
    );
  }
  console.log(divider);
}

function printThroughput(results) {
  const divider = '─'.repeat(40);
  console.log('\n' + divider);
  console.log('Protocol'.padEnd(12) + '│' + ' Req/sec'.padStart(12) + '│' + ' Total(ms)'.padStart(12));
  console.log(divider);
  for (const [name, r] of Object.entries(results)) {
    if (!r) { console.log(`${name.padEnd(12)}│  ERROR`); continue; }
    console.log(
      name.padEnd(12) +
      '│' + String(r.rps.toFixed(0)).padStart(11) + ' ' +
      '│' + String(r.total.toFixed(0) + 'ms').padStart(11) + ' '
    );
  }
  console.log(divider);
}

// ============================================================
// REST 테스트
// ============================================================
async function benchmarkREST_latency(n, warmup) {
  const latencies = [];
  const total = n + warmup;

  for (let i = 0; i < total; i++) {
    const start = performance.now();
    await fetch(`http://localhost:3001/ping?id=${i}`);
    const elapsed = performance.now() - start;
    if (i >= warmup) latencies.push(elapsed);
  }

  return calcStats(latencies);
}

async function benchmarkREST_throughput(total, concurrency) {
  const start = performance.now();
  let completed = 0;

  async function worker() {
    while (completed < total) {
      const id = completed++;
      await fetch(`http://localhost:3001/ping?id=${id}`);
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker));
  const elapsed = performance.now() - start;
  return { rps: total / (elapsed / 1000), total: elapsed };
}

// ============================================================
// WebSocket 테스트
// ============================================================
async function benchmarkWS_latency(n, warmup) {
  return new Promise((resolve, reject) => {
    const ws = new WebSocket('ws://localhost:3002');
    const latencies = [];
    let count = 0;
    let startTime;

    ws.on('error', reject);

    ws.on('open', () => {
      startTime = performance.now();
      ws.send(JSON.stringify({ id: 0 }));
    });

    ws.on('message', () => {
      const elapsed = performance.now() - startTime;
      if (count >= warmup) latencies.push(elapsed);
      count++;

      if (count >= n + warmup) {
        ws.close();
        resolve(calcStats(latencies));
        return;
      }

      startTime = performance.now();
      ws.send(JSON.stringify({ id: count }));
    });
  });
}

async function benchmarkWS_throughput(total, concurrency) {
  // 여러 WebSocket 연결을 열어 동시 처리
  const start = performance.now();
  const perConn = Math.ceil(total / concurrency);

  async function runConn(n) {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket('ws://localhost:3002');
      let count = 0;
      ws.on('error', reject);
      ws.on('open', () => ws.send(JSON.stringify({ id: count })));
      ws.on('message', () => {
        count++;
        if (count >= n) { ws.close(); resolve(); return; }
        ws.send(JSON.stringify({ id: count }));
      });
    });
  }

  await Promise.all(Array.from({ length: concurrency }, () => runConn(perConn)));
  const elapsed = performance.now() - start;
  return { rps: total / (elapsed / 1000), total: elapsed };
}

// ============================================================
// SSE 테스트
// ============================================================
// 새 연결마다 첫 이벤트까지의 latency를 측정 (SSE 특성상 연결 비용 포함)
function sseOnePing(id) {
  return new Promise((resolve, reject) => {
    const start = performance.now();
    const req = http.get(`http://localhost:3003/ping?id=${id}`, (res) => {
      let buffer = '';
      res.on('data', (chunk) => {
        buffer += chunk.toString();
        // 첫 번째 data: 라인을 받는 순간 측정 완료
        if (buffer.includes('data:')) {
          resolve(performance.now() - start);
          req.destroy(); // 연결 종료
        }
      });
      res.on('error', reject);
    });
    req.on('error', reject);
  });
}

async function benchmarkSSE_latency(n, warmup) {
  const latencies = [];
  const total = n + warmup;

  for (let i = 0; i < total; i++) {
    const elapsed = await sseOnePing(i);
    if (i >= warmup) latencies.push(elapsed);
  }

  return calcStats(latencies);
}

async function benchmarkSSE_throughput(total, concurrency) {
  const start = performance.now();
  let completed = 0;

  async function worker() {
    while (completed < total) {
      const id = completed++;
      await sseOnePing(id);
    }
  }

  await Promise.all(Array.from({ length: concurrency }, worker));
  const elapsed = performance.now() - start;
  return { rps: total / (elapsed / 1000), total: elapsed };
}

// ============================================================
// gRPC 테스트
// ============================================================
function makeGrpcClient() {
  const PROTO_PATH = path.join(__dirname, '../server/proto/service.proto');
  const packageDef = protoLoader.loadSync(PROTO_PATH, {
    keepCase: true, longs: String, enums: String, defaults: true, oneofs: true,
  });
  const proto = grpc.loadPackageDefinition(packageDef).benchmark;
  return new proto.BenchmarkService('localhost:3004', grpc.credentials.createInsecure());
}

function grpcPing(client, id) {
  return new Promise((resolve, reject) => {
    const start = performance.now();
    client.ping({ message: 'ping', id }, (err) => {
      if (err) reject(err);
      else resolve(performance.now() - start);
    });
  });
}

async function benchmarkGRPC_latency(n, warmup) {
  const client = makeGrpcClient();
  const latencies = [];

  for (let i = 0; i < n + warmup; i++) {
    const elapsed = await grpcPing(client, i);
    if (i >= warmup) latencies.push(elapsed);
  }

  client.close();
  return calcStats(latencies);
}

async function benchmarkGRPC_throughput(total, concurrency) {
  // 커넥션 풀처럼 여러 클라이언트 생성
  const clients = Array.from({ length: concurrency }, makeGrpcClient);
  const start = performance.now();
  let completed = 0;

  async function worker(client) {
    while (completed < total) {
      const id = completed++;
      await grpcPing(client, id);
    }
  }

  await Promise.all(clients.map(worker));
  const elapsed = performance.now() - start;
  clients.forEach((c) => c.close());
  return { rps: total / (elapsed / 1000), total: elapsed };
}

// ============================================================
// 메인 실행
// ============================================================
async function main() {
  console.log('');
  console.log('╔══════════════════════════════════════════════════════════╗');
  console.log('║      Web Protocol Performance Benchmark                  ║');
  console.log('║   REST | WebSocket | SSE | gRPC                         ║');
  console.log('╚══════════════════════════════════════════════════════════╝');
  console.log(`\n설정: Latency=${CONFIG.LATENCY_ITERATIONS}회, Throughput=${CONFIG.THROUGHPUT_TOTAL}req(동시=${CONFIG.CONCURRENCY}), Warmup=${CONFIG.WARMUP}회`);

  // ─── Latency Test ───
  console.log(`\n\n📏 [1/2] Latency Test (순차 요청 ${CONFIG.LATENCY_ITERATIONS}회)\n`);

  const latencyResults = {};

  process.stdout.write('  REST      ... ');
  latencyResults['REST'] = await benchmarkREST_latency(CONFIG.LATENCY_ITERATIONS, CONFIG.WARMUP);
  console.log('done');

  process.stdout.write('  WebSocket ... ');
  latencyResults['WebSocket'] = await benchmarkWS_latency(CONFIG.LATENCY_ITERATIONS, CONFIG.WARMUP);
  console.log('done');

  process.stdout.write('  SSE       ... ');
  latencyResults['SSE'] = await benchmarkSSE_latency(CONFIG.LATENCY_ITERATIONS, CONFIG.WARMUP);
  console.log('done');

  process.stdout.write('  gRPC      ... ');
  latencyResults['gRPC'] = await benchmarkGRPC_latency(CONFIG.LATENCY_ITERATIONS, CONFIG.WARMUP);
  console.log('done');

  printTable(latencyResults);

  // ─── Throughput Test ───
  console.log(`\n\n🚀 [2/2] Throughput Test (동시 ${CONFIG.CONCURRENCY}개 / 총 ${CONFIG.THROUGHPUT_TOTAL}회)\n`);

  const throughputResults = {};

  process.stdout.write('  REST      ... ');
  throughputResults['REST'] = await benchmarkREST_throughput(CONFIG.THROUGHPUT_TOTAL, CONFIG.CONCURRENCY);
  console.log('done');

  process.stdout.write('  WebSocket ... ');
  throughputResults['WebSocket'] = await benchmarkWS_throughput(CONFIG.THROUGHPUT_TOTAL, CONFIG.CONCURRENCY);
  console.log('done');

  process.stdout.write('  SSE       ... ');
  throughputResults['SSE'] = await benchmarkSSE_throughput(CONFIG.THROUGHPUT_TOTAL, CONFIG.CONCURRENCY);
  console.log('done');

  process.stdout.write('  gRPC      ... ');
  throughputResults['gRPC'] = await benchmarkGRPC_throughput(CONFIG.THROUGHPUT_TOTAL, CONFIG.CONCURRENCY);
  console.log('done');

  printThroughput(throughputResults);

  console.log('\n✅ Benchmark complete!\n');
}

main().catch((err) => {
  console.error('\n❌ Error:', err.message);
  console.error('서버가 실행 중인지 확인하세요: npm run server');
  process.exit(1);
});
