/**
 * Web Protocol Benchmark - Server
 *
 * REST      → http://localhost:3001
 * WebSocket → ws://localhost:3002
 * SSE       → http://localhost:3003
 * gRPC      → localhost:3004
 */

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');

// ============================================================
// 1. REST Server (Port 3001)
// ============================================================
const restApp = express();
restApp.use(express.json());

// 단순 ping-pong
restApp.get('/ping', (req, res) => {
  res.json({
    message: 'pong',
    id: Number(req.query.id) || 0,
    timestamp: Date.now(),
  });
});

// echo (POST body를 그대로 반환)
restApp.post('/echo', (req, res) => {
  res.json({ ...req.body, timestamp: Date.now() });
});

restApp.listen(3001, () => console.log('✅ REST      → http://localhost:3001'));

// ============================================================
// 2. WebSocket Server (Port 3002)
// ============================================================
const wss = new WebSocket.Server({ port: 3002 }, () =>
  console.log('✅ WebSocket → ws://localhost:3002')
);

wss.on('connection', (ws) => {
  ws.on('message', (data) => {
    try {
      const msg = JSON.parse(data);
      // 받은 메시지를 그대로 echo
      ws.send(JSON.stringify({ ...msg, timestamp: Date.now() }));
    } catch {
      ws.send(JSON.stringify({ error: 'Invalid JSON', timestamp: Date.now() }));
    }
  });

  ws.on('error', (err) => console.error('WebSocket error:', err.message));
});

// ============================================================
// 3. SSE Server (Port 3003)
// ============================================================
const sseApp = express();
sseApp.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  next();
});

// 단건 ping: 연결 후 이벤트 1개 전송 (latency 측정용)
sseApp.get('/ping', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  res.write(
    `data: ${JSON.stringify({
      message: 'pong',
      id: Number(req.query.id) || 0,
      timestamp: Date.now(),
    })}\n\n`
  );

  // 클라이언트가 연결을 닫으면 정리
  req.on('close', () => res.end());
});

// 스트리밍: N개 이벤트를 연속으로 전송 (throughput 측정용)
sseApp.get('/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const count = Math.min(parseInt(req.query.count) || 100, 10000);
  let sent = 0;

  const send = () => {
    if (sent >= count) {
      res.write('event: done\ndata: {}\n\n');
      res.end();
      return;
    }
    res.write(`data: ${JSON.stringify({ id: sent, timestamp: Date.now() })}\n\n`);
    sent++;
    setImmediate(send); // 블로킹 없이 빠르게 전송
  };

  send();
  req.on('close', () => res.end());
});

sseApp.listen(3003, () =>
  console.log('✅ SSE       → http://localhost:3003')
);

// ============================================================
// 4. gRPC Server (Port 3004)
// ============================================================
const PROTO_PATH = path.join(__dirname, 'proto/service.proto');

const packageDef = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});
const proto = grpc.loadPackageDefinition(packageDef).benchmark;

const grpcServer = new grpc.Server();

grpcServer.addService(proto.BenchmarkService.service, {
  ping(call, callback) {
    callback(null, {
      message: 'pong',
      id: call.request.id,
      timestamp: Date.now(),
    });
  },
});

grpcServer.bindAsync(
  '0.0.0.0:3004',
  grpc.ServerCredentials.createInsecure(),
  (err, port) => {
    if (err) {
      console.error('gRPC bind error:', err);
      return;
    }
    console.log(`✅ gRPC      → localhost:3004`);
  }
);
