# Web Protocol Performance Benchmark

REST vs WebSocket vs SSE vs gRPC 성능 비교 도구

## 프로젝트 구조

```
web-benchmark/
├── server/
│   ├── index.js          ← 4개 프로토콜 서버 (포트별)
│   └── proto/
│       └── service.proto ← gRPC 스키마 정의
├── client/
│   └── benchmark.js      ← 성능 테스트 클라이언트
├── package.json
└── README.md
```

## 서버 포트

| 프로토콜  | 포트  | 엔드포인트               |
|-----------|-------|--------------------------|
| REST      | 3001  | GET /ping, POST /echo    |
| WebSocket | 3002  | ws://localhost:3002      |
| SSE       | 3003  | GET /ping, GET /stream   |
| gRPC      | 3004  | BenchmarkService.Ping    |

## 실행 방법

```bash
# 1. 의존성 설치
npm install

# 2. 서버 시작 (터미널 1)
npm run server

# 3. 벤치마크 실행 (터미널 2)
npm run benchmark
```

## 측정 항목

### Latency Test (순차 요청)
- 요청 1개를 보내고 응답을 받을 때까지의 시간
- 지표: avg, min, max, P50, P95, P99 (ms)

### Throughput Test (동시 요청)
- N개의 요청을 동시에 처리
- 지표: Req/sec (초당 처리 요청 수)

## 설정 변경

`client/benchmark.js` 상단의 CONFIG 객체를 수정하면 됩니다:

```js
const CONFIG = {
  LATENCY_ITERATIONS: 500,  // 순차 요청 수
  CONCURRENCY: 50,          // 동시 요청 수
  THROUGHPUT_TOTAL: 1000,   // throughput 총 요청 수
  WARMUP: 20,               // 워밍업 횟수 (통계 제외)
};
```

## 각 프로토콜 특성 요약

| 프로토콜  | 연결방식     | 방향         | 주요 장점                  |
|-----------|-------------|--------------|---------------------------|
| REST      | 요청마다 연결 | 양방향       | 범용성, 캐싱               |
| WebSocket | 영속적 연결   | 양방향       | 낮은 latency, 실시간       |
| SSE       | 영속적 연결   | 서버→클라이언트 | 단순 구현, HTTP 기반      |
| gRPC      | HTTP/2 멀티플렉싱 | 양방향  | 바이너리, 타입 안전, 고성능 |

## 환경 요구사항

- Node.js 18+
- npm 8+
