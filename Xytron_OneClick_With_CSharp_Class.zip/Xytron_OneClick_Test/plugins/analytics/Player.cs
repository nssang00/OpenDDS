// Class plugin authoring example: just annotate the class with [Export].
// Supported public constructor, instance methods, and properties are found
// by Xytron.Managed SDK using Reflection. No manual bridge code is needed.
using Xytron;

namespace AnalyticsPlugin;

[Export]
public sealed class Player
{
    public Player(string name) => Name = name;

    public string Name { get; }         // read-only -> JS wrapper getName()
    public long Hp { get; set; } = 100; // read/write -> getHp(), setHp()
    public double X { get; private set; }
    public double Y { get; private set; }

    public void Move(double x, double y)
    {
        X = x;
        Y = y;
    }

    public void Attack() => Hp -= 10;

    public string Describe() => $"{Name} (HP={Hp})";

    private void Secret() { }           // private: not exposed
}
