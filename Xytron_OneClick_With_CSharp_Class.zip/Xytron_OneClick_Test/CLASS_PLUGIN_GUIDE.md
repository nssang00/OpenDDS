# Xytron C# 클래스 플러그인 테스트

> 기존 `Xytron_OneClick_CSharp_Load_Fix.zip` 기반. 사용자에게는 `[Export]` 어노테이션만 필요합니다. 테스트 코드와 내부 SDK를 분리했습니다.

## 1. 사용자 작성 코드: `plugins/analytics/Player.cs`

```csharp
using Xytron;

namespace AnalyticsPlugin;

[Export]
public sealed class Player
{
    public Player(string name) => Name = name;

    public string Name { get; }              // 읽기 전용
    public long Hp { get; set; } = 100;       // 읽기/쓰기
    public double X { get; private set; }    // 읽기 전용으로 노출
    public double Y { get; private set; }

    public void Move(double x, double y) { X = x; Y = y; }
    public void Attack() => Hp -= 10;
    public string Describe() => $"{Name} (HP={Hp})";
}
```

`[Export]`가 클래스에 붙으면 지원되는 **public 생성자, public 인스턴스 메서드 및 프로퍼티**를 SDK에서 Reflection으로 자동 등록합니다. 별도 Reflection / `UnmanagedCallersOnly` / 네이티브 브리지 작성은 필요 없습니다.

기존 정적 함수 `[Export]` 방식(`Plugin.cs`)도 그대로 동작합니다.

## 2. 자동 등록되는 호출 이름 (내부 Registry)

| C# 구성요소 | Registry 이름 | 인자 예시 / 반환 |
|---|---|---|
| `Player(string name)` | `Player.new` | `(name)` → `int64` 객체 핸들 |
| `Player.Move(double,double)` | `Player.move` | `(handle,x,y)` → `void` |
| `Player.Attack()` | `Player.attack` | `(handle)` → `void` |
| `Player.Describe()` | `Player.describe` | `(handle)` → `string` |
| `Player.Name { get; }` | `Player.getName` | `(handle)` → `string` |
| `Player.Hp { get; set; }` | `Player.getHp`, `Player.setHp` | `(handle)`, `(handle,hp)` |
| `Player.X { get; private set; }` | `Player.getX` | `(handle)` → `double` |
| 객체 삭제 | `Player.dispose` | `(handle)` → `void` |

`Player.new` 등은 **내부 RPC 호출 이름**으로, 개발자가 작성해야 하는 C# 메서드가 아닙니다. 객체 핸들은 C# SDK에서 보관하며 해당 호스트 프로세스의 수명 동안에만 유효합니다.

## 3. JavaScript 클래스 사용 예시

```js
import { Player } from 'analytics';

const player = await Player.create('Xytron');
await player.move(10, 20);
await player.setHp(80);
await player.attack();
console.log(await player.getHp());  // 70
console.log(await player.getName());
await player.dispose();
```

실제 파일: `js/class_example.mjs`. 개별 실행 시 종료 처리를 위해 `closeClassSession()`을 사용합니다.

**중요한 구현 구분:** 이 원클릭 예제의 JS 클래스 facade(`node_modules/analytics/index.mjs`)는 테스트용 수동 래퍼이며, 향후 Xytron CLI가 자동 생성할 대상입니다. 또한 JS에서 `new Player()`가 아니라 `await Player.create()`를 사용합니다. JS↔Core 호출이 비동기이고 원격 객체 생성에 시간이 걸리기 때문입니다. 프로퍼티도 직접 `player.hp` 형태가 아닌 `getHp()` / `setHp()`로 노출합니다.

## 4. 실제 호출 경로

```text
JavaScript Player.create('Xytron')
    ↓ [Node 테스트용 비동기 프로세스 세션]
C++ host --session (계속 실행)
    ↓ PluginManager → Module Registry
.NET Bridge.Invoke('Player.new')
    ↓ Reflection ConstructorInfo.Invoke
C# new Player('Xytron') → 객체 핸들 반환

JavaScript player.move(10,20)
    ↓ 동일한 C++ host 세션
.NET Bridge.Invoke('Player.move', handle, 10, 20)
    ↓ Reflection MethodInfo.Invoke
C# player.Move(10,20)
```

기존 함수 테스트의 `execFileSync`는 호출할 때마다 C++ 호스트가 재시작되어 객체를 보관할 수 없었습니다. 클래스 호출은 **하나의 C++ 호스트 프로세스를 유지**하는 `--session` 경로를 추가했습니다. 이 세션은 데모용 탭 구분 IPC이며 상용 WebView/ES Module 로더가 아닙니다.

## 5. 원클릭 테스트

### Windows

`RUN_WINDOWS.bat` 더블클릭. CMake/MSVC/Python/.NET 8 SDK가 필요하며, Node.js가 있으면 JS 클래스 세션 테스트까지 실행합니다.

### Linux

```bash
bash RUN_LINUX.sh
```

원클릭은 먼저 C++/Python을 빌드하고 검사합니다. `.NET SDK`가 있으면 C# 프로젝트도 빌드하여 정적 함수 + 클래스 생성/호출/프로퍼티/다중 객체/삭제까지 검사합니다. Node.js가 있으면 JS 클래스 facade 테스트도 수행합니다.

개별 JS 클래스 예제 실행:

```bash
node js/class_example.mjs
```

### 현재 버전의 제한

- C#은 **지원되는 공개 인스턴스 멤버**를 자동 노출합니다. 접근이 private인 멤버는 노출하지 않습니다.
- 기본 예제에선 클래스당 지원되는 public 생성자 하나, 오버로드 없는 메서드, `int`, `long`, `float`, `double`, `bool`, `string`, `void`만 지원합니다.
- 속성 getter/setter 및 메서드 반환에 객체 그래프, List, async Task, delegate는 지원하지 않습니다.
- 객체 핸들은 프로세스 간 공유할 수 없습니다. 핸들 수명과 동시성/GC 정책은 실제 SDK에서 더 정교하게 설계해야 합니다.
- 개발자가 작성하는 코드는 `Player.cs` 수준으로 유지하지만, 현재 JS facade는 **자동 생성되지 않습니다**.
- 이 패키지는 **Linux 환경에서 C++/Python/Node 기본 경로만 실행 검증**했습니다. .NET SDK가 없어 C# 클래스 Reflection 실행과 Windows 실행은 아직 검증하지 못했습니다.
