// Xytron runtime-owned bridge. Plugin authors should NOT copy or edit this file.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Loader;
using System.Text;

namespace Xytron;

[StructLayout(LayoutKind.Sequential)]
public unsafe struct NativeValue
{
    public int Tag;
    public int Reserved;
    public long Int64;
    public double Float64;
    public byte* Text;
}

public static unsafe class Bridge
{
    private sealed class PluginLoadContext : AssemblyLoadContext
    {
        private readonly AssemblyDependencyResolver resolver;
        private readonly string directory;
        private readonly Assembly sdkAssembly = typeof(ExportAttribute).Assembly;

        public PluginLoadContext(string pluginPath) : base(isCollectible: false)
        {
            resolver = new AssemblyDependencyResolver(pluginPath);
            directory = System.IO.Path.GetDirectoryName(pluginPath)!;
        }

        protected override Assembly? Load(AssemblyName name)
        {
            // Sharing the SDK assembly is essential: [Export] must have the same
            // runtime type identity as the Bridge's ExportAttribute.
            if (string.Equals(name.Name, sdkAssembly.GetName().Name,
                              StringComparison.OrdinalIgnoreCase))
                return sdkAssembly;

            string? path = resolver.ResolveAssemblyToPath(name);
            if (path is null && name.Name is not null)
            {
                string candidate = System.IO.Path.Combine(directory, name.Name + ".dll");
                if (System.IO.File.Exists(candidate)) path = candidate;
            }
            return path is null ? null : LoadFromAssemblyPath(path);
        }

        protected override IntPtr LoadUnmanagedDll(string name)
        {
            string? path = resolver.ResolveUnmanagedDllToPath(name);
            return path is null ? IntPtr.Zero : LoadUnmanagedDllFromPath(path);
        }
    }

    private sealed class BoundCall
    {
        public Type[] Parameters { get; init; } = Array.Empty<Type>();
        public Func<object?[], object?> Handler { get; init; } = null!;
    }

    private sealed class PluginBindings
    {
        public PluginLoadContext Context { get; init; } = null!;
        public Dictionary<string, BoundCall> Functions { get; } = new(StringComparer.Ordinal);
        public List<string> Names { get; } = new();
        public Dictionary<long, object> Objects { get; } = new();
        public long NextObjectId = 1;
    }

    private static readonly object Gate = new();
    private static readonly Dictionary<int, PluginBindings> Modules = new();
    private static int nextId = 1;

    private static string LowerCamel(string name)
        => name.Length == 0 ? name : char.ToLowerInvariant(name[0]) + name[1..];

    private static string ExportName(string name, ExportAttribute? attr)
        => string.IsNullOrWhiteSpace(attr?.Name) ? LowerCamel(name) : attr!.Name!;

    private static bool IsSupported(Type t, bool returnType = false)
        => (returnType && t == typeof(void)) || t == typeof(int) || t == typeof(long)
           || t == typeof(float) || t == typeof(double) || t == typeof(bool)
           || t == typeof(string);

    private static bool SupportedParameters(ParameterInfo[] ps)
        => ps.All(p => !p.IsOut && !p.ParameterType.IsByRef &&
                       !p.IsOptional && IsSupported(p.ParameterType));

    private static void Bind(PluginBindings bindings, string name, Type[] parameters,
                             Func<object?[], object?> handler)
    {
        if (!bindings.Functions.TryAdd(name, new BoundCall { Parameters = parameters, Handler = handler }))
            throw new InvalidOperationException($"Duplicate exported name: {name} (method overloads are not supported)");
        bindings.Names.Add(name);
    }

    private static object RequireObject(PluginBindings bindings, long handle, Type requiredType)
    {
        lock (bindings.Objects)
        {
            if (!bindings.Objects.TryGetValue(handle, out var obj))
                throw new InvalidOperationException($"Invalid or disposed object handle: {handle}");
            if (!requiredType.IsInstanceOfType(obj))
                throw new InvalidOperationException($"Object handle {handle} is not a {requiredType.Name}");
            return obj;
        }
    }

    private static void RegisterClass(PluginBindings bindings, Type type, ExportAttribute attr)
    {
        string className = string.IsNullOrWhiteSpace(attr.Name) ? type.Name : attr.Name!;
        if (!type.IsClass || type.IsAbstract || type.ContainsGenericParameters)
            throw new NotSupportedException($"[Export] class must be concrete and non-generic: {type}");
        const BindingFlags flags = BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly;
        var constructors = type.GetConstructors(BindingFlags.Public | BindingFlags.Instance)
                               .Where(c => SupportedParameters(c.GetParameters())).ToArray();
        if (constructors.Length != 1)
            throw new NotSupportedException($"{className} must have exactly one supported public constructor in this demo");
        var constructor = constructors[0];
        Bind(bindings, className + ".new", constructor.GetParameters().Select(p => p.ParameterType).ToArray(),
            values =>
            {
                object obj = constructor.Invoke(values);
                lock (bindings.Objects)
                {
                    long handle = bindings.NextObjectId++;
                    bindings.Objects.Add(handle, obj);
                    return handle;
                }
            });

        Bind(bindings, className + ".dispose", new[] { typeof(long) }, values =>
        {
            long handle = (long)values[0]!;
            lock (bindings.Objects)
            {
                if (!bindings.Objects.TryGetValue(handle, out var obj) || !type.IsInstanceOfType(obj))
                    throw new InvalidOperationException($"Invalid or disposed {className} handle: {handle}");
                // Demo: only managed state is removed. IDisposable is deliberately not
                // invoked implicitly; production SDK needs an ownership policy.
                bindings.Objects.Remove(handle);
            }
            return null;
        });

        foreach (var method in type.GetMethods(flags))
        {
            if (method.IsSpecialName || method.ContainsGenericParameters || method.ReturnType.IsByRef)
                continue;
            var parameters = method.GetParameters();
            if (!SupportedParameters(parameters) || !IsSupported(method.ReturnType, returnType: true))
                continue;
            string methodName = ExportName(method.Name, method.GetCustomAttribute<ExportAttribute>());
            var types = new[] { typeof(long) }.Concat(parameters.Select(p => p.ParameterType)).ToArray();
            Bind(bindings, className + "." + methodName, types, values =>
            {
                object obj = RequireObject(bindings, (long)values[0]!, type);
                return method.Invoke(obj, values.Skip(1).ToArray());
            });
        }

        foreach (var property in type.GetProperties(flags))
        {
            if (property.GetIndexParameters().Length != 0 || !IsSupported(property.PropertyType)) continue;
            string propertyName = property.Name;
            if (property.GetMethod?.IsPublic == true)
            {
                var get = property.GetMethod;
                Bind(bindings, className + ".get" + propertyName, new[] { typeof(long) },
                    values => get.Invoke(RequireObject(bindings, (long)values[0]!, type), null));
            }
            if (property.SetMethod?.IsPublic == true)
            {
                var set = property.SetMethod;
                Bind(bindings, className + ".set" + propertyName, new[] { typeof(long), property.PropertyType },
                    values =>
                    {
                        set.Invoke(RequireObject(bindings, (long)values[0]!, type), new[] { values[1] });
                        return null;
                    });
            }
        }
    }

    // Returned module ID is positive; -1 indicates error.
    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Load(byte* assemblyPath)
    {
        try
        {
            string? path = Marshal.PtrToStringUTF8((IntPtr)assemblyPath);
            if (string.IsNullOrWhiteSpace(path)) return -1;
            string fullPath = System.IO.Path.GetFullPath(path);
            if (!System.IO.File.Exists(fullPath))
                throw new System.IO.FileNotFoundException("C# plugin assembly is missing", fullPath);
            var context = new PluginLoadContext(fullPath);
            var assembly = context.LoadFromAssemblyPath(fullPath);
            var bindings = new PluginBindings { Context = context };
            foreach (var type in assembly.GetTypes())
            {
                foreach (var method in type.GetMethods(BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly))
                {
                    var export = method.GetCustomAttribute<ExportAttribute>();
                    if (export == null) continue;
                    if (method.ContainsGenericParameters || method.ReturnType.IsByRef ||
                        !SupportedParameters(method.GetParameters()) || !IsSupported(method.ReturnType, returnType: true))
                        throw new NotSupportedException($"Unsupported export signature: {method}");
                    string name = ExportName(method.Name, export);
                    Bind(bindings, name, method.GetParameters().Select(p => p.ParameterType).ToArray(),
                        values => method.Invoke(null, values));
                }
                var classExport = type.GetCustomAttribute<ExportAttribute>();
                if (classExport != null) RegisterClass(bindings, type, classExport);
            }
            if (bindings.Names.Count == 0)
                throw new InvalidOperationException($"No [Export] methods or classes found in {path}");
            bindings.Names.Sort(StringComparer.Ordinal);
            lock (Gate)
            {
                int id = nextId++;
                Modules.Add(id, bindings);
                return id;
            }
        }
        catch (ReflectionTypeLoadException e)
        {
            Console.Error.WriteLine("[xytron .NET load] " + e);
            foreach (Exception? cause in e.LoaderExceptions)
                if (cause != null) Console.Error.WriteLine("  [dependency] " + cause);
            return -1;
        }
        catch (Exception e)
        {
            Console.Error.WriteLine("[xytron .NET load] " + e);
            return -1;
        }
    }

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Count(int moduleId)
    {
        lock (Gate) return Modules.TryGetValue(moduleId, out var module) ? module.Names.Count : -1;
    }

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Name(int moduleId, int index, byte* buffer, int capacity)
    {
        if (buffer == null || capacity < 1) return -1;
        string name;
        lock (Gate)
        {
            if (!Modules.TryGetValue(moduleId, out var module) || index < 0 || index >= module.Names.Count) return -1;
            name = module.Names[index];
        }
        byte[] utf8 = Encoding.UTF8.GetBytes(name);
        if (utf8.Length + 1 > capacity) return -2;
        for (int i = 0; i < utf8.Length; i++) buffer[i] = utf8[i];
        buffer[utf8.Length] = 0;
        return 0;
    }

    private static object? FromNative(NativeValue value, Type target)
    {
        if (target == typeof(long) && value.Tag == 1) return value.Int64;
        if (target == typeof(int) && value.Tag == 1) return checked((int)value.Int64);
        if (target == typeof(double) && value.Tag == 2) return value.Float64;
        if (target == typeof(float) && value.Tag == 2) return checked((float)value.Float64);
        if (target == typeof(bool) && value.Tag == 3) return value.Int64 != 0;
        if (target == typeof(string) && value.Tag == 4)
            return Marshal.PtrToStringUTF8((IntPtr)value.Text);
        throw new ArgumentException($"Cannot convert ABI tag {value.Tag} to {target.Name}");
    }

    private static NativeValue ToNative(object? result)
    {
        var value = new NativeValue();
        switch (result)
        {
            case null: value.Tag = 0; break;
            case int n: value.Tag = 1; value.Int64 = n; break;
            case long n: value.Tag = 1; value.Int64 = n; break;
            case float n: value.Tag = 2; value.Float64 = n; break;
            case double n: value.Tag = 2; value.Float64 = n; break;
            case bool n: value.Tag = 3; value.Int64 = n ? 1 : 0; break;
            case string n:
                value.Tag = 4;
                value.Text = (byte*)Marshal.StringToCoTaskMemUTF8(n);
                break;
            default: throw new NotSupportedException($"Unsupported return type: {result.GetType().Name}");
        }
        return value;
    }

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Invoke(int moduleId, byte* functionName, NativeValue* args, int count, NativeValue* result)
    {
        try
        {
            if (result == null || count < 0 || (count != 0 && args == null)) return 1;
            string? name = Marshal.PtrToStringUTF8((IntPtr)functionName);
            BoundCall? bound;
            lock (Gate)
            {
                if (name == null || !Modules.TryGetValue(moduleId, out var module) ||
                    !module.Functions.TryGetValue(name, out bound)) return 1;
            }
            if (bound.Parameters.Length != count) return 2;
            var values = new object?[count];
            for (int i = 0; i < count; i++) values[i] = FromNative(args[i], bound.Parameters[i]);
            *result = ToNative(bound.Handler(values));
            return 0;
        }
        catch (Exception e)
        {
            Console.Error.WriteLine("[xytron .NET invoke] " + e);
            return 3;
        }
    }

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static void FreeString(byte* text)
    {
        if (text != null) Marshal.FreeCoTaskMem((IntPtr)text);
    }
}
