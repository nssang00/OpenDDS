using System;

namespace Xytron;

/// <summary>
/// Mark a public static method or concrete class for export.
/// For an exported class, one supported public constructor plus supported
/// public instance methods and properties are auto-registered.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false, Inherited = false)]
public sealed class ExportAttribute : Attribute
{
    public string? Name { get; }
    public ExportAttribute() { }
    public ExportAttribute(string name) => Name = name;
}
