# Xytron 원클릭 테스트 상태 — C# [Export] 클래스 바인딩 추가

## 이번 클래스 바인딩 추가

- **사용자 코드:** `plugins/analytics/Player.cs`에 `[Export]` 클래스, 생성자, `Move`/`Attack`/`Describe`, `Name`/`Hp`/`X`/`Y` 프로퍼티 예제.
- **SDK 코드:** `ExportAttribute`를 Class/Method 대상으로 확장. `Bridge.cs`가 Reflection으로 공개 생성자·인스턴스 메서드·프로퍼티를 Registry 함수로 등록하고 객체를 핸들로 관리.
- **C++ 테스트:** 생성자, 메서드, getter/setter, 2개 객체 독립성 및 dispose 후 접근 거부 검사.
- **JS 테스트:** Node subprocess마다 C++을 재실행하던 함수 프록시와 달리 클래스용 `--session` IPC를 추가해 호스트 프로세스를 유지. `js/class_example.mjs` 단독 예제 포함.

## 기존 변경

- **플러그인 사용자 코드:** `plugins/analytics/Plugin.cs`는 `[Export]` 함수만 포함합니다.
- **SDK 내부:** `sdk/dotnet/Xytron.Managed/ExportAttribute.cs`, `Bridge.cs`에 Reflection, hostfxr용 콜백, 타입/문자열 변환, 예외 처리를 이동했습니다.
- **Core 연결:** `src/core.cpp`는 SDK `Xytron.Managed.dll`의 `Load / Count / Name / Invoke / FreeString` 함수를 가져옵니다.
- **테스트 확대:** C# 함수 등록·호출 외에 string 반환, `[Export("subtract")]` 별칭도 테스트합니다.

## 실제 실행 검증

- Linux: C++ + CPython + JavaScript 기본 smoke test — 아래 실행 로그 참조.
- .NET Reflection 및 SDK 브리지: **이 환경에 dotnet 실행 도구/SDK가 없어 실행 검증하지 못함.**
- Windows: **검증하지 못함.**

아래 `RUN_WINDOWS.bat` 또는 `RUN_LINUX.sh`가 현재 PC에 .NET SDK가 있으면 C# SDK와 플러그인을 빌드하고 전체 테스트를 진행합니다. SDK가 없으면 C#은 명시적으로 `[SKIP]` 처리합니다.

## 남은 작업

- C# 클래스의 오버로드, 복합 타입, 비동기 메서드, 객체 소유권 정책 고도화
- 고급 오버로드/nullable/복합 타입/비동기 메서드
- .NET AssemblyLoadContext 격리, 프로세스 종료/언로드, 런타임 버전 정책 강화
- 실제 Xytron 내부 ES Module Loader (현재 JS 테스트는 Node CLI 프록시)

## 2026-10 수정: Xytron.Managed.FileNotFoundException

- 원인 가능성: `hostfxr`가 SDK를 격리 컨텍스트로 로드하는 동안, 기존 Bridge가 플러그인을 기본 컨텍스트로 로드함.
- `Bridge.cs`: 플러그인별 `AssemblyDependencyResolver` + SDK 공통 어셈블리 반환으로 변경.
- 사용자 `[Export]` API 불변.
- 이 컨테이너에는 `dotnet` 실행 파일이 없어 C# 코드는 **정적 점검만 완료**, Windows/.NET 테스트는 미검증.

## 이번 패키지에서 다시 검증한 범위

- Linux CMake C++ build 및 C++/Python 테스트: **통과**.
- Node.js의 C++/Python named-import 기본 smoke test: **통과**.
- C++ `--session`의 여러 명령 처리: **통과** (native + Python).
- .NET 8 SDK가 환경에 없어 실제 C# 정적 함수/클래스 바인딩 실행: **미검증**.
- Windows 원클릭 실행: **미검증**.
