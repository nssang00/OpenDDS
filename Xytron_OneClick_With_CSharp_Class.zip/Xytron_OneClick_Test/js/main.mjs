import { add as nativeAdd, multiply as nativeMultiply, greet as nativeGreet } from 'game';
import { add as pythonAdd, greet } from 'automation';
import { add as dotnetAdd, multiply as dotnetMultiply, isPositive, greet as dotnetGreet, subtract, Player } from 'analytics';
function check(test, description) {
  if(!test)throw new Error('FAIL ' + description);
  console.log('[PASS] JS import: ' + description);
}
check(nativeAdd(10,20)===30, 'C++ native add(10,20) = 30');
check(nativeMultiply(2.5,3)===7.5, 'C++ native multiply(2.5,3) = 7.5');
check(nativeGreet('Xytron')==='Hello from C++, Xytron!', 'C++ native string return');
check(pythonAdd(7,8)===15, 'Python add(7,8) = 15');
check(greet('Xytron')==='Hello, Xytron!', 'Python greet string roundtrip');
check(dotnetAdd(5,6)===11, 'C# add(5,6) = 11');
check(dotnetMultiply(2,4)===8, 'C# multiply(2,4) = 8');
check(isPositive(-3)===false, 'C# bool return');
check(dotnetGreet('Xytron')==='Hello from C#, Xytron!', 'C# string return');
check(subtract(10,7)===3, 'C# [Export] alias');
console.log('JS IMPORT SMOKE TEST PASSED');

// Class test uses ONE persistent native host (unlike the function-only shim).
import { closeClassSession } from '../node_modules/xytron_session.mjs';
try {
  const player = await Player.create('Ada');
  const other = await Player.create('Lin');
  check(await player.getName() === 'Ada', 'C# [Export] class readonly property');
  await player.move(1.25, 2.5);
  check(await player.getX() === 1.25 && await player.getY() === 2.5,
        'C# class instance method + stateful properties');
  await player.setHp(80);
  await player.attack();
  check(await player.getHp() === 70 && await other.getHp() === 100,
        'C# class setter/attack and instance isolation');
  check(await player.describe() === 'Ada (HP=70)', 'C# class method string return');
  await player.dispose();
  let rejected = false;
  try { await player.getHp(); } catch { rejected = true; }
  check(rejected, 'C# disposed handle rejected');
  await other.dispose();
  console.log('C# CLASS SESSION TEST PASSED');
} finally {
  await closeClassSession();
}
