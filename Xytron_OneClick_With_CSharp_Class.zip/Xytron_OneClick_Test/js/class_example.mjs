// Standalone C# class plugin demo. Run after RUN_WINDOWS.bat / RUN_LINUX.sh
// has built the C++ host and analytics managed plugin.
import { Player } from 'analytics';
import { closeClassSession } from '../node_modules/xytron_session.mjs';

try {
  const player = await Player.create('Xytron');
  console.log('Name:', await player.getName());
  console.log('HP:', await player.getHp());
  await player.move(10.5, 20.25);
  console.log('Position:', await player.getX(), await player.getY());
  await player.attack();
  console.log('After attack:', await player.describe());
  await player.setHp(55);
  console.log('After setHp:', await player.getHp());
  await player.dispose();
} finally {
  await closeClassSession();
}
