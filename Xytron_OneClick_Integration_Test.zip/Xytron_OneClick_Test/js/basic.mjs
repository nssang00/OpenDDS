import { add } from 'game';
import { greet } from 'automation';
if(add(10,20)!==30 || greet('Xytron')!=='Hello, Xytron!')
  throw new Error('JS basic test failed');
console.log('[PASS] JS imports: native + Python (C# not checked)');
