@echo off
setlocal EnableExtensions
cd /d "%~dp0\.."
echo === XYTRON ONE-CLICK TEST (Windows x64) ===
where cmake >nul 2>nul
if errorlevel 1 (
  echo [ERROR] CMake not found. Install CMake and Visual Studio 2022 C++ Build Tools.
  exit /b 1
)
where py >nul 2>nul
if errorlevel 1 (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [ERROR] Python development installation not found.
    exit /b 1
  )
)
cmake -S . -B build
if errorlevel 1 (
  echo [ERROR] Configuration failed. Verify MSVC x64 C++ tools and Python headers/libs.
  exit /b 1
)
cmake --build build --config Release --parallel 2
if errorlevel 1 exit /b 1
where dotnet >nul 2>nul
if errorlevel 1 goto basic

echo [INFO] .NET SDK detected: building C# plugin
dotnet build plugins\analytics\AnalyticsPlugin.csproj --configuration Release --output plugins\analytics\build
if errorlevel 1 exit /b 1
copy /Y plugins\analytics\AnalyticsPlugin.runtimeconfig.json plugins\analytics\build\ >nul
if errorlevel 1 exit /b 1
build\Release\xytron_test.exe
if errorlevel 1 (
  if exist build\xytron_test.exe (build\xytron_test.exe) else exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo [SKIP] Node.js missing: JS import smoke test
) else (
  node js\main.mjs
  if errorlevel 1 exit /b 1
)
echo [SUCCESS] C++ + Python + C# tests PASSED
exit /b 0

:basic
echo [SKIP] dotnet missing. Install .NET 8+ SDK for the C# test.
build\Release\xytron_test.exe --test-basic
if errorlevel 1 (
  if exist build\xytron_test.exe (build\xytron_test.exe --test-basic) else exit /b 1
)
where node >nul 2>nul
if errorlevel 1 (
  echo [SKIP] Node.js missing: JS import smoke test
) else (
  node js\basic.mjs
  if errorlevel 1 exit /b 1
)
echo [PARTIAL PASS] C++ + Python passed. C# NOT TESTED.
exit /b 0
