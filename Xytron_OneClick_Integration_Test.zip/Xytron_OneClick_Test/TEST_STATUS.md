# 실제 검증 기록 (2026-10-14)

## 통과한 테스트 — 이 대화의 Linux 환경

- 환경: Debian Linux x86-64, GCC 14.2.0, CMake 3.31.6, Python 3.13.5, Node.js 22.16.0
- 실행: `./RUN_LINUX.sh`
- `[PASS]` manifest 3개 발견
- `[PASS]` C++ `std::function` + `std::any` template invoker
- `[PASS]` C++ 네이티브 공유 라이브러리 동적 로딩 및 정수/실수/문자열 반환
- `[PASS]` Python 임베디드 런타임 호출 및 decorated 함수 발견/숨김 함수 제외
- `[PASS]` JS `import` 테스트용 Node 래퍼 (C++ + Python)

## 이 환경에서 검증하지 못한 테스트

- `[NOT RUN]` .NET 호스팅 및 Reflection: `dotnet` SDK/런타임 미설치
- `[NOT RUN]` Windows: Windows OS와 Visual Studio Build Tools 없음
- `[NOT IMPLEMENTED]` 실제 C++ Core 내부 JS 엔진·ES Module 커스텀 로더
- `[NOT IMPLEMENTED]` 클래스 생성자/프로퍼티/인스턴스 메서드 바인딩

**주의:** `RUN_WINDOWS.bat`의 C# 빌드·실행 경로는 제공했지만 이 환경에서 성공을 확인했다고 주장할 수 없습니다. 사용자의 PC에서 실행한 후 `test_results.txt`를 확인하세요.
