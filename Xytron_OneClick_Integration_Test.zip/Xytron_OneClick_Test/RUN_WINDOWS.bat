@echo off
cd /d "%~dp0"
echo Starting Xytron test... 
call scripts\run_windows_inner.bat > test_results.txt 2>&1
set "RESULT=%errorlevel%"
type test_results.txt
echo.
echo Test log: %cd%\test_results.txt
if not "%RESULT%"=="0" echo [FAILED] See errors above.
pause
exit /b %RESULT%
