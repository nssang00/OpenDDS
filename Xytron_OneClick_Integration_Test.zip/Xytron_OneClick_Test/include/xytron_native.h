#pragma once
#include <stddef.h>
#include <stdint.h>

#ifdef _WIN32
#  define XY_EXPORT extern "C" __declspec(dllexport)
#else
#  define XY_EXPORT extern "C" __attribute__((visibility("default")))
#endif

// Stable C layout. String pointers are borrowed during each call.
enum XyTag : int32_t { XY_VOID=0, XY_INT64=1, XY_DOUBLE=2, XY_BOOL=3, XY_STRING=4 };
struct XyValue {
    int32_t tag = XY_VOID;
    int32_t reserved = 0;
    int64_t i64 = 0;
    double f64 = 0;
    const char* text = nullptr;
};
using XyInvokeFn = int (*)(void* context, const XyValue* args, size_t count, XyValue* out);
struct XyHostApi {
    uint32_t abi_version;
    void* context;
    int (*register_function)(void* context, const char* name, XyInvokeFn fn, void* fn_context);
};
using XyRegisterFn = int (*)(const XyHostApi*);
