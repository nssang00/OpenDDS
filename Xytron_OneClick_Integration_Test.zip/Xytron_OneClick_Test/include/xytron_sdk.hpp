#pragma once
#include "xytron_native.h"
#include <memory>
#include <stdexcept>
#include <string>
#include <tuple>
#include <type_traits>
#include <utility>
#include <vector>

namespace xytron {
namespace detail {
    template<class T> using Plain = std::decay_t<T>;

    template<class T> Plain<T> read(const XyValue& value) {
        using U=Plain<T>;
        if constexpr(std::is_same_v<U,std::string>) {
            if(value.tag!=XY_STRING)throw std::runtime_error("expected string");
            return std::string(value.text?value.text:"");
        }else if constexpr(std::is_same_v<U,bool>) {
            if(value.tag!=XY_BOOL)throw std::runtime_error("expected bool");
            return value.i64!=0;
        }else if constexpr(std::is_integral_v<U>) {
            if(value.tag!=XY_INT64)throw std::runtime_error("expected int64");
            return static_cast<U>(value.i64);
        }else if constexpr(std::is_floating_point_v<U>) {
            if(value.tag!=XY_DOUBLE)throw std::runtime_error("expected double");
            return static_cast<U>(value.f64);
        }else {
            static_assert(!sizeof(U),"unsupported parameter type");
        }
    }
    template<class T> XyValue write(T&& value) {
        using U=Plain<T>;
        XyValue result{};
        if constexpr(std::is_same_v<U,std::string>) {
            static thread_local std::string buffer;
            buffer=std::forward<T>(value); // borrowed until the next call on this thread
            result.tag=XY_STRING;result.text=buffer.c_str();
        }else if constexpr(std::is_same_v<U,bool>) {
            result.tag=XY_BOOL;result.i64=value;
        }else if constexpr(std::is_integral_v<U>) {
            result.tag=XY_INT64;result.i64=static_cast<int64_t>(value);
        }else if constexpr(std::is_floating_point_v<U>) {
            result.tag=XY_DOUBLE;result.f64=static_cast<double>(value);
        }else {
            static_assert(!sizeof(U),"unsupported return type");
        }
        return result;
    }
    struct BaseHolder {virtual ~BaseHolder()=default;};
    template<class Signature> struct Holder;
    template<class R,class... A> struct Holder<R(*)(A...)>:BaseHolder {
        R(*fn)(A...);
        explicit Holder(R(*function)(A...)):fn(function){}
        template<size_t... I>
        int call(const XyValue* args, XyValue* out, std::index_sequence<I...>) {
            if constexpr(std::is_void_v<R>) {
                fn(read<A>(args[I])...);*out=XyValue{};
            }else {
                *out=write(fn(read<A>(args[I])...));
            }
            return 0;
        }
        static int thunk(void* ptr, const XyValue* args, size_t count, XyValue* out){
            if(!out || count!=sizeof...(A))return 1;
            try {return static_cast<Holder*>(ptr)->call(args,out,std::index_sequence_for<A...>{});}
            catch(...){return 2;} // Never pass C++ exceptions across the DLL boundary.
        }
    };
    inline std::vector<std::unique_ptr<BaseHolder>>& storage(){
        static std::vector<std::unique_ptr<BaseHolder>> objects;
        return objects;
    }
}
class ModuleBinder {
    const XyHostApi* api_;
public:
    explicit ModuleBinder(const XyHostApi* api):api_(api){}
    template<class R, class... A>
    void function(const char* name,R(*fn)(A...)){
        using H=detail::Holder<R(*)(A...)>;
        auto h=std::make_unique<H>(fn);
        int rc=api_->register_function(api_->context,name,&H::thunk,h.get());
        if(rc!=0)throw std::runtime_error("cannot register plugin function");
        detail::storage().push_back(std::move(h));
    }
};
}

#define XYTRON_MODULE(m) \
    static void xytron_register_impl(::xytron::ModuleBinder& m); \
    XY_EXPORT int xytron_plugin_register(const XyHostApi* api) { \
        if(!api || api->abi_version!=1 || !api->register_function)return 1; \
        try {::xytron::ModuleBinder m(api);xytron_register_impl(m);return 0;} \
        catch(...){return 2;} \
    } \
    static void xytron_register_impl(::xytron::ModuleBinder& m)
