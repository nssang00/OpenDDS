#!/usr/bin/env bash
cd "$(dirname "$0")" || exit 1
bash scripts/run_linux_inner.sh 2>&1 | tee test_results.txt
exit "${PIPESTATUS[0]}"
