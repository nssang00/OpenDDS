using System;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

namespace AnalyticsPlugin;

[AttributeUsage(AttributeTargets.Method)]
public sealed class ExportAttribute : Attribute { }

public static class Analytics {
    [Export] public static long Add(long a, long b) => a+b;
    [Export] public static double Multiply(double a, double b) => a*b;
    [Export] public static bool IsPositive(long number) => number > 0;
    public static long Hidden(long a) => a;
}

[StructLayout(LayoutKind.Sequential)]
public unsafe struct XyValue {
    public int tag;
    public int reserved;
    public long i64;
    public double f64;
    public byte* text;
}

public static unsafe class Bridge {
    private static readonly MethodInfo[] Exports = typeof(Analytics).Assembly
        .GetTypes().SelectMany(t => t.GetMethods(BindingFlags.Public | BindingFlags.Static))
        .Where(m => m.GetCustomAttribute<ExportAttribute>() != null)
        .ToArray();

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Count() => Exports.Length;

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Name(int index, byte* buffer, int capacity) {
        if (index < 0 || index >= Exports.Length || buffer == null || capacity <= 0) return -1;
        string n = Exports[index].Name;
        n = char.ToLowerInvariant(n[0]) + n.Substring(1);
        var bytes = System.Text.Encoding.UTF8.GetBytes(n);
        if (bytes.Length + 1 > capacity) return -2;
        for (int i=0;i<bytes.Length;i++) buffer[i]=bytes[i];
        buffer[bytes.Length]=0;
        return 0;
    }

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Invoke(byte* name, XyValue* args, int count, XyValue* result) {
        try {
            string? n = Marshal.PtrToStringUTF8((IntPtr)name);
            MethodInfo? method = Exports.FirstOrDefault(m =>
                string.Equals(char.ToLowerInvariant(m.Name[0])+m.Name.Substring(1), n, StringComparison.Ordinal));
            if (method == null || count != method.GetParameters().Length || result == null) return 1;
            var p = method.GetParameters();
            object[] values = new object[count];
            for(int i=0;i<count;i++) {
                Type t = p[i].ParameterType;
                if(t == typeof(long) && args[i].tag == 1) values[i] = args[i].i64;
                else if(t == typeof(double) && args[i].tag == 2) values[i] = args[i].f64;
                else if(t == typeof(bool) && args[i].tag == 3) values[i] = args[i].i64 != 0;
                else return 2;
            }
            object? ret = method.Invoke(null, values);
            *result = default;
            if(ret is long l) {result->tag=1;result->i64=l;}
            else if(ret is double d) {result->tag=2;result->f64=d;}
            else if(ret is bool b) {result->tag=3;result->i64=b ? 1 : 0;}
            else if(ret == null) result->tag=0;
            else return 3;
            return 0;
        } catch(Exception e) {
            Console.Error.WriteLine("[dotnet invoke error] " + e);
            return 4;
        }
    }
}
