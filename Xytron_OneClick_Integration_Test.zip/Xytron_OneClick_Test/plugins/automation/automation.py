# Demo equivalent to @xytron.export, without requiring a pip package.
def export(fn):
    fn.__xytron_export__ = True
    return fn

@export
def add(a: int, b: int) -> int:
    return a + b

@export
def greet(name: str) -> str:
    return f"Hello, {name}!"

@export
def double(x: float) -> float:
    return x * 2.0

# Should NOT be registered: discovered only when marked.
def internal_secret():
    return 99
