#include "xytron_sdk.hpp"
#include <cstdint>
#include <string>

static int64_t add(int64_t a,int64_t b){return a+b;}
static double multiply(double a,double b){return a*b;}
static std::string greet(std::string name){return "Hello from C++, " + name + "!";}

XYTRON_MODULE(m) {
    m.function("add", &add);
    m.function("multiply", &multiply);
    m.function("greet", &greet);
}
