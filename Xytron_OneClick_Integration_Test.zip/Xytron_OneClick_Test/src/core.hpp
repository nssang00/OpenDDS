#pragma once
#include <any>
#include <filesystem>
#include <functional>
#include <memory>
#include <string>
#include <unordered_map>
#include <vector>
#include <stdexcept>
#include <type_traits>
#include <utility>

using Value = std::any;
using Args = std::vector<Value>;
using Invoker = std::function<Value(const Args&)>;

class Module {
    std::unordered_map<std::string, Invoker> functions_;
public:
    void addInvoker(const std::string& name, Invoker invoker) {
        if (!functions_.emplace(name, std::move(invoker)).second)
            throw std::runtime_error("duplicate function: " + name);
    }
    template<class R, class... P>
    void function(const std::string& name, R(*fn)(P...)) {
        addInvoker(name, [fn](const Args& args) -> Value {
            if (args.size() != sizeof...(P)) throw std::runtime_error("argument count mismatch");
            return invoke(fn,args,std::index_sequence_for<P...>{});
        });
    }
    Value call(const std::string& name, const Args& args) const {
        auto it=functions_.find(name);
        if (it==functions_.end()) throw std::runtime_error("function not registered: " + name);
        return it->second(args);
    }
    bool contains(const std::string& name) const {return functions_.count(name) != 0;}
    size_t count() const {return functions_.size();}
private:
    template<class R, class... P, size_t... I>
    static Value invoke(R(*fn)(P...), const Args& args, std::index_sequence<I...>) {
        if constexpr(std::is_void_v<R>) {fn(std::any_cast<std::decay_t<P>>(args[I])...);return {};}
        else {return fn(std::any_cast<std::decay_t<P>>(args[I])...);}
    }
};

struct PluginManifest {
    std::string name, runtime;
    std::filesystem::path folder, entry;
};

class PluginManager {
    struct Item;
    std::unordered_map<std::string, std::unique_ptr<Item>> plugins_;
public:
    PluginManager();
    ~PluginManager();
    void discover(const std::filesystem::path& pluginsDir);
    Module& importModule(const std::string& name);
    size_t discoveredCount() const {return plugins_.size();}
};

std::string showValue(const Value& v);
std::string jsonValue(const Value& v);
