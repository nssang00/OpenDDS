#include "core.hpp"
#include <cmath>
#include <iostream>
#include <string>
#include <filesystem>
#include <stdexcept>

static void require(bool ok, const std::string& desc){
    if(!ok)throw std::runtime_error("assertion failed: "+desc);
    std::cout<<"[PASS] "<<desc<<"\n";
}
static Value parse(const std::string& s) {
    if(s.size()<2 || s[1]!=':')throw std::runtime_error("arguments must be prefixed i:/d:/b:/s:");
    auto body=s.substr(2);
    switch(s[0]){
    case 'i':return int64_t(std::stoll(body));
    case 'd':return std::stod(body);
    case 'b':return body=="true" || body=="1";
    case 's':return body;
    default:throw std::runtime_error("unknown arg prefix");
    }
}
static int64_t directAdd(int64_t a,int64_t b){return a+b;}

int main(int argc,char** argv){
    try {
        std::filesystem::path root=std::filesystem::current_path();
        PluginManager manager;
        manager.discover(root/"plugins");
        if(argc>=2 && std::string(argv[1])=="--call"){
            if(argc<4)throw std::runtime_error("usage: --call MODULE FN [i:10 d:2.5 s:hello b:true]");
            Args args;
            for(int i=4;i<argc;++i)args.push_back(parse(argv[i]));
            Value result=manager.importModule(argv[2]).call(argv[3],args);
            std::cout<<jsonValue(result)<<"\n";
            return 0;
        }
        if(argc>=2 && std::string(argv[1])=="--list"){
            std::cout<<"discovered plugins: "<<manager.discoveredCount()<<"\n";
            return 0;
        }
        require(manager.discoveredCount()==3,"manifest-only discovery: 3 plugins");
        Module templateModule;
        templateModule.function("sum", &directAdd);
        require(std::any_cast<int64_t>(templateModule.call("sum",{int64_t(1),int64_t(2)}))==3,
                "std::function + std::any template invoker");
        Module& game=manager.importModule("game");
        require(game.contains("add") && game.contains("multiply") && game.contains("greet"),"C++ DLL template-binder registered three functions");
        require(std::any_cast<int64_t>(game.call("add",{int64_t(10),int64_t(20)}))==30,"native add(10,20) = 30");
        require(std::abs(std::any_cast<double>(game.call("multiply",{2.5,3.0}))-7.5)<1e-12,"native multiply(2.5,3)=7.5");
        require(std::any_cast<std::string>(game.call("greet",{std::string("Xytron")})) == "Hello from C++, Xytron!",
                "native C ABI string return copied safely");
        Module& py=manager.importModule("automation");
        require(py.contains("add") && py.contains("greet") && !py.contains("internal_secret"),"Python @export introspection");
        require(std::any_cast<int64_t>(py.call("add",{int64_t(7),int64_t(8)}))==15,"python add(7,8)=15");
        require(std::any_cast<std::string>(py.call("greet",{std::string("Xytron")}))=="Hello, Xytron!","python greet string roundtrip");
        if(argc>=2 && std::string(argv[1])=="--test-basic") {
            std::cout<<"\nNATIVE + PYTHON PASSED (.NET not checked)\n";
            return 0;
        }
        Module& cs=manager.importModule("analytics");
        require(cs.contains("add") && cs.contains("multiply") && !cs.contains("hidden"),"C# [Export] Reflection registration");
        require(std::any_cast<int64_t>(cs.call("add",{int64_t(5),int64_t(6)}))==11,"C# add(5,6)=11");
        require(std::abs(std::any_cast<double>(cs.call("multiply",{2.0,4.0}))-8.0)<1e-12,"C# multiply(2,4)=8");
        require(std::any_cast<bool>(cs.call("isPositive",{int64_t(-3)}))==false,"C# bool return");
        std::cout<<"\nALL 3 LANGUAGES PASSED\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<"[FAIL] "<<e.what()<<"\n";return 1;}
}
