# Xytron: C++ / Python / C# 플러그인 원클릭 통합 테스트

> **테스트용 구현** — 원본 `Xytron_Plugin_System_Design.md`의 함수 등록·플러그인 지연 로딩·언어별 호출 흐름을 실제 코드로 재현합니다. 상용 SDK가 아니며 클래스/프로퍼티·프로덕션 ES Module Loader까지 완성한 패키지는 아닙니다.

## 1. 바로 실행

### Windows 10/11 x64

압축을 풀고 **`RUN_WINDOWS.bat` 더블클릭**. 완료 결과가 창과 `test_results.txt`에 남습니다.

사전 설치 필요:

1. **Visual Studio 2022 Build Tools** — Desktop development with C++ (MSVC x64)
2. **CMake** — PATH 등록
3. **Python 3.x x64** — 헤더 및 import library를 포함하는 일반 개발용 설치
4. **.NET 8 SDK** — C# 플러그인 빌드용; 실행 시에는 .NET 런타임만 사용
5. **Node.js 18+** — 선택 사항 (JS import 연동 테스트)

CMake가 Python 헤더·라이브러리를 찾지 못하면 Python x64 개발 설치와 `Python3_ROOT_DIR`를 확인하세요. 프로그램을 더블클릭하기 전에 해당 빌드 도구가 설치되어 있어야 합니다. SDK를 자동 설치하지는 않습니다.

### Linux x64

```bash
chmod +x RUN_LINUX.sh
./RUN_LINUX.sh
```

사전 설치: C++17 컴파일러, CMake, Python3 개발 헤더(`python3-dev` 등), 선택적으로 .NET 8 SDK, Node.js. Linux의 `RUN_LINUX.sh`는 즉시 CMake로 컴파일하고 동작을 검사합니다.

**.NET 8 SDK:** C# 원클릭 테스트에는 필요합니다. SDK가 이미 있는 PC에서는 C# 플러그인과 Xytron.Managed SDK를 함께 컴파일합니다. 최종 앱 배포에서는 SDK 없이 런타임만으로 실행할 수 있지만 런타임 제공과 패키징 구현은 별도 과제입니다.

**.NET SDK가 없는 경우:** 테스트 스크립트는 C++ + Python + 선택적인 Node 연동만 실행하고 C#을 `[SKIP]`으로 표시합니다. *전체 성공으로 표시하지 않습니다.* C#까지 검증하려면 SDK를 설치한 후 스크립트를 다시 실행하세요.

## 2. 시스템 구조

```text
JS import "game" / "automation" / "analytics"
    ↓  [데모: Node.js execFileSync으로 C++ 호출]
C++ Host (xytron_test)
    ├─ PluginManager: plugin.json 탐색 (코드 실행 없음)
    │    └─ importModule(name): 해당 런타임 필요 시 로드
    ├─ Module Registry
    │    using Value = std::any;
    │    using Args = std::vector<Value>;
    │    using Invoker = std::function<Value(const Args&)>;
    └─ Loader
         ├─ Native: dlopen / LoadLibrary → C ABI → 템플릿 Invoker
         ├─ Python: CPython C API → @export 함수 검색 → PyObject_Call
         └─ .NET: hostfxr + CoreCLR → Xytron.Managed SDK → [Export] Reflection → MethodInfo.Invoke
```

**Python 실행 시 `python.exe`를 실행하지 않습니다.** 호스트가 CPython 공유 라이브러리를 링크하여 동일 프로세스 내부에서 인터프리터를 초기화합니다. `dotnet.exe` 역시 C# **실행 시** 호출하지 않습니다. 단, 예제 C# 라이브러리 **빌드 시**에는 .NET SDK의 `dotnet build`를 사용합니다.

## 3. 핵심 API

C++ Core 내부의 공통 호출 타입 (`src/core.hpp`):

```cpp
using Value   = std::any;
using Args    = std::vector<Value>;
using Invoker = std::function<Value(const Args&)>;

Module module;
module.function("sum", &add);
Value result = module.call("sum", {int64_t(10), int64_t(20)});
```

C++ 네이티브 플러그인 (`src/game_plugin.cpp`) — 템플릿 바인딩은 `include/xytron_sdk.hpp`:

```cpp
int64_t add(int64_t a, int64_t b) { return a + b; }
XYTRON_MODULE(m) {
    m.function("add", &add);
}
```

Python (`plugins/automation/automation.py`):

```python
@export
def add(a: int, b: int) -> int:
    return a + b
```

이 데모에서 `@export`는 `__xytron_export__ = True`를 설정하는 로컬 함수입니다. 실 Xytron SDK에서는 `@xytron.export`로 바꿀 수 있습니다.

C# (`plugins/analytics/Plugin.cs`):

```csharp
using Xytron;

namespace AnalyticsPlugin;
public static class Analytics {
    [Export] public static long Add(long a, long b) => a + b;
    [Export] public static string Greet(string name) => $"Hello from C#, {name}!";
    [Export("subtract")] public static long Difference(long a, long b) => a - b;
}
```

**플러그인 개발자가 작성하는 것은 함수 + `[Export]`뿐입니다.** `[Export]` 속성과 `UnmanagedCallersOnly`, `NativeValue`, Reflection, native 호출 및 string 메모리 관리는 모두 `sdk/dotnet/Xytron.Managed/`에 포함됩니다. 새 C# 프로젝트 생성 시 `ProjectReference`를 Xytron CLI가 자동으로 추가한다는 설계이며, 이 테스트에서는 이미 `AnalyticsPlugin.csproj`에 설정돼 있습니다.

`[Export]` 없이 작성한 메서드는 숨겨지고, `[Export("alias")]`로 JS 이름을 지정할 수 있습니다. 지원 타입은 `int`, `long`, `float`, `double`, `bool`, `string` 및 `void`이며 JS 래퍼 데모의 인자 타입 코드는 수동으로 작성되어 있습니다. **C# 클래스/생성자/인스턴스 메서드 자동 바인딩은 아직 구현되지 않았습니다.**

## 4. 테스트 항목

| 검증 항목 | 기대 결과 |
|---|---|
| `plugin.json` 탐색 | 3개 발견, DLL/런타임 로드는 import 시 수행 |
| 템플릿+`std::any` Registry | `sum(1,2) → 3` |
| C++ 네이티브 DLL/SO | `add(10,20) → 30`, `multiply(2.5,3) → 7.5` |
| C++ 문자열 반환 | `greet("Xytron") → "Hello from C++, Xytron!"` |
| Python 함수 발견 | `@export`만 등록, `internal_secret` 미등록 |
| Python 함수 호출 | `add(7,8) → 15`, `greet("Xytron") → "Hello, Xytron!"` |
| C# Reflection | Xytron.Managed SDK가 `[Export]` 자동 등록, `Hidden` 미등록 |
| C# 호출 | `add(5,6) → 11`, `multiply(2,4) → 8`, `isPositive(-3) → false`, `greet` 문자열, `subtract` alias |
| JS named import 데모 | C++/Python/C# 함수 호출 후 결과 검증 (Node 설치 시) |

모든 런타임이 설치돼 있으면 C++ 호스트와 JS 검증이 함께 실행됩니다. JS에서 호출된 C++ 호스트는 각 함수 호출마다 새 프로세스로 시작하므로 성능·수명 테스트가 아닌 연동 smoke test입니다.

## 5. 개별 명령

Linux에서 빌드 후:

```bash
./build/xytron_test --list
./build/xytron_test --test-basic
./build/xytron_test --call game add i:10 i:20
./build/xytron_test --call game greet s:Xytron
./build/xytron_test --call automation add i:7 i:8
./build/xytron_test --call automation greet s:Xytron
./build/xytron_test --call analytics add i:5 i:6 # .NET 빌드/런타임 필요
node js/main.mjs                      # 모든 언어에 대한 JS 테스트
node js/basic.mjs                     # C++/Python JS 테스트
```

Windows 명령은 `build\\Release\\xytron_test.exe`입니다. 제네레이터에 따라 `build\\xytron_test.exe`일 수도 있습니다. `--call` 인자는 `i:`=64비트 정수, `d:`=double, `s:`=UTF-8 문자열, `b:`=bool 입니다. `--call`은 JSON 결과를 stdout으로 출력하고 오류를 stderr에 출력합니다.

## 6. 구성

```text
RUN_WINDOWS.bat                    # 더블클릭 진입점
RUN_LINUX.sh                      # Linux one-click 진입점
scripts/                          # 빌드 및 테스트 내부 스크립트
CMakeLists.txt
include/xytron_native.h           # Native DLL <-> Host C ABI
include/xytron_sdk.hpp            # XYTRON_MODULE + m.function 자동 어댑터
src/core.hpp                      # std::any + std::function Registry
src/core.cpp                      # PluginManager / Native / Python / hostfxr 로더
src/main.cpp                      # 테스트/CLI
src/game_plugin.cpp               # 네이티브 C++ 플러그인
plugins/game/plugin.json
plugins/automation/plugin.json
plugins/automation/automation.py
plugins/analytics/plugin.json
plugins/analytics/AnalyticsPlugin.csproj
sdk/dotnet/Xytron.Managed/           # 공통 C# SDK: [Export], Reflection, 네이티브 브리지
plugins/analytics/Plugin.cs            # 사용자 코드: [Export]만 필요
plugins/analytics/AnalyticsPlugin.runtimeconfig.json
node_modules/                     # npm 설치 없이 동작하는 예제용 JS 모듈 래퍼
js/main.mjs                       # JS named import smoke test
js/basic.mjs
TEST_STATUS.md                    # 검증된 범위 및 미검증 항목
```

## 7. 원본 Xytron 설계와의 차이 및 미구현

- **C# API 단순화:** 사용자 플러그인에서는 `[Export]`만 사용. `Bridge.cs` / `NativeValue`는 Xytron.Managed SDK로 분리.
- **완료한 경로:** 플러그인 manifest 발견 → 필요 시 로드 → 함수 등록 → C++ Registry 호출 → 결과 반환. Native는 C ABI 어댑터, Python은 실제 Python C API, C#은 `hostfxr` + Xytron.Managed SDK 내장 Reflection 브리지 코드.
- **JS 통합은 테스트용:** 이 샘플의 `import { add } from "game"`은 Node 패키지 래퍼를 통해 동작합니다. Xytron의 C++ 프로세스에 임베드된 JS 엔진과 커스텀 ES Module Loader를 구현한 것이 아닙니다.
- **객체 바인딩 미구현:** `Player` 생성자, 인스턴스 메서드, 프로퍼티, 객체 수명·핸들, 오버로드, 비동기 호출은 테스트 범위에 없습니다.
- **타입 한정:** 원시 숫자·bool·문자열·void만 지원합니다. C# 문자열 반환은 SDK에서 할당하고 Core가 복사한 뒤 해제합니다. 큰 정수/JS `BigInt`·복잡한 자료구조 미지원.
- **데모 구현의 제약:** manifest는 정규식으로 한정된 JSON 형식만 읽습니다. 플러그인 서명, 허용 목록, 샌드박스, 복잡한 버전 정책, 독립 스레드 GIL 처리, 프로덕션 수준의 오류 진단은 없습니다.
- **ABI 소유권:** `XyValue.text`는 호출 중 빌려온 포인터이며 반환 문자열은 Core가 즉시 복사합니다. 네이티브 플러그인은 앱 종료 시까지 로드한 상태를 유지합니다.
- **별도 프로세스:** JS 연동 데모만 Node→CLI 별도 프로세스를 사용합니다. C++ 호스트에서 Python/C# 함수를 호출할 때 해당 런타임을 위해 별도 프로세스를 실행하지 않습니다.

## 8. 외부 구현 참고

- Microsoft, custom .NET host: https://learn.microsoft.com/en-us/dotnet/core/tutorials/netcore-hosting
- Microsoft .NET native hosting sample: https://github.com/dotnet/samples/tree/main/core/hosting
- CPython embedding: https://docs.python.org/3/extending/embedding.html

원래 설계안과 연동 테스트 구현 간 차이점은 의도적으로 명시했습니다. 새 운영용 SDK를 만들 때는 정규식 JSON 파싱을 정식 파서로 교체하고, Runtime/ABI 버전·리소스 수명·스레드 안전성 검사를 추가해야 합니다.
