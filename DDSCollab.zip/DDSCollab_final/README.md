# DDSCollab - Sparx EA to DDS Repository Converter

## Overview
Converts Sparx EA QEA files to a DDS-based collaboration DB (SQLite).
Generates DDS IDL compatible with RTI DDS and Fast DDS.

## Layer Architecture
```
EA Model (QEA) -> Repository (SQLite) -> DDS Model (C++) -> IDL / JSON / MD
```

## Folder Structure
```
src/
  ea/           EA Model layer (EAReader, EAConverter)
  repository/   Repository layer (SQLiteRepository)
  dds/          DDS Model layer (DDSModels, DDSLoader)
  generator/    Output generators (IDLGenerator)
  utils/        Utilities (Any.h)
  main.cpp
third_party/
  sqlite3/      SQLite3 header (sqlite3.h)
                Download sqlite3.c from https://www.sqlite.org/download.html
  nlohmann/     JSON library (header-only)
dds_collab.sql  SQLite DDL (15 tables)
```

## Build

### Linux/Mac
```bash
# Initialize DB schema
sqlite3 collab.db < dds_collab.sql

# Build
g++ -std=c++11 -I./src -I./third_party/sqlite3 \
    src/main.cpp \
    src/ea/EAReader.cpp \
    src/ea/EAConverter.cpp \
    src/repository/SQLiteRepository.cpp \
    src/dds/DDSModels.cpp \
    src/dds/DDSLoader.cpp \
    src/generator/IDLGenerator.cpp \
    -lsqlite3 -o dds_collab
```

### Visual Studio 2019
- Project type: Console Application
- C++ Standard: /std:c++11
- Additional Include: src; third_party/sqlite3
- Add sqlite3.c to project (download amalgamation)
- Remove -lsqlite3 flag

## Usage
```bash
./dds_collab <qea_file> <output_db> [project_name] [root_package]

# Example: process only "DDS Example Models" package subtree
./dds_collab DDS_Example.qea collab.db "MyProject" "DDS Example Models"

# Example: process all DDS-stereotyped objects
./dds_collab DDS_Example.qea collab.db "MyProject"
```

## Output
- collab.db       : Collaboration SQLite DB
- collab.db.idl   : Generated DDS IDL
- collab.db.json  : Full DDS Model as JSON

## Any.h Note
src/utils/Any.h is a C++11-compatible variant type (replaces std::any).
Lines 19-21 (namespace std typedef) are commented out for g++ compatibility.
MSVC (Visual Studio) can use the original without modification.
