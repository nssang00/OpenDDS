SQLite3 Amalgamation
====================

sqlite3.h : SQLite3 header (included)
sqlite3.c : Download from https://www.sqlite.org/download.html
            -> sqlite-amalgamation-XXXXXXXX.zip
            -> Replace sqlite3.c with the downloaded version

Build with system library (Linux/Mac):
  g++ ... -lsqlite3

Build with amalgamation (Windows/standalone):
  Add sqlite3.c to your project and compile together
  Remove -lsqlite3 flag
