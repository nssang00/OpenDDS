/*
** SQLite3 Amalgamation Stub
** 
** This file is a stub for the SQLite3 amalgamation.
** 
** Option 1 (Linux/Mac): Link against system library
**   g++ ... -lsqlite3
**
** Option 2 (Windows/Standalone): Download the real amalgamation
**   https://www.sqlite.org/download.html
**   -> sqlite-amalgamation-XXXXXXXX.zip
**   -> Replace this file with the downloaded sqlite3.c
**
** The sqlite3.h in this directory is from the system installation.
*/
#include "sqlite3.h"
