#pragma once
#include <string>
#include <vector>
#include "RepositoryModels.h"

namespace Repo {

// ============================================================
// IRepository
// SQLite / PostgreSQL 공통 인터페이스
// ============================================================
class IRepository {
public:
    virtual ~IRepository() = default;

    // 연결
    virtual bool open(const std::string& connection_string) = 0;
    virtual void close() = 0;
    virtual bool isOpen() const = 0;

    // DDL 초기화
    virtual bool initSchema(const std::string& ddl_path) = 0;

    // --------------------------------------------------------
    // projects
    // --------------------------------------------------------
    virtual bool        saveProject(const Project& project) = 0;
    virtual Project     loadProject(const std::string& id) = 0;
    virtual std::vector<Project> loadAllProjects() = 0;

    // --------------------------------------------------------
    // packages
    // --------------------------------------------------------
    virtual bool        savePackage(const Package& package) = 0;
    virtual Package     loadPackage(const std::string& id) = 0;
    virtual std::vector<Package> loadPackages(
        const std::string& project_id) = 0;
    virtual std::vector<Package> loadChildPackages(
        const std::string& parent_id) = 0;
    virtual std::string findPackageByEaGuid(
        const std::string& ea_guid) = 0;  // → id 반환

    // --------------------------------------------------------
    // types
    // --------------------------------------------------------
    virtual bool        saveType(const Type& type) = 0;
    virtual Type        loadType(const std::string& id) = 0;
    virtual std::vector<Type> loadTypes(
        const std::string& project_id) = 0;
    virtual std::vector<Type> loadTypesByPackage(
        const std::string& package_id) = 0;
    virtual std::string findTypeByEaGuid(
        const std::string& ea_guid) = 0;
    virtual std::string findTypeByName(
        const std::string& project_id,
        const std::string& name) = 0;

    // --------------------------------------------------------
    // type_members
    // --------------------------------------------------------
    virtual bool        saveMember(const TypeMember& member) = 0;
    virtual std::vector<TypeMember> loadMembers(
        const std::string& type_id) = 0;
    virtual std::string findMemberByEaGuid(
        const std::string& ea_guid) = 0;

    // --------------------------------------------------------
    // domains
    // --------------------------------------------------------
    virtual bool        saveDomain(const Domain& domain) = 0;
    virtual Domain      loadDomain(const std::string& id) = 0;
    virtual std::vector<Domain> loadDomains(
        const std::string& project_id) = 0;
    virtual std::string findDomainByEaGuid(
        const std::string& ea_guid) = 0;

    // --------------------------------------------------------
    // register_types
    // --------------------------------------------------------
    virtual bool        saveRegisterType(const RegisterType& rt) = 0;
    virtual std::vector<RegisterType> loadRegisterTypes(
        const std::string& domain_id) = 0;

    // --------------------------------------------------------
    // topics
    // --------------------------------------------------------
    virtual bool        saveTopic(const Topic& topic) = 0;
    virtual Topic       loadTopic(const std::string& id) = 0;
    virtual std::vector<Topic> loadTopics(
        const std::string& project_id) = 0;
    virtual std::vector<Topic> loadTopicsByDomain(
        const std::string& domain_id) = 0;
    virtual std::string findTopicByEaGuid(
        const std::string& ea_guid) = 0;

    // --------------------------------------------------------
    // qos_profiles
    // --------------------------------------------------------
    virtual bool        saveQosProfile(const QosProfile& profile) = 0;
    virtual QosProfile  loadQosProfile(const std::string& id) = 0;
    virtual std::vector<QosProfile> loadQosProfiles(
        const std::string& project_id) = 0;

    // --------------------------------------------------------
    // qos_policies
    // --------------------------------------------------------
    virtual bool        saveQosPolicy(const QosPolicy& policy) = 0;
    virtual std::vector<QosPolicy> loadQosPolicies(
        const std::string& profile_id) = 0;

    // --------------------------------------------------------
    // participants
    // --------------------------------------------------------
    virtual bool        saveParticipant(const Participant& p) = 0;
    virtual std::vector<Participant> loadParticipants(
        const std::string& project_id) = 0;
    virtual std::string findParticipantByEaGuid(
        const std::string& ea_guid) = 0;

    // --------------------------------------------------------
    // publishers
    // --------------------------------------------------------
    virtual bool        savePublisher(const Publisher& p) = 0;
    virtual std::vector<Publisher> loadPublishers(
        const std::string& participant_id) = 0;

    // --------------------------------------------------------
    // subscribers
    // --------------------------------------------------------
    virtual bool        saveSubscriber(const Subscriber& s) = 0;
    virtual std::vector<Subscriber> loadSubscribers(
        const std::string& participant_id) = 0;

    // --------------------------------------------------------
    // writers
    // --------------------------------------------------------
    virtual bool        saveWriter(const Writer& w) = 0;
    virtual std::vector<Writer> loadWriters(
        const std::string& publisher_id) = 0;

    // --------------------------------------------------------
    // readers
    // --------------------------------------------------------
    virtual bool        saveReader(const Reader& r) = 0;
    virtual std::vector<Reader> loadReaders(
        const std::string& subscriber_id) = 0;

    // --------------------------------------------------------
    // audit_log
    // --------------------------------------------------------
    virtual bool        saveAuditLog(const AuditLog& log) = 0;
    virtual std::vector<AuditLog> loadAuditLogs(
        const std::string& project_id,
        int limit = 100) = 0;

    // --------------------------------------------------------
    // 트랜잭션
    // --------------------------------------------------------
    virtual bool beginTransaction() = 0;
    virtual bool commitTransaction() = 0;
    virtual bool rollbackTransaction() = 0;

    virtual std::string getLastError() const = 0;
};

} // namespace Repo
