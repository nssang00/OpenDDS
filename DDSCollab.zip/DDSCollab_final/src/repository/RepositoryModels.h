#pragma once
#include <string>
#include <vector>

namespace Repo {

// ============================================================
// Repository 구조체
// 협업 DB 테이블과 1:1 대응
// ============================================================

struct Project {
    std::string id;
    std::string name;
    std::string description;
    std::string version;
    std::string created_at;
    std::string updated_at;
};

struct Package {
    std::string id;
    std::string project_id;
    std::string parent_id;      // NULL이면 최상위
    std::string name;
    std::string kind;           // 'module'|'type_library'|'domain_library'|'folder'
    std::string description;
    int         ordinal       = 0;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source        = "ea";
};

struct Type {
    std::string id;
    std::string project_id;
    std::string package_id;
    std::string name;
    std::string kind;           // 'struct'|'enum'|'union'|'typedef'
    std::string base_type_id;   // 상속
    std::string extensibility  = "appendable";
    std::string description;
    std::string annotations;    // JSON
    std::string ea_guid;
    std::string ea_object_type;
    std::string ea_stereotype;
    std::string source         = "ea";
};

struct TypeMember {
    std::string id;
    std::string type_id;
    std::string name;
    int         ordinal        = 0;
    std::string member_kind;    // 'field'|'literal'|'case'|'discriminator'

    // 타입 참조
    std::string primitive_type;
    std::string ref_type_id;

    // EA 원본 보존
    std::string ea_type_name;
    std::string lower_bound;
    std::string upper_bound;

    // 컬렉션
    int         is_sequence    = 0;
    int         sequence_bound = -1;  // -1이면 unbounded
    int         is_array       = 0;
    std::string array_dimensions;     // JSON "[3,4]"
    int         string_bound   = 0;

    // annotation
    int         is_key         = 0;
    int         is_optional    = 0;
    std::string annotations;          // JSON

    // enum 전용
    int         enum_value     = 0;
    bool        has_enum_value = false;

    // union 전용
    std::string case_labels;          // JSON

    std::string default_value;
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source         = "ea";
};

struct Domain {
    std::string id;
    std::string project_id;
    std::string package_id;
    std::string name;
    int         domain_id     = -1;   // -1이면 미설정
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source        = "ea";
};

struct RegisterType {
    std::string id;
    std::string domain_id;
    std::string type_id;
    std::string register_name;  // NULL이면 types.name 사용
    std::string description;
};

struct Topic {
    std::string id;
    std::string project_id;
    std::string package_id;
    std::string domain_id;
    std::string name;
    std::string register_type_id;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source        = "ea";
};

struct QosProfile {
    std::string id;
    std::string project_id;
    std::string name;
    std::string base_profile_id;
    std::string description;
};

struct QosPolicy {
    std::string id;
    std::string profile_id;
    std::string entity_kind;   // 'topic'|'writer'|'reader'|'participant'
    std::string policy_name;   // 'DURABILITY'|'RELIABILITY'|...
    std::string policy_value;  // JSON
};

struct Participant {
    std::string id;
    std::string project_id;
    std::string package_id;
    std::string domain_id;
    std::string name;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source        = "ea";
};

struct Publisher {
    std::string id;
    std::string participant_id;
    std::string name;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source        = "ea";
};

struct Subscriber {
    std::string id;
    std::string participant_id;
    std::string name;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source        = "ea";
};

struct Writer {
    std::string id;
    std::string publisher_id;
    std::string topic_id;
    std::string name;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source        = "ea";
};

struct Reader {
    std::string id;
    std::string subscriber_id;
    std::string topic_id;
    std::string name;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source        = "ea";
};

struct AuditLog {
    std::string id;
    std::string project_id;
    std::string target_kind;
    std::string target_id;
    std::string action;        // 'create'|'update'|'delete'|'ea_sync'
    std::string changed_by;
    std::string changed_at;
    std::string diff;          // JSON
};

} // namespace Repo
