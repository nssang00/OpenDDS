#include "SQLiteRepository.h"
#include <fstream>
#include <sstream>
#include <iostream>

namespace Repo {

SQLiteRepository::SQLiteRepository() : db_(nullptr) {}

SQLiteRepository::~SQLiteRepository() {
    close();
}

// ============================================================
// 연결
// ============================================================
bool SQLiteRepository::open(const std::string& db_path) {
    int rc = sqlite3_open(db_path.c_str(), &db_);
    if (rc != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        sqlite3_close(db_);
        db_ = nullptr;
        return false;
    }
    // 외래키 활성화
    exec("PRAGMA foreign_keys = ON;");
    exec("PRAGMA journal_mode = WAL;");
    return true;
}

void SQLiteRepository::close() {
    if (db_) {
        sqlite3_close(db_);
        db_ = nullptr;
    }
}

bool SQLiteRepository::isOpen() const {
    return db_ != nullptr;
}

bool SQLiteRepository::initSchema(const std::string& ddl_path) {
    std::ifstream f(ddl_path);
    if (!f.is_open()) {
        last_error_ = "DDL 파일을 열 수 없습니다: " + ddl_path;
        return false;
    }
    std::stringstream ss;
    ss << f.rdbuf();
    return exec(ss.str());
}

// ============================================================
// 헬퍼
// ============================================================
bool SQLiteRepository::exec(const std::string& sql) {
    char* err = nullptr;
    int rc = sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &err);
    if (rc != SQLITE_OK) {
        last_error_ = err ? err : "Unknown error";
        sqlite3_free(err);
        return false;
    }
    return true;
}

std::string SQLiteRepository::getString(sqlite3_stmt* stmt, int col) {
    const char* v = (const char*)sqlite3_column_text(stmt, col);
    return v ? v : "";
}

int SQLiteRepository::getInt(sqlite3_stmt* stmt, int col) {
    return sqlite3_column_int(stmt, col);
}

// ============================================================
// 트랜잭션
// ============================================================
bool SQLiteRepository::beginTransaction() {
    return exec("BEGIN TRANSACTION;");
}

bool SQLiteRepository::commitTransaction() {
    return exec("COMMIT;");
}

bool SQLiteRepository::rollbackTransaction() {
    return exec("ROLLBACK;");
}

// ============================================================
// projects
// ============================================================
bool SQLiteRepository::saveProject(const Project& p) {
    std::string sql =
        "INSERT OR REPLACE INTO projects "
        "(id, name, description, version, created_at, updated_at) "
        "VALUES (?, ?, ?, ?, datetime('now'), datetime('now'));";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }

    sqlite3_bind_text(stmt, 1, p.id.c_str(),          -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, p.name.c_str(),         -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, p.description.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4, p.version.c_str(),      -1, SQLITE_STATIC);

    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

Project SQLiteRepository::loadProject(const std::string& id) {
    Project p;
    std::string sql =
        "SELECT id, name, description, version, created_at, updated_at "
        "FROM projects WHERE id = ?;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK)
        return p;

    sqlite3_bind_text(stmt, 1, id.c_str(), -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) == SQLITE_ROW) {
        p.id          = getString(stmt, 0);
        p.name        = getString(stmt, 1);
        p.description = getString(stmt, 2);
        p.version     = getString(stmt, 3);
        p.created_at  = getString(stmt, 4);
        p.updated_at  = getString(stmt, 5);
    }
    sqlite3_finalize(stmt);
    return p;
}

std::vector<Project> SQLiteRepository::loadAllProjects() {
    std::vector<Project> result;
    const char* sql =
        "SELECT id, name, description, version, created_at, updated_at "
        "FROM projects ORDER BY created_at;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Project p;
        p.id          = getString(stmt, 0);
        p.name        = getString(stmt, 1);
        p.description = getString(stmt, 2);
        p.version     = getString(stmt, 3);
        p.created_at  = getString(stmt, 4);
        p.updated_at  = getString(stmt, 5);
        result.push_back(p);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// packages
// ============================================================
bool SQLiteRepository::savePackage(const Package& p) {
    std::string sql =
        "INSERT OR REPLACE INTO packages "
        "(id, project_id, parent_id, name, kind, description, "
        " ordinal, ea_guid, ea_stereotype, source, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'));";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }

    sqlite3_bind_text(stmt, 1,  p.id.c_str(),           -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2,  p.project_id.c_str(),   -1, SQLITE_STATIC);
    if (p.parent_id.empty())
        sqlite3_bind_null(stmt, 3);
    else
        sqlite3_bind_text(stmt, 3, p.parent_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4,  p.name.c_str(),          -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5,  p.kind.c_str(),          -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 6,  p.description.c_str(),   -1, SQLITE_STATIC);
    sqlite3_bind_int (stmt, 7,  p.ordinal);
    sqlite3_bind_text(stmt, 8,  p.ea_guid.c_str(),       -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 9,  p.ea_stereotype.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 10, p.source.c_str(),        -1, SQLITE_STATIC);

    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

Package SQLiteRepository::loadPackage(const std::string& id) {
    Package p;
    const char* sql =
        "SELECT id, project_id, parent_id, name, kind, description, "
        "       ordinal, ea_guid, ea_stereotype, source "
        "FROM packages WHERE id = ?;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return p;

    sqlite3_bind_text(stmt, 1, id.c_str(), -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) == SQLITE_ROW) {
        p.id           = getString(stmt, 0);
        p.project_id   = getString(stmt, 1);
        p.parent_id    = getString(stmt, 2);
        p.name         = getString(stmt, 3);
        p.kind         = getString(stmt, 4);
        p.description  = getString(stmt, 5);
        p.ordinal      = getInt   (stmt, 6);
        p.ea_guid      = getString(stmt, 7);
        p.ea_stereotype = getString(stmt, 8);
        p.source       = getString(stmt, 9);
    }
    sqlite3_finalize(stmt);
    return p;
}

std::vector<Package> SQLiteRepository::loadPackages(
    const std::string& project_id)
{
    std::vector<Package> result;
    const char* sql =
        "SELECT id, project_id, parent_id, name, kind, description, "
        "       ordinal, ea_guid, ea_stereotype, source "
        "FROM packages WHERE project_id = ? ORDER BY ordinal;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;

    sqlite3_bind_text(stmt, 1, project_id.c_str(), -1, SQLITE_STATIC);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Package p;
        p.id           = getString(stmt, 0);
        p.project_id   = getString(stmt, 1);
        p.parent_id    = getString(stmt, 2);
        p.name         = getString(stmt, 3);
        p.kind         = getString(stmt, 4);
        p.description  = getString(stmt, 5);
        p.ordinal      = getInt   (stmt, 6);
        p.ea_guid      = getString(stmt, 7);
        p.ea_stereotype = getString(stmt, 8);
        p.source       = getString(stmt, 9);
        result.push_back(p);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::vector<Package> SQLiteRepository::loadChildPackages(
    const std::string& parent_id)
{
    std::vector<Package> result;
    const char* sql =
        "SELECT id, project_id, parent_id, name, kind, description, "
        "       ordinal, ea_guid, ea_stereotype, source "
        "FROM packages WHERE parent_id = ? ORDER BY ordinal;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;

    sqlite3_bind_text(stmt, 1, parent_id.c_str(), -1, SQLITE_STATIC);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Package p;
        p.id           = getString(stmt, 0);
        p.project_id   = getString(stmt, 1);
        p.parent_id    = getString(stmt, 2);
        p.name         = getString(stmt, 3);
        p.kind         = getString(stmt, 4);
        p.description  = getString(stmt, 5);
        p.ordinal      = getInt   (stmt, 6);
        p.ea_guid      = getString(stmt, 7);
        p.ea_stereotype = getString(stmt, 8);
        p.source       = getString(stmt, 9);
        result.push_back(p);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::string SQLiteRepository::findPackageByEaGuid(const std::string& ea_guid) {
    if (ea_guid.empty()) return "";
    const char* sql = "SELECT id FROM packages WHERE ea_guid = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    std::string result;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, ea_guid.c_str(), -1, SQLITE_STATIC);
        if (sqlite3_step(stmt) == SQLITE_ROW) result = getString(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// types
// ============================================================
bool SQLiteRepository::saveType(const Type& t) {
    std::string sql =
        "INSERT OR REPLACE INTO types "
        "(id, project_id, package_id, name, kind, base_type_id, "
        " extensibility, description, annotations, "
        " ea_guid, ea_object_type, ea_stereotype, source, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'));";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }

    sqlite3_bind_text(stmt, 1,  t.id.c_str(),            -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2,  t.project_id.c_str(),    -1, SQLITE_STATIC);
    if (t.package_id.empty())
        sqlite3_bind_null(stmt, 3);
    else
        sqlite3_bind_text(stmt, 3, t.package_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4,  t.name.c_str(),          -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5,  t.kind.c_str(),          -1, SQLITE_STATIC);
    if (t.base_type_id.empty())
        sqlite3_bind_null(stmt, 6);
    else
        sqlite3_bind_text(stmt, 6, t.base_type_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 7,  t.extensibility.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 8,  t.description.c_str(),   -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 9,  t.annotations.c_str(),   -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 10, t.ea_guid.c_str(),       -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 11, t.ea_object_type.c_str(),-1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 12, t.ea_stereotype.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 13, t.source.c_str(),        -1, SQLITE_STATIC);

    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

Type SQLiteRepository::loadType(const std::string& id) {
    Type t;
    const char* sql =
        "SELECT id, project_id, package_id, name, kind, base_type_id, "
        "       extensibility, description, annotations, "
        "       ea_guid, ea_object_type, ea_stereotype, source "
        "FROM types WHERE id = ?;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return t;

    sqlite3_bind_text(stmt, 1, id.c_str(), -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) == SQLITE_ROW) {
        t.id             = getString(stmt, 0);
        t.project_id     = getString(stmt, 1);
        t.package_id     = getString(stmt, 2);
        t.name           = getString(stmt, 3);
        t.kind           = getString(stmt, 4);
        t.base_type_id   = getString(stmt, 5);
        t.extensibility  = getString(stmt, 6);
        t.description    = getString(stmt, 7);
        t.annotations    = getString(stmt, 8);
        t.ea_guid        = getString(stmt, 9);
        t.ea_object_type = getString(stmt, 10);
        t.ea_stereotype  = getString(stmt, 11);
        t.source         = getString(stmt, 12);
    }
    sqlite3_finalize(stmt);
    return t;
}

std::vector<Type> SQLiteRepository::loadTypes(const std::string& project_id) {
    std::vector<Type> result;
    const char* sql =
        "SELECT id, project_id, package_id, name, kind, base_type_id, "
        "       extensibility, description, annotations, "
        "       ea_guid, ea_object_type, ea_stereotype, source "
        "FROM types WHERE project_id = ? ORDER BY name;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;

    sqlite3_bind_text(stmt, 1, project_id.c_str(), -1, SQLITE_STATIC);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Type t;
        t.id             = getString(stmt, 0);
        t.project_id     = getString(stmt, 1);
        t.package_id     = getString(stmt, 2);
        t.name           = getString(stmt, 3);
        t.kind           = getString(stmt, 4);
        t.base_type_id   = getString(stmt, 5);
        t.extensibility  = getString(stmt, 6);
        t.description    = getString(stmt, 7);
        t.annotations    = getString(stmt, 8);
        t.ea_guid        = getString(stmt, 9);
        t.ea_object_type = getString(stmt, 10);
        t.ea_stereotype  = getString(stmt, 11);
        t.source         = getString(stmt, 12);
        result.push_back(t);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::vector<Type> SQLiteRepository::loadTypesByPackage(
    const std::string& package_id)
{
    std::vector<Type> result;
    const char* sql =
        "SELECT id, project_id, package_id, name, kind, base_type_id, "
        "       extensibility, description, annotations, "
        "       ea_guid, ea_object_type, ea_stereotype, source "
        "FROM types WHERE package_id = ? ORDER BY name;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;

    sqlite3_bind_text(stmt, 1, package_id.c_str(), -1, SQLITE_STATIC);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Type t;
        t.id             = getString(stmt, 0);
        t.project_id     = getString(stmt, 1);
        t.package_id     = getString(stmt, 2);
        t.name           = getString(stmt, 3);
        t.kind           = getString(stmt, 4);
        t.base_type_id   = getString(stmt, 5);
        t.extensibility  = getString(stmt, 6);
        t.description    = getString(stmt, 7);
        t.annotations    = getString(stmt, 8);
        t.ea_guid        = getString(stmt, 9);
        t.ea_object_type = getString(stmt, 10);
        t.ea_stereotype  = getString(stmt, 11);
        t.source         = getString(stmt, 12);
        result.push_back(t);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::string SQLiteRepository::findTypeByEaGuid(const std::string& ea_guid) {
    if (ea_guid.empty()) return "";
    const char* sql = "SELECT id FROM types WHERE ea_guid = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    std::string result;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, ea_guid.c_str(), -1, SQLITE_STATIC);
        if (sqlite3_step(stmt) == SQLITE_ROW) result = getString(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::string SQLiteRepository::findTypeByName(
    const std::string& project_id,
    const std::string& name)
{
    const char* sql =
        "SELECT id FROM types WHERE project_id = ? AND name = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    std::string result;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, project_id.c_str(), -1, SQLITE_STATIC);
        sqlite3_bind_text(stmt, 2, name.c_str(),       -1, SQLITE_STATIC);
        if (sqlite3_step(stmt) == SQLITE_ROW) result = getString(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// type_members
// ============================================================
bool SQLiteRepository::saveMember(const TypeMember& m) {
    std::string sql =
        "INSERT OR REPLACE INTO type_members "
        "(id, type_id, name, ordinal, member_kind, "
        " primitive_type, ref_type_id, "
        " ea_type_name, lower_bound, upper_bound, "
        " is_sequence, sequence_bound, is_array, array_dimensions, "
        " string_bound, is_key, is_optional, annotations, "
        " enum_value, case_labels, default_value, description, "
        " ea_guid, ea_stereotype, source, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,"
        "        datetime('now'),datetime('now'));";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }

    sqlite3_bind_text(stmt, 1,  m.id.c_str(),           -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2,  m.type_id.c_str(),      -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3,  m.name.c_str(),         -1, SQLITE_STATIC);
    sqlite3_bind_int (stmt, 4,  m.ordinal);
    sqlite3_bind_text(stmt, 5,  m.member_kind.c_str(),  -1, SQLITE_STATIC);
    if (m.primitive_type.empty())
        sqlite3_bind_null(stmt, 6);
    else
        sqlite3_bind_text(stmt, 6, m.primitive_type.c_str(), -1, SQLITE_STATIC);
    if (m.ref_type_id.empty())
        sqlite3_bind_null(stmt, 7);
    else
        sqlite3_bind_text(stmt, 7, m.ref_type_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 8,  m.ea_type_name.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 9,  m.lower_bound.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 10, m.upper_bound.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_int (stmt, 11, m.is_sequence);
    if (m.sequence_bound < 0)
        sqlite3_bind_null(stmt, 12);
    else
        sqlite3_bind_int(stmt, 12, m.sequence_bound);
    sqlite3_bind_int (stmt, 13, m.is_array);
    sqlite3_bind_text(stmt, 14, m.array_dimensions.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_int (stmt, 15, m.string_bound);
    sqlite3_bind_int (stmt, 16, m.is_key);
    sqlite3_bind_int (stmt, 17, m.is_optional);
    sqlite3_bind_text(stmt, 18, m.annotations.c_str(),  -1, SQLITE_STATIC);
    if (m.has_enum_value)
        sqlite3_bind_int(stmt, 19, m.enum_value);
    else
        sqlite3_bind_null(stmt, 19);
    sqlite3_bind_text(stmt, 20, m.case_labels.c_str(),   -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 21, m.default_value.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 22, m.description.c_str(),   -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 23, m.ea_guid.c_str(),       -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 24, m.ea_stereotype.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 25, m.source.c_str(),        -1, SQLITE_STATIC);

    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

std::vector<TypeMember> SQLiteRepository::loadMembers(
    const std::string& type_id)
{
    std::vector<TypeMember> result;
    const char* sql =
        "SELECT id, type_id, name, ordinal, member_kind, "
        "       primitive_type, ref_type_id, "
        "       ea_type_name, lower_bound, upper_bound, "
        "       is_sequence, sequence_bound, is_array, array_dimensions, "
        "       string_bound, is_key, is_optional, annotations, "
        "       enum_value, case_labels, default_value, description, "
        "       ea_guid, ea_stereotype, source "
        "FROM type_members WHERE type_id = ? ORDER BY ordinal;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;

    sqlite3_bind_text(stmt, 1, type_id.c_str(), -1, SQLITE_STATIC);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        TypeMember m;
        m.id              = getString(stmt, 0);
        m.type_id         = getString(stmt, 1);
        m.name            = getString(stmt, 2);
        m.ordinal         = getInt   (stmt, 3);
        m.member_kind     = getString(stmt, 4);
        m.primitive_type  = getString(stmt, 5);
        m.ref_type_id     = getString(stmt, 6);
        m.ea_type_name    = getString(stmt, 7);
        m.lower_bound     = getString(stmt, 8);
        m.upper_bound     = getString(stmt, 9);
        m.is_sequence     = getInt   (stmt, 10);
        m.sequence_bound  = sqlite3_column_type(stmt, 11) == SQLITE_NULL
                            ? -1 : getInt(stmt, 11);
        m.is_array        = getInt   (stmt, 12);
        m.array_dimensions = getString(stmt, 13);
        m.string_bound    = getInt   (stmt, 14);
        m.is_key          = getInt   (stmt, 15);
        m.is_optional     = getInt   (stmt, 16);
        m.annotations     = getString(stmt, 17);
        if (sqlite3_column_type(stmt, 18) != SQLITE_NULL) {
            m.enum_value     = getInt(stmt, 18);
            m.has_enum_value = true;
        }
        m.case_labels     = getString(stmt, 19);
        m.default_value   = getString(stmt, 20);
        m.description     = getString(stmt, 21);
        m.ea_guid         = getString(stmt, 22);
        m.ea_stereotype   = getString(stmt, 23);
        m.source          = getString(stmt, 24);
        result.push_back(m);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::string SQLiteRepository::findMemberByEaGuid(const std::string& ea_guid) {
    if (ea_guid.empty()) return "";
    const char* sql =
        "SELECT id FROM type_members WHERE ea_guid = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    std::string result;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, ea_guid.c_str(), -1, SQLITE_STATIC);
        if (sqlite3_step(stmt) == SQLITE_ROW) result = getString(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// domains
// ============================================================
bool SQLiteRepository::saveDomain(const Domain& d) {
    std::string sql =
        "INSERT OR REPLACE INTO domains "
        "(id, project_id, package_id, name, domain_id, description, "
        " ea_guid, ea_stereotype, source, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'));";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }

    sqlite3_bind_text(stmt, 1, d.id.c_str(),           -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, d.project_id.c_str(),   -1, SQLITE_STATIC);
    if (d.package_id.empty())
        sqlite3_bind_null(stmt, 3);
    else
        sqlite3_bind_text(stmt, 3, d.package_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4, d.name.c_str(),          -1, SQLITE_STATIC);
    if (d.domain_id < 0)
        sqlite3_bind_null(stmt, 5);
    else
        sqlite3_bind_int(stmt, 5, d.domain_id);
    sqlite3_bind_text(stmt, 6, d.description.c_str(),   -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 7, d.ea_guid.c_str(),       -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 8, d.ea_stereotype.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 9, d.source.c_str(),        -1, SQLITE_STATIC);

    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

Domain SQLiteRepository::loadDomain(const std::string& id) {
    Domain d;
    const char* sql =
        "SELECT id, project_id, package_id, name, domain_id, description, "
        "       ea_guid, ea_stereotype, source "
        "FROM domains WHERE id = ?;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return d;

    sqlite3_bind_text(stmt, 1, id.c_str(), -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) == SQLITE_ROW) {
        d.id           = getString(stmt, 0);
        d.project_id   = getString(stmt, 1);
        d.package_id   = getString(stmt, 2);
        d.name         = getString(stmt, 3);
        d.domain_id    = sqlite3_column_type(stmt, 4) == SQLITE_NULL
                         ? -1 : getInt(stmt, 4);
        d.description  = getString(stmt, 5);
        d.ea_guid      = getString(stmt, 6);
        d.ea_stereotype = getString(stmt, 7);
        d.source       = getString(stmt, 8);
    }
    sqlite3_finalize(stmt);
    return d;
}

std::vector<Domain> SQLiteRepository::loadDomains(
    const std::string& project_id)
{
    std::vector<Domain> result;
    const char* sql =
        "SELECT id, project_id, package_id, name, domain_id, description, "
        "       ea_guid, ea_stereotype, source "
        "FROM domains WHERE project_id = ?;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;

    sqlite3_bind_text(stmt, 1, project_id.c_str(), -1, SQLITE_STATIC);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Domain d;
        d.id           = getString(stmt, 0);
        d.project_id   = getString(stmt, 1);
        d.package_id   = getString(stmt, 2);
        d.name         = getString(stmt, 3);
        d.domain_id    = sqlite3_column_type(stmt, 4) == SQLITE_NULL
                         ? -1 : getInt(stmt, 4);
        d.description  = getString(stmt, 5);
        d.ea_guid      = getString(stmt, 6);
        d.ea_stereotype = getString(stmt, 7);
        d.source       = getString(stmt, 8);
        result.push_back(d);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::string SQLiteRepository::findDomainByEaGuid(const std::string& ea_guid) {
    if (ea_guid.empty()) return "";
    const char* sql = "SELECT id FROM domains WHERE ea_guid = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    std::string result;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, ea_guid.c_str(), -1, SQLITE_STATIC);
        if (sqlite3_step(stmt) == SQLITE_ROW) result = getString(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// register_types
// ============================================================
bool SQLiteRepository::saveRegisterType(const RegisterType& rt) {
    std::string sql =
        "INSERT OR REPLACE INTO register_types "
        "(id, domain_id, type_id, register_name, description, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,datetime('now'),datetime('now'));";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }

    sqlite3_bind_text(stmt, 1, rt.id.c_str(),           -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, rt.domain_id.c_str(),    -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, rt.type_id.c_str(),      -1, SQLITE_STATIC);
    if (rt.register_name.empty())
        sqlite3_bind_null(stmt, 4);
    else
        sqlite3_bind_text(stmt, 4, rt.register_name.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5, rt.description.c_str(),  -1, SQLITE_STATIC);

    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

std::vector<RegisterType> SQLiteRepository::loadRegisterTypes(
    const std::string& domain_id)
{
    std::vector<RegisterType> result;
    const char* sql =
        "SELECT id, domain_id, type_id, register_name, description "
        "FROM register_types WHERE domain_id = ?;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;

    sqlite3_bind_text(stmt, 1, domain_id.c_str(), -1, SQLITE_STATIC);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        RegisterType rt;
        rt.id            = getString(stmt, 0);
        rt.domain_id     = getString(stmt, 1);
        rt.type_id       = getString(stmt, 2);
        rt.register_name = getString(stmt, 3);
        rt.description   = getString(stmt, 4);
        result.push_back(rt);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// topics
// ============================================================
bool SQLiteRepository::saveTopic(const Topic& t) {
    std::string sql =
        "INSERT OR REPLACE INTO topics "
        "(id, project_id, package_id, domain_id, name, "
        " register_type_id, qos_profile_id, description, "
        " ea_guid, ea_stereotype, source, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'));";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }

    sqlite3_bind_text(stmt, 1,  t.id.c_str(),              -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2,  t.project_id.c_str(),      -1, SQLITE_STATIC);
    if (t.package_id.empty())
        sqlite3_bind_null(stmt, 3);
    else
        sqlite3_bind_text(stmt, 3, t.package_id.c_str(),   -1, SQLITE_STATIC);
    if (t.domain_id.empty())
        sqlite3_bind_null(stmt, 4);
    else
        sqlite3_bind_text(stmt, 4, t.domain_id.c_str(),    -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5,  t.name.c_str(),            -1, SQLITE_STATIC);
    if (t.register_type_id.empty())
        sqlite3_bind_null(stmt, 6);
    else
        sqlite3_bind_text(stmt, 6, t.register_type_id.c_str(), -1, SQLITE_STATIC);
    if (t.qos_profile_id.empty())
        sqlite3_bind_null(stmt, 7);
    else
        sqlite3_bind_text(stmt, 7, t.qos_profile_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 8,  t.description.c_str(),     -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 9,  t.ea_guid.c_str(),         -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 10, t.ea_stereotype.c_str(),   -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 11, t.source.c_str(),          -1, SQLITE_STATIC);

    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

Topic SQLiteRepository::loadTopic(const std::string& id) {
    Topic t;
    const char* sql =
        "SELECT id, project_id, package_id, domain_id, name, "
        "       register_type_id, qos_profile_id, description, "
        "       ea_guid, ea_stereotype, source "
        "FROM topics WHERE id = ?;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return t;

    sqlite3_bind_text(stmt, 1, id.c_str(), -1, SQLITE_STATIC);

    if (sqlite3_step(stmt) == SQLITE_ROW) {
        t.id               = getString(stmt, 0);
        t.project_id       = getString(stmt, 1);
        t.package_id       = getString(stmt, 2);
        t.domain_id        = getString(stmt, 3);
        t.name             = getString(stmt, 4);
        t.register_type_id = getString(stmt, 5);
        t.qos_profile_id   = getString(stmt, 6);
        t.description      = getString(stmt, 7);
        t.ea_guid          = getString(stmt, 8);
        t.ea_stereotype    = getString(stmt, 9);
        t.source           = getString(stmt, 10);
    }
    sqlite3_finalize(stmt);
    return t;
}

std::vector<Topic> SQLiteRepository::loadTopics(const std::string& project_id) {
    std::vector<Topic> result;
    const char* sql =
        "SELECT id, project_id, package_id, domain_id, name, "
        "       register_type_id, qos_profile_id, description, "
        "       ea_guid, ea_stereotype, source "
        "FROM topics WHERE project_id = ?;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;

    sqlite3_bind_text(stmt, 1, project_id.c_str(), -1, SQLITE_STATIC);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Topic t;
        t.id               = getString(stmt, 0);
        t.project_id       = getString(stmt, 1);
        t.package_id       = getString(stmt, 2);
        t.domain_id        = getString(stmt, 3);
        t.name             = getString(stmt, 4);
        t.register_type_id = getString(stmt, 5);
        t.qos_profile_id   = getString(stmt, 6);
        t.description      = getString(stmt, 7);
        t.ea_guid          = getString(stmt, 8);
        t.ea_stereotype    = getString(stmt, 9);
        t.source           = getString(stmt, 10);
        result.push_back(t);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::vector<Topic> SQLiteRepository::loadTopicsByDomain(
    const std::string& domain_id)
{
    std::vector<Topic> result;
    const char* sql =
        "SELECT id, project_id, package_id, domain_id, name, "
        "       register_type_id, qos_profile_id, description, "
        "       ea_guid, ea_stereotype, source "
        "FROM topics WHERE domain_id = ?;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;

    sqlite3_bind_text(stmt, 1, domain_id.c_str(), -1, SQLITE_STATIC);

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Topic t;
        t.id               = getString(stmt, 0);
        t.project_id       = getString(stmt, 1);
        t.package_id       = getString(stmt, 2);
        t.domain_id        = getString(stmt, 3);
        t.name             = getString(stmt, 4);
        t.register_type_id = getString(stmt, 5);
        t.qos_profile_id   = getString(stmt, 6);
        t.description      = getString(stmt, 7);
        t.ea_guid          = getString(stmt, 8);
        t.ea_stereotype    = getString(stmt, 9);
        t.source           = getString(stmt, 10);
        result.push_back(t);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::string SQLiteRepository::findTopicByEaGuid(const std::string& ea_guid) {
    if (ea_guid.empty()) return "";
    const char* sql = "SELECT id FROM topics WHERE ea_guid = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    std::string result;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, ea_guid.c_str(), -1, SQLITE_STATIC);
        if (sqlite3_step(stmt) == SQLITE_ROW) result = getString(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// qos_profiles
// ============================================================
bool SQLiteRepository::saveQosProfile(const QosProfile& p) {
    std::string sql =
        "INSERT OR REPLACE INTO qos_profiles "
        "(id, project_id, name, base_profile_id, description, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,datetime('now'),datetime('now'));";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }

    sqlite3_bind_text(stmt, 1, p.id.c_str(),          -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, p.project_id.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, p.name.c_str(),         -1, SQLITE_STATIC);
    if (p.base_profile_id.empty())
        sqlite3_bind_null(stmt, 4);
    else
        sqlite3_bind_text(stmt, 4, p.base_profile_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5, p.description.c_str(), -1, SQLITE_STATIC);

    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

QosProfile SQLiteRepository::loadQosProfile(const std::string& id) {
    QosProfile p;
    const char* sql =
        "SELECT id, project_id, name, base_profile_id, description "
        "FROM qos_profiles WHERE id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return p;
    sqlite3_bind_text(stmt, 1, id.c_str(), -1, SQLITE_STATIC);
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        p.id              = getString(stmt, 0);
        p.project_id      = getString(stmt, 1);
        p.name            = getString(stmt, 2);
        p.base_profile_id = getString(stmt, 3);
        p.description     = getString(stmt, 4);
    }
    sqlite3_finalize(stmt);
    return p;
}

std::vector<QosProfile> SQLiteRepository::loadQosProfiles(
    const std::string& project_id)
{
    std::vector<QosProfile> result;
    const char* sql =
        "SELECT id, project_id, name, base_profile_id, description "
        "FROM qos_profiles WHERE project_id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;
    sqlite3_bind_text(stmt, 1, project_id.c_str(), -1, SQLITE_STATIC);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        QosProfile p;
        p.id              = getString(stmt, 0);
        p.project_id      = getString(stmt, 1);
        p.name            = getString(stmt, 2);
        p.base_profile_id = getString(stmt, 3);
        p.description     = getString(stmt, 4);
        result.push_back(p);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// qos_policies
// ============================================================
bool SQLiteRepository::saveQosPolicy(const QosPolicy& p) {
    std::string sql =
        "INSERT OR REPLACE INTO qos_policies "
        "(id, profile_id, entity_kind, policy_name, policy_value, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,datetime('now'),datetime('now'));";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }
    sqlite3_bind_text(stmt, 1, p.id.c_str(),           -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, p.profile_id.c_str(),   -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, p.entity_kind.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4, p.policy_name.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5, p.policy_value.c_str(), -1, SQLITE_STATIC);
    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

std::vector<QosPolicy> SQLiteRepository::loadQosPolicies(
    const std::string& profile_id)
{
    std::vector<QosPolicy> result;
    const char* sql =
        "SELECT id, profile_id, entity_kind, policy_name, policy_value "
        "FROM qos_policies WHERE profile_id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;
    sqlite3_bind_text(stmt, 1, profile_id.c_str(), -1, SQLITE_STATIC);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        QosPolicy p;
        p.id           = getString(stmt, 0);
        p.profile_id   = getString(stmt, 1);
        p.entity_kind  = getString(stmt, 2);
        p.policy_name  = getString(stmt, 3);
        p.policy_value = getString(stmt, 4);
        result.push_back(p);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// participants
// ============================================================
bool SQLiteRepository::saveParticipant(const Participant& p) {
    std::string sql =
        "INSERT OR REPLACE INTO participants "
        "(id, project_id, package_id, domain_id, name, "
        " qos_profile_id, description, "
        " ea_guid, ea_stereotype, source, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'));";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }
    sqlite3_bind_text(stmt, 1,  p.id.c_str(),           -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2,  p.project_id.c_str(),   -1, SQLITE_STATIC);
    p.package_id.empty() ? sqlite3_bind_null(stmt, 3) :
        sqlite3_bind_text(stmt, 3, p.package_id.c_str(), -1, SQLITE_STATIC);
    p.domain_id.empty() ? sqlite3_bind_null(stmt, 4) :
        sqlite3_bind_text(stmt, 4, p.domain_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5,  p.name.c_str(),         -1, SQLITE_STATIC);
    p.qos_profile_id.empty() ? sqlite3_bind_null(stmt, 6) :
        sqlite3_bind_text(stmt, 6, p.qos_profile_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 7,  p.description.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 8,  p.ea_guid.c_str(),      -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 9,  p.ea_stereotype.c_str(),-1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 10, p.source.c_str(),       -1, SQLITE_STATIC);
    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

std::vector<Participant> SQLiteRepository::loadParticipants(
    const std::string& project_id)
{
    std::vector<Participant> result;
    const char* sql =
        "SELECT id, project_id, package_id, domain_id, name, "
        "       qos_profile_id, description, ea_guid, ea_stereotype, source "
        "FROM participants WHERE project_id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;
    sqlite3_bind_text(stmt, 1, project_id.c_str(), -1, SQLITE_STATIC);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Participant p;
        p.id             = getString(stmt, 0);
        p.project_id     = getString(stmt, 1);
        p.package_id     = getString(stmt, 2);
        p.domain_id      = getString(stmt, 3);
        p.name           = getString(stmt, 4);
        p.qos_profile_id = getString(stmt, 5);
        p.description    = getString(stmt, 6);
        p.ea_guid        = getString(stmt, 7);
        p.ea_stereotype  = getString(stmt, 8);
        p.source         = getString(stmt, 9);
        result.push_back(p);
    }
    sqlite3_finalize(stmt);
    return result;
}

std::string SQLiteRepository::findParticipantByEaGuid(
    const std::string& ea_guid)
{
    if (ea_guid.empty()) return "";
    const char* sql =
        "SELECT id FROM participants WHERE ea_guid = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    std::string result;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, ea_guid.c_str(), -1, SQLITE_STATIC);
        if (sqlite3_step(stmt) == SQLITE_ROW) result = getString(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// publishers
// ============================================================
bool SQLiteRepository::savePublisher(const Publisher& p) {
    std::string sql =
        "INSERT OR REPLACE INTO publishers "
        "(id, participant_id, name, qos_profile_id, description, "
        " ea_guid, ea_stereotype, source, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,datetime('now'),datetime('now'));";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }
    sqlite3_bind_text(stmt, 1, p.id.c_str(),             -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, p.participant_id.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, p.name.c_str(),            -1, SQLITE_STATIC);
    p.qos_profile_id.empty() ? sqlite3_bind_null(stmt, 4) :
        sqlite3_bind_text(stmt, 4, p.qos_profile_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5, p.description.c_str(),    -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 6, p.ea_guid.c_str(),        -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 7, p.ea_stereotype.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 8, p.source.c_str(),         -1, SQLITE_STATIC);
    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

std::vector<Publisher> SQLiteRepository::loadPublishers(
    const std::string& participant_id)
{
    std::vector<Publisher> result;
    const char* sql =
        "SELECT id, participant_id, name, qos_profile_id, description, "
        "       ea_guid, ea_stereotype, source "
        "FROM publishers WHERE participant_id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;
    sqlite3_bind_text(stmt, 1, participant_id.c_str(), -1, SQLITE_STATIC);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Publisher p;
        p.id             = getString(stmt, 0);
        p.participant_id = getString(stmt, 1);
        p.name           = getString(stmt, 2);
        p.qos_profile_id = getString(stmt, 3);
        p.description    = getString(stmt, 4);
        p.ea_guid        = getString(stmt, 5);
        p.ea_stereotype  = getString(stmt, 6);
        p.source         = getString(stmt, 7);
        result.push_back(p);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// subscribers
// ============================================================
bool SQLiteRepository::saveSubscriber(const Subscriber& s) {
    std::string sql =
        "INSERT OR REPLACE INTO subscribers "
        "(id, participant_id, name, qos_profile_id, description, "
        " ea_guid, ea_stereotype, source, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,datetime('now'),datetime('now'));";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }
    sqlite3_bind_text(stmt, 1, s.id.c_str(),             -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, s.participant_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, s.name.c_str(),           -1, SQLITE_STATIC);
    s.qos_profile_id.empty() ? sqlite3_bind_null(stmt, 4) :
        sqlite3_bind_text(stmt, 4, s.qos_profile_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5, s.description.c_str(),   -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 6, s.ea_guid.c_str(),       -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 7, s.ea_stereotype.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 8, s.source.c_str(),        -1, SQLITE_STATIC);
    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

std::vector<Subscriber> SQLiteRepository::loadSubscribers(
    const std::string& participant_id)
{
    std::vector<Subscriber> result;
    const char* sql =
        "SELECT id, participant_id, name, qos_profile_id, description, "
        "       ea_guid, ea_stereotype, source "
        "FROM subscribers WHERE participant_id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;
    sqlite3_bind_text(stmt, 1, participant_id.c_str(), -1, SQLITE_STATIC);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Subscriber s;
        s.id             = getString(stmt, 0);
        s.participant_id = getString(stmt, 1);
        s.name           = getString(stmt, 2);
        s.qos_profile_id = getString(stmt, 3);
        s.description    = getString(stmt, 4);
        s.ea_guid        = getString(stmt, 5);
        s.ea_stereotype  = getString(stmt, 6);
        s.source         = getString(stmt, 7);
        result.push_back(s);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// writers
// ============================================================
bool SQLiteRepository::saveWriter(const Writer& w) {
    std::string sql =
        "INSERT OR REPLACE INTO writers "
        "(id, publisher_id, topic_id, name, qos_profile_id, description, "
        " ea_guid, ea_stereotype, source, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'));";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }
    sqlite3_bind_text(stmt, 1, w.id.c_str(),           -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, w.publisher_id.c_str(), -1, SQLITE_STATIC);
    w.topic_id.empty() ? sqlite3_bind_null(stmt, 3) :
        sqlite3_bind_text(stmt, 3, w.topic_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4, w.name.c_str(),          -1, SQLITE_STATIC);
    w.qos_profile_id.empty() ? sqlite3_bind_null(stmt, 5) :
        sqlite3_bind_text(stmt, 5, w.qos_profile_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 6, w.description.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 7, w.ea_guid.c_str(),      -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 8, w.ea_stereotype.c_str(),-1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 9, w.source.c_str(),       -1, SQLITE_STATIC);
    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

std::vector<Writer> SQLiteRepository::loadWriters(
    const std::string& publisher_id)
{
    std::vector<Writer> result;
    const char* sql =
        "SELECT id, publisher_id, topic_id, name, qos_profile_id, "
        "       description, ea_guid, ea_stereotype, source "
        "FROM writers WHERE publisher_id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;
    sqlite3_bind_text(stmt, 1, publisher_id.c_str(), -1, SQLITE_STATIC);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Writer w;
        w.id             = getString(stmt, 0);
        w.publisher_id   = getString(stmt, 1);
        w.topic_id       = getString(stmt, 2);
        w.name           = getString(stmt, 3);
        w.qos_profile_id = getString(stmt, 4);
        w.description    = getString(stmt, 5);
        w.ea_guid        = getString(stmt, 6);
        w.ea_stereotype  = getString(stmt, 7);
        w.source         = getString(stmt, 8);
        result.push_back(w);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// readers
// ============================================================
bool SQLiteRepository::saveReader(const Reader& r) {
    std::string sql =
        "INSERT OR REPLACE INTO readers "
        "(id, subscriber_id, topic_id, name, qos_profile_id, description, "
        " ea_guid, ea_stereotype, source, "
        " created_at, updated_at) "
        "VALUES (?,?,?,?,?,?,?,?,?,datetime('now'),datetime('now'));";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }
    sqlite3_bind_text(stmt, 1, r.id.c_str(),            -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, r.subscriber_id.c_str(), -1, SQLITE_STATIC);
    r.topic_id.empty() ? sqlite3_bind_null(stmt, 3) :
        sqlite3_bind_text(stmt, 3, r.topic_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4, r.name.c_str(),          -1, SQLITE_STATIC);
    r.qos_profile_id.empty() ? sqlite3_bind_null(stmt, 5) :
        sqlite3_bind_text(stmt, 5, r.qos_profile_id.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 6, r.description.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 7, r.ea_guid.c_str(),      -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 8, r.ea_stereotype.c_str(),-1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 9, r.source.c_str(),       -1, SQLITE_STATIC);
    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

std::vector<Reader> SQLiteRepository::loadReaders(
    const std::string& subscriber_id)
{
    std::vector<Reader> result;
    const char* sql =
        "SELECT id, subscriber_id, topic_id, name, qos_profile_id, "
        "       description, ea_guid, ea_stereotype, source "
        "FROM readers WHERE subscriber_id = ?;";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK)
        return result;
    sqlite3_bind_text(stmt, 1, subscriber_id.c_str(), -1, SQLITE_STATIC);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        Reader r;
        r.id             = getString(stmt, 0);
        r.subscriber_id  = getString(stmt, 1);
        r.topic_id       = getString(stmt, 2);
        r.name           = getString(stmt, 3);
        r.qos_profile_id = getString(stmt, 4);
        r.description    = getString(stmt, 5);
        r.ea_guid        = getString(stmt, 6);
        r.ea_stereotype  = getString(stmt, 7);
        r.source         = getString(stmt, 8);
        result.push_back(r);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// audit_log
// ============================================================
bool SQLiteRepository::saveAuditLog(const AuditLog& log) {
    std::string sql =
        "INSERT INTO audit_log "
        "(id, project_id, target_kind, target_id, action, "
        " changed_by, changed_at, diff) "
        "VALUES (?,?,?,?,?,?,datetime('now'),?);";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return false;
    }
    sqlite3_bind_text(stmt, 1, log.id.c_str(),          -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 2, log.project_id.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 3, log.target_kind.c_str(), -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 4, log.target_id.c_str(),   -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 5, log.action.c_str(),      -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 6, log.changed_by.c_str(),  -1, SQLITE_STATIC);
    sqlite3_bind_text(stmt, 7, log.diff.c_str(),        -1, SQLITE_STATIC);
    bool ok = (sqlite3_step(stmt) == SQLITE_DONE);
    if (!ok) last_error_ = sqlite3_errmsg(db_);
    sqlite3_finalize(stmt);
    return ok;
}

std::vector<AuditLog> SQLiteRepository::loadAuditLogs(
    const std::string& project_id,
    int limit)
{
    std::vector<AuditLog> result;
    std::string sql =
        "SELECT id, project_id, target_kind, target_id, action, "
        "       changed_by, changed_at, diff "
        "FROM audit_log WHERE project_id = ? "
        "ORDER BY changed_at DESC LIMIT " + std::to_string(limit) + ";";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK)
        return result;
    sqlite3_bind_text(stmt, 1, project_id.c_str(), -1, SQLITE_STATIC);
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        AuditLog log;
        log.id          = getString(stmt, 0);
        log.project_id  = getString(stmt, 1);
        log.target_kind = getString(stmt, 2);
        log.target_id   = getString(stmt, 3);
        log.action      = getString(stmt, 4);
        log.changed_by  = getString(stmt, 5);
        log.changed_at  = getString(stmt, 6);
        log.diff        = getString(stmt, 7);
        result.push_back(log);
    }
    sqlite3_finalize(stmt);
    return result;
}

} // namespace Repo
