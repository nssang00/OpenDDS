#pragma once
#include <string>
#include <vector>
#include <map>
#include <set>
#include <functional>
#include "../ea/EAModels.h"
#include "../ea/EAReader.h"
#include "../repository/IRepository.h"

namespace Converter {

struct ConvertResult {
    int packages      = 0;
    int types         = 0;
    int type_members  = 0;
    int domains       = 0;
    int register_types= 0;
    int topics        = 0;
    int participants  = 0;
    int publishers    = 0;
    int subscribers   = 0;
    int writers       = 0;
    int readers       = 0;
    std::vector<std::string> warnings;
    std::vector<std::string> errors;
};

// EAConverter
// Converts EA Model -> Repository
// Supports root package filtering to extract only DDS-related elements
class EAConverter {
public:
    EAConverter(EA::EAReader& reader, Repo::IRepository& repo);

    // Convert with optional root package name filter
    // If root_package_name is empty, all DDS-stereotyped objects are included
    ConvertResult convert(const std::string& project_id,
                          const std::string& qea_path,
                          const std::string& root_package_name = "");

private:
    EA::EAReader&       reader_;
    Repo::IRepository&  repo_;

    // ea_guid -> Repository id cache
    std::map<std::string, std::string> pkg_guid_to_id_;
    std::map<int, std::string>         pkg_id_to_repo_id_;
    std::map<std::string, std::string> type_guid_to_id_;
    std::map<std::string, std::string> domain_guid_to_id_;
    std::map<std::string, std::string> topic_guid_to_id_;
    std::map<int, std::string>         obj_id_to_type_id_;
    std::map<int, std::string>         obj_id_to_domain_id_;
    std::map<int, std::string>         obj_id_to_topic_id_;
    std::map<int, std::string>         obj_id_to_participant_id_;
    std::map<int, std::string>         obj_id_to_publisher_id_;
    std::map<int, std::string>         obj_id_to_subscriber_id_;

    void convertPackages(const std::string& project_id,
                         const std::set<int>& required_pkg_ids,
                         const std::vector<EA::EAPackage>& all_packages,
                         ConvertResult& result);

    void convertObjects(const std::string& project_id,
                        const std::vector<EA::EAObject>& objects,
                        ConvertResult& result);

    void convertToType       (const std::string& project_id, const EA::EAObject& obj, ConvertResult& result);
    void convertToDomain     (const std::string& project_id, const EA::EAObject& obj, ConvertResult& result);
    void convertToTopic      (const std::string& project_id, const EA::EAObject& obj, ConvertResult& result);
    void convertToParticipant(const std::string& project_id, const EA::EAObject& obj, ConvertResult& result);
    void convertToPublisher  (const std::string& project_id, const EA::EAObject& obj, ConvertResult& result);
    void convertToSubscriber (const std::string& project_id, const EA::EAObject& obj, ConvertResult& result);
    void convertToWriter     (const std::string& project_id, const EA::EAObject& obj, ConvertResult& result);
    void convertToReader     (const std::string& project_id, const EA::EAObject& obj, ConvertResult& result);

    void convertAttributes(const std::string& project_id,
                           const std::vector<EA::EAAttribute>& attributes,
                           const std::vector<EA::EAAttributeTag>& attr_tags,
                           ConvertResult& result);

    void processObjectProperties(const std::vector<EA::EAObjectProperty>& props,
                                 ConvertResult& result);

    void processConnectors(const std::vector<EA::EAConnector>& connectors,
                           ConvertResult& result);

    std::string resolveTypeKind(const std::string& object_type,
                                const std::string& stereotype);

    std::string resolvePrimitiveType(const std::string& ea_type);

    void resolveCollection(const std::string& lower_bound,
                           const std::string& upper_bound,
                           Repo::TypeMember& member);

    std::string resolveMemberKind(const std::string& type_kind,
                                  const std::string& ea_stereotype);

    std::string generateUUID();
};

} // namespace Converter
