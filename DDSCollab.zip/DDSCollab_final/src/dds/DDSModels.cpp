#include "DDSModels.h"
#include <sstream>
#include <algorithm>

namespace DDS {

// ============================================================
// JSON 헬퍼
// ============================================================
static std::string jsonStr(const std::string& s) {
    std::string r = "\"";
    for (char c : s) {
        switch (c) {
            case '"':  r += "\\\""; break;
            case '\\': r += "\\\\"; break;
            case '\n': r += "\\n";  break;
            case '\r': r += "\\r";  break;
            case '\t': r += "\\t";  break;
            default:   r += c;      break;
        }
    }
    r += "\"";
    return r;
}
static std::string jsonBool(bool v) { return v ? "true" : "false"; }
static std::string jsonInt(int v)   { return std::to_string(v); }

// ============================================================
// Any 헬퍼 - VariantDict / VariantList 생성
// ============================================================
static Any makeDict() {
    return Any(VariantDict());
}
static Any makeList() {
    return Any(VariantList());
}
static void dictSet(Any& dict, const std::string& key, const Any& val) {
    AnyCast<VariantDict&>(dict)[key] = val;
}
static void listPush(Any& list, const Any& val) {
    AnyCast<VariantList&>(list).push_back(val);
}

// ============================================================
// DDSMember
// ============================================================
Any DDSMember::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",            Any(id));
    dictSet(m, "name",          Any(name));
    dictSet(m, "ordinal",       Any(ordinal));
    dictSet(m, "member_kind",   Any(member_kind));
    dictSet(m, "primitive_type",Any(primitive_type));
    dictSet(m, "ref_type_id",   Any(ref_type_id));
    dictSet(m, "ref_type_name", Any(ref_type_name));
    dictSet(m, "ea_type_name",  Any(ea_type_name));
    dictSet(m, "is_sequence",   Any(is_sequence));
    dictSet(m, "sequence_bound",Any(sequence_bound));
    dictSet(m, "is_array",      Any(is_array));
    dictSet(m, "string_bound",  Any(string_bound));
    dictSet(m, "is_key",        Any(is_key));
    dictSet(m, "is_optional",   Any(is_optional));
    dictSet(m, "default_value", Any(default_value));
    dictSet(m, "description",   Any(description));
    dictSet(m, "ea_guid",       Any(ea_guid));
    dictSet(m, "source",        Any(source));

    Any dims = makeList();
    for (int d : array_dimensions) listPush(dims, Any(d));
    dictSet(m, "array_dimensions", dims);

    Any labels = makeList();
    for (const auto& l : case_labels) listPush(labels, Any(l));
    dictSet(m, "case_labels", labels);

    if (has_enum_value) dictSet(m, "enum_value", Any(enum_value));
    return m;
}

std::string DDSMember::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"            << jsonStr(id)            << ",";
    ss << "\"name\":"          << jsonStr(name)          << ",";
    ss << "\"ordinal\":"       << jsonInt(ordinal)       << ",";
    ss << "\"member_kind\":"   << jsonStr(member_kind)   << ",";
    ss << "\"primitive_type\":" << jsonStr(primitive_type) << ",";
    ss << "\"ref_type_id\":"   << jsonStr(ref_type_id)   << ",";
    ss << "\"ref_type_name\":" << jsonStr(ref_type_name) << ",";
    ss << "\"ea_type_name\":"  << jsonStr(ea_type_name)  << ",";
    ss << "\"is_sequence\":"   << jsonBool(is_sequence)  << ",";
    ss << "\"sequence_bound\":" << jsonInt(sequence_bound) << ",";
    ss << "\"is_array\":"      << jsonBool(is_array)     << ",";
    ss << "\"array_dimensions\":[";
    for (size_t i = 0; i < array_dimensions.size(); ++i) {
        if (i > 0) ss << ",";
        ss << array_dimensions[i];
    }
    ss << "],";
    ss << "\"string_bound\":"  << jsonInt(string_bound)  << ",";
    ss << "\"is_key\":"        << jsonBool(is_key)       << ",";
    ss << "\"is_optional\":"   << jsonBool(is_optional)  << ",";
    ss << "\"default_value\":" << jsonStr(default_value) << ",";
    ss << "\"description\":"   << jsonStr(description)   << ",";
    ss << "\"ea_guid\":"       << jsonStr(ea_guid)       << ",";
    ss << "\"source\":"        << jsonStr(source);
    if (has_enum_value) ss << ",\"enum_value\":" << jsonInt(enum_value);
    if (!case_labels.empty()) {
        ss << ",\"case_labels\":[";
        for (size_t i = 0; i < case_labels.size(); ++i) {
            if (i > 0) ss << ",";
            ss << jsonStr(case_labels[i]);
        }
        ss << "]";
    }
    ss << "}";
    return ss.str();
}

// ============================================================
// DDSType
// ============================================================
Any DDSType::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",             Any(id));
    dictSet(m, "name",           Any(name));
    dictSet(m, "kind",           Any(kind));
    dictSet(m, "base_type_id",   Any(base_type_id));
    dictSet(m, "base_type_name", Any(base_type_name));
    dictSet(m, "extensibility",  Any(extensibility));
    dictSet(m, "description",    Any(description));
    dictSet(m, "ea_guid",        Any(ea_guid));
    dictSet(m, "ea_stereotype",  Any(ea_stereotype));
    dictSet(m, "source",         Any(source));
    Any ml = makeList();
    for (const auto& mbr : members) listPush(ml, mbr.toAny());
    dictSet(m, "members", ml);
    return m;
}

std::string DDSType::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"            << jsonStr(id)            << ",";
    ss << "\"name\":"          << jsonStr(name)          << ",";
    ss << "\"kind\":"          << jsonStr(kind)          << ",";
    ss << "\"base_type_id\":"  << jsonStr(base_type_id)  << ",";
    ss << "\"base_type_name\":" << jsonStr(base_type_name) << ",";
    ss << "\"extensibility\":" << jsonStr(extensibility) << ",";
    ss << "\"description\":"   << jsonStr(description)   << ",";
    ss << "\"ea_guid\":"       << jsonStr(ea_guid)       << ",";
    ss << "\"ea_stereotype\":" << jsonStr(ea_stereotype) << ",";
    ss << "\"source\":"        << jsonStr(source)        << ",";
    ss << "\"members\":[";
    for (size_t i = 0; i < members.size(); ++i) {
        if (i > 0) ss << ",";
        ss << members[i].toJson();
    }
    ss << "]}";
    return ss.str();
}

// ============================================================
// DDSPackage
// ============================================================
std::string DDSPackage::qualifiedName(const std::string& sep) const {
    return name;
}

Any DDSPackage::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",          Any(id));
    dictSet(m, "name",        Any(name));
    dictSet(m, "kind",        Any(kind));
    dictSet(m, "description", Any(description));
    dictSet(m, "ea_guid",     Any(ea_guid));
    dictSet(m, "source",      Any(source));
    Any tl = makeList();
    for (const auto& t : types) listPush(tl, t.toAny());
    dictSet(m, "types", tl);
    Any cl = makeList();
    for (const auto& c : children) listPush(cl, c.toAny());
    dictSet(m, "children", cl);
    return m;
}

std::string DDSPackage::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"          << jsonStr(id)          << ",";
    ss << "\"name\":"        << jsonStr(name)        << ",";
    ss << "\"kind\":"        << jsonStr(kind)        << ",";
    ss << "\"description\":" << jsonStr(description) << ",";
    ss << "\"ea_guid\":"     << jsonStr(ea_guid)     << ",";
    ss << "\"source\":"      << jsonStr(source)      << ",";
    ss << "\"types\":[";
    for (size_t i = 0; i < types.size(); ++i) {
        if (i > 0) ss << ",";
        ss << types[i].toJson();
    }
    ss << "],\"children\":[";
    for (size_t i = 0; i < children.size(); ++i) {
        if (i > 0) ss << ",";
        ss << children[i].toJson();
    }
    ss << "]}";
    return ss.str();
}

// ============================================================
// DDSQosPolicy
// ============================================================
Any DDSQosPolicy::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",           Any(id));
    dictSet(m, "entity_kind",  Any(entity_kind));
    dictSet(m, "policy_name",  Any(policy_name));
    dictSet(m, "policy_value", Any(policy_value));
    return m;
}

std::string DDSQosPolicy::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"           << jsonStr(id)          << ",";
    ss << "\"entity_kind\":"  << jsonStr(entity_kind) << ",";
    ss << "\"policy_name\":"  << jsonStr(policy_name) << ",";
    ss << "\"policy_value\":" << policy_value;
    ss << "}";
    return ss.str();
}

// ============================================================
// DDSQosProfile
// ============================================================
Any DDSQosProfile::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",              Any(id));
    dictSet(m, "name",            Any(name));
    dictSet(m, "base_profile_id", Any(base_profile_id));
    dictSet(m, "description",     Any(description));
    Any pl = makeList();
    for (const auto& p : policies) listPush(pl, p.toAny());
    dictSet(m, "policies", pl);
    return m;
}

std::string DDSQosProfile::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"              << jsonStr(id)              << ",";
    ss << "\"name\":"            << jsonStr(name)            << ",";
    ss << "\"base_profile_id\":" << jsonStr(base_profile_id) << ",";
    ss << "\"description\":"     << jsonStr(description)     << ",";
    ss << "\"policies\":[";
    for (size_t i = 0; i < policies.size(); ++i) {
        if (i > 0) ss << ",";
        ss << policies[i].toJson();
    }
    ss << "]}";
    return ss.str();
}

// ============================================================
// DDSRegisterType
// ============================================================
Any DDSRegisterType::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",             Any(id));
    dictSet(m, "type_id",        Any(type_id));
    dictSet(m, "type_name",      Any(type_name));
    dictSet(m, "register_name",  Any(register_name));
    dictSet(m, "effective_name", Any(effectiveName()));
    return m;
}

std::string DDSRegisterType::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"             << jsonStr(id)              << ",";
    ss << "\"type_id\":"        << jsonStr(type_id)         << ",";
    ss << "\"type_name\":"      << jsonStr(type_name)       << ",";
    ss << "\"register_name\":"  << jsonStr(register_name)   << ",";
    ss << "\"effective_name\":" << jsonStr(effectiveName());
    ss << "}";
    return ss.str();
}

// ============================================================
// DDSTopic
// ============================================================
Any DDSTopic::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",               Any(id));
    dictSet(m, "name",             Any(name));
    dictSet(m, "domain_id",        Any(domain_id));
    dictSet(m, "register_type_id", Any(register_type_id));
    dictSet(m, "type_name",        Any(type_name));
    dictSet(m, "qos_profile_id",   Any(qos_profile_id));
    dictSet(m, "description",      Any(description));
    dictSet(m, "ea_guid",          Any(ea_guid));
    dictSet(m, "source",           Any(source));
    return m;
}

std::string DDSTopic::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"               << jsonStr(id)               << ",";
    ss << "\"name\":"             << jsonStr(name)             << ",";
    ss << "\"domain_id\":"        << jsonStr(domain_id)        << ",";
    ss << "\"register_type_id\":" << jsonStr(register_type_id) << ",";
    ss << "\"type_name\":"        << jsonStr(type_name)        << ",";
    ss << "\"qos_profile_id\":"   << jsonStr(qos_profile_id)   << ",";
    ss << "\"description\":"      << jsonStr(description)      << ",";
    ss << "\"ea_guid\":"          << jsonStr(ea_guid)          << ",";
    ss << "\"source\":"           << jsonStr(source);
    ss << "}";
    return ss.str();
}

// ============================================================
// DDSDomain
// ============================================================
Any DDSDomain::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",          Any(id));
    dictSet(m, "name",        Any(name));
    dictSet(m, "domain_id",   Any(domain_id));
    dictSet(m, "description", Any(description));
    dictSet(m, "ea_guid",     Any(ea_guid));
    dictSet(m, "source",      Any(source));
    Any rtl = makeList();
    for (const auto& rt : register_types) listPush(rtl, rt.toAny());
    dictSet(m, "register_types", rtl);
    Any tl = makeList();
    for (const auto& t : topics) listPush(tl, t.toAny());
    dictSet(m, "topics", tl);
    return m;
}

std::string DDSDomain::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"          << jsonStr(id)          << ",";
    ss << "\"name\":"        << jsonStr(name)        << ",";
    ss << "\"domain_id\":"   << jsonInt(domain_id)   << ",";
    ss << "\"description\":" << jsonStr(description) << ",";
    ss << "\"ea_guid\":"     << jsonStr(ea_guid)     << ",";
    ss << "\"source\":"      << jsonStr(source)      << ",";
    ss << "\"register_types\":[";
    for (size_t i = 0; i < register_types.size(); ++i) {
        if (i > 0) ss << ",";
        ss << register_types[i].toJson();
    }
    ss << "],\"topics\":[";
    for (size_t i = 0; i < topics.size(); ++i) {
        if (i > 0) ss << ",";
        ss << topics[i].toJson();
    }
    ss << "]}";
    return ss.str();
}

// ============================================================
// DDSWriter / DDSReader
// ============================================================
Any DDSWriter::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",             Any(id));
    dictSet(m, "name",           Any(name));
    dictSet(m, "topic_id",       Any(topic_id));
    dictSet(m, "topic_name",     Any(topic_name));
    dictSet(m, "qos_profile_id", Any(qos_profile_id));
    dictSet(m, "description",    Any(description));
    dictSet(m, "source",         Any(source));
    return m;
}

std::string DDSWriter::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"             << jsonStr(id)             << ",";
    ss << "\"name\":"           << jsonStr(name)           << ",";
    ss << "\"topic_id\":"       << jsonStr(topic_id)       << ",";
    ss << "\"topic_name\":"     << jsonStr(topic_name)     << ",";
    ss << "\"qos_profile_id\":" << jsonStr(qos_profile_id) << ",";
    ss << "\"description\":"    << jsonStr(description)    << ",";
    ss << "\"source\":"         << jsonStr(source);
    ss << "}";
    return ss.str();
}

Any DDSReader::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",             Any(id));
    dictSet(m, "name",           Any(name));
    dictSet(m, "topic_id",       Any(topic_id));
    dictSet(m, "topic_name",     Any(topic_name));
    dictSet(m, "qos_profile_id", Any(qos_profile_id));
    dictSet(m, "description",    Any(description));
    dictSet(m, "source",         Any(source));
    return m;
}

std::string DDSReader::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"             << jsonStr(id)             << ",";
    ss << "\"name\":"           << jsonStr(name)           << ",";
    ss << "\"topic_id\":"       << jsonStr(topic_id)       << ",";
    ss << "\"topic_name\":"     << jsonStr(topic_name)     << ",";
    ss << "\"qos_profile_id\":" << jsonStr(qos_profile_id) << ",";
    ss << "\"description\":"    << jsonStr(description)    << ",";
    ss << "\"source\":"         << jsonStr(source);
    ss << "}";
    return ss.str();
}

// ============================================================
// DDSPublisher / DDSSubscriber
// ============================================================
Any DDSPublisher::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",   Any(id));
    dictSet(m, "name", Any(name));
    Any wl = makeList();
    for (const auto& w : writers) listPush(wl, w.toAny());
    dictSet(m, "writers", wl);
    return m;
}

std::string DDSPublisher::toJson() const {
    std::ostringstream ss;
    ss << "{\"id\":" << jsonStr(id) << ",\"name\":" << jsonStr(name)
       << ",\"writers\":[";
    for (size_t i = 0; i < writers.size(); ++i) {
        if (i > 0) ss << ",";
        ss << writers[i].toJson();
    }
    ss << "]}";
    return ss.str();
}

Any DDSSubscriber::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",   Any(id));
    dictSet(m, "name", Any(name));
    Any rl = makeList();
    for (const auto& r : readers) listPush(rl, r.toAny());
    dictSet(m, "readers", rl);
    return m;
}

std::string DDSSubscriber::toJson() const {
    std::ostringstream ss;
    ss << "{\"id\":" << jsonStr(id) << ",\"name\":" << jsonStr(name)
       << ",\"readers\":[";
    for (size_t i = 0; i < readers.size(); ++i) {
        if (i > 0) ss << ",";
        ss << readers[i].toJson();
    }
    ss << "]}";
    return ss.str();
}

// ============================================================
// DDSParticipant
// ============================================================
Any DDSParticipant::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",          Any(id));
    dictSet(m, "name",        Any(name));
    dictSet(m, "domain_id",   Any(domain_id));
    dictSet(m, "domain_name", Any(domain_name));
    dictSet(m, "description", Any(description));
    dictSet(m, "source",      Any(source));
    Any pl = makeList();
    for (const auto& p : publishers) listPush(pl, p.toAny());
    dictSet(m, "publishers", pl);
    Any sl = makeList();
    for (const auto& s : subscribers) listPush(sl, s.toAny());
    dictSet(m, "subscribers", sl);
    return m;
}

std::string DDSParticipant::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"          << jsonStr(id)          << ",";
    ss << "\"name\":"        << jsonStr(name)        << ",";
    ss << "\"domain_id\":"   << jsonStr(domain_id)   << ",";
    ss << "\"domain_name\":" << jsonStr(domain_name) << ",";
    ss << "\"description\":" << jsonStr(description) << ",";
    ss << "\"source\":"      << jsonStr(source)      << ",";
    ss << "\"publishers\":[";
    for (size_t i = 0; i < publishers.size(); ++i) {
        if (i > 0) ss << ",";
        ss << publishers[i].toJson();
    }
    ss << "],\"subscribers\":[";
    for (size_t i = 0; i < subscribers.size(); ++i) {
        if (i > 0) ss << ",";
        ss << subscribers[i].toJson();
    }
    ss << "]}";
    return ss.str();
}

// ============================================================
// DDSProject
// ============================================================
Any DDSProject::toAny() const {
    Any m = makeDict();
    dictSet(m, "id",          Any(id));
    dictSet(m, "name",        Any(name));
    dictSet(m, "description", Any(description));
    dictSet(m, "version",     Any(version));
    Any pkgl = makeList();
    for (const auto& p : packages) listPush(pkgl, p.toAny());
    dictSet(m, "packages", pkgl);
    Any doml = makeList();
    for (const auto& d : domains) listPush(doml, d.toAny());
    dictSet(m, "domains", doml);
    Any qosl = makeList();
    for (const auto& q : qos_profiles) listPush(qosl, q.toAny());
    dictSet(m, "qos_profiles", qosl);
    Any partl = makeList();
    for (const auto& p : participants) listPush(partl, p.toAny());
    dictSet(m, "participants", partl);
    return m;
}

std::string DDSProject::toJson() const {
    std::ostringstream ss;
    ss << "{";
    ss << "\"id\":"          << jsonStr(id)          << ",";
    ss << "\"name\":"        << jsonStr(name)        << ",";
    ss << "\"description\":" << jsonStr(description) << ",";
    ss << "\"version\":"     << jsonStr(version)     << ",";
    ss << "\"packages\":[";
    for (size_t i = 0; i < packages.size(); ++i) {
        if (i > 0) ss << ",";
        ss << packages[i].toJson();
    }
    ss << "],\"domains\":[";
    for (size_t i = 0; i < domains.size(); ++i) {
        if (i > 0) ss << ",";
        ss << domains[i].toJson();
    }
    ss << "],\"qos_profiles\":[";
    for (size_t i = 0; i < qos_profiles.size(); ++i) {
        if (i > 0) ss << ",";
        ss << qos_profiles[i].toJson();
    }
    ss << "],\"participants\":[";
    for (size_t i = 0; i < participants.size(); ++i) {
        if (i > 0) ss << ",";
        ss << participants[i].toJson();
    }
    ss << "]}";
    return ss.str();
}

} // namespace DDS
