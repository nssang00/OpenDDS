#pragma once
#include "DDSModels.h"
#include "../repository/IRepository.h"
#include <memory>
#include <map>

namespace DDS {

// ============================================================
// DDSLoader
// Repository → DDS Model 로드
// ============================================================
class DDSLoader {
public:
    explicit DDSLoader(Repo::IRepository& repo);

    // 프로젝트 전체 로드
    DDSProject loadProject(const std::string& project_id);

    // 부분 로드
    std::vector<DDSType>    loadTypes(const std::string& project_id);
    std::vector<DDSDomain>  loadDomains(const std::string& project_id);
    std::vector<DDSQosProfile> loadQosProfiles(const std::string& project_id);
    std::vector<DDSParticipant> loadParticipants(const std::string& project_id);

private:
    Repo::IRepository& repo_;

    // 패키지 트리 구성
    std::vector<DDSPackage> buildPackageTree(
        const std::string& project_id);

    // 패키지에 타입 채우기
    void fillPackageTypes(
        DDSPackage& pkg,
        const std::map<std::string, std::vector<DDSType>>& type_map);

    // type_members 로드
    DDSType loadTypeWithMembers(
        const Repo::Type& repo_type,
        const std::map<std::string, std::string>& type_id_to_name);

    DDSMember convertMember(
        const Repo::TypeMember& m,
        const std::map<std::string, std::string>& type_id_to_name);
};

} // namespace DDS
