#include "IDLGenerator.h"
#include <sstream>
#include <algorithm>
#include <functional>

namespace Generator {

// ------------------------------------------------------------
// Indent helper
// ------------------------------------------------------------
std::string IDLGenerator::indent(int level) {
    return std::string(level * 4, ' ');
}

// ------------------------------------------------------------
// Get IDL type string for a member
// ------------------------------------------------------------
std::string IDLGenerator::getMemberTypeStr(const DDS::DDSMember& member) {
    std::string base_type;

    // Determine base type
    if (!member.primitive_type.empty()) {
        // Map DDS primitive types to IDL types
        const std::string& pt = member.primitive_type;
        if (pt == "boolean")  base_type = "boolean";
        else if (pt == "octet")    base_type = "octet";
        else if (pt == "char")     base_type = "char";
        else if (pt == "wchar")    base_type = "wchar";
        else if (pt == "int8")     base_type = "int8";
        else if (pt == "uint8")    base_type = "uint8";
        else if (pt == "int16")    base_type = "short";
        else if (pt == "uint16")   base_type = "unsigned short";
        else if (pt == "int32")    base_type = "long";
        else if (pt == "uint32")   base_type = "unsigned long";
        else if (pt == "int64")    base_type = "long long";
        else if (pt == "uint64")   base_type = "unsigned long long";
        else if (pt == "float32")  base_type = "float";
        else if (pt == "float64")  base_type = "double";
        else if (pt == "float128") base_type = "long double";
        else if (pt == "string") {
            if (member.string_bound > 0)
                return "string<" + std::to_string(member.string_bound) + ">";
            return "string";
        }
        else if (pt == "wstring") {
            if (member.string_bound > 0)
                return "wstring<" + std::to_string(member.string_bound) + ">";
            return "wstring";
        }
        else base_type = pt;
    } else if (!member.ref_type_name.empty()) {
        base_type = member.ref_type_name;
    } else if (!member.ea_type_name.empty()) {
        base_type = member.ea_type_name;
    } else {
        base_type = "long"; // fallback
    }

    // Apply collection wrapper
    if (member.is_sequence) {
        if (member.sequence_bound > 0)
            return "sequence<" + base_type + ", " +
                   std::to_string(member.sequence_bound) + ">";
        return "sequence<" + base_type + ">";
    }
    if (member.is_array && !member.array_dimensions.empty()) {
        // array dimensions are applied after member name in IDL
        // return base type here, dimensions added in member line
        return base_type;
    }
    return base_type;
}

// ------------------------------------------------------------
// Get annotation string for a member
// ------------------------------------------------------------
std::string IDLGenerator::getAnnotationStr(const DDS::DDSMember& member) {
    std::string anno;
    if (member.is_key)      anno += "@key ";
    if (member.is_optional) anno += "@optional ";
    return anno;
}

// ------------------------------------------------------------
// Get extensibility annotation for a type
// ------------------------------------------------------------
std::string IDLGenerator::getExtensibilityAnnotation(const DDS::DDSType& type) {
    if (type.extensibility == "final")    return "@final\n";
    if (type.extensibility == "mutable")  return "@mutable\n";
    // appendable is default, can be omitted or explicit
    return "";
}

// ------------------------------------------------------------
// Helper: vector<int> dimensions -> "3][4" string for IDL
// ------------------------------------------------------------
static std::string dimsToStr(const std::vector<int>& dims) {
    std::string r;
    for (size_t i = 0; i < dims.size(); ++i) {
        if (i > 0) r += "][";
        r += std::to_string(dims[i]);
    }
    return r;
}

// ------------------------------------------------------------
// Generate member IDL line
// ------------------------------------------------------------
std::string IDLGenerator::generateMemberIDL(const DDS::DDSMember& member) {
    std::string line;

    if (member.member_kind == "literal") {
        // enum literal
        line = member.name;
        if (member.has_enum_value)
            line += " = " + std::to_string(member.enum_value);
        return line;
    }

    if (member.member_kind == "discriminator") {
        return ""; // handled in union generation
    }

    if (member.member_kind == "case") {
        // union case: case labels handled separately
        std::string type_str = getMemberTypeStr(member);
        line = type_str + " " + member.name;
        if (member.is_array && !member.array_dimensions.empty())
            line += "[" + dimsToStr(member.array_dimensions) + "]";
        return line;
    }

    // Regular field
    std::string anno = getAnnotationStr(member);
    std::string type_str = getMemberTypeStr(member);
    line = anno + type_str + " " + member.name;

    if (member.is_array && !member.array_dimensions.empty())
        line += "[" + dimsToStr(member.array_dimensions) + "]";

    if (!member.default_value.empty())
        line += " default " + member.default_value;

    return line;
}

// ------------------------------------------------------------
// Generate struct IDL
// ------------------------------------------------------------
std::string IDLGenerator::generateStructIDL(const DDS::DDSType& type,
                                             int ind)
{
    std::ostringstream ss;

    // Extensibility annotation
    std::string ext_anno = getExtensibilityAnnotation(type);
    if (!ext_anno.empty()) ss << indent(ind) << ext_anno;

    // Base type (inheritance)
    if (!type.base_type_name.empty()) {
        ss << indent(ind) << "struct " << type.name
           << " : " << type.base_type_name << " {\n";
    } else {
        ss << indent(ind) << "struct " << type.name << " {\n";
    }

    for (const auto& member : type.members) {
        if (member.member_kind == "field") {
            std::string line = generateMemberIDL(member);
            if (!line.empty())
                ss << indent(ind + 1) << line << ";\n";
        }
    }

    ss << indent(ind) << "};\n";
    return ss.str();
}

// ------------------------------------------------------------
// Generate enum IDL
// ------------------------------------------------------------
std::string IDLGenerator::generateEnumIDL(const DDS::DDSType& type, int ind) {
    std::ostringstream ss;
    ss << indent(ind) << "enum " << type.name << " {\n";

    for (size_t i = 0; i < type.members.size(); ++i) {
        const auto& member = type.members[i];
        if (member.member_kind == "literal") {
            ss << indent(ind + 1) << member.name;
            if (i < type.members.size() - 1) ss << ",";
            ss << "\n";
        }
    }

    ss << indent(ind) << "};\n";
    return ss.str();
}

// ------------------------------------------------------------
// Generate union IDL
// ------------------------------------------------------------
std::string IDLGenerator::generateUnionIDL(const DDS::DDSType& type, int ind) {
    std::ostringstream ss;

    // Find discriminator
    std::string disc_type = "long";
    for (const auto& member : type.members) {
        if (member.member_kind == "discriminator") {
            disc_type = getMemberTypeStr(member);
            break;
        }
    }

    ss << indent(ind) << "union " << type.name
       << " switch(" << disc_type << ") {\n";

    for (const auto& member : type.members) {
        if (member.member_kind == "case") {
            // case labels
            if (member.case_labels.empty()) {
                ss << indent(ind + 1) << "default:\n";
            } else {
                for (const auto& label : member.case_labels) {
                    if (label == "default")
                        ss << indent(ind + 1) << "default:\n";
                    else
                        ss << indent(ind + 1) << "case " << label << ":\n";
                }
            }
            std::string line = generateMemberIDL(member);
            if (!line.empty())
                ss << indent(ind + 2) << line << ";\n";
        }
    }

    ss << indent(ind) << "};\n";
    return ss.str();
}

// ------------------------------------------------------------
// Generate typedef IDL
// ------------------------------------------------------------
std::string IDLGenerator::generateTypedefIDL(const DDS::DDSType& type,
                                              int ind)
{
    std::ostringstream ss;
    std::string base = type.base_type_name.empty()
                       ? type.ea_stereotype : type.base_type_name;
    if (base.empty()) base = "long";
    ss << indent(ind) << "typedef " << base << " " << type.name << ";\n";
    return ss.str();
}

// ------------------------------------------------------------
// Generate IDL for a single type
// ------------------------------------------------------------
std::string IDLGenerator::generateTypeIDL(const DDS::DDSType& type, int ind) {
    if (type.kind == "struct")  return generateStructIDL (type, ind);
    if (type.kind == "enum")    return generateEnumIDL   (type, ind);
    if (type.kind == "union")   return generateUnionIDL  (type, ind);
    if (type.kind == "typedef") return generateTypedefIDL(type, ind);
    // unknown kind -> treat as struct
    return generateStructIDL(type, ind);
}

// ------------------------------------------------------------
// Generate IDL for a package (module), recursive
// ------------------------------------------------------------
std::string IDLGenerator::generatePackageIDL(const DDS::DDSPackage& pkg,
                                              int ind)
{
    std::ostringstream ss;

    bool has_content = !pkg.types.empty() || !pkg.children.empty();
    if (!has_content) return "";

    ss << indent(ind) << "module " << pkg.name << " {\n\n";

    // Types in this package
    for (const auto& type : pkg.types) {
        if (!type.description.empty())
            ss << indent(ind + 1) << "// " << type.description << "\n";
        ss << generateTypeIDL(type, ind + 1);
        ss << "\n";
    }

    // Child packages (nested modules)
    for (const auto& child : pkg.children) {
        std::string child_idl = generatePackageIDL(child, ind + 1);
        if (!child_idl.empty()) ss << child_idl << "\n";
    }

    ss << indent(ind) << "}; // module " << pkg.name << "\n";
    return ss.str();
}

// ------------------------------------------------------------
// Generate IDL for entire project
// ------------------------------------------------------------
std::string IDLGenerator::generateIDL(const DDS::DDSProject& project) {
    std::ostringstream ss;

    // Header comment
    ss << "// DDS IDL - Generated by DDSCollab\n";
    ss << "// Project: " << project.name << "\n";
    if (!project.version.empty())
        ss << "// Version: " << project.version << "\n";
    ss << "\n";

    // Generate modules from packages
    for (const auto& pkg : project.packages) {
        std::string pkg_idl = generatePackageIDL(pkg, 0);
        if (!pkg_idl.empty()) ss << pkg_idl << "\n";
    }

    return ss.str();
}

} // namespace Generator
