#pragma once
#include <string>
#include <sstream>
#include "../dds/DDSModels.h"

namespace Generator {

// IDLGenerator
// Generates DDS IDL from DDS Model
// Compatible with RTI DDS and Fast DDS
class IDLGenerator {
public:
    // Generate IDL for entire project
    std::string generateIDL(const DDS::DDSProject& project);

    // Generate IDL for a single type
    std::string generateTypeIDL(const DDS::DDSType& type, int indent = 0);

    // Generate IDL for a single package (module)
    std::string generatePackageIDL(const DDS::DDSPackage& pkg, int indent = 0);

private:
    std::string generateMemberIDL  (const DDS::DDSMember& member);
    std::string generateStructIDL  (const DDS::DDSType& type, int indent);
    std::string generateEnumIDL    (const DDS::DDSType& type, int indent);
    std::string generateUnionIDL   (const DDS::DDSType& type, int indent);
    std::string generateTypedefIDL (const DDS::DDSType& type, int indent);

    std::string getMemberTypeStr   (const DDS::DDSMember& member);
    std::string getAnnotationStr   (const DDS::DDSMember& member);
    std::string getExtensibilityAnnotation(const DDS::DDSType& type);

    std::string indent(int level);
};

} // namespace Generator
