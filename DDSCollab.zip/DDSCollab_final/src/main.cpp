#include <iostream>
#include <fstream>
#include <string>
#include <functional>
#include "ea/EAReader.h"
#include "ea/EAConverter.h"
#include "repository/SQLiteRepository.h"
#include "dds/DDSModels.h"
#include "dds/DDSLoader.h"
#include "generator/IDLGenerator.h"

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cout << "Usage: DDSCollab <qea_file> <output_db>"
                     " [project_name] [root_package]\n";
        std::cout << "Example: DDSCollab DDS_Example.qea collab.db"
                     " \"MyProject\" \"DDS Example Models\"\n";
        return 1;
    }

    std::string qea_path         = argv[1];
    std::string db_path          = argv[2];
    std::string project_name     = argc > 3 ? argv[3] : "DDS Project";
    std::string root_package     = argc > 4 ? argv[4] : "";

    std::cout << "=== DDS Collab Converter ===\n";
    std::cout << "QEA : " << qea_path     << "\n";
    std::cout << "DB  : " << db_path      << "\n";
    if (!root_package.empty())
        std::cout << "Root: " << root_package << "\n";
    std::cout << "\n";

    // 1. Open repository
    Repo::SQLiteRepository repo;
    if (!repo.open(db_path)) {
        std::cerr << "DB open failed: " << repo.getLastError() << "\n";
        return 1;
    }
    if (!repo.initSchema("dds_collab.sql"))
        std::cout << "[WARN] DDL file not found. Using existing schema.\n";

    Repo::Project project;
    project.id          = "proj-001";
    project.name        = project_name;
    project.description = "Converted from QEA";
    project.version     = "1.0";
    repo.saveProject(project);

    // 2. EA -> Repository conversion
    EA::EAReader reader;
    if (!reader.open(qea_path)) {
        std::cerr << "QEA open failed: " << reader.getLastError() << "\n";
        return 1;
    }

    Converter::EAConverter converter(reader, repo);
    auto result = converter.convert(project.id, qea_path, root_package);
    reader.close();

    std::cout << "=== Conversion Result ===\n";
    std::cout << "packages    : " << result.packages     << "\n";
    std::cout << "types       : " << result.types        << "\n";
    std::cout << "type_members: " << result.type_members << "\n";
    std::cout << "domains     : " << result.domains      << "\n";
    std::cout << "topics      : " << result.topics       << "\n";
    std::cout << "participants: " << result.participants  << "\n";

    for (const auto& e : result.errors)
        std::cerr << "[ERROR] " << e << "\n";
    for (const auto& w : result.warnings)
        std::cout << "[WARN]  " << w << "\n";

    // 3. Load DDS Model
    std::cout << "\n=== Load DDS Model ===\n";
    DDS::DDSLoader loader(repo);
    DDS::DDSProject dds_project = loader.loadProject(project.id);

    std::cout << "Project  : " << dds_project.name << "\n";
    std::cout << "Packages : " << dds_project.packages.size()     << "\n";
    std::cout << "Domains  : " << dds_project.domains.size()      << "\n";
    std::cout << "QoS      : " << dds_project.qos_profiles.size() << "\n";

    int total_types = 0;
    std::function<void(const DDS::DDSPackage&)> countTypes =
        [&](const DDS::DDSPackage& pkg) {
            total_types += (int)pkg.types.size();
            for (const auto& c : pkg.children) countTypes(c);
        };
    for (const auto& pkg : dds_project.packages) countTypes(pkg);
    std::cout << "Types    : " << total_types << "\n";

    // 4. Generate IDL
    std::cout << "\n=== Generate IDL ===\n";
    Generator::IDLGenerator idl_gen;
    std::string idl_content = idl_gen.generateIDL(dds_project);

    std::string idl_path = db_path + ".idl";
    std::ofstream idl_file(idl_path);
    if (idl_file.is_open()) {
        idl_file << idl_content;
        idl_file.close();
        std::cout << "IDL saved: " << idl_path << "\n";
    }

    // Print IDL to console (first 60 lines)
    std::istringstream iss(idl_content);
    std::string line;
    int line_count = 0;
    while (std::getline(iss, line) && line_count < 60) {
        std::cout << line << "\n";
        line_count++;
    }
    if (line_count >= 60)
        std::cout << "...(truncated, see " << idl_path << ")\n";

    // 5. Save JSON
    std::string json_path = db_path + ".json";
    std::ofstream json_file(json_path);
    if (json_file.is_open()) {
        json_file << dds_project.toJson();
        json_file.close();
        std::cout << "\nJSON saved: " << json_path << "\n";
    }

    repo.close();
    std::cout << "\nDone!\n";
    return 0;
}
