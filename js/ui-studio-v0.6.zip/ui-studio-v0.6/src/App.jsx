import React, { useEffect, useRef, useState } from 'react';
import { Button, Input, InputNumber, Select, Segmented, Tag, Tooltip, Typography, Modal, ConfigProvider, message } from 'antd';
import { createProject,createNode,deepCopy,findLocation,isFrame,addChild,moveChild,removeChild,changeNode,duplicateChild,switchLayout,createComponentModule,getTargetRoot,setTargetRoot,parseProjectJson,validateProject,labelOf,resolveBinding,isBinding,COMPONENT_TYPES } from './model.js';
import { VisualElement, RuntimeNode } from './runtime.jsx';
import { layoutStyle, generateDsl, generateTsx } from './generator.js';
import { parseImportedProject } from './legacy.js';
import { printDsl, applyDsl, parseDsl, nodeAtOffset } from './dsl.js';
import './styles.css';
const GROUPS=[{title:'LAYOUT',subtitle:'구조 · Auto Layout',items:[['Frame','Frame / Auto Layout']]},{title:'BASIC',subtitle:'Ant Design 컴포넌트',items:[['Text','Text'],['Button','Button'],['Input','Input'],['Select','Select'],['Checkbox','Checkbox'],['Tag','Tag']]},{title:'DATA & DISPLAY',subtitle:'화면 표시',items:[['Table','DataGrid'],['Card','Card'],['Divider','Divider']]}];
const GLYPHS={Frame:'▦',Text:'T',Button:'▰',Input:'▭',Select:'⌄',Checkbox:'☑',Table:'▤',Card:'▣',Divider:'━',Tag:'◇'};
const ICONS={play:'▶',design:'◫',layers:'☷',code:'</>',json:'{}',export:'↥',import:'↧',undo:'↶',redo:'↷',trash:'⌫',copy:'⧉',save:'▣',plus:'+',zoom:'⊕'};
const isEditableTarget=el=>['INPUT','TEXTAREA','SELECT'].includes(el?.tagName)||el?.isContentEditable;
const downloadable=(text,filename,mime='text/plain')=>{const url=URL.createObjectURL(new Blob([text],{type:mime}));const a=document.createElement('a');a.href=url;a.download=filename;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);};
const fmtName=v=>String(v||'Component').replace(/[^\w-]+/g,'-');

function ToolBox({onAdd,onDragging}){
  return <div className="toolbox">
    <div className="sidebar-title">Elements <span className="subtitle-mini">드래그 또는 클릭</span></div>
    {GROUPS.map(g=><section className="tool-group" key={g.title}><div className="tool-group-name">{g.title}<small>{g.subtitle}</small></div><div className="tool-list">{g.items.map(([type,label])=><button key={type} className={'tool-item '+(type==='Frame'?'tool-frame':'')} draggable onDragStart={e=>{onDragging(true);e.dataTransfer.effectAllowed='copy';e.dataTransfer.setData('application/x-ui-studio',JSON.stringify({kind:'new',type}));e.dataTransfer.setData('text/plain',type);}} onDragEnd={()=>onDragging(false)} onClick={()=>onAdd(type)} title={`${label} 추가`}><span className="tool-icon">{GLYPHS[type]}</span><span>{label}</span><span className="tool-grip">⠿</span></button>)}</div></section>)}
    <div className="help-note">Frame이 레이아웃을 관리합니다. 요소를 Frame 내부로 드래그하거나 선택한 Frame에 클릭으로 추가하세요.</div>
  </div>;
}
function LayerTree({node,selected,onSelect,depth=0,expanded,onToggle,project,onDragging}){
  const children=node.kind==='frame'?node.children:[];
  const instance=node.kind==='instance',isContainer=node.kind==='frame';
  return <>
    <div className={'layer-row '+(selected===node.id?'active':'')} style={{paddingLeft:12+depth*16}} onClick={()=>onSelect(node.id)} title={node.name} draggable={depth>0} onDragStart={e=>{e.stopPropagation();onDragging(true);e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('application/x-ui-studio',JSON.stringify({kind:'move',id:node.id}));e.dataTransfer.setData('text/plain',node.id);}} onDragEnd={()=>onDragging(false)}>
      <span className="tree-chevron" onClick={e=>{e.stopPropagation();onToggle(node.id);}}>{children.length?(expanded[node.id]!==false?'▾':'▸'):'·'}</span>
      <span className={'layer-icon '+(isContainer?'layer-icon-frame':instance?'layer-icon-instance':'')}>{isContainer?'▦':instance?'◇':GLYPHS[node.component]||'□'}</span>
      <span className="layer-name">{labelOf(node)}</span>
      {isContainer&&<span className="layer-meta">{node.layout==='column'?'↓':node.layout==='row'?'→':'▦'}</span>}
    </div>
    {isContainer&&expanded[node.id]!==false&&children.map(child=><LayerTree key={child.id} node={child} selected={selected} onSelect={onSelect} depth={depth+1} expanded={expanded} onToggle={onToggle} project={project} onDragging={onDragging}/>)}
  </>;
}
const onReceiveDrag=(e)=>{try{return JSON.parse(e.dataTransfer.getData('application/x-ui-studio'));}catch{return null;}};
function InsertMark({ownerId,index,drop,dragging,setDrop,onDropAt}){
  const active=drop?.ownerId===ownerId&&drop?.index===index;
  return <div className={'insert-mark '+(active?'insert-active':'')+' '+(dragging?'in-drag':'')} aria-label="삽입 위치" onDragOver={e=>{if(!e.dataTransfer.types.includes('application/x-ui-studio'))return;e.preventDefault();e.stopPropagation();e.dataTransfer.dropEffect='move';setDrop({ownerId,index});}} onDrop={e=>{e.preventDefault();e.stopPropagation();onDropAt(onReceiveDrag(e),ownerId,index);}}><span>＋ 여기 삽입</span></div>;
}
function CanvasNode({node,project,selected,onSelect,dragging,onDragging,drop,setDrop,onDropAt,ctx,onResize,zoom,root=false,depth=0}){
  const active=selected===node.id;
  const nRef=useRef(null);
  if(node.kind==='instance'){
    const m=project.modules[node.moduleId];
    return <div className={'canvas-node canvas-instance '+(active?'node-selected':'')} onClick={e=>{e.stopPropagation();onSelect(node.id);}} style={{width:node.width==='fixed'?node.widthPx:node.width==='fill'?'100%':undefined}}>
      <div className="canvas-node-chip instance-chip">◇ {node.name} · instance</div>
      <div className="instance-inner">{m?<RuntimeNode node={m.root} project={project} ctx={ctx}/>:<div>컴포넌트를 찾을 수 없음</div>}</div><div className="hit-shield"/>
    </div>;
  }
  const layout=isFrame(node);
  const style=layout?{...layoutStyle(node),position:'relative'}:{width:node.width==='fill'?'100%':node.width==='fixed'?`${node.widthPx}px`:'fit-content',minWidth:0};
  function onDragOver(e){
    if(!e.dataTransfer.types.includes('application/x-ui-studio'))return;
    e.preventDefault();e.stopPropagation();e.dataTransfer.dropEffect='move';
    if(layout)setDrop({ownerId:node.id,index:node.children.length});
    else {
      const parent=nRef.current?.parentElement?.closest('[data-frame-id]');
      if(!parent)return;
      const parentId=parent.getAttribute('data-frame-id');
      const frame=findLocation(getTargetRoot(project,'page'),parentId)?.node || Object.values(project.modules).map(m=>findLocation(m.root,parentId)?.node).find(Boolean);
      const at=findLocationInView(parent,node.id);
      const r=nRef.current.getBoundingClientRect();
      const horizontal=frame?.layout==='row';
      const mid=horizontal?r.left+r.width/2:r.top+r.height/2;
      const before=horizontal?e.clientX<mid:e.clientY<mid;
      setDrop({ownerId:parentId,index:Math.max(0,at+(before?0:1))});
    }
  }
  function findLocationInView(parent,childId){return [...parent.children].filter(el=>el?.dataset?.nodeId).findIndex(el=>el.dataset.nodeId===childId);}
  function onDrop(e){if(!e.dataTransfer.types.includes('application/x-ui-studio'))return;e.preventDefault();e.stopPropagation();
    if(layout)onDropAt(onReceiveDrag(e),node.id,node.children.length);
    else if(drop)onDropAt(onReceiveDrag(e),drop.ownerId,drop.index);
  }
  function startResize(e){e.stopPropagation();e.preventDefault();onResize(node.id,nRef.current?.getBoundingClientRect()?.width||220,e.clientX,zoom);}
  return <div ref={nRef} data-node-id={node.id} data-frame-id={layout?node.id:undefined} className={'canvas-node '+(layout?'canvas-frame frame-'+node.layout:'canvas-component')+' '+(active?'node-selected':'')+' '+(root?'canvas-root':'')} style={style} onClick={e=>{e.stopPropagation();onSelect(node.id);}} onDragOver={onDragOver} onDrop={onDrop}>
    <div className={'canvas-node-chip '+(layout?'frame-chip':'element-chip')}><span>{layout?'▦':'□'}</span> {node.name}<small>{layout?node.layout.toUpperCase():node.component}</small></div>
    {active&&!root&&<div className="move-handle" draggable title="이동" onDragStart={e=>{e.stopPropagation();onDragging(true);e.dataTransfer.effectAllowed='move';e.dataTransfer.setData('application/x-ui-studio',JSON.stringify({kind:'move',id:node.id}));e.dataTransfer.setData('text/plain',node.id);}} onDragEnd={()=>onDragging(false)}>⠿</div>}
    {layout?(
      <>{node.children.length===0&&<div className="frame-empty">+ 요소를 여기에 놓으세요</div>}
        {node.children.map((child,i)=><React.Fragment key={child.id}><InsertMark ownerId={node.id} index={i} drop={drop} dragging={dragging} setDrop={setDrop} onDropAt={onDropAt}/><CanvasNode node={child} project={project} selected={selected} onSelect={onSelect} dragging={dragging} onDragging={onDragging} drop={drop} setDrop={setDrop} onDropAt={onDropAt} ctx={ctx} onResize={onResize} zoom={zoom} depth={depth+1}/></React.Fragment>)}
        <InsertMark ownerId={node.id} index={node.children.length} drop={drop} dragging={dragging} setDrop={setDrop} onDropAt={onDropAt}/>
      </>
    ):<><div className="actual-component"><VisualElement node={node} project={project} ctx={ctx} editing/></div><div className="hit-shield"/></>}
    {active&&!root&&<span className="resize-east" onPointerDown={startResize} title="드래그해서 너비 조절"/>}
  </div>;
}
const previewValue=(v)=>{if(v===undefined)return '⚠ 경로에 값이 없습니다';if(Array.isArray(v))return `Array(${v.length}): ${JSON.stringify(v.slice(0,2)).slice(0,170)}`;if(v&&typeof v==='object')return JSON.stringify(v).slice(0,190);return String(v);};
function bindingPaths(data){
  const result=[];
  function walk(value,path,depth){if(depth>3||result.length>90)return;result.push({path,value});if(value&&typeof value==='object'){for(const [k,v] of Object.entries(value)){if(!/^[A-Za-z_$][\w$]*$/.test(k))continue;walk(v,`${path}.${k}`,depth+1);}}}
  for(const [k,v] of Object.entries(data.state||{}))walk(v,`state.${k}`,0);
  for(const [k,v] of Object.entries(data.sources||{}))walk(v,`sources.${k}`,0);
  return result;
}
function BindingInput({label,value,onChange,data}){
  const ctx={state:data.state,sources:data.sources},paths=bindingPaths(data);
  const bind=v=>onChange(`{{${v}}}`);
  const valid=!String(value||'').includes('{{')||isBinding(value);
  return <div className="property-field binding-field" onDragOver={e=>{if(e.dataTransfer.types.includes('application/x-ui-binding'))e.preventDefault();}} onDrop={e=>{const path=e.dataTransfer.getData('application/x-ui-binding');if(path){e.preventDefault();bind(path);}}}>
    <label>{label} <span className="bind-hint">◎ 데이터 경로를 이곳에 놓으세요</span></label>
    <Input size="small" value={value||''} status={valid?'':'error'} onChange={e=>onChange(e.target.value)} placeholder="{{state.keyword}}" list={`paths-${label.replace(/\W/g,'')}`}/>
    <datalist id={`paths-${label.replace(/\W/g,'')}`}>{paths.map(p=><option key={p.path} value={`{{${p.path}}}`}/>)}</datalist>
    <div className={'binding-evaluation '+(!valid?'bind-invalid':'')}><strong>{!valid?'지원하지 않는 바인딩 문법':'현재 평가값'}</strong><span>{valid?previewValue(resolveBinding(value,ctx)):'{{state.key}} 또는 {{sources.name}} 형식만 지원'}</span></div>
  </div>;
}
function DataTree({project,onBind}){
  return <div className="data-tree"><div className="sidebar-title">Data <span className="subtitle-mini">끌어다 연결</span></div>
    <p className="data-instructions">오른쪽 Binding 속성에 끌어 놓거나 경로를 클릭해 선택된 요소에 연결할 수 있습니다.</p>
    {['state','sources'].map(group=><section key={group}><div className="tool-group-name">{group.toUpperCase()}</div>
      {bindingPaths({state:group==='state'?project.data.state:{},sources:group==='sources'?project.data.sources:{}}).filter(({path})=>path.split('.').length<=3).map(({path,value})=><button key={path} className="data-path" draggable onDragStart={e=>{e.dataTransfer.setData('application/x-ui-binding',path);e.dataTransfer.setData('text/plain',`{{${path}}}`);}} onClick={()=>onBind(path)} title="클릭: 선택된 요소에 바인딩"><span>⠿</span><span>{path}</span><small>{Array.isArray(value)?`[${value.length}]`:typeof value}</small></button>)}
    </section>)}
  </div>;
}
function CodeEditor({draft,error,onChange,onCaret,codeRef,ranges,selected,onExport}){
  const gutterRef=useRef(null);
  const lines=draft.split('\n');const r=ranges?.[selected];const highlighted=r?draft.slice(0,r.start).split('\n').length:0;
  return <div className="dsl-editor"><div className="dsl-editor-label"><strong>JSX-style UI DSL</strong><span className="dsl-status">{error?<span className="dsl-error" title={error}>⚠ {error}</span>:<span className="dsl-ok">● 동기화됨</span>} <button className="dsl-export" onClick={onExport}>DSL 저장</button></span></div>
    <div className="dsl-editor-body"><div ref={gutterRef} className="dsl-lines" aria-hidden="true">{lines.map((_,i)=><div key={i} className={highlighted===i+1?'code-current-line':''}>{i+1}</div>)}</div>
    <textarea ref={codeRef} className="dsl-textarea" value={draft} spellCheck={false} onChange={e=>onChange(e.target.value,e.target.selectionStart)} onClick={onCaret} onKeyUp={onCaret} onScroll={e=>{if(gutterRef.current)gutterRef.current.scrollTop=e.currentTarget.scrollTop;}} aria-label="JSX 스타일 UI DSL 편집"/></div>
    <div className="dsl-editor-footer">nodeId는 Design↔Code 연결에 사용됩니다. 자유로운 JavaScript 표현식은 지원하지 않습니다.</div>
  </div>;
}
function PropertyPanel({node,rootId,project,onPatch,onDelete,onDuplicate,onModule,onEditModule,target}){
  const layout=node?.kind==='frame',instance=node?.kind==='instance',p=node?.props||{};
  const patch=(key,value)=>onPatch(n=>{n[key]=value;});
  const prop=(key,value)=>onPatch(n=>{n.props={...n.props,[key]:value};});
  const field=(label,content,hint)=> <div className="property-field"><label>{label}</label>{content}{hint&&<small className="prop-hint">{hint}</small>}</div>;
  const text=(label,key,valueSetter=prop)=>field(label,<Input size="small" value={valueSetter===patch?node[key]??'':p[key]??''} onChange={e=>valueSetter(key,e.target.value)}/>);
  const number=(label,key,min=0,max=1500)=>field(label,<InputNumber size="small" style={{width:'100%'}} min={min} max={max} value={node[key]||0} onChange={v=>patch(key,v??0)}/>);
  const select=(label,value,items,cb)=>field(label,<Select size="small" style={{width:'100%'}} value={value} options={items.map(x=>({label:x[1],value:x[0]}))} onChange={cb}/>);
  if(!node)return <div className="properties"><div className="sidebar-title">Inspector</div><div className="prop-empty">캔버스 또는 Layers에서 요소를 선택하세요.</div></div>;
  const module=instance?project.modules[node.moduleId]:null;
  return <div className="properties"><div className="sidebar-title">Inspector <span className="subtitle-mini">속성 편집</span></div>
    <div className={'inspector-type '+(layout?'inspect-frame':'inspect-control')}><span>{layout?'▦ FRAME':instance?'◇ INSTANCE':'□ COMPONENT'}</span><strong>{layout?'Frame':instance?module?.name||'Module':node.component}</strong></div>
    <div className="prop-section-title">GENERAL</div>
    {field('Name',<Input size="small" value={node.name} onChange={e=>patch('name',e.target.value)}/>)}
    {select('Width',node.width,[['hug','Hug contents'],['fill','Fill available'],['fixed','Fixed (px)']],v=>patch('width',v))}
    {node.width==='fixed'&&number('Width(px)','widthPx',60,2000)}
    {layout&&<>
      <div className="prop-section-title">AUTO LAYOUT</div>
      {field('Direction / mode',<Segmented block size="small" value={node.layout} onChange={v=>patch('layout',v)} options={[{label:'↓',value:'column',title:'Column'},{label:'→',value:'row',title:'Row'},{label:'▦',value:'grid',title:'Grid'}]}/>)}
      {node.layout==='grid'&&number('Grid columns','columns',1,8)}
      {number('Gap (px)','gap',0,96)}{number('Padding (px)','padding',0,120)}
      {select('Alignment',node.align,[['stretch','Stretch'],['start','Start'],['center','Center'],['end','End']],v=>patch('align',v))}
      {node.layout==='row'&&field('Wrap',<Segmented block size="small" value={node.wrap?'yes':'no'} options={[{label:'No wrap',value:'no'},{label:'Wrap',value:'yes'}]} onChange={v=>patch('wrap',v==='yes')}/>)}
      {number('Min height (px)','minHeight',0,2000)}
      {field('Background',<div className="color-pick"><input type="color" value={/^#[0-9a-fA-F]{6}$/.test(node.background)?node.background:'#ffffff'} onChange={e=>patch('background',e.target.value)}/><Input size="small" value={node.background} onChange={e=>patch('background',e.target.value)} /></div>)}
    </>}
    {node.kind==='component'&&<>
      <div className="prop-section-title">COMPONENT</div>
      {['Text','Button','Tag','Checkbox'].includes(node.component)&&text('Text','text')}
      {['Input','Select'].includes(node.component)&&text('Label','label')}
      {node.component==='Input'&&text('Placeholder','placeholder')}
      {node.component==='Text'&&select('Typography',p.weight,[['normal','Body'],['heading','Heading']],v=>prop('weight',v))}
      {node.component==='Button'&&select('Variant',p.variant,[['default','Default'],['primary','Primary']],v=>prop('variant',v))}
      {node.component==='Select'&&text('Options (comma-separated)','options')}
      {['Table','Card'].includes(node.component)&&text('Title','title')}
      {node.component==='Table'&&text('Columns (comma-separated)','columns')}
      {node.component==='Card'&&text('Description','description')}
      {node.component==='Tag'&&select('Color',p.color,[['blue','Blue'],['green','Green'],['orange','Orange'],['red','Red']],v=>prop('color',v))}
      {['Input','Table','Text'].includes(node.component)&&<>
        <div className="prop-section-title">BINDING</div>
        {node.component==='Input'&&<BindingInput label="Value expression" value={p.valueBinding} onChange={v=>prop('valueBinding',v)} data={project.data}/>}
        {node.component==='Text'&&<BindingInput label="Text binding (optional)" value={p.valueBinding} onChange={v=>prop('valueBinding',v)} data={project.data}/>}
        {node.component==='Table'&&<><BindingInput label="Rows" value={p.rowsBinding} onChange={v=>prop('rowsBinding',v)} data={project.data}/><BindingInput label="Filter" value={p.filterBinding} onChange={v=>prop('filterBinding',v)} data={project.data}/></>}
      </>}
      {node.component==='Button'&&<><div className="prop-section-title">EVENT</div>{select('On click',p.action?.type||'message',[['message','Show message'],['clear','Clear state']],v=>prop('action',{type:v,target:'keyword',message:'버튼을 클릭했습니다.'}))}{p.action?.type==='clear'?field('State key',<Input size="small" value={p.action.target||''} onChange={e=>prop('action',{...p.action,target:e.target.value})}/>):field('Message',<Input size="small" value={p.action?.message||''} onChange={e=>prop('action',{...p.action,message:e.target.value})}/>)}</>}
    </>}
    {instance&&<div className="property-field"><p className="prop-hint">공유 정의를 참조하는 인스턴스입니다. 내부 요소는 모듈 편집 모드에서 수정하세요.</p><Button size="small" block onClick={()=>onEditModule(node.moduleId)}>공유 컴포넌트 편집 ↗</Button></div>}
    <div className="inspector-bottom">
      {layout&&target!=='page'&&<div className="prop-hint">현재 공유 컴포넌트를 편집하는 중입니다.</div>}
      {layout&&node.id!==rootId&&<Button block size="small" onClick={onModule}>◇ 공유 컴포넌트로 만들기</Button>}
      <div className="prop-actions"><Button size="small" onClick={onDuplicate} disabled={node.id===rootId}>⧉ 복제</Button><Button size="small" danger onClick={onDelete} disabled={node.id===rootId}>⌫ 삭제</Button></div>
    </div>
  </div>;
}
function App(){
  const [project,setProject]=useState(()=>{
    try{const saved=(localStorage.getItem('ui-studio-v06')||localStorage.getItem('ui-studio-v05'));return saved?parseProjectJson(saved):createProject();}catch{return createProject();}
  });
  const [target,setTarget]=useState('page');
  const [selected,setSelected]=useState('search-row');
  const [activeTab,setActiveTab]=useState('design');
  const [codeDraft,setCodeDraft]=useState(()=>printDsl(project.root).text);
  const [codeRanges,setCodeRanges]=useState(()=>printDsl(project.root).ranges);
  const [codeError,setCodeError]=useState(null);
  const codeEditorRef=useRef(null);
  const changeFromCodeRef=useRef(false);
  const selectionFromCodeRef=useRef(false);
  const [leftTab,setLeftTab]=useState('layers');
  const [dragging,setDragging]=useState(false);
  const [drop,setDrop]=useState(null);
  const [expanded,setExpanded]=useState({});
  const [zoom,setZoom]=useState(75);
  const [device,setDevice]=useState('desktop');
  const [runtimeState,setRuntimeState]=useState(()=>deepCopy(project.data.state));
  const [notice,noticeContext]=message.useMessage();
  const uploadRef=useRef(null);
  const history=useRef({past:[],future:[]});
  const root=getTargetRoot(project,target)||project.root;
  const selectedNode=findLocation(root,selected)?.node || root;
  const ctx={state:activeTab==='preview'?runtimeState:project.data.state,sources:project.data.sources};
  useEffect(()=>{try{localStorage.setItem('ui-studio-v06',JSON.stringify(project));}catch{}},[project]);
  useEffect(()=>{if(changeFromCodeRef.current){changeFromCodeRef.current=false;return;}const result=printDsl(getTargetRoot(project,target)||project.root);setCodeDraft(result.text);setCodeRanges(result.ranges);setCodeError(null);},[project,target]);
  useEffect(()=>{if(activeTab!=='code'||!codeEditorRef.current)return;if(selectionFromCodeRef.current){selectionFromCodeRef.current=false;return;}const range=codeRanges[selected];if(!range)return;const el=codeEditorRef.current;el.setSelectionRange(range.start,range.openEnd);const line=codeDraft.slice(0,range.start).split('\n').length;el.scrollTop=Math.max(0,(line-4)*20);},[selected,activeTab,codeRanges]);
  function commit(next,chosen,fromCode=false){
    if(JSON.stringify(project)===JSON.stringify(next))return;
    if(!validateProject(next)){notice.error('프로젝트 스키마가 유효하지 않습니다.');return;}
    history.current.past.push(project);if(history.current.past.length>60)history.current.past.shift();history.current.future=[];
    if(fromCode)changeFromCodeRef.current=true;
    setProject(next);if(chosen!==undefined)setSelected(chosen);
  }
  function onCodeEdit(value,offset){
    setCodeDraft(value);
    try{
      const {project:next,ranges}=applyDsl(project,target,value);
      setCodeRanges(ranges);setCodeError(null);
      const id=nodeAtOffset(ranges,offset);
      selectionFromCodeRef.current=true;
      if(id)setSelected(id);
      commit(next,id||undefined,true);
    }catch(e){setCodeError(e.message||'문법 오류');}
  }
  function onCodeCaret(e){
    try{const {ranges}=parseDsl(codeDraft);const id=nodeAtOffset(ranges,e.target.selectionStart);if(id&&id!==selected){selectionFromCodeRef.current=true;setSelected(id);}}catch{}
  }
  function chooseDataBinding(path){
    if(selectedNode.kind!=='component')return notice.info('Input, Text, Table 컴포넌트를 먼저 선택하세요.');
    const field=selectedNode.component==='Input'||selectedNode.component==='Text'?'valueBinding':selectedNode.component==='Table'?'rowsBinding':null;
    if(!field)return notice.info('이 요소는 데이터 바인딩 속성이 없습니다.');
    patchSelected(n=>{n.props={...n.props,[field]:`{{${path}}}`};});
    notice.success(`${selectedNode.name}에 ${path} 연결`);
  }
  function editRoot(op,chosen){
    try{const result=op(root);const next=setTargetRoot(project,target,result);commit(next,chosen);}catch(e){notice.warning(e.message||'작업 실패');}
  }
  function chooseTarget(v){if(v==='page'||project.modules[v]){setTarget(v);setSelected(getTargetRoot(project,v)?.id||'page-root');setActiveTab('design');}}
  function add(type){
    const chosen=isFrame(selectedNode)?selectedNode.id:(findLocation(root,selectedNode.id)?.parent?.id||root.id);
    const node=createNode(type);
    editRoot(r=>addChild(r,chosen,node),node.id);
    setLeftTab('layers');
  }
  function onDropAt(data,ownerId,index){
    setDragging(false);setDrop(null);
    if(!data)return;
    if(data.kind==='new'){
      try{const node=createNode(data.type);editRoot(r=>addChild(r,ownerId,node,index),node.id);}catch(e){notice.warning(e.message);}return;
    }
    if(data.kind==='module'){
      const mod=project.modules[data.moduleId];if(!mod)return;
      const id=`instance_${Date.now().toString(36)}_${Math.random().toString(36).slice(2,7)}`;
      const instance={id,kind:'instance',name:mod.name,moduleId:mod.id,width:'fill',widthPx:360};
      editRoot(r=>addChild(r,ownerId,instance,index),id);return;
    }
    if(data.kind==='move')editRoot(r=>moveChild(r,data.id,ownerId,index),data.id);
  }
  function patchSelected(fn){editRoot(r=>changeNode(r,selectedNode.id,fn));}
  function erase(){if(selectedNode.id===root.id)return;const loc=findLocation(root,selectedNode.id);editRoot(r=>removeChild(r,selectedNode.id),loc?.parent?.id||root.id);}
  function duplicate(){try{const r=duplicateChild(root,selectedNode.id);editRoot(()=>r.root,r.id);}catch(e){notice.warning(e.message);}}
  function resize(id,startWidth,startX,z){
    const onMove=e=>{const w=Math.round(Math.max(72,Math.min(1800,startWidth+(e.clientX-startX)/(z/100))));const el=document.querySelector(`[data-node-id="${id}"]`);if(el)el.style.width=`${w}px`;};
    const onUp=e=>{window.removeEventListener('pointermove',onMove);window.removeEventListener('pointerup',onUp);const w=Math.round(Math.max(72,Math.min(1800,startWidth+(e.clientX-startX)/(z/100))));editRoot(r=>changeNode(r,id,n=>{n.width='fixed';n.widthPx=w;}));};
    window.addEventListener('pointermove',onMove);window.addEventListener('pointerup',onUp,{once:true});
  }
  function saveModule(){
    const name=window.prompt('새 공유 컴포넌트 이름',selectedNode.name||'MyComponent');if(name===null)return;
    try{const result=createComponentModule(project,target,selectedNode.id,name);
      if(!validateProject(result.project))throw Error('모듈 순환 참조 또는 스키마 오류');
      commit(result.project,result.instanceId);notice.success(`${name||selectedNode.name} 컴포넌트를 저장했습니다.`);
    }catch(e){notice.warning(e.message);}
  }
  function undo(){const h=history.current;if(!h.past.length)return;h.future.push(project);const prev=h.past.pop();setProject(prev);if(target!=='page'&&!prev.modules[target])setTarget('page');setSelected(null);}
  function redo(){const h=history.current;if(!h.future.length)return;h.past.push(project);const next=h.future.pop();setProject(next);setSelected(null);}
  useEffect(()=>{
    const handle=e=>{
      if(isEditableTarget(e.target))return;
      if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();if(e.shiftKey)redo();else undo();}
      else if((e.key==='Backspace'||e.key==='Delete')&&activeTab==='design'&&selectedNode.id!==root.id){e.preventDefault();erase();}
      else if(e.key==='Escape')setSelected(root.id);
    };
    window.addEventListener('keydown',handle);return()=>window.removeEventListener('keydown',handle);
  });
  async function importFile(e){
    const file=e.target.files?.[0];if(!file)return;
    try{const p=parseImportedProject(await file.text());commit(p,p.root.id);setTarget('page');setRuntimeState(deepCopy(p.data.state));notice.success('프로젝트를 가져왔습니다.');}
    catch(err){Modal.error({title:'불러오기 실패',content:err.message});}finally{e.target.value='';}
  }
  const width={desktop:980,tablet:768,mobile:390}[device];
  const activePath=(()=>{let path=[];if(selected){const loc=findLocation(root,selected);if(loc)path=[...loc.ancestors,selected];}return path;})();
  const trail=activePath.map(id=>findLocation(root,id)?.node).filter(Boolean);
  const counts=(()=>{let c=0,f=0;const walk=n=>{if(isFrame(n))f++;else c++;for(const ch of n.children||[])walk(ch);};walk(root);return {controls:c,frames:f};})();
  return <ConfigProvider theme={{token:{colorPrimary:'#3764df',borderRadius:7,fontFamily:'Inter, Pretendard, system-ui, sans-serif'}}}>
    {noticeContext}
    <div className="studio">
      <header className="topbar">
        <div className="brand"><span className="brand-mark">◈</span><span><strong>UI Studio</strong><small>Design + Code <b>0.6</b></small></span></div>
        <div className="project-dropdown"><span>PROJECT</span><strong>{project.title}</strong><span className="crumb-caret">⌄</span></div>
        <div className="top-center">One IR <span className="top-dot">·</span> Visual + JSX DSL + Binding</div>
        <div className="top-actions">
          <Tooltip title="Ctrl+Z"><button className="icon-button" onClick={undo}>{ICONS.undo}</button></Tooltip>
          <Tooltip title="Ctrl+Shift+Z"><button className="icon-button" onClick={redo}>{ICONS.redo}</button></Tooltip>
          <span className="toolbar-sep"/>
          <button className="secondary-btn" onClick={()=>uploadRef.current?.click()}>↧ 가져오기</button>
          <button className="secondary-btn" onClick={()=>downloadable(JSON.stringify(project,null,2),'ui-studio-project.json','application/json')}>JSON 저장</button>
          <button className="primary-btn" onClick={()=>downloadable(generateTsx(project),'GeneratedPage.tsx','text/typescript')}>↥ React TSX</button>
          <input type="file" ref={uploadRef} accept="application/json,.json" hidden onChange={importFile}/>
        </div>
      </header>
      <div className="workspace">
        <aside className="left-sidebar">
          <div className="sidebar-tabs"><button className={leftTab==='layers'?'on':''} onClick={()=>setLeftTab('layers')}>☷ Layers</button><button className={leftTab==='elements'?'on':''} onClick={()=>setLeftTab('elements')}>⊞ Insert</button><button className={leftTab==='data'?'on':''} onClick={()=>setLeftTab('data')}>◎ Data</button></div>
          <div className="page-picker"><span>EDITING</span><Select size="small" style={{width:'100%'}} value={target} onChange={chooseTarget} options={[{value:'page',label:'▣ Main Page'},...Object.values(project.modules).map(m=>({value:m.id,label:`◇ ${m.name}`}))]}/></div>
          {leftTab==='layers'?<>
            <div className="sidebar-title side-label">Page layers <span className="sidebar-mini">{counts.frames} Frames · {counts.controls} nodes</span></div>
            <div className="layer-scroll"><LayerTree node={root} selected={selected} onSelect={setSelected} expanded={expanded} onToggle={id=>setExpanded(s=>({...s,[id]:s[id]===false?true:false}))} project={project} onDragging={setDragging}/></div>
            <div className="left-bottom"><button className="add-layer-button" onClick={()=>setLeftTab('elements')}>＋ 요소 추가</button><div className="sidebar-title module-title">◇ My components</div>
              {Object.values(project.modules).length===0?<p className="module-empty">Frame 선택 → 컴포넌트로 만들기</p>:Object.values(project.modules).map(m=><div key={m.id} className="saved-component"><span title="모듈 편집" onClick={()=>chooseTarget(m.id)}>◇ {m.name}<small>v{m.version}</small></span><button title="선택한 Frame에 추가" onClick={()=>{const parent=isFrame(selectedNode)?selectedNode.id:findLocation(root,selectedNode.id)?.parent?.id||root.id;onDropAt({kind:'module',moduleId:m.id},parent);}}>＋</button></div>)}
            </div>
          </>:leftTab==='data'?<DataTree project={project} onBind={chooseDataBinding}/>:<ToolBox onAdd={add} onDragging={setDragging}/>}
        </aside>
        <main className="main-pane">
          <div className="pane-toolbar">
            <div className="view-tabs"><button className={activeTab==='design'?'active':''} onClick={()=>setActiveTab('design')}>◫ Design</button><button className={activeTab==='code'?'active':''} onClick={()=>setActiveTab('code')}>◫ + 〈/〉 Design / Code</button><button className={activeTab==='preview'?'active':''} onClick={()=>{setRuntimeState(deepCopy(project.data.state));setActiveTab('preview');}}>▶ Preview</button></div>
            <div className="view-controls"><span className="readonly-marker">{activeTab==='code'?'실시간 IR 동기화 · 유효한 DSL만 적용':'LIVE ANT DESIGN'}</span></div>
          </div>
          {['design','preview','code'].includes(activeTab)?<div className={activeTab==='code'?'split-workspace':'single-workspace'}><div className="design-workspace">
            <div className="canvas-header">
              <div className="breadcrumbs">{trail.map((n,i)=><React.Fragment key={n.id}>{i>0&&<span className="crumb-arrow">›</span>}<button className={i===trail.length-1?'crumb-active':''} onClick={()=>setSelected(n.id)}>{n.name}</button></React.Fragment>)}{!trail.length&&<span>{root.name}</span>}</div>
              <div className="canvas-size-controls"><Segmented size="small" value={device} onChange={setDevice} options={[{label:'Desktop',value:'desktop'},{label:'Tablet',value:'tablet'},{label:'Mobile',value:'mobile'}]}/><span className="control-divider"/><button onClick={()=>setZoom(v=>Math.max(35,v-10))}>−</button><strong>{zoom}%</strong><button onClick={()=>setZoom(v=>Math.min(125,v+10))}>+</button></div>
            </div>
            <div className="canvas-workspace" onClick={()=>activeTab==='design'&&setSelected(root.id)}>
              <div className="artboard-dimensions" style={{width:Math.min(width*zoom/100,1100)}}>{width} px · {activeTab==='preview'?'Interactive preview':'Design Canvas'}</div>
              <div className="artboard-container" style={{width:width*zoom/100,minHeight:Math.min(500*zoom/100,500)}}>
                <div className={'artboard '+(activeTab==='preview'?'artboard-preview':'')} style={{width,transform:`scale(${zoom/100})`,transformOrigin:'top left'}} onClick={e=>e.stopPropagation()}>
                  {activeTab!=='preview'?<CanvasNode root node={root} project={project} selected={selected} onSelect={setSelected} dragging={dragging} onDragging={setDragging} drop={drop} setDrop={setDrop} onDropAt={onDropAt} ctx={ctx} zoom={zoom} onResize={resize}/>:<RuntimeNode node={root} project={project} ctx={ctx} onStateChange={(key,v)=>setRuntimeState(s=>({...s,[key]:v}))}/>}
                </div>
              </div>
              {activeTab!=='preview'&&<div className="canvas-tip">▦ 청록색 = Frame · □ 파란색 = UI 요소 · ⠿ 이동 · ◁▷ 너비 조절</div>}
            </div>
          </div>{activeTab==='code'&&<CodeEditor draft={codeDraft} error={codeError} onChange={onCodeEdit} onCaret={onCodeCaret} codeRef={codeEditorRef} ranges={codeRanges} selected={selected} onExport={()=>downloadable(codeDraft,'ui-studio.dsl.jsx','text/plain')}/>}</div>:null}
          <div className="statusbar"><span>● Schema v5 · DSL v0.6</span><span>{Object.keys(project.modules).length} shared components</span><span>React + Ant Design</span><span>Designer Lab / {activeTab}</span></div>
        </main>
        <aside className="right-sidebar">
          <PropertyPanel node={selectedNode} rootId={root.id} project={project} onPatch={patchSelected} onDelete={erase} onDuplicate={duplicate} onModule={saveModule} onEditModule={chooseTarget} target={target}/>
        </aside>
      </div>
    </div>
  </ConfigProvider>;
}
export default App;
