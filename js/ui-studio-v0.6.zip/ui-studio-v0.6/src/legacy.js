/** Best-effort import of UI Studio v0.3/v0.4 project models. Unsupported behavior is not silently executed. */
import { createProject,validateProject,deepCopy } from './model.js';
const width=p=> /^\d+px$/.test(String(p?.width||''))?'fixed':p?.width==='auto'?'hug':'fill';
const px=p=> Number.parseInt(p?.width,10)||220;
const base=(p,name)=>({id:String(p?.id||`legacy_${Math.random().toString(36).slice(2)}`),name:String(p?.radName||name),width:width(p),widthPx:px(p)});
export function convertLegacyProject(old){
  if(old?.format!=='ui-studio'||![2,3].includes(old.schemaVersion)||!Array.isArray(old.data?.content))throw Error('v0.3/v0.4 형식이 아닙니다.');
  const next=createProject();next.title='ImportedPage';next.data.state=deepCopy(old.model?.initialState||{});next.data.sources={};
  for(const [key,src] of Object.entries(old.model?.sources||{})) {
    if(src?.kind==='mock') next.data.sources[key]=deepCopy(src.rows||[]);
    // REST connectors require explicit reconnection in the new editor.
  }
  const oldMods=old.model?.modules||{};
  const convertNodes=items=>(items||[]).map(convert).filter(Boolean);
  function frame(node,layout,children){const p=node.props||{};return {...base(p,node.type),kind:'frame',layout,gap:Number(p.gap)||12,padding:node.type==='Panel'?16:0,columns:Math.max(1,Math.min(8,Number(p.columns)||2)),align:'stretch',wrap:layout==='row',background:node.type==='Panel'?'#f8fafc':'transparent',minHeight:50,children};}
  function component(node,type,props){return {...base(node.props,type),kind:'component',component:type,props};}
  function convert(node){
    const p=node?.props||{};
    switch(node.type){
      case 'Stack':return frame(node,p.direction==='horizontal'?'row':'column',convertNodes(p.content));
      case 'Grid':return frame(node,'grid',convertNodes(p.content));
      case 'Panel':return frame(node,'column',[...(p.title?[component({props:{id:`${p.id}-title`}},'Text',{text:p.title,weight:'heading'})]:[]),...convertNodes(p.content)]);
      case 'TwoColumns':return frame(node,'grid',[frame({props:{id:`${p.id}-left`}},'column',convertNodes(p.left)),frame({props:{id:`${p.id}-right`}},'column',convertNodes(p.right))]);
      case 'Dock':return frame(node,'column',[frame({props:{id:`${p.id}-top`}},'row',convertNodes(p.top)),frame({props:{id:`${p.id}-main`}},'column',convertNodes(p.main)),frame({props:{id:`${p.id}-bottom`}},'row',convertNodes(p.bottom))]);
      case 'Heading':return component(node,'Text',{text:p.text||'',weight:'heading'});
      case 'Paragraph':return component(node,'Text',{text:p.text||'',weight:'normal'});
      case 'TextInput':return component(node,'Input',{label:p.label||'',placeholder:p.placeholder||'',valueBinding:p.bindKey?`{{state.${p.bindKey}}}`:''});
      case 'SelectInput':return component(node,'Select',{label:p.label||'',options:p.options||''});
      case 'CheckBox':return component(node,'Checkbox',{text:p.label||''});
      case 'ActionButton':return component(node,'Button',{text:p.text||'버튼',variant:p.variant||'default',action:p.event?.type==='clearValue'?{type:'clear',target:p.event.target}:{type:'message',message:p.event?.message||'이벤트를 다시 설정하세요.'}});
      case 'DataTable':return component(node,'Table',{title:'데이터 목록',rowsBinding:`{{sources.${p.sourceKey||'customers'}}}`,filterBinding:p.filterKey?`{{state.${p.filterKey}}}`:'',columns:p.columns||'id,name,email'});
      case 'Separator':return component(node,'Divider',{});
      case 'ModuleBlock':return {...base(p,'Module Instance'),kind:'instance',moduleId:p.moduleId||'',width:'fill'};
      default:return null;
    }
  }
  for(const [id,m] of Object.entries(oldMods))next.modules[id]={id,name:String(m.name||id),version:Number(m.version)||1,root:{id:`module-root-${id}`,kind:'frame',name:m.name||id,layout:'column',gap:12,padding:0,columns:2,align:'stretch',wrap:false,background:'transparent',width:'fill',widthPx:500,minHeight:50,children:convertNodes(m.content)}};
  next.root.children=convertNodes(old.data.content);
  if(!validateProject(next))throw Error('이전 프로젝트 변환에 실패했습니다. 중복 ID 또는 지원하지 않는 모듈 참조가 있을 수 있습니다.');
  return next;
}
export function parseImportedProject(text){
  let parsed;try{parsed=JSON.parse(text);}catch{throw Error('JSON 문법 오류');}
  if(parsed.format==='ui-studio'&&[2,3].includes(parsed.schemaVersion))return convertLegacyProject(parsed);
  if(!validateProject(parsed))throw Error('지원하지 않는 프로젝트 형식입니다. v0.5 또는 v0.3/v0.4 JSON만 지원합니다.');
  return parsed;
}
