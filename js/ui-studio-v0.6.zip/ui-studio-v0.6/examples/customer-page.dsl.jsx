<Frame nodeId="page-root" name="CustomerPage" layout="column" gap={20} padding={30} columns={2}
  align="stretch" wrap={false} background="#ffffff" width="fill" widthPx={900} minHeight={620}>
  <Frame nodeId="title-row" name="Page header" layout="row" gap={12} padding={0} columns={2} align="center"
    wrap={false} background="transparent" width="fill" widthPx={800} minHeight={55}>
    <Text nodeId="heading-1" name="Page title" width="fill" widthPx={350} text="고객 관리" weight="heading" />
    <Tag nodeId="badge-1" name="Status" width="hug" widthPx={80} text="DEMO" color="blue" />
  </Frame>
  <Frame nodeId="search-row" name="Search bar" layout="row" gap={10} padding={18} columns={2} align="end"
    wrap={true} background="#f7f9fc" width="fill" widthPx={800} minHeight={100}>
    <Input nodeId="search-input" name="고객명 검색" width="fixed" widthPx={290} label="고객명 / 이메일"
      placeholder="고객명 또는 이메일" valueBinding="{{state.keyword}}" />
    <Button nodeId="reset-button" name="초기화 버튼" width="hug" widthPx={100} text="초기화" variant="default"
      action={{"type":"clear","target":"keyword"}} />
  </Frame>
  <Frame nodeId="table-panel" name="Results panel" layout="column" gap={16} padding={22} columns={2}
    align="stretch" wrap={false} background="#ffffff" width="fill" widthPx={800} minHeight={300}>
    <Table nodeId="table-1" name="Customers" width="fill" widthPx={720} title="고객 목록"
      rowsBinding="{{sources.customers}}" filterBinding="{{state.keyword}}" columns="id,name,email,status" />
  </Frame>
  <Frame nodeId="summary-grid" name="Summary grid" layout="grid" gap={12} padding={0} columns={2}
    align="stretch" wrap={false} background="transparent" width="fill" widthPx={800} minHeight={110}>
    <Card nodeId="info-card-1" name="Reusable hint" width="fill" widthPx={250} title="Frame 기반 설계"
      description="왼쪽 레이어에서 Frame을 선택하여 Row / Column / Grid로 변경해보세요." />
    <Card nodeId="info-card-2" name="Binding hint" width="fill" widthPx={250} title="실제 Ant Design"
      description="미리보기에서는 검색 입력과 초기화 버튼을 직접 실행할 수 있습니다." />
  </Frame>
</Frame>
