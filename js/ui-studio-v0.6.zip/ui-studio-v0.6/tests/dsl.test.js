import test from 'node:test';
import assert from 'node:assert/strict';
import {createProject, changeNode, createComponentModule, findLocation} from '../src/model.js';
import {printDsl, parseDsl, applyDsl, nodeAtOffset} from '../src/dsl.js';
import {generateTsx} from '../src/generator.js';

const mk=()=>createProject();
test('full sample Code→IR→Code preserves all node details',()=>{
  const p=mk(),s=printDsl(p.root),r=parseDsl(s.text);
  assert.deepEqual(r.root,p.root);
  assert.equal(printDsl(r.root).text,s.text);
});
test('valid code edit updates visual IR',()=>{
  const p=mk();let s=printDsl(p.root).text;
  s=s.replace('name="Search bar" layout="row" gap={10}', 'name="Search panel" layout="grid" gap={24}');
  s=s.replace('text="초기화"','text="Clear search"');
  const r=applyDsl(p,'page',s);
  assert.equal(findLocation(r.project.root,'search-row').node.layout,'grid');
  assert.equal(findLocation(r.project.root,'search-row').node.gap,24);
  assert.equal(findLocation(r.project.root,'reset-button').node.props.text,'Clear search');
  assert.equal(p.root.children[1].name,'Search bar');
});
test('visual IR edit prints source and retains nodeId selection',()=>{
  const p=mk();p.root=changeNode(p.root,'search-input',n=>n.props.label='New label');
  const {text,ranges}=printDsl(p.root);
  assert.match(text,/label="New label"/);
  assert.equal(nodeAtOffset(ranges,text.indexOf('New label')),'search-input');
});
test('nested nodes win offset mapping over ancestor ranges',()=>{
  const {text,ranges}=printDsl(mk().root);
  const pos=text.indexOf('name="고객명 검색"');
  assert.equal(nodeAtOffset(ranges,pos),'search-input');
});
test('binding expression roundtrip is a literal, not JavaScript',()=>{
  const p=mk(),s=printDsl(p.root).text;
  const parsed=parseDsl(s);
  assert.equal(findLocation(parsed.root,'search-input').node.props.valueBinding,'{{state.keyword}}');
});
test('arbitrary inline JS is rejected, no evaluation occurs',()=>{
  const s='<Frame nodeId="root">\n  <Button nodeId="b" text={alert(1)} />\n</Frame>';
  assert.throws(()=>parseDsl(s),/JSON 리터럴/);
});
test('closing tag mismatch is rejected',()=>assert.throws(()=>parseDsl('<Frame nodeId="x"><Input /></Card>'),/필요합니다/));
test('unclosed tag is rejected',()=>assert.throws(()=>parseDsl('<Frame nodeId="x"><Input />'),/없습니다/));
test('unsupported tag rejected',()=>assert.throws(()=>parseDsl('<script nodeId="x" />'),/지원하지 않는 요소/));
test('duplicate node id rejected',()=>assert.throws(()=>parseDsl('<Frame nodeId="x"><Button nodeId="x" /></Frame>'),/중복 nodeId/));
test('no unknown Frame props',()=>assert.throws(()=>parseDsl('<Frame nodeId="r" onClick="alert(1)" />'),/알 수 없는/));
test('flat text children syntax accepted',()=>{
  const n=parseDsl('<Frame nodeId="root"><Button nodeId="btn">조회</Button></Frame>').root.children[0];
  assert.equal(n.props.text,'조회');
});
test('module references survive DSL serialization',()=>{
  const p=mk();const {project}=createComponentModule(p,'page','search-row','SearchPanel');
  const result=applyDsl(project,'page',printDsl(project.root).text);
  assert.deepEqual(result.project,project);
});
test('editing module code does not modify page tree',()=>{
  const {project,moduleId}=createComponentModule(mk(),'page','search-row','SearchPanel');
  const original=structuredClone(project.root);
  const s=printDsl(project.modules[moduleId].root).text.replace('gap={10}','gap={19}');
  const result=applyDsl(project,moduleId,s);
  assert.deepEqual(result.project.root,original);
  assert.equal(result.project.modules[moduleId].root.gap,19);
});
test('exported React code includes real AntD and data binding',()=>{
  const p=mk(),s=printDsl(p.root).text.replace('name="Page title"', 'name="Page title" valueBinding="{{state.keyword}}"');
  const r=applyDsl(p,'page',s);
  const tsx=generateTsx(r.project);
  assert.match(tsx,/getBound\("\{\{state\.keyword\}\}"\)/);
  assert.match(tsx,/from 'antd'/);
});
test('malformed draft leaves saved project untouched',()=>{
  const p=mk(),before=JSON.stringify(p);
  assert.throws(()=>applyDsl(p,'page','<Frame>'),/없습니다/);
  assert.equal(JSON.stringify(p),before);
});
test('DSL rejects unsafe function-like binding expressions',()=>{
  const p=mk(),s=printDsl(p.root).text.replace('valueBinding="{{state.keyword}}"','valueBinding="{{fetch(secret)}}"');
  assert.throws(()=>applyDsl(p,'page',s),/형식만 지원/);
});
test('DSL rejects invalid frame numeric layout properties',()=>{
  const p=mk(),s=printDsl(p.root).text.replace('gap={20}','gap="many"');
  assert.throws(()=>applyDsl(p,'page',s),/Frame 레이아웃 값/);
});
