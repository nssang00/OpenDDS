import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { STUDIO_DRAG_TYPE, isStudioDrag, getDropEffect, readStudioDrag } from '../src/drag.js';
import { createProject, findLocation } from '../src/model.js';
import { parseDsl, printDsl, applyDsl } from '../src/dsl.js';
import { generateTsx } from '../src/generator.js';

function fakeDrag(kind, effectAllowed) {
  const values = {[STUDIO_DRAG_TYPE]: JSON.stringify(kind==='new'?{kind,type:'Button'}:{kind,id:'reset-button'})};
  return {types:[STUDIO_DRAG_TYPE,'text/plain'],effectAllowed,getData:mime=>values[mime] || ''};
}
test('new toolbox element uses copy/copy rather than copy/move', () => {
  const data=fakeDrag('new','copy');
  assert.equal(isStudioDrag(data,'new'),true);
  assert.equal(getDropEffect('new',data),'copy');
  assert.deepEqual(readStudioDrag(data),{kind:'new',type:'Button'});
});
test('dragging existing layers negotiates a move operation', () => {
  const data=fakeDrag('move','move');
  assert.equal(getDropEffect('move',data),'move');
  assert.deepEqual(readStudioDrag(data),{kind:'move',id:'reset-button'});
});
test('invalid cross-page data cannot be interpreted as an internal drop', () => {
  assert.equal(readStudioDrag({getData:()=>'{ bad'}),null);
  assert.equal(isStudioDrag({types:['text/plain']},null),false);
});

test('quick-start Page/Row/Input/Button DSL modifies the visual IR', () => {
  const src=`<Page id="page-demo" name="샘플 화면" gap={20}>
    <Row gap={8}>
      <Input id="search" label="검색어" value="{{state.keyword}}" />
      <Button id="go" text="조회" />
    </Row>
    <Table id="users" data="{{sources.customers}}" />
  </Page>`;
  const p=createProject();
  const {project,ranges}=applyDsl(p,'page',src);
  assert.equal(project.root.id,'page-demo');
  assert.equal(project.root.children[0].layout,'row');
  assert.equal(findLocation(project.root,'search').node.props.valueBinding,'{{state.keyword}}');
  assert.equal(findLocation(project.root,'go').node.props.text,'조회');
  assert.equal(findLocation(project.root,'users').node.props.rowsBinding,'{{sources.customers}}');
  assert.ok(ranges.search);
  const roundtrip=applyDsl(project,'page',printDsl(project.root).text);
  assert.deepEqual(roundtrip.project.root,project.root);
  const tsx=generateTsx(project);
  assert.match(tsx,/<Input/);
  assert.match(tsx,/<Button/);
  assert.match(tsx,/<Table/);
});
test('short tag names without explicit IDs produce deterministic IDs across edits', () => {
  const a=parseDsl('<Page><Column><Text>첫 번째</Text></Column></Page>');
  const b=parseDsl('<Page><Column><Text>두 번째</Text></Column></Page>');
  assert.equal(a.root.id,b.root.id);
  assert.equal(a.root.children[0].children[0].id,b.root.children[0].children[0].id);
});
test('unsafe React event handlers remain excluded with a meaningful error', () => {
  assert.throws(()=>parseDsl('<Page><Button onClick="actions.search" /></Page>'),/action=\{JSON 객체\}/);
});
test('legacy Frame-shaped code preserves data and event objects', () => {
  const p=createProject();
  const after=applyDsl(p,'page',printDsl(p.root).text);
  assert.deepEqual(after.project,p);
});

test('shipped quick-start DSL parses, binds, and round-trips', () => {
  const src = fs.readFileSync('./examples/quick-start.dsl.jsx','utf8');
  const project=applyDsl(createProject(),'page',src).project;
  assert.equal(project.root.name,'샘플 화면');
  assert.equal(findLocation(project.root,'users').node.component,'Table');
  assert.equal(findLocation(project.root,'search').node.props.valueBinding,'{{state.keyword}}');
  assert.deepEqual(parseDsl(printDsl(project.root).text).root,project.root);
});
