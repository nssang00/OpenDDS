# UI Studio v0.6.1 — Drag & DSL Fix

A small, **React + Ant Design** visual UI editor. The default view is a Figma-inspired Frame canvas; a split Code view edits the **same IR** through a constrained JSX-shaped DSL. There is no MAUI, Puck, arbitrary JS execution, or cloud service.

> This is a **technical MVP**, not a production app-builder. Core model and code-generation tests pass. npm package installation and browser integration tests could not be performed in the packaging environment (registry access was blocked).


## v0.6.1 bug fixes (reported after v0.6)

- **Insert dragging / forbidden-drop cursor:** Fixed a native browser DnD operation mismatch. The toolbox declared `effectAllowed=copy`, while the drop target incorrectly demanded `dropEffect=move`. Insert now uses **copy → copy**, existing layer movement uses **move → move**. The artboard has an additional accepted-drop fallback.
- **DSL pasted but Canvas stays unchanged:** The old parser only accepted `<Frame>`; documentation examples showing `<Page>`, `<Column>`, `<Row>`, `<Grid>` were rejected. Those aliases now compile into the same internal Frame IR. `<TextBox>`/`<DataGrid>` also map to `Input`/`Table`. `id` can be used as shorthand for `nodeId`, `value` as shorthand for a bindable Input/Text value, and `data` for table data.
- **Error visibility:** Unsupported DSL is still rejected without damaging the current Design. Errors now appear in a persistent warning panel below the code editor, instead of only a truncated header. The DSL is intentionally restricted: `onClick="actions.search"` and arbitrary JS expressions do not execute. Use the supported JSON `action` definition instead.
- **Regression tests:** 46 pure-model/DSL/drag-negotiation tests pass. Syntax checks pass. A complete browser E2E run was **not possible in the packaging environment**, since `npm install` failed with a registry DNS error (`EAI_AGAIN`). **Validate in Chrome/Edge** after installing dependencies.

To verify the fix:

1. Open Insert, drag **Button** onto a Frame. The cursor should allow dropping. You can also **click** an Insert item to add it to the selected Frame.
2. Open **Design / Code**, select all current code and paste `examples/quick-start.dsl.jsx`. The Canvas should update to the new Page/Column/Row/Table example.
3. Edit `text="조회"` to `text="검색"`. The AntD button in Design should update.
4. Paste invalid DSL and confirm a visible warning appears while the previous Canvas is preserved.

`<Page>` and layout tag aliases are **readable input shortcuts**. After any visual edit, Code may be reprinted in canonical `<Frame layout=...>` format; this is expected.

## Quick start (5 minutes)

Requirements: **Node.js 20.19+ or 22.12+**, npm network access.

```bash
npm install
npm run dev
```

Open `http://localhost:5173`.

1. **Design:** Click *Search bar* in Layers. Change **Direction / mode** in the Inspector from Row to Column or Grid. Canvas updates immediately.
2. **Insert:** Select a Frame, click Insert → Button (or drag it onto the canvas). Drag the element handle to rearrange; use the resize handle for fixed width.
3. **Design / Code:** Select a Button or Input in the canvas. Its opening tag is highlighted in the DSL pane. Change `text="초기화"` to `text="지우기"` in Code: the canvas updates. You can also change a Frame's `layout` or `gap`.
4. **Data Binding:** Select *고객명 검색* (Input), open the Data tab on the left, drag `state.keyword` onto Inspector → **Value expression**. The stored value is `{{state.keyword}}`, and the evaluated value appears immediately. You can also type it directly.
5. **Preview:** Type part of a customer name. The table filters. Press Reset to clear the keyword.
6. **Reuse:** Select a non-root Frame → **공유 컴포넌트로 만들기**; edit its definition via *My components*. Instances use a common definition (no public props/state API yet).
7. **Export:** Header → **JSON 저장** for the project schema, or **React TSX** for a single React component file. **가져오기** loads compatible project JSON. Code pane → **DSL 저장** downloads the editable representation.

```bash
npm test
npm run build
```

## What's implemented

| Area | v0.6 behavior |
|---|---|
| Design | Frame-first Canvas, Layers, drag/drop insertion and reorder, selection/resize, Row/Column/Grid, actual AntD controls |
| Code | Editable constrained JSX-shaped DSL, instant parse/validation and updates to the same project IR |
| Selection sync | Fixed `nodeId` ↔ source offsets, canvas/tree to code and code caret to canvas |
| Invalid drafts | Error with line and column; **last valid Design/IR stays intact** |
| Data Binding | Left Data tree, drag onto Inspector field or click a path; direct `{{...}}` editing and resolved preview |
| Binding grammar | Safe dotted paths from `state` or `sources`; no JavaScript evaluation |
| Preview | Live AntD components, mock state, sample customer list filter, simple message/reset button events |
| Components | Shared Frame definition and instances (module references; no separate published contracts yet) |
| Import/Export | Project JSON import/export; editable DSL text download; single-file React TSX export |
| Storage | Browser localStorage `ui-studio-v06`; can open v0.5 and best-effort import v0.3/v0.4 JSON |

## DSL rules

The Code pane **looks like JSX but is not arbitrary React code**. It supports only registered UI tags (`Frame`, `Text`, `Button`, `Input`, `Select`, `Checkbox`, `Table`, `Card`, `Divider`, `Tag`, `Use`); allowed props are strings or `{JSON literals}`. `Frame` can contain other registered UI elements. No hooks, functions, inline JSX expressions or arbitrary JavaScript.

```jsx
<Frame nodeId="my-page" name="Example" layout="column" gap={12}>
  <Input nodeId="my-input" name="Keyword" label="Search" valueBinding="{{state.keyword}}" />
  <Button nodeId="search-btn" name="Clear" text="Reset"
    action={{"type":"clear","target":"keyword"}} />
</Frame>
```

In this representation, `nodeId` is a **stable internal identity** for editor/code selection. `name` is a user-friendly label, not the binding scope. `<Use moduleId="..." />` references a previously registered shared component. Valid code edits reparse into the same project model. Visual edits print a canonical DSL form (comments, attribute spacing and text formatting are **not preserved**).

`{{state.keyword}}`, `{{sources.customers}}` and nested dotted paths are supported in the binding Inspector. These **are string bindings**, not JSX double-brace JavaScript expressions. Arbitrary expressions such as `{{fetch(...)}}` are not supported.

## Architecture

```
Design (Canvas + Layers + Inspector)       Code (DSL editor)
                   \                     /
                    \                   /
                Project IR (schema v5)
                  |         |          |
        AntD renderer   Bindings   React TSX generator
```

- `src/model.js` — validated project and node tree, edits, reusable module references, safe dotted-path resolver
- `src/dsl.js` — constrained DSL parser/printer + stable source maps + Code-to-IR application
- `src/App.jsx` — editor shell, visual canvas, split code editor, binding tree and inspector, file import/export
- `src/runtime.jsx` — preview and actual AntD UI rendering
- `src/generator.js` — CSS layout mapping, DSL forwarding and React TSX code generation
- `src/legacy.js` — compatibility import for older project formats
- `tests/` — model, migration, source, DSL round trips, source selection and safety tests

## Current limitations

- React TSX export is **one component file**, not a complete standalone Vite project. It requires a React/AntD application to host it.
- Browser drag/drop, responsiveness, accessibility, and package-version compatibility have not been end-to-end verified here. `npm install && npm run build` must be run in your environment.
- The Code pane uses a lightweight textarea, **not Monaco**. Only the opening tag/source line is highlighted; no full syntax intelligence, formatting-preserving round trips or collaborative editing.
- Design is auto layout only; no freeform absolute coordinates, multi-select, or full Grid-cell manipulation.
- Data Binding currently resolves safe paths only; no CEL/JSONata, REST connector editor, asynchronous fetching, typed expressions, or computed formulas.
- Shared components use a shared definition but **do not yet support scoped public props/events/slots or semver release management**.
- Preview and generated TSX implement basic mock data/input state/table filtering/message/clear; they are not a general action engine.
- Imported v0.3/v0.4 actions and REST connections can lose unsupported information; verify converted screens.

## Suggested next iteration

First validate browser interaction with a real npm install. Then tighten selection/resize UX and focus on Component Props/Events/Slots and a useful safe typed Binding expression engine before expanding the widget catalog.
