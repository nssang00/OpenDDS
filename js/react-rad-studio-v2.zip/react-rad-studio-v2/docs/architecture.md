# React RAD Studio v0.2 아키텍처 메모

## 목적
MFC/WPF 개발자가 UI 배치 → 속성 → 이벤트 → 데이터 바인딩 → React/AntD 내보내기 흐름으로 앱을 구축하게 한다.

## 현재 데이터 흐름

```text
Puck Visual Editor → project.data (Puck schema) ┐
                                                  ├─ project JSON ─┬─ Preview Runtime + Puck Render
Data/State Manager → project.model               ┘                └─ TSX Export Generator

project.model = {
  initialState: Record<string, string>,
  sources: Record<string, {kind:"mock",rows:object[]} | {kind:"rest",url:string,dataPath:string}>
}
```

### PropertyGrid
- Puck의 기본 우측 속성 패널을 직접 활용한다. 각 컴포넌트는 common fields(Name, Visible, Width)와 고유 fields(Enabled, Text, Source, Binding)를 가짐.
- EventHandler는 Puck `custom` 필드이며 이벤트 타입과 대상을 dropdown으로 지정한다.
- 레이아웃은 유사 WPF Grid(2열) 및 GroupBox(Panel)를 제공하지만 자유 좌표 배치는 지원하지 않는다.

### Action 모델

```json
{ "type": "clearValue", "target": "customerName" }
```

허용: `message`, `clearValue`, `setValue`, `refresh`. 문자열을 eval하지 않으며 임의 JavaScript 핸들러는 생성하지 않는다.

### Binding 모델
- TextInput.bindKey → project.model.initialState 변수 이름.
- DataTable.sourceKey → project.model.sources 이름.
- DataTable.filterKey → 상태 변수 이름 (즉시 부분 문자열 필터링).
- DataTable.filterColumns → 검색할 컬럼 목록.

### Runtime
- 편집 중에는 편집용 UI만 표시한다.
- 미리보기는 RuntimeProvider로 state/datasets/loading을 보유한다.
- Mock 데이터는 로컬 배열, REST는 CORS를 따르는 GET이며 브라우저 환경에서 실행된다.
- 생성 TSX는 동일한 이벤트·바인딩 모델을 인라인 React hooks로 구현한다.

## 공식화해야 할 후속 계약

1. `project.data`를 자체 컴포넌트 IR로 교체하고 `Puck ↔ IR` 양방향 adapter 구축.
2. 런타임 동작과 TSX 생성 코드가 같은 의미론을 공유하도록 Golden tests 및 browser E2E tests 구축.
3. 컴포넌트/바인딩/데이터 타입에 JSON Schema/Zod 버전 규약 도입.
4. UI 라이브러리 어댑터 `AntdRenderer` / `MuiRenderer`, 컨트롤 매핑 차이를 별도 계약으로 분리.
5. 복잡한 이벤트에는 Action Registry 및 트랜잭션/에러 핸들링 정책이 필요.
6. REST 자격증명이나 권한이 필요한 경우 사용자 브라우저가 아닌 서버측 인증 프록시 및 적절한 접근 제어 도입.
7. 단방향 소스 생성 이후, 사용자 수정 코드를 별도 확장 파일로 관리하여 재생성 시 덮어쓰지 않게 설계.

## 이 프로토타입의 의도적 트레이드오프

현재 프로젝트는 처음부터 자체 IR/파서를 구축하지 않고 Puck의 안정적인 디자인 데이터 포맷을 화면 계층에 유지한다. 이는 PoC에 적합하지만 다양한 렌더러, DSL, 코드 역변환을 지원하는 정식 제품에는 충분하지 않다.
