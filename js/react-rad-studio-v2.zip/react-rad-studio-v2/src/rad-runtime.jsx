import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import { Button, Input, Table, message } from "antd";
import { columnKeys, filterRows, getPath, isSafeUrl } from "./rad-model.js";

const RuntimeContext = createContext(null);

export function RuntimeProvider({ model, children }) {
  const [values, setValues] = useState(() => ({ ...model.initialState }));
  const [datasets, setDatasets] = useState(() => Object.fromEntries(Object.entries(model.sources).map(([key, src]) => [key, src.kind === "mock" ? src.rows : []])));
  const [loading, setLoading] = useState({});

  const refresh = useCallback(async (key, signal) => {
    const src = model.sources[key];
    if (!src) throw new Error(`데이터 소스가 없습니다: ${key}`);
    if (src.kind === "mock") { setDatasets((prev) => ({ ...prev, [key]: src.rows })); return; }
    if (!isSafeUrl(src.url)) throw new Error("허용되지 않은 API 주소입니다.");
    setLoading((prev) => ({ ...prev, [key]: true }));
    try {
      const response = await fetch(src.url, { method: "GET", credentials: "omit", signal });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const payload = await response.json();
      const rows = src.dataPath ? getPath(payload, src.dataPath) : payload;
      if (!Array.isArray(rows)) throw new Error("API 응답의 지정한 경로가 배열이 아닙니다.");
      setDatasets((prev) => ({ ...prev, [key]: rows.slice(0, 1000) }));
    } finally { setLoading((prev) => ({ ...prev, [key]: false })); }
  }, [model]);

  useEffect(() => {
    const controller = new AbortController();
    for (const [key, src] of Object.entries(model.sources)) {
      if (src.kind === "rest") refresh(key, controller.signal).catch((error) => {
        if (error.name !== "AbortError") message.error(`${key}: ${error.message} (CORS 설정도 확인하세요)`);
      });
    }
    return () => controller.abort();
  }, [model, refresh]);

  const runAction = useCallback((action) => {
    const { type, target, value } = action || {};
    if (type === "message") message.info(action.message || "이벤트 실행");
    else if (type === "clearValue" && Object.hasOwn(model.initialState, target)) setValues((prev) => ({ ...prev, [target]: "" }));
    else if (type === "setValue" && Object.hasOwn(model.initialState, target)) setValues((prev) => ({ ...prev, [target]: String(value ?? "") }));
    else if (type === "refresh") refresh(target).catch((error) => message.error(error.message));
  }, [model, refresh]);

  return <RuntimeContext.Provider value={{ values, setValues, datasets, loading, runAction }}>
    {children}
  </RuntimeContext.Provider>;
}

function commonStyle({ width, visible }, isEditing) {
  return {
    width: ["auto", "50%", "100%"].includes(width) ? width : "auto",
    maxWidth: "100%",
    ...(visible === "hidden" ? (isEditing ? { opacity: 0.45, outline: "1px dashed #999" } : { display: "none" }) : {})
  };
}

export function RadTextInput(props) {
  const runtime = useContext(RuntimeContext);
  const editing = Boolean(props.isEditing);
  const { bindKey, label, placeholder, disabled } = props;
  const bound = runtime && bindKey && Object.hasOwn(runtime.values, bindKey);
  return <div className="formField" style={commonStyle(props, editing)} title={props.radName || "TextInput"}>
    <label className="formLabel">{label || "입력"}</label>
    <Input placeholder={placeholder} value={bound ? runtime.values[bindKey] : ""} disabled={editing || disabled === "yes"}
      onChange={(event) => {
        if (!bound || editing) return;
        const next = event.target.value;
        runtime.setValues((prev) => ({ ...prev, [bindKey]: next }));
      }}/>
    {editing && bindKey && <span className="bindingHint">↔ {bindKey}</span>}
  </div>;
}

export function RadButton(props) {
  const runtime = useContext(RuntimeContext);
  const editing = Boolean(props.isEditing);
  return <Button title={props.radName || "ActionButton"} type={props.variant === "primary" ? "primary" : "default"}
    style={commonStyle(props, editing)} disabled={editing || props.disabled === "yes"}
    onClick={() => runtime?.runAction(props.event || { type: "message", message: props.notificationText || "버튼 클릭" })}>{props.text || "버튼"}</Button>;
}

export function RadTable(props) {
  const runtime = useContext(RuntimeContext);
  const editing = Boolean(props.isEditing);
  const keys = columnKeys(props.columns);
  const columns = keys.map((key) => ({ title: key, dataIndex: key, key, render: (value) => String(value ?? "") }));
  const sourceRows = runtime?.datasets[props.sourceKey] || props.fallbackRows || [];
  const filtered = filterRows(sourceRows, runtime?.values[props.filterKey], props.filterColumns || keys.join(","));
  return <div className="radTableWrap" style={commonStyle(props, editing)} title={props.radName || "DataTable"}>
    {editing && <div className="bindingHint">source: {props.sourceKey || "미설정"} · filter: {props.filterKey || "없음"}</div>}
    <Table size="small" rowKey={(row, idx) => String(row.id ?? idx)} loading={runtime?.loading[props.sourceKey]}
      dataSource={filtered} columns={columns} pagination={{ pageSize: Math.max(1, Math.min(50, Number(props.pageSize) || 5)) }} scroll={{ x: true }} />
  </div>;
}

export { commonStyle };
