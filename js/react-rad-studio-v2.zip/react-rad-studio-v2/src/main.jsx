import React from "react";
import { createRoot } from "react-dom/client";
import "@puckeditor/core/puck.css";
import "./styles.css";
import { App } from "./studio.jsx";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
