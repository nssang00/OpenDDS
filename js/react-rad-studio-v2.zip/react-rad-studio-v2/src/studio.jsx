import React, { useMemo, useRef, useState } from "react";
import { Puck, Render, FieldLabel } from "@puckeditor/core";
import { Button, Card, Divider, Input, Modal, Select, Space, Tabs, Typography, message } from "antd";
import { createProject, importProject, isSafeKey, validateModel } from "./rad-model.js";
import { RuntimeProvider, RadTextInput, RadButton, RadTable, commonStyle } from "./rad-runtime.jsx";
import { generateTsx } from "./tsx-generator.js";

const { Title, Text } = Typography;
const STORAGE_KEY = "react-rad-studio-project-v2";
const deepCopy = (value) => JSON.parse(JSON.stringify(value));

function download(filename, content, mime = "text/plain") {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function loadProject() {
  try { return importProject(JSON.parse(localStorage.getItem(STORAGE_KEY) || "null")); }
  catch { return createProject(); }
}

function EventField({ value, onChange, stateKeys, sourceKeys, field }) {
  const a = { type: "message", target: "", value: "", message: "", ...(value && typeof value === "object" ? value : {}) };
  const set = (key, newValue) => onChange({ ...a, [key]: newValue });
  const isVariableAction = ["clearValue", "setValue"].includes(a.type);
  return <div className="eventField">
    <FieldLabel label={field.label || "onClick 이벤트"}/>
    <Select aria-label="클릭 이벤트 타입" value={a.type} style={{ width: "100%" }} onChange={(v) => onChange({ type: v, target: "", message: "", value: "" })}
      options={[
        { label: "ShowMessage · 알림", value: "message" },
        { label: "ClearValue · 입력 초기화", value: "clearValue" },
        { label: "SetValue · 상태 변경", value: "setValue" },
        { label: "RefreshSource · 데이터 새로고침", value: "refresh" }
      ]}/>
    {a.type === "message" && <Input value={a.message} placeholder="알림 메시지" aria-label="알림 메시지" onChange={(e) => set("message", e.target.value)}/>}
    {(isVariableAction || a.type === "refresh") && <Select style={{ width: "100%" }} aria-label="대상 선택" value={a.target || undefined} placeholder="대상 선택"
      onChange={(v) => set("target", v)}
      options={(isVariableAction ? stateKeys : sourceKeys).map((k) => ({ label: k, value: k }))}/>}
    {a.type === "setValue" && <Input aria-label="설정할 값" value={a.value} placeholder="설정할 값" onChange={(e) => set("value", e.target.value)}/>}
    <Text type="secondary" style={{ fontSize: 11 }}>onClick → {a.type}({a.target || (a.type === "message" ? "message" : "source")})</Text>
  </div>;
}

function makeConfig(model) {
  const stateKeys = Object.keys(model.initialState);
  const sourceKeys = Object.keys(model.sources);
  const stateChoices = [{ label: "바인딩 안 함", value: "" }, ...stateKeys.map((k) => ({ label: k, value: k }))];
  const sourceChoices = [{ label: "소스 선택", value: "" }, ...sourceKeys.map((k) => ({ label: k, value: k }))];
  const common = {
    radName: { type: "text", label: "(Name) 컨트롤 이름" },
    visible: { type: "select", label: "Visible", options: [{ label: "표시", value: "visible" }, { label: "숨기기", value: "hidden" }] },
    width: { type: "select", label: "Width", options: [{ label: "Auto", value: "auto" }, { label: "50%", value: "50%" }, { label: "100%", value: "100%" }] }
  };
  const defaultCommon = { radName: "", width: "100%", visible: "visible" };
  return {
    categories: {
      layout: { title: "레이아웃", components: ["Panel", "TwoColumns"] },
      form: { title: "폼/이벤트", components: ["TextInput", "ActionButton"] },
      data: { title: "데이터", components: ["DataTable"] },
      text: { title: "텍스트", components: ["Heading", "Paragraph"] }
    },
    components: {
      Heading: {
        label: "제목", fields: { text: { type: "text", label: "Text" }, ...common },
        defaultProps: { text: "새 제목", ...defaultCommon },
        render: (p) => <Title level={2} style={commonStyle(p, p.puck?.isEditing)}>{p.text}</Title>
      },
      Paragraph: {
        label: "본문", fields: { text: { type: "textarea", label: "Text" }, ...common },
        defaultProps: { text: "내용을 입력하세요.", ...defaultCommon },
        render: (p) => <Text style={commonStyle(p, p.puck?.isEditing)}>{p.text}</Text>
      },
      TextInput: {
        label: "TextBox", fields: {
          label: { type: "text", label: "Label" },
          placeholder: { type: "text", label: "Placeholder" },
          bindKey: { type: "select", label: "Binding / State", options: stateChoices },
          disabled: { type: "select", label: "Enabled", options: [{ label: "활성화", value: "no" }, { label: "비활성화", value: "yes" }] },
          ...common
        },
        defaultProps: { ...defaultCommon, radName: "textBox1", label: "고객명", placeholder: "입력하세요", bindKey: "", disabled: "no" },
        render: (p) => <RadTextInput {...p} isEditing={p.puck?.isEditing}/>
      },
      ActionButton: {
        label: "Button", fields: {
          text: { type: "text", label: "Text" },
          variant: { type: "select", label: "Style", options: [{ label: "기본", value: "default" }, { label: "강조", value: "primary" }] },
          disabled: { type: "select", label: "Enabled", options: [{ label: "활성화", value: "no" }, { label: "비활성화", value: "yes" }] },
          event: { type: "custom", label: "onClick (이벤트 편집기)", render: (props) => <EventField {...props} stateKeys={stateKeys} sourceKeys={sourceKeys}/> },
          ...common
        },
        defaultProps: { ...defaultCommon, radName: "button1", text: "실행", variant: "primary", disabled: "no", event: { type: "message", message: "버튼을 클릭했습니다." } },
        render: (p) => <RadButton {...p} isEditing={p.puck?.isEditing}/>
      },
      DataTable: {
        label: "DataGrid", fields: {
          sourceKey: { type: "select", label: "DataSource", options: sourceChoices },
          filterKey: { type: "select", label: "Filter / Binding", options: stateChoices },
          filterColumns: { type: "text", label: "Search columns (, 구분)" },
          columns: { type: "text", label: "Columns (, 구분)" },
          pageSize: { type: "number", label: "PageSize", min: 1, max: 50 },
          ...common
        },
        defaultProps: { ...defaultCommon, radName: "dataGrid1", columns: "id,name,email,status", pageSize: 5, sourceKey: "customers", filterKey: "", filterColumns: "name,email" },
        render: (p) => <RadTable {...p} isEditing={p.puck?.isEditing} fallbackRows={model.sources[p.sourceKey]?.kind === "mock" ? model.sources[p.sourceKey].rows : []}/>
      },
      Panel: {
        label: "GroupBox", fields: { title: { type: "text", label: "Header" }, ...common, content: { type: "slot" } },
        defaultProps: { ...defaultCommon, title: "새 패널", content: [] },
        render: ({ content: Content, puck, ...p }) => <Card title={p.title} size="small" style={commonStyle(p, puck?.isEditing)}><Content minEmptyHeight={95}/></Card>
      },
      TwoColumns: {
        label: "Grid(2 Column)", fields: { ...common, left: { type: "slot" }, right: { type: "slot" } },
        defaultProps: { ...defaultCommon, left: [], right: [] },
        render: ({ left: Left, right: Right, puck, ...p }) => <div className="columns2" style={commonStyle(p, puck?.isEditing)}><Left minEmptyHeight={95}/><Right minEmptyHeight={95}/></div>
      }
    }
  };
}

function ModelSettings({ model, onSave, onCancel }) {
  const [draft, setDraft] = useState(() => deepCopy(model));
  const [newStateName, setNewStateName] = useState("");
  const [newSourceName, setNewSourceName] = useState("");
  const [selectedSource, setSelectedSource] = useState(Object.keys(model.sources)[0] || "");
  const [rowsText, setRowsText] = useState(() => Object.fromEntries(Object.entries(model.sources).filter(([,s]) => s.kind === "mock").map(([k,s]) => [k, JSON.stringify(s.rows, null, 2)])));
  const changeState = (key, value) => setDraft((d) => ({ ...d, initialState: { ...d.initialState, [key]: value } }));
  const changeSource = (key, patch) => setDraft((d) => ({ ...d, sources: { ...d.sources, [key]: { ...d.sources[key], ...patch } } }));
  const addState = () => {
    const k = newStateName.trim();
    if (!isSafeKey(k) || Object.hasOwn(draft.initialState, k)) return message.warning("영문·숫자·_ 로 된 중복되지 않는 이름을 입력하세요.");
    changeState(k, ""); setNewStateName("");
  };
  const addSource = () => {
    const k = newSourceName.trim();
    if (!isSafeKey(k) || Object.hasOwn(draft.sources, k)) return message.warning("영문·숫자·_ 로 된 중복되지 않는 소스 이름을 입력하세요.");
    changeSource(k, { kind: "mock", rows: [] }); setRowsText((prev) => ({ ...prev, [k]: "[]" })); setSelectedSource(k); setNewSourceName("");
  };
  const save = () => {
    try {
      const next = deepCopy(draft);
      for (const [key, src] of Object.entries(next.sources)) {
        if (src.kind === "mock") {
          const rows = JSON.parse(rowsText[key] ?? "[]");
          if (!Array.isArray(rows)) throw new Error(`${key}: 샘플 데이터가 배열이 아닙니다.`);
          src.rows = rows;
        }
      }
      if (!validateModel(next)) throw new Error("상태나 데이터 소스 설정이 유효하지 않습니다. REST 주소는 http(s) 형식이어야 합니다.");
      onSave(next);
    } catch (error) { message.error(error.message); }
  };
  const source = draft.sources[selectedSource];
  const stateUI = <div className="settingsPane">
    <Text type="secondary">WPF Binding과 비슷하게 TextBox 값을 연결하는 문자열 상태입니다. 현재는 문자열만 지원합니다.</Text>
    {Object.entries(draft.initialState).map(([key, value]) => <div className="settingsRow" key={key}>
      <code>{key}</code><Input aria-label={`${key} 초기값`} value={value} onChange={(e) => changeState(key, e.target.value)} placeholder="초기값"/>
      <Button danger size="small" onClick={() => setDraft((d) => { const vars = { ...d.initialState }; delete vars[key]; return { ...d, initialState: vars }; })}>삭제</Button>
    </div>)}
    <Space.Compact style={{ width: "100%" }}>
      <Input value={newStateName} placeholder="새 상태명 (예: queryText)" onChange={(e) => setNewStateName(e.target.value)} onPressEnter={addState}/>
      <Button onClick={addState}>상태 추가</Button>
    </Space.Compact>
  </div>;
  const sourceUI = <div className="settingsPane">
    <Text type="secondary">Mock JSON 배열 또는 인증 없는 REST GET API를 연결합니다. REST는 브라우저 CORS 정책을 따릅니다.</Text>
    <Space.Compact style={{ width: "100%" }}>
      <Input value={newSourceName} placeholder="새 소스명 (예: orders)" onChange={(e) => setNewSourceName(e.target.value)} onPressEnter={addSource}/>
      <Button onClick={addSource}>소스 추가</Button>
    </Space.Compact>
    <div className="settingsRow">
      <Select aria-label="데이터 소스 선택" style={{ minWidth: 180, flex: 1 }} value={selectedSource || undefined} onChange={setSelectedSource} options={Object.keys(draft.sources).map((k) => ({ label: k, value: k }))}/>
      <Button danger disabled={!source} onClick={() => {
        setDraft((d) => { const sources = { ...d.sources }; delete sources[selectedSource]; return { ...d, sources }; });
        setSelectedSource(Object.keys(draft.sources).find((k) => k !== selectedSource) || "");
      }}>소스 삭제</Button>
    </div>
    {source && <>
      <div className="settingLabel">종류</div>
      <Select style={{ width: "100%" }} value={source.kind} onChange={(kind) => {
        changeSource(selectedSource, kind === "rest" ? { kind, url: "https://jsonplaceholder.typicode.com/users", dataPath: "" } : { kind, rows: [] });
        if (kind === "mock") setRowsText((prev) => ({ ...prev, [selectedSource]: "[]" }));
      }}
        options={[{ label: "Mock · 샘플 JSON", value: "mock" }, { label: "REST · GET API", value: "rest" }]}/>
      {source.kind === "mock" ? <>
        <div className="settingLabel">JSON 배열 (최대 1,000개)</div>
        <Input.TextArea aria-label="샘플 JSON 배열" spellCheck={false} rows={9} style={{ fontFamily: "monospace" }} value={rowsText[selectedSource] ?? "[]"} onChange={(e) => setRowsText((prev) => ({ ...prev, [selectedSource]: e.target.value }))}/>
      </> : <>
        <div className="settingLabel">GET URL</div>
        <Input value={source.url || ""} placeholder="https://api.example.com/customers" onChange={(e) => changeSource(selectedSource, { url: e.target.value })}/>
        <div className="settingLabel">배열 응답 경로 (선택)</div>
        <Input value={source.dataPath || ""} placeholder="예: data.items (루트 배열이면 빈 값)" onChange={(e) => changeSource(selectedSource, { dataPath: e.target.value })}/>
      </>}
    </>}
  </div>;
  return <Modal width={740} open title="데이터 · 상태 모델 / Binding Manager" onCancel={onCancel} onOk={save} okText="설정 적용" cancelText="취소" destroyOnHidden>
    <Tabs items={[{ key: "state", label: "상태 변수", children: stateUI }, { key: "sources", label: "데이터 소스", children: sourceUI }]}/>
  </Modal>;
}

export function App() {
  const projectRef = useRef(loadProject());
  const [model, setModel] = useState(projectRef.current.model);
  const [mode, setMode] = useState("design");
  const [revision, setRevision] = useState(0);
  const [modelOpen, setModelOpen] = useState(false);
  const importRef = useRef(null);
  const config = useMemo(() => makeConfig(model), [model]);
  const persist = (project) => { projectRef.current = project; localStorage.setItem(STORAGE_KEY, JSON.stringify(project)); };
  const savePuck = (data) => persist({ ...projectRef.current, data });
  const saveModel = (next) => {
    persist({ ...projectRef.current, model: next });
    setModel(next); setModelOpen(false); setRevision((n) => n + 1);
    message.success("상태/데이터 모델이 저장되었습니다.");
  };
  const importJson = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      if (file.size > 2_000_000) throw new Error("2MB 이하 프로젝트 파일만 열 수 있습니다.");
      const project = importProject(JSON.parse(await file.text()));
      persist(project); setModel(project.model); setRevision((n) => n + 1); setMode("design");
      message.success("프로젝트를 불러왔습니다.");
    } catch (error) { message.error(error.message || "프로젝트를 읽을 수 없습니다."); }
    finally { event.target.value = ""; }
  };
  return <main className="appShell">
    <header className="topBar">
      <div><strong>React RAD Studio <span className="version">v0.2</span></strong><small>Visual Designer · PropertyGrid · EventHandler · Binding · Ant Design</small></div>
      <Space wrap>
        <Button onClick={() => setModelOpen(true)}>데이터 · 상태</Button>
        <Button onClick={() => importRef.current?.click()}>JSON 열기</Button>
        <input ref={importRef} type="file" accept="application/json,.json" style={{ display: "none" }} onChange={importJson}/>
        <Button onClick={() => download("rad-project.json", JSON.stringify(projectRef.current, null, 2), "application/json")}>JSON 저장</Button>
        <Button onClick={() => setMode(mode === "design" ? "preview" : "design")}>{mode === "design" ? "실행 미리보기" : "디자이너로"}</Button>
        <Button type="primary" onClick={() => download("CustomerPage.tsx", generateTsx(projectRef.current))}>React TSX 내보내기</Button>
      </Space>
    </header>
    {mode === "design" ? <div className="editorShell" key={revision}>
      <Puck config={config} data={projectRef.current.data} onChange={savePuck} onPublish={async (data) => { savePuck(data); message.success("프로젝트를 브라우저에 저장했습니다."); }}/>
    </div> : <section className="previewWrap">
      <div className="previewBar"><strong>실행 미리보기</strong><span>입력 → DataGrid 필터 · 버튼 이벤트 · REST GET</span></div>
      <div className="previewContent"><RuntimeProvider key={revision} model={model}><Render config={config} data={projectRef.current.data}/></RuntimeProvider></div>
    </section>}
    {modelOpen && <ModelSettings model={model} onSave={saveModel} onCancel={() => setModelOpen(false)}/>}
  </main>;
}
