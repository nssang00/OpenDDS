/** Versioned, serializable RAD project model. No executable expressions. */
export const SAMPLE_ROWS = [
  { id: "C001", name: "김민수", email: "minsu@example.com", status: "활성" },
  { id: "C002", name: "이지은", email: "jieun@example.com", status: "활성" },
  { id: "C003", name: "박서준", email: "seojun@example.com", status: "대기" }
];

export const sampleData = {
  content: [
    { type: "Heading", props: { id: "heading-1", text: "고객 관리" } },
    { type: "TwoColumns", props: { id: "cols-1", left: [
      { type: "TextInput", props: { id: "input-1", radName: "txtCustomer", label: "고객명", placeholder: "이름이나 이메일 검색", bindKey: "customerName" } }
    ], right: [
      { type: "ActionButton", props: { id: "button-1", radName: "btnSearch", text: "검색 완료", variant: "primary", event: { type: "message", message: "현재 검색 조건이 테이블에 반영되었습니다." } } },
      { type: "ActionButton", props: { id: "button-2", radName: "btnReset", text: "초기화", variant: "default", event: { type: "clearValue", target: "customerName" } } }
    ] } },
    { type: "Panel", props: { id: "panel-1", title: "고객 목록", content: [
      { type: "DataTable", props: { id: "table-1", radName: "gridCustomers", sourceKey: "customers", filterKey: "customerName", filterColumns: "name,email", columns: "id,name,email,status", pageSize: 5 } }
    ] } },
    { type: "Paragraph", props: { id: "helper", text: "상단의 데이터·상태 버튼에서 REST GET API와 바인딩 변수를 추가할 수 있습니다." } }
  ], root: {}
};

export const defaultModel = {
  initialState: { customerName: "", statusFilter: "" },
  sources: { customers: { kind: "mock", rows: SAMPLE_ROWS } }
};

const copy = (x) => JSON.parse(JSON.stringify(x));
export const createProject = () => ({ format: "react-rad-studio", schemaVersion: 2, data: copy(sampleData), model: copy(defaultModel) });

export const isSafeKey = (key) => /^[a-zA-Z_][a-zA-Z0-9_]{0,59}$/.test(key) && !["__proto__", "constructor", "prototype"].includes(key);
export const isSafeUrl = (url) => {
  try { const p = new URL(url); return ["https:", "http:"].includes(p.protocol) && Boolean(p.hostname); }
  catch { return false; }
};

export const columnKeys = (csv) => [...new Set(String(csv || "id,name,email").split(",").map((k) => k.trim()).filter((k) => /^[a-zA-Z_][\w.-]{0,59}$/.test(k)))].slice(0, 30);
export const getPath = (object, path) => String(path || "").split(".").filter(Boolean).reduce((acc, key) => acc && typeof acc === "object" && Object.hasOwn(acc, key) ? acc[key] : undefined, object);
export function filterRows(rows, search, columns) {
  if (!Array.isArray(rows)) return [];
  const q = String(search ?? "").trim().toLocaleLowerCase();
  if (!q) return rows;
  const fields = columnKeys(columns);
  return rows.filter((row) => fields.some((field) => String(getPath(row, field) ?? "").toLocaleLowerCase().includes(q)));
}

const TYPES = new Set(["Heading", "Paragraph", "TextInput", "ActionButton", "DataTable", "Panel", "TwoColumns"]);
export function validatePuck(data) {
  if (!data || typeof data !== "object" || !Array.isArray(data.content) || !data.root || typeof data.root !== "object") return false;
  let count = 0;
  function visit(nodes, depth) {
    if (!Array.isArray(nodes) || depth > 16) return false;
    return nodes.every((node) => {
      if (++count > 700 || !node || !TYPES.has(node.type) || !node.props || typeof node.props !== "object" || Array.isArray(node.props)) return false;
      return Object.values(node.props).every((val) => {
        if (Array.isArray(val)) return visit(val, depth + 1);
        if (val && typeof val === "object") return Object.values(val).every((v) => v === null || ["string", "number", "boolean"].includes(typeof v));
        return val === null || ["string", "number", "boolean"].includes(typeof val);
      });
    });
  }
  return visit(data.content, 0);
}

export function validateModel(model) {
  if (!model || typeof model !== "object" || !model.initialState || !model.sources) return false;
  const states = Object.entries(model.initialState);
  const sources = Object.entries(model.sources);
  if (states.length > 30 || sources.length > 20 || !states.every(([k,v]) => isSafeKey(k) && typeof v === "string" && v.length <= 300)) return false;
  return sources.every(([k, src]) => {
    if (!isSafeKey(k) || !src || !["mock", "rest"].includes(src.kind)) return false;
    if (src.kind === "rest") return typeof src.url === "string" && isSafeUrl(src.url) && typeof src.dataPath === "string" && /^[\w.]*$/.test(src.dataPath);
    return Array.isArray(src.rows) && src.rows.length <= 1000 && src.rows.every((r) => r && typeof r === "object" && !Array.isArray(r) && Object.values(r).every((v) => v === null || ["string", "number", "boolean"].includes(typeof v)));
  });
}

export function importProject(parsed) {
  // Backward compatibility for the Puck-only V1 starter.
  if (parsed?.format === "puck-prototype" || (parsed?.content && parsed?.root)) {
    const data = parsed?.data || parsed;
    if (!validatePuck(data)) throw new Error("이전 버전 JSON 형식이 올바르지 않습니다.");
    return { ...createProject(), data };
  }
  if (!parsed || parsed.schemaVersion !== 2 || !validatePuck(parsed.data) || !validateModel(parsed.model)) {
    throw new Error("프로젝트 JSON 스키마가 올바르지 않습니다.");
  }
  return { format: "react-rad-studio", schemaVersion: 2, data: parsed.data, model: parsed.model };
}
