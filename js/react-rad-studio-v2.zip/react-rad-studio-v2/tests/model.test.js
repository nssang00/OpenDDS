import test from "node:test";
import assert from "node:assert/strict";
import { createProject, defaultModel, filterRows, getPath, importProject, isSafeKey, validateModel } from "../src/rad-model.js";
import { generateTsx } from "../src/tsx-generator.js";

test("Project schema V2 round trip", () => {
  const project = createProject();
  assert.deepEqual(importProject(JSON.parse(JSON.stringify(project))), project);
});
test("Legacy Puck-only V1 data imports", () => {
  const data = createProject().data;
  const project = importProject({ format: "puck-prototype", schemaVersion: 1, data });
  assert.equal(project.schemaVersion, 2);
  assert.deepEqual(project.data, data);
  assert.ok(project.model.sources.customers);
});
test("Binding-driven DataTable filters over multiple columns", () => {
  const rows = defaultModel.sources.customers.rows;
  assert.equal(filterRows(rows, "지은", "name,email").length, 1);
  assert.equal(filterRows(rows, "minsu@", "name,email").length, 1);
  assert.equal(filterRows(rows, "", "name,email").length, 3);
  assert.deepEqual(filterRows(rows, "no match", "name,email"), []);
});
test("Safe source and state names, REST URL validation", () => {
  assert.ok(isSafeKey("customerName"));
  assert.ok(!isSafeKey("prototype.unsafe"));
  assert.ok(!validateModel({ initialState: { search: "" }, sources: { customers: { kind: "rest", url: "file:///etc/passwd", dataPath: "" } } }));
  assert.ok(validateModel({ initialState: { search: "" }, sources: { customers: { kind: "rest", url: "https://api.example.com/customers", dataPath: "data.items" } } }));
  assert.equal(getPath({ data: { items: [1, 2] } }, "data.items").length, 2);
});
test("TSX export contains complete runtime and expected event handlers", () => {
  const tsx = generateTsx(createProject());
  for (const token of ["useState", "useEffect", "filterRows(", "clearValue", "refresh", "fetch(", "runAction(", "source.kind", "customerName"]) assert.ok(tsx.includes(token), token);
  assert.ok(!tsx.includes("@puckeditor"), "generated output should not depend on visual editor");
});
test("JSX text string injection remains a string literal", () => {
  const project = createProject();
  project.data.content[0].props.text = '"}; alert(1337); //';
  const tsx = generateTsx(project);
  assert.ok(tsx.includes('>{"\\"}; alert(1337); //"}</Typography.Title>'));
});
