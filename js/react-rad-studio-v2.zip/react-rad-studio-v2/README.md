# React RAD Studio — v0.2 (PropertyGrid / Events / Binding)

MFC/WPF 개발자가 React + Ant Design UI를 마우스로 구성하고, 속성·이벤트·데이터 바인딩을 설정한 뒤 독립적인 React TSX 코드를 생성하는 **로컬 프로토타입**입니다.

## 실행

Node.js 20.19+ 또는 22.12+가 필요합니다.

```bash
npm install
npm run dev
```

브라우저 `http://127.0.0.1:5173`에서 실행합니다.

> 패키지 설치 후 `npm run build`로 빌드를 확인하세요. 이 파일 작성 환경에서는 npm 레지스트리 연결이 되지 않아 전체 브라우저 구동은 검증하지 못했습니다.

## 1분 동작 확인

1. **실행 미리보기**를 눌러 고객 관리 화면으로 이동합니다.
2. `고객명`에 `지은`을 입력하면 `DataGrid`가 김민수/박서준 행을 제외하고 이지은 행만 보여줍니다.
3. **초기화** 버튼을 누르면 검색 상태가 지워지고 3개 행이 다시 나옵니다.
4. **디자이너로** 돌아와 Button을 선택하고 Puck 우측 속성창의 **onClick (이벤트 편집기)**를 변경합니다.
5. **데이터 · 상태**에서 상태 변수나 데이터 소스를 추가합니다. DataGrid의 `DataSource`, `Filter` 속성으로 연결합니다.
6. **React TSX 내보내기** 버튼으로 `CustomerPage.tsx`를 다운로드합니다. 이 파일은 Puck 없이 React + AntD 프로젝트에서 사용 가능합니다.

## 포함된 기능

| 구분 | 기능 |
| --- | --- |
| Visual Designer | Puck 드래그 앤 드롭, 슬롯 패널/2열 레이아웃 |
| PropertyGrid | 컨트롤 이름, Width, Visible, Enabled, 텍스트, 데이터/바인딩 관련 속성 |
| EventHandler | Button `onClick`: ShowMessage, SetValue, ClearValue, RefreshSource |
| Data Binding | TextInput ↔ 상태 변수, DataTable ↔ 데이터 소스, TextInput 상태로 테이블 검색 |
| 데이터 소스 | 샘플 JSON, 인증 없는 REST GET, 응답 배열 경로 `data.items` |
| 미리보기 | 입력/버튼/필터/API GET 실제 동작 테스트 |
| JSON 저장 | 프로젝트 모델 + Puck 화면을 함께 저장 / V1 JSON 읽기 |
| 코드 내보내기 | Puck 의존성이 없는 단일 `CustomerPage.tsx` 파일 |
| 테스트 | 상태·필터·스키마·코드 생성기 Node 테스트 |

## 생성 TSX 사용

다른 React + Ant Design 앱에서 다운로드한 `CustomerPage.tsx`를 `src/`에 두고 다음처럼 불러옵니다.

```tsx
import CustomerPage from './CustomerPage';
export default function App() { return <CustomerPage />; }
```

## 테스트

```bash
npm test
npm run build
```

`npm test`는 추가 패키지 없이 Node 테스트를 실행합니다. `npm run build`는 `npm install` 이후 수행하세요.

## 한계와 보안

- Puck 자체 우측 속성 패널을 PropertyGrid로 활용합니다. Visual Studio 동일 UI를 별도로 재현한 것은 아닙니다.
- 상태는 문자열이며, 데이터 소스는 mock JSON 또는 인증 없는 **GET** 요청만 지원합니다. POST/PUT/DELETE, OAuth, 시크릿 보관은 미지원입니다.
- REST API 요청은 브라우저에서 직접 수행하며 CORS 제약을 받습니다. API 주소와 샘플 데이터는 **생성된 코드에 공개**됩니다. 민감 정보를 넣지 마세요.
- 액션은 4종의 고정 동작으로 제한하며, 문자열을 코드로 실행하지 않습니다.
- TSX는 **단방향** 생성입니다. 생성 파일을 수정한 뒤 UI 디자이너로 자동 역변환할 수 없습니다.
- JSON 스키마는 MVP 검증 단계로 정식 IR·AST·버전 마이그레이션 체계는 추가 구현이 필요합니다.
- 일부 레이아웃의 편집 중 표시와 실행 미리보기는 다릅니다. `Visible=hidden`일 때 편집 화면에서는 반투명으로 표시합니다.
- 협업, 인증, 저장소, 배포, 자동 API 검증, CORS 프록시, 코드-디자이너 양방향 동기화는 아직 구현되지 않았습니다.

## 구성

```
src/
  main.jsx          # Puck 스타일, React 진입점
  studio.jsx        # UI Builder / PropertyGrid / EventField / Binding Manager
  rad-runtime.jsx   # 미리보기용 상태·이벤트·REST GET 런타임
  rad-model.js      # 프로젝트 모델/검증/필터링
  tsx-generator.js  # 독립 실행형 React TSX 소스 생성기
  styles.css
tests/model.test.js
docs/architecture.md
docs/generated-example.tsx
```

자세한 설계 방향은 `docs/architecture.md`에 있습니다.
