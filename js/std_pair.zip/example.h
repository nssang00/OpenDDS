#include <utility>
#include <tuple>
#include <string>

namespace SmartGIS {

    typedef std::pair<int, double> MyPair;
    typedef std::tuple<int, double, std::string> MyTuple3;

    class PairUser {
    public:
        static MyPair make_pair(int a, double b) {
            return MyPair(a, b);
        }

        static int get_first(const MyPair& p) {
            return p.first;
        }

        static double get_second(const MyPair& p) {
            return p.second;
        }

        static MyTuple3 make_tuple(int a, double b, const std::string& s) {
            return MyTuple3(a, b, s);
        }

    };

} // namespace SmartGIS
