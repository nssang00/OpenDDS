using System;

namespace SmartGISharp
{
    class Program
    {
        static void Main()
        {
            var pair = PairUser.make_pair(42, 3.14);
            Console.WriteLine($"Pair: ({PairUser.get_first(pair)}, {PairUser.get_second(pair)})");

            var tuple = PairUser.make_tuple(1, 2.2, "hello");
            Console.WriteLine(tuple.Item3);
            //Console.WriteLine($"Tuple: ({PairUser.get_Item1(tuple)}, {PairUser.get_Item2(tuple)}, {PairUser.get_Item3(tuple)})");
        }
    }
}
