/** Deterministic standalone React/AntD TSX exporter, without Puck dependencies. */
import { columnKeys } from "./rad-model.js";
const q = (v) => JSON.stringify(String(v ?? ""));
const pad = (n) => "  ".repeat(n);
const safeAction = (action) => {
  const a = action && typeof action === "object" ? action : {};
  return { type: ["message", "clearValue", "setValue", "refresh"].includes(a.type) ? a.type : "message", target: String(a.target || ""), value: String(a.value || ""), message: String(a.message || "") };
};
const css = `.rad-page{max-width:1200px;margin:auto;padding:24px;display:flex;flex-direction:column;gap:16px}.rad-field{display:flex;flex-direction:column;gap:6px}.rad-field label{font-size:13px;font-weight:500}.rad-cols{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.rad-cols>div{min-width:0}.rad-table{min-width:0}.rad-dock{display:flex;flex-direction:column;gap:8px;min-height:240px}.rad-dock>.rad-dock-main{flex:1}@media(max-width:640px){.rad-cols{grid-template-columns:1fr}.rad-grid{grid-template-columns:1fr!important}}`;
const styleOf = (p) => JSON.stringify({
  width: ["50%", "100%"].includes(p.width) ? p.width : "auto",
  maxWidth: "100%",
  ...(p.visible === "hidden" ? { display: "none" } : {})
});

function renderNode(node, depth = 3, modules = {}) {
  const p = node.props || {}, s = pad(depth);
  const children = (array, d = depth + 1) => (Array.isArray(array) ? array : []).map((child) => renderNode(child, d, modules)).join("\n");
  const style = `style={${styleOf(p)}}`;
  switch (node.type) {
    case "Heading": return `${s}<Typography.Title level={2} ${style}>{${q(p.text)}}</Typography.Title>`;
    case "Paragraph": return `${s}<Typography.Paragraph ${style}>{${q(p.text)}}</Typography.Paragraph>`;
    case "TextInput": {
      const key = String(p.bindKey || "");
      const bound = key ? `value={values[${q(key)}] ?? ""} onChange={(e) => setValues((prev) => ({ ...prev, [${q(key)}]: e.target.value }))}` : `defaultValue=""`;
      return `${s}<div className="rad-field" ${style}>\n${s}  <label>{${q(p.label)}}</label>\n${s}  <Input placeholder={${q(p.placeholder)}} disabled={${p.disabled === "yes"}} ${bound} />\n${s}</div>`;
    }
    case "ActionButton": {
      const event = safeAction(p.event || (p.notificationText ? { type: "message", message: p.notificationText } : {}));
      return `${s}<Button ${style} type={${q(p.variant === "primary" ? "primary" : "default")}} disabled={${p.disabled === "yes"}} onClick={() => runAction(${JSON.stringify(event)})}>{${q(p.text)}}</Button>`;
    }
    case "DataTable": {
      const cols = columnKeys(p.columns).map((key) => ({ key, dataIndex: key, title: key }));
      const source = q(p.sourceKey || "customers"), filter = q(p.filterKey || "");
      const searchColumns = q(p.filterColumns || columnKeys(p.columns).join(","));
      const pageSize = Math.max(1, Math.min(50, Number(p.pageSize) || 5));
      return `${s}<div className="rad-table" ${style}>\n${s}  <Table size="small" rowKey={(row, idx) => String(row.id ?? idx)} loading={Boolean(loading[${source}])}\n${s}    dataSource={filterRows(datasets[${source}] ?? [], values[${filter}], ${searchColumns})}\n${s}    columns={${JSON.stringify(cols)}} pagination={{ pageSize: ${pageSize} }} scroll={{ x: true }} />\n${s}</div>`;
    }
    case "Panel": return `${s}<Card title={${q(p.title)}} size="small" ${style}>\n${children(p.content)}\n${s}</Card>`;
    case "TwoColumns": return `${s}<div className="rad-cols" ${style}>\n${s}  <div>\n${children(p.left, depth + 2)}\n${s}  </div>\n${s}  <div>\n${children(p.right, depth + 2)}\n${s}  </div>\n${s}</div>`;
    case "Stack": {
      const layoutStyle = JSON.stringify({ display: "flex", flexDirection: p.direction === "horizontal" ? "row" : "column", flexWrap: p.direction === "horizontal" ? "wrap" : "nowrap", gap: Number(p.gap) || 0, alignItems: p.align || "stretch", minWidth: 0, ...JSON.parse(styleOf(p)) });
      return `${s}<div style={${layoutStyle}}>\n${children(p.content)}\n${s}</div>`;
    }
    case "Grid": {
      const count = Math.max(1, Math.min(4, Number(p.columns) || 2));
      const layoutStyle = JSON.stringify({ display: "grid", gridTemplateColumns: `repeat(${count}, minmax(0, 1fr))`, gap: Number(p.gap) || 0, ...JSON.parse(styleOf(p)) });
      return `${s}<div className="rad-grid" style={${layoutStyle}}>\n${children(p.content)}\n${s}</div>`;
    }
    case "Dock": return `${s}<div className="rad-dock" ${style}>\n${s}  <div>\n${children(p.top, depth + 2)}\n${s}  </div>\n${s}  <div className="rad-dock-main">\n${children(p.main, depth + 2)}\n${s}  </div>\n${s}  <div>\n${children(p.bottom, depth + 2)}\n${s}  </div>\n${s}</div>`;
    case "SelectInput": {
      const key = String(p.bindKey || "");
      const bound = key ? `value={values[${q(key)}] ?? undefined} onChange={(v) => setValues((prev) => ({ ...prev, [${q(key)}]: String(v) }))}` : `defaultValue={undefined}`;
      const options = String(p.options || "").split(",").map((v) => v.trim()).filter(Boolean).map((value) => ({ label: value, value }));
      return `${s}<div className="rad-field" ${style}><label>{${q(p.label)}}</label><Select style={{ width: "100%" }} options={${JSON.stringify(options)}} ${bound}/></div>`;
    }
    case "CheckBox": {
      const key = String(p.bindKey || "");
      const bound = key ? `checked={values[${q(key)}] === "true"} onChange={(e) => setValues((prev) => ({ ...prev, [${q(key)}]: String(e.target.checked) }))}` : `defaultChecked={false}`;
      return `${s}<Checkbox ${style} ${bound}>{${q(p.label)}}</Checkbox>`;
    }
    case "Separator": return `${s}<Divider ${style}/>`;
    case "ModuleBlock": {
      const module = modules[p.moduleId];
      return module ? `${s}<div ${style}><RadModule_${p.moduleId} values={values} setValues={setValues} datasets={datasets} loading={loading} runAction={runAction}/></div>` : `${s}{/* Unresolved shared component */}`;
    }
    default: return `${s}{/* Unsupported component omitted */}`;
  }
}

export function generateTsx(project) {
  const data = project?.data || project;
  const model = project?.model || { initialState: { customerName: "" }, sources: {} };
  const widgets = (data?.content || []).map((node) => renderNode(node, 3, model.modules || {})).join("\n");
  const moduleFunctions = Object.entries(model.modules || {}).map(([id, m]) => {
    const body = m.content.map((node) => renderNode(node, 3, model.modules)).join("\n");
    return `function RadModule_${id}({ values, setValues, datasets, loading, runAction }: ModuleProps) {\n  return (\n    <>\n${body}\n    </>\n  );\n}`;
  }).join("\n\n");
  return `/** Generated by UI Studio v0.3. Standalone TSX, no Puck dependency. */
import React, { useCallback, useEffect, useState } from "react";
import { Button, Card, Checkbox, Divider, Input, Select, Table, Typography, message } from "antd";

type Row = Record<string, unknown>;
type Source = { kind: "mock"; rows: Row[] } | { kind: "rest"; url: string; dataPath: string };
type Action = { type: "message" | "clearValue" | "setValue" | "refresh"; target?: string; value?: string; message?: string };
type ModuleProps = {
  values: Record<string, string>;
  setValues: React.Dispatch<React.SetStateAction<Record<string, string>>>;
  datasets: Record<string, Row[]>;
  loading: Record<string, boolean>;
  runAction: (action: Action) => void;
};
const INITIAL_STATE: Record<string, string> = ${JSON.stringify(model.initialState, null, 2)};
const SOURCES: Record<string, Source> = ${JSON.stringify(model.sources, null, 2)};
const PAGE_CSS = ${JSON.stringify(css)};

function getPath(obj: unknown, path: string): unknown {
  return path.split(".").filter(Boolean).reduce<unknown>((acc, part) =>
    acc && typeof acc === "object" && Object.prototype.hasOwnProperty.call(acc, part)
      ? (acc as Record<string, unknown>)[part] : undefined, obj);
}
function filterRows(rows: Row[], search: unknown, keys: string): Row[] {
  const term = String(search ?? "").trim().toLocaleLowerCase();
  if (!term) return rows;
  const fields = keys.split(",").map((k) => k.trim()).filter(Boolean);
  return rows.filter((row) => fields.some((f) => String(getPath(row, f) ?? "").toLocaleLowerCase().includes(term)));
}
${moduleFunctions}

export default function CustomerPage() {
  const [values, setValues] = useState<Record<string, string>>(() => ({ ...INITIAL_STATE }));
  const [datasets, setDatasets] = useState<Record<string, Row[]>>(() => Object.fromEntries(
    Object.entries(SOURCES).map(([key, source]) => [key, source.kind === "mock" ? source.rows : []])));
  const [loading, setLoading] = useState<Record<string, boolean>>({});

  const refresh = useCallback(async (key: string, signal?: AbortSignal) => {
    const source = SOURCES[key];
    if (!source) throw new Error("데이터 소스를 찾을 수 없습니다: " + key);
    if (source.kind === "mock") { setDatasets((prev) => ({ ...prev, [key]: source.rows })); return; }
    const parsed = new URL(source.url);
    if (!["https:", "http:"].includes(parsed.protocol)) throw new Error("허용하지 않는 API URL");
    setLoading((prev) => ({ ...prev, [key]: true }));
    try {
      const response = await fetch(source.url, { method: "GET", credentials: "omit", signal });
      if (!response.ok) throw new Error("HTTP " + response.status);
      const json: unknown = await response.json();
      const rows = source.dataPath ? getPath(json, source.dataPath) : json;
      if (!Array.isArray(rows)) throw new Error("결과가 배열이 아닙니다.");
      setDatasets((prev) => ({ ...prev, [key]: rows.slice(0, 1000) }));
    } finally { setLoading((prev) => ({ ...prev, [key]: false })); }
  }, []);

  useEffect(() => {
    const controller = new AbortController();
    for (const [key, source] of Object.entries(SOURCES)) {
      if (source.kind === "rest") refresh(key, controller.signal).catch((error: Error) => {
        if (error.name !== "AbortError") message.error(key + ": " + error.message + " (CORS 설정 확인)");
      });
    }
    return () => controller.abort();
  }, [refresh]);

  const runAction = (action: Action) => {
    if (action.type === "message") message.info(action.message || "이벤트 실행");
    else if (action.type === "clearValue" && Object.prototype.hasOwnProperty.call(INITIAL_STATE, action.target))
      setValues((prev) => ({ ...prev, [action.target!]: "" }));
    else if (action.type === "setValue" && Object.prototype.hasOwnProperty.call(INITIAL_STATE, action.target))
      setValues((prev) => ({ ...prev, [action.target!]: String(action.value ?? "") }));
    else if (action.type === "refresh" && action.target)
      refresh(action.target).catch((error: Error) => message.error(error.message));
  };

  return (
    <main className="rad-page">
      <style>{PAGE_CSS}</style>
${widgets}
    </main>
  );
}
`;
}
