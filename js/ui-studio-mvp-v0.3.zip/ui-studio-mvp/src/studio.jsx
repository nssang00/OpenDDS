import React, { useMemo, useRef, useState } from "react";
import { Puck, Render, FieldLabel } from "@puckeditor/core";
import { Button, Card, Divider, Input, Modal, Select, Space, Tabs, Typography, message, Alert, Segmented } from "antd";
import { createProject, importProject, isSafeKey, validateModel, reusableCandidates, findNode } from "./rad-model.js";
import { RuntimeProvider, RadTextInput, RadButton, RadTable, RadSelectInput, RadCheckBox, commonStyle } from "./rad-runtime.jsx";
import { generateTsx } from "./tsx-generator.js";

const { Title, Text } = Typography;
const STORAGE_KEY = "ui-studio-project-v3";
const deepCopy = (value) => JSON.parse(JSON.stringify(value));

function download(filename, content, mime = "text/plain") {
  const blob = new Blob([content], { type: `${mime};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function loadProject() {
  try { return importProject(JSON.parse(localStorage.getItem(STORAGE_KEY) || "null")); }
  catch { return createProject(); }
}

function EventField({ value, onChange, stateKeys, sourceKeys, field }) {
  const a = { type: "message", target: "", value: "", message: "", ...(value && typeof value === "object" ? value : {}) };
  const set = (key, newValue) => onChange({ ...a, [key]: newValue });
  const isVariableAction = ["clearValue", "setValue"].includes(a.type);
  return <div className="eventField">
    <FieldLabel label={field.label || "onClick 이벤트"}/>
    <Select aria-label="클릭 이벤트 타입" value={a.type} style={{ width: "100%" }} onChange={(v) => onChange({ type: v, target: "", message: "", value: "" })}
      options={[
        { label: "ShowMessage · 알림", value: "message" },
        { label: "ClearValue · 입력 초기화", value: "clearValue" },
        { label: "SetValue · 상태 변경", value: "setValue" },
        { label: "RefreshSource · 데이터 새로고침", value: "refresh" }
      ]}/>
    {a.type === "message" && <Input value={a.message} placeholder="알림 메시지" aria-label="알림 메시지" onChange={(e) => set("message", e.target.value)}/>}
    {(isVariableAction || a.type === "refresh") && <Select style={{ width: "100%" }} aria-label="대상 선택" value={a.target || undefined} placeholder="대상 선택"
      onChange={(v) => set("target", v)}
      options={(isVariableAction ? stateKeys : sourceKeys).map((k) => ({ label: k, value: k }))}/>}
    {a.type === "setValue" && <Input aria-label="설정할 값" value={a.value} placeholder="설정할 값" onChange={(e) => set("value", e.target.value)}/>}
    <Text type="secondary" style={{ fontSize: 11 }}>onClick → {a.type}({a.target || (a.type === "message" ? "message" : "source")})</Text>
  </div>;
}

function makeConfig(model) {
  const stateKeys = Object.keys(model.initialState);
  const sourceKeys = Object.keys(model.sources);
  const stateChoices = [{ label: "바인딩 안 함", value: "" }, ...stateKeys.map((k) => ({ label: k, value: k }))];
  const sourceChoices = [{ label: "소스 선택", value: "" }, ...sourceKeys.map((k) => ({ label: k, value: k }))];
  const common = {
    radName: { type: "text", label: "(Name) 컨트롤 이름" },
    visible: { type: "select", label: "Visible", options: [{ label: "표시", value: "visible" }, { label: "숨기기", value: "hidden" }] },
    width: { type: "select", label: "Width", options: [{ label: "Auto", value: "auto" }, { label: "50%", value: "50%" }, { label: "100%", value: "100%" }] }
  };
  const defaultCommon = { radName: "", width: "100%", visible: "visible" };
  const moduleChoices = [{ label: "컴포넌트를 먼저 저장하세요", value: "" }, ...Object.entries(model.modules || {}).map(([key, m]) => ({ label: `${m.name} (v${m.version})`, value: key }))];
  const config = {
    categories: {
      layout: { title: "레이아웃", components: ["Stack", "Grid", "Dock", "Panel", "TwoColumns"] },
      form: { title: "입력·이벤트", components: ["TextInput", "SelectInput", "CheckBox", "ActionButton"] },
      data: { title: "데이터", components: ["DataTable"] },
      reuse: { title: "내 컴포넌트", components: ["ModuleBlock"] },
      text: { title: "텍스트", components: ["Heading", "Paragraph", "Separator"] }
    },
    components: {
      Heading: {
        label: "제목", fields: { text: { type: "text", label: "Text" }, ...common },
        defaultProps: { text: "새 제목", ...defaultCommon },
        render: (p) => <Title level={2} style={commonStyle(p, p.puck?.isEditing)}>{p.text}</Title>
      },
      Paragraph: {
        label: "본문", fields: { text: { type: "textarea", label: "Text" }, ...common },
        defaultProps: { text: "내용을 입력하세요.", ...defaultCommon },
        render: (p) => <Text style={commonStyle(p, p.puck?.isEditing)}>{p.text}</Text>
      },
      TextInput: {
        label: "TextBox", fields: {
          label: { type: "text", label: "Label" },
          placeholder: { type: "text", label: "Placeholder" },
          bindKey: { type: "select", label: "Binding / State", options: stateChoices },
          disabled: { type: "select", label: "Enabled", options: [{ label: "활성화", value: "no" }, { label: "비활성화", value: "yes" }] },
          ...common
        },
        defaultProps: { ...defaultCommon, radName: "textBox1", label: "고객명", placeholder: "입력하세요", bindKey: "", disabled: "no" },
        render: (p) => <RadTextInput {...p} isEditing={p.puck?.isEditing}/>
      },
      ActionButton: {
        label: "Button", fields: {
          text: { type: "text", label: "Text" },
          variant: { type: "select", label: "Style", options: [{ label: "기본", value: "default" }, { label: "강조", value: "primary" }] },
          disabled: { type: "select", label: "Enabled", options: [{ label: "활성화", value: "no" }, { label: "비활성화", value: "yes" }] },
          event: { type: "custom", label: "onClick (이벤트 편집기)", render: (props) => <EventField {...props} stateKeys={stateKeys} sourceKeys={sourceKeys}/> },
          ...common
        },
        defaultProps: { ...defaultCommon, radName: "button1", text: "실행", variant: "primary", disabled: "no", event: { type: "message", message: "버튼을 클릭했습니다." } },
        render: (p) => <RadButton {...p} isEditing={p.puck?.isEditing}/>
      },
      DataTable: {
        label: "DataGrid", fields: {
          sourceKey: { type: "select", label: "DataSource", options: sourceChoices },
          filterKey: { type: "select", label: "Filter / Binding", options: stateChoices },
          filterColumns: { type: "text", label: "Search columns (, 구분)" },
          columns: { type: "text", label: "Columns (, 구분)" },
          pageSize: { type: "number", label: "PageSize", min: 1, max: 50 },
          ...common
        },
        defaultProps: { ...defaultCommon, radName: "dataGrid1", columns: "id,name,email,status", pageSize: 5, sourceKey: "customers", filterKey: "", filterColumns: "name,email" },
        render: (p) => <RadTable {...p} isEditing={p.puck?.isEditing} fallbackRows={model.sources[p.sourceKey]?.kind === "mock" ? model.sources[p.sourceKey].rows : []}/>
      },
      Panel: {
        label: "GroupBox", fields: { title: { type: "text", label: "Header" }, ...common, content: { type: "slot" } },
        defaultProps: { ...defaultCommon, title: "새 패널", content: [] },
        render: ({ content: Content, puck, ...p }) => <Card title={p.title} size="small" style={commonStyle(p, puck?.isEditing)}><Content minEmptyHeight={95}/></Card>
      },
      TwoColumns: {
        label: "2열 그리드(간편)", fields: { ...common, left: { type: "slot" }, right: { type: "slot" } },
        defaultProps: { ...defaultCommon, left: [], right: [] },
        render: ({ left: Left, right: Right, puck, ...p }) => <div className="columns2" style={commonStyle(p, puck?.isEditing)}><Left minEmptyHeight={95}/><Right minEmptyHeight={95}/></div>
      },
      Stack: {
        label: "Stack / 순차", fields: {
          direction: { type: "radio", label: "방향", options: [{ label: "가로", value: "horizontal" }, { label: "세로", value: "vertical" }] },
          gap: { type: "number", label: "간격(px)", min: 0, max: 64 },
          align: { type: "select", label: "정렬", options: [{ label: "시작", value: "start" }, { label: "가운데", value: "center" }, { label: "끝", value: "end" }, { label: "늘이기", value: "stretch" }] },
          ...common, content: { type: "slot" }
        },
        defaultProps: { ...defaultCommon, direction: "vertical", gap: 12, align: "stretch", content: [] },
        render: ({ content: Content, puck, ...p }) => <Content className="rad-stack" minEmptyHeight={85} style={{ ...commonStyle(p, puck?.isEditing), display: "flex", flexDirection: p.direction === "horizontal" ? "row" : "column", alignItems: p.align || "stretch", gap: Number(p.gap) || 0, flexWrap: p.direction === "horizontal" ? "wrap" : "nowrap" }}/>
      },
      Grid: {
        label: "Grid / 격자", fields: {
          columns: { type: "select", label: "열 개수", options: [1, 2, 3, 4].map((x) => ({ label: `${x}열`, value: String(x) })) },
          gap: { type: "number", label: "간격(px)", min: 0, max: 64 }, ...common, content: { type: "slot" }
        },
        defaultProps: { ...defaultCommon, columns: "2", gap: 12, content: [] },
        render: ({ content: Content, puck, ...p }) => <Content className="rad-grid" minEmptyHeight={100} style={{ ...commonStyle(p, puck?.isEditing), display: "grid", gridTemplateColumns: `repeat(${Math.min(4, Math.max(1, Number(p.columns) || 2))}, minmax(0, 1fr))`, gap: Number(p.gap) || 0 }}/>
      },
      Dock: {
        label: "Dock / 영역", fields: { ...common, top: { type: "slot" }, main: { type: "slot" }, bottom: { type: "slot" } },
        defaultProps: { ...defaultCommon, top: [], main: [], bottom: [] },
        render: ({ top: Top, main: Main, bottom: Bottom, puck, ...p }) => <div className="rad-dock" style={commonStyle(p, puck?.isEditing)}><Top minEmptyHeight={52}/><Main minEmptyHeight={110}/><Bottom minEmptyHeight={52}/></div>
      },
      SelectInput: {
        label: "ComboBox", fields: { label: { type: "text", label: "레이블" }, options: { type: "text", label: "선택지 (, 구분)" }, bindKey: { type: "select", label: "상태 바인딩", options: stateChoices }, ...common },
        defaultProps: { ...defaultCommon, label: "상태", options: "진행중,완료,보류", bindKey: "" },
        render: (p) => <RadSelectInput {...p} isEditing={p.puck?.isEditing}/>
      },
      CheckBox: {
        label: "CheckBox", fields: { label: { type: "text", label: "레이블" }, bindKey: { type: "select", label: "상태 바인딩", options: stateChoices }, ...common },
        defaultProps: { ...defaultCommon, label: "확인", bindKey: "" },
        render: (p) => <RadCheckBox {...p} isEditing={p.puck?.isEditing}/>
      },
      Separator: {
        label: "구분선", fields: { ...common }, defaultProps: { ...defaultCommon },
        render: (p) => <Divider style={commonStyle(p, p.puck?.isEditing)}/>
      },
      ModuleBlock: {
        label: "저장된 컴포넌트", fields: { moduleId: { type: "select", label: "불러올 컴포넌트", options: moduleChoices }, ...common },
        defaultProps: { ...defaultCommon, moduleId: Object.keys(model.modules || {})[0] || "" },
        render: (p) => {
          const module = model.modules?.[p.moduleId];
          return <div className="rad-module" style={commonStyle(p, p.puck?.isEditing)}>
            {p.puck?.isEditing && <span className="rad-module-badge">▧ {module?.name || "저장된 컴포넌트를 선택하세요"}</span>}
            {module ? <Render config={config} data={{ root: {}, content: module.content }}/> : <Alert type="warning" showIcon message="컴포넌트 미선택"/>}
          </div>;
        }
      }
    }
  };
  return config;
}

function ModelSettings({ model, onSave, onCancel }) {
  const [draft, setDraft] = useState(() => deepCopy(model));
  const [newStateName, setNewStateName] = useState("");
  const [newSourceName, setNewSourceName] = useState("");
  const [selectedSource, setSelectedSource] = useState(Object.keys(model.sources)[0] || "");
  const [rowsText, setRowsText] = useState(() => Object.fromEntries(Object.entries(model.sources).filter(([,s]) => s.kind === "mock").map(([k,s]) => [k, JSON.stringify(s.rows, null, 2)])));
  const changeState = (key, value) => setDraft((d) => ({ ...d, initialState: { ...d.initialState, [key]: value } }));
  const changeSource = (key, patch) => setDraft((d) => ({ ...d, sources: { ...d.sources, [key]: { ...d.sources[key], ...patch } } }));
  const addState = () => {
    const k = newStateName.trim();
    if (!isSafeKey(k) || Object.hasOwn(draft.initialState, k)) return message.warning("영문·숫자·_ 로 된 중복되지 않는 이름을 입력하세요.");
    changeState(k, ""); setNewStateName("");
  };
  const addSource = () => {
    const k = newSourceName.trim();
    if (!isSafeKey(k) || Object.hasOwn(draft.sources, k)) return message.warning("영문·숫자·_ 로 된 중복되지 않는 소스 이름을 입력하세요.");
    changeSource(k, { kind: "mock", rows: [] }); setRowsText((prev) => ({ ...prev, [k]: "[]" })); setSelectedSource(k); setNewSourceName("");
  };
  const save = () => {
    try {
      const next = deepCopy(draft);
      for (const [key, src] of Object.entries(next.sources)) {
        if (src.kind === "mock") {
          const rows = JSON.parse(rowsText[key] ?? "[]");
          if (!Array.isArray(rows)) throw new Error(`${key}: 샘플 데이터가 배열이 아닙니다.`);
          src.rows = rows;
        }
      }
      if (!validateModel(next)) throw new Error("상태나 데이터 소스 설정이 유효하지 않습니다. REST 주소는 http(s) 형식이어야 합니다.");
      onSave(next);
    } catch (error) { message.error(error.message); }
  };
  const source = draft.sources[selectedSource];
  const stateUI = <div className="settingsPane">
    <Text type="secondary">WPF Binding과 비슷하게 TextBox 값을 연결하는 문자열 상태입니다. 현재는 문자열만 지원합니다.</Text>
    {Object.entries(draft.initialState).map(([key, value]) => <div className="settingsRow" key={key}>
      <code>{key}</code><Input aria-label={`${key} 초기값`} value={value} onChange={(e) => changeState(key, e.target.value)} placeholder="초기값"/>
      <Button danger size="small" onClick={() => setDraft((d) => { const vars = { ...d.initialState }; delete vars[key]; return { ...d, initialState: vars }; })}>삭제</Button>
    </div>)}
    <Space.Compact style={{ width: "100%" }}>
      <Input value={newStateName} placeholder="새 상태명 (예: queryText)" onChange={(e) => setNewStateName(e.target.value)} onPressEnter={addState}/>
      <Button onClick={addState}>상태 추가</Button>
    </Space.Compact>
  </div>;
  const sourceUI = <div className="settingsPane">
    <Text type="secondary">Mock JSON 배열 또는 인증 없는 REST GET API를 연결합니다. REST는 브라우저 CORS 정책을 따릅니다.</Text>
    <Space.Compact style={{ width: "100%" }}>
      <Input value={newSourceName} placeholder="새 소스명 (예: orders)" onChange={(e) => setNewSourceName(e.target.value)} onPressEnter={addSource}/>
      <Button onClick={addSource}>소스 추가</Button>
    </Space.Compact>
    <div className="settingsRow">
      <Select aria-label="데이터 소스 선택" style={{ minWidth: 180, flex: 1 }} value={selectedSource || undefined} onChange={setSelectedSource} options={Object.keys(draft.sources).map((k) => ({ label: k, value: k }))}/>
      <Button danger disabled={!source} onClick={() => {
        setDraft((d) => { const sources = { ...d.sources }; delete sources[selectedSource]; return { ...d, sources }; });
        setSelectedSource(Object.keys(draft.sources).find((k) => k !== selectedSource) || "");
      }}>소스 삭제</Button>
    </div>
    {source && <>
      <div className="settingLabel">종류</div>
      <Select style={{ width: "100%" }} value={source.kind} onChange={(kind) => {
        changeSource(selectedSource, kind === "rest" ? { kind, url: "https://jsonplaceholder.typicode.com/users", dataPath: "" } : { kind, rows: [] });
        if (kind === "mock") setRowsText((prev) => ({ ...prev, [selectedSource]: "[]" }));
      }}
        options={[{ label: "Mock · 샘플 JSON", value: "mock" }, { label: "REST · GET API", value: "rest" }]}/>
      {source.kind === "mock" ? <>
        <div className="settingLabel">JSON 배열 (최대 1,000개)</div>
        <Input.TextArea aria-label="샘플 JSON 배열" spellCheck={false} rows={9} style={{ fontFamily: "monospace" }} value={rowsText[selectedSource] ?? "[]"} onChange={(e) => setRowsText((prev) => ({ ...prev, [selectedSource]: e.target.value }))}/>
      </> : <>
        <div className="settingLabel">GET URL</div>
        <Input value={source.url || ""} placeholder="https://api.example.com/customers" onChange={(e) => changeSource(selectedSource, { url: e.target.value })}/>
        <div className="settingLabel">배열 응답 경로 (선택)</div>
        <Input value={source.dataPath || ""} placeholder="예: data.items (루트 배열이면 빈 값)" onChange={(e) => changeSource(selectedSource, { dataPath: e.target.value })}/>
      </>}
    </>}
  </div>;
  return <Modal width={740} open title="데이터 · 상태 모델 / Binding Manager" onCancel={onCancel} onOk={save} okText="설정 적용" cancelText="취소" destroyOnHidden>
    <Tabs items={[{ key: "state", label: "상태 변수", children: stateUI }, { key: "sources", label: "데이터 소스", children: sourceUI }]}/>
  </Modal>;
}

/** Save a visual container as a shared JSON definition. */
function ModuleManager({ project, onSave, onClose }) {
  const candidates = reusableCandidates(project.data);
  const entries = Object.entries(project.model.modules);
  const [sourceId, setSourceId] = useState(candidates[0]?.id || "");
  const [name, setName] = useState("NewComponent");
  const [targetId, setTargetId] = useState("");
  const save = () => {
    const node = findNode(project.data, sourceId);
    if (!node) return message.warning("저장할 컨테이너를 선택하세요.");
    const display = name.trim();
    if (!display || display.length > 60) return message.warning("컴포넌트 이름을 입력하세요. (최대 60자)");
    const modules = deepCopy(project.model.modules);
    const id = targetId || (() => {
      let i = 1;
      while (modules[`component_${i}`]) i++;
      return `component_${i}`;
    })();
    const old = modules[id];
    modules[id] = { name: display, version: old ? old.version + 1 : 1, content: [deepCopy(node)] };
    const next = { ...project.model, modules };
    if (!validateModel(next)) return message.error("이 컨테이너는 컴포넌트 참조 순환을 만들거나 잘못된 데이터를 포함합니다.");
    onSave(next);
    message.success(old ? "공유 컴포넌트 정의가 업데이트되었습니다." : "공유 컴포넌트가 추가되었습니다. 왼쪽 '내 컴포넌트'에서 배치할 수 있습니다.");
  };
  return <Modal title="내 컴포넌트 만들기" open onCancel={onClose} onOk={save} okText="라이브러리에 저장" width={650}>
    <div className="moduleManager">
      <Alert type="info" showIcon message="Stack·Grid·Panel 등의 컨테이너를 묶어 재사용합니다. 저장된 정의를 여러 곳에서 참조할 수 있습니다."/>
      <label className="settingLabel">1. 저장할 컨테이너</label>
      <Select style={{ width: "100%" }} value={sourceId || undefined} placeholder="먼저 캔버스에 컨테이너를 추가하세요" onChange={setSourceId}
        options={candidates.map((c) => ({ label: `${c.label} · ${c.type} · ${c.id}`, value: c.id }))}/>
      <label className="settingLabel">2. 컴포넌트 이름</label>
      <Input value={name} maxLength={60} onChange={(e) => setName(e.target.value)} placeholder="예: SearchPanel"/>
      <label className="settingLabel">3. 새로 저장하거나 기존 정의 업데이트</label>
      <Select style={{ width: "100%" }} value={targetId} onChange={(id) => { setTargetId(id); if (id) setName(project.model.modules[id].name); }}
        options={[{ label: "새 컴포넌트 생성", value: "" }, ...entries.map(([id, m]) => ({ label: `${m.name} (v${m.version}) 업데이트`, value: id }))]}/>
      <Text type="secondary" style={{ fontSize: 12 }}>기존 정의를 업데이트하면 해당 컴포넌트를 참조하는 모든 화면에 새 정의가 적용됩니다. 버전 기록·개별 Props/State 분리는 후속 기능입니다.</Text>
      <Divider style={{ margin: "3px 0" }}/>
      <Text strong>내 컴포넌트 ({entries.length})</Text>
      {entries.map(([id, m]) => <div className="moduleListItem" key={id}><span>▧ {m.name}</span><code>{id}</code><Text type="secondary">v{m.version}</Text></div>)}
    </div>
  </Modal>;
}

export function App() {
  const projectRef = useRef(loadProject());
  const [model, setModel] = useState(projectRef.current.model);
  const [mode, setMode] = useState("design");
  const [revision, setRevision] = useState(0);
  const [modelOpen, setModelOpen] = useState(false);
  const [moduleOpen, setModuleOpen] = useState(false);
  const [guideOpen, setGuideOpen] = useState(false);
  const [jsonDraft, setJsonDraft] = useState("");
  const importRef = useRef(null);
  const config = useMemo(() => makeConfig(model), [model]);
  const persist = (project) => { projectRef.current = project; localStorage.setItem(STORAGE_KEY, JSON.stringify(project)); };
  const savePuck = (data) => persist({ ...projectRef.current, data });
  const saveModel = (next) => {
    persist({ ...projectRef.current, model: next });
    setModel(next); setModelOpen(false); setModuleOpen(false); setRevision((n) => n + 1);
  };
  const applyProject = (parsed) => {
    const project = importProject(parsed);
    persist(project);
    setModel(project.model);
    setRevision((n) => n + 1);
    setMode("design");
  };
  const importJson = async (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    try {
      if (file.size > 2_000_000) throw new Error("2MB 이하 프로젝트 파일만 열 수 있습니다.");
      applyProject(JSON.parse(await file.text()));
      message.success("프로젝트를 불러왔습니다.");
    } catch (error) { message.error(error.message || "프로젝트를 읽을 수 없습니다."); }
    finally { event.target.value = ""; }
  };
  const changeMode = (m) => {
    if (m === "json") setJsonDraft(JSON.stringify(projectRef.current, null, 2));
    setMode(m);
  };
  const applyJson = () => {
    try { applyProject(JSON.parse(jsonDraft)); message.success("JSON 변경 사항이 반영되었습니다."); }
    catch (error) { message.error(error.message || "JSON 형식이 올바르지 않습니다."); }
  };
  const reset = () => Modal.confirm({
    title: "샘플 프로젝트로 초기화할까요?",
    content: "현재 브라우저에 저장된 편집 내용이 삭제됩니다. 필요한 경우 먼저 JSON을 저장하세요.",
    okText: "초기화", okType: "danger", cancelText: "취소",
    onOk: () => { applyProject(createProject()); message.success("샘플 프로젝트를 열었습니다."); }
  });
  return <main className="appShell">
    <header className="topBar">
      <div className="brand"><strong>◈ UI Studio <span className="version">MVP 0.3</span></strong><small>배치 · 조합 · 데이터 연결 · 실행</small></div>
      <Space size={7} wrap>
        <Button onClick={() => setGuideOpen(true)}>처음 시작하기</Button>
        <Button onClick={() => setModuleOpen(true)}>▧ 컴포넌트 저장</Button>
        <Button onClick={() => setModelOpen(true)}>데이터 연결</Button>
        <Button onClick={() => importRef.current?.click()}>JSON 열기</Button>
        <input ref={importRef} type="file" accept="application/json,.json" style={{ display: "none" }} onChange={importJson}/>
        <Button onClick={() => download("ui-studio-project.json", JSON.stringify(projectRef.current, null, 2), "application/json")}>JSON 저장</Button>
        <Button onClick={reset}>샘플 초기화</Button>
        <Button type="primary" onClick={() => download("CustomerPage.tsx", generateTsx(projectRef.current))}>React TSX 받기</Button>
      </Space>
    </header>
    <div className="modeBar">
      <Segmented value={mode} onChange={changeMode} options={[
        { value: "design", label: "디자인" }, { value: "preview", label: "▶ 실행" },
        { value: "code", label: "코드" }, { value: "json", label: "JSON" }
      ]}/>
      <Text type="secondary" style={{ fontSize: 12 }}>브라우저에 자동 저장 · 공유 컴포넌트 {Object.keys(model.modules).length}개</Text>
    </div>
    {mode === "design" ? <div className="editorShell" key={revision}>
      <Puck config={config} data={projectRef.current.data} onChange={savePuck}
        onPublish={async (data) => { savePuck(data); message.success("브라우저에 저장했습니다."); }}/>
    </div> : mode === "preview" ? <section className="previewWrap">
      <div className="previewBar"><strong>실행 미리보기</strong><span>입력 변경 · 검색 필터 · 버튼 이벤트 · REST GET 연결</span></div>
      <div className="previewContent"><RuntimeProvider key={revision} model={model}><Render config={config} data={projectRef.current.data}/></RuntimeProvider></div>
    </section> : mode === "code" ? <section className="textWorkspace">
      <div className="workspaceTitle"><div><strong>React / Ant Design 생성 코드</strong><p>읽기 전용입니다. 다운로드해 일반 React 프로젝트에서 수정할 수 있습니다.</p></div><Button onClick={() => download("CustomerPage.tsx", generateTsx(projectRef.current))}>TSX 다운로드</Button></div>
      <Input.TextArea rows={28} spellCheck={false} readOnly value={generateTsx(projectRef.current)} className="codeArea"/>
    </section> : <section className="textWorkspace">
      <div className="workspaceTitle"><div><strong>프로젝트 JSON 편집</strong><p>디자인·데이터 소스·공유 컴포넌트 정의가 함께 저장됩니다. 적용 전 구조를 검증합니다.</p></div><Button type="primary" onClick={applyJson}>JSON 적용</Button></div>
      <Input.TextArea rows={28} spellCheck={false} value={jsonDraft} onChange={(e) => setJsonDraft(e.target.value)} className="codeArea"/>
    </section>}
    {modelOpen && <ModelSettings model={model} onSave={saveModel} onCancel={() => setModelOpen(false)}/>}
    {moduleOpen && <ModuleManager project={projectRef.current} onSave={saveModel} onClose={() => setModuleOpen(false)}/>}
    <Modal title="UI Studio · 5분 시작 가이드" open={guideOpen} onCancel={() => setGuideOpen(false)} onOk={() => { setGuideOpen(false); changeMode("design"); }} okText="디자인 시작" cancelText="닫기" width={670}>
      <ol className="quickGuide">
        <li><b>실행해 보기:</b> 상단의 ‘▶ 실행’을 누르고 고객 이름을 검색해 보세요.</li>
        <li><b>UI 배치:</b> ‘디자인’으로 돌아가 왼쪽 Toolbox에서 Stack, Grid, Input, Button을 중앙에 끌어 놓습니다.</li>
        <li><b>속성 변경:</b> 캔버스의 컴포넌트를 선택하고 오른쪽 필드에서 텍스트·배치·바인딩을 수정합니다.</li>
        <li><b>컴포넌트로 저장:</b> Stack·Grid·Panel을 만든 뒤 ‘▧ 컴포넌트 저장’에서 선택합니다. 왼쪽 ‘내 컴포넌트’를 여러 번 배치해 재사용합니다.</li>
        <li><b>데이터 연결:</b> ‘데이터 연결’에서 상태나 샘플 JSON / REST GET을 등록하고 컴포넌트 바인딩을 선택합니다.</li>
        <li><b>내보내기:</b> JSON은 디자이너로 다시 읽을 수 있고, TSX는 일반 React + AntD 소스입니다.</li>
      </ol>
      <Alert type="info" showIcon message="첫 버전의 공유 컴포넌트는 UI 정의를 참조합니다. 독립 Props·내부 상태·모듈별 이벤트 공개는 아직 지원하지 않습니다."/>
    </Modal>
  </main>;
}
