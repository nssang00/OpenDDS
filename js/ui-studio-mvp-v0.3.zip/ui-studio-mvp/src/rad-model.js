/** Serializable UI Studio project data. All actions are declarative; never eval project JSON. */
export const SAMPLE_ROWS = [
  { id: "C001", name: "김민수", email: "minsu@example.com", status: "활성" },
  { id: "C002", name: "이지은", email: "jieun@example.com", status: "활성" },
  { id: "C003", name: "박서준", email: "seojun@example.com", status: "대기" }
];

const clone = (value) => JSON.parse(JSON.stringify(value));
const searchNode = {
  type: "Stack", props: {
    id: "search-stack", direction: "horizontal", gap: 12, align: "end",
    content: [
      { type: "TextInput", props: { id: "search-input", label: "고객 검색", placeholder: "이름 또는 이메일", bindKey: "customerName" } },
      { type: "ActionButton", props: { id: "search-reset", text: "초기화", variant: "default", event: { type: "clearValue", target: "customerName" } } }
    ]
  }
};
export const sampleData = {
  root: {}, content: [
    { type: "Heading", props: { id: "heading-1", text: "고객 관리" } },
    { type: "Paragraph", props: { id: "intro", text: "왼쪽에서 컴포넌트를 추가하고 오른쪽에서 속성을 설정하세요. 실행 버튼으로 실제 동작을 확인할 수 있습니다." } },
    { type: "Panel", props: { id: "search-panel", title: "검색 조건", content: [
      { type: "ModuleBlock", props: { id: "reusable-search", moduleId: "searchPanel" } }
    ] } },
    { type: "Panel", props: { id: "list-panel", title: "고객 목록", content: [
      { type: "DataTable", props: { id: "table-1", sourceKey: "customers", filterKey: "customerName", filterColumns: "name,email", columns: "id,name,email,status", pageSize: 5 } }
    ] } }
  ]
};

export const defaultModel = {
  initialState: { customerName: "" },
  sources: { customers: { kind: "mock", rows: SAMPLE_ROWS } },
  modules: {
    "searchPanel": { name: "SearchPanel", version: 1, content: [searchNode] }
  }
};

export const createProject = () => ({ format: "ui-studio", schemaVersion: 3, data: clone(sampleData), model: clone(defaultModel) });
export const isSafeKey = (key) => /^[a-zA-Z_][a-zA-Z0-9_]{0,59}$/.test(key) && !["__proto__", "constructor", "prototype"].includes(key);
export const isSafeUrl = (url) => { try { const p = new URL(url); return ["https:", "http:"].includes(p.protocol) && Boolean(p.hostname); } catch { return false; } };
export const columnKeys = (csv) => [...new Set(String(csv || "id,name,email").split(",").map((k) => k.trim()).filter((k) => /^[a-zA-Z_][\w.-]{0,59}$/.test(k)))].slice(0, 30);
export const getPath = (object, path) => String(path || "").split(".").filter(Boolean).reduce((acc, key) => acc && typeof acc === "object" && Object.hasOwn(acc, key) ? acc[key] : undefined, object);
export function filterRows(rows, search, columns) {
  if (!Array.isArray(rows)) return [];
  const q = String(search ?? "").trim().toLocaleLowerCase();
  if (!q) return rows;
  const fields = columnKeys(columns);
  return rows.filter((row) => fields.some((field) => String(getPath(row, field) ?? "").toLocaleLowerCase().includes(q)));
}

// Slot arrays must be explicitly listed to distinguish child nodes from ordinary prop arrays.
export const SLOT_KEYS = { Panel: ["content"], TwoColumns: ["left", "right"], Stack: ["content"], Grid: ["content"], Dock: ["top", "main", "bottom"] };
const TYPES = new Set(["Heading", "Paragraph", "TextInput", "ActionButton", "DataTable", "Panel", "TwoColumns", "Stack", "Grid", "Dock", "ModuleBlock", "SelectInput", "CheckBox", "Separator"]);
const isPlainValue = (value, depth = 0) => {
  if (depth > 6) return false;
  if (value === null || ["string", "number", "boolean"].includes(typeof value)) return true;
  if (Array.isArray(value)) return value.length <= 100 && value.every((entry) => isPlainValue(entry, depth + 1));
  return typeof value === "object" && Object.keys(value).length <= 30 && Object.values(value).every((v) => isPlainValue(v, depth + 1));
};
export function validateNodes(nodes, depth = 0, counter = { total: 0 }) {
  if (!Array.isArray(nodes) || depth > 16) return false;
  return nodes.every((node) => {
    if (++counter.total > 700 || !node || !TYPES.has(node.type) || !node.props || typeof node.props !== "object" || Array.isArray(node.props)) return false;
    if (typeof node.props.id !== "string" || node.props.id.length > 120) return false;
    const slots = SLOT_KEYS[node.type] || [];
    return Object.entries(node.props).every(([key, val]) => slots.includes(key) ? validateNodes(val || [], depth + 1, counter) : isPlainValue(val));
  });
}
export function validatePuck(data) {
  return Boolean(data && typeof data === "object" && Array.isArray(data.content) && data.root && typeof data.root === "object" && validateNodes(data.content));
}
export function walkNodes(nodes, fn) {
  for (const node of nodes || []) {
    fn(node);
    for (const slot of SLOT_KEYS[node.type] || []) walkNodes(node.props?.[slot], fn);
  }
}
export function reusableCandidates(data) {
  const result = [];
  walkNodes(data.content, (node) => {
    if (["Panel", "Stack", "Grid", "TwoColumns", "Dock"].includes(node.type)) result.push({ id: node.props.id, type: node.type, label: node.props.title || node.props.radName || node.type });
  });
  return result;
}
export function findNode(data, id) { let found; walkNodes(data.content, (node) => { if (node.props.id === id) found = node; }); return found; }
export function referencesModule(nodes, moduleId) { let found = false; walkNodes(nodes, (n) => { if (n.type === "ModuleBlock" && n.props.moduleId === moduleId) found = true; }); return found; }
export function validateModel(model) {
  if (!model || typeof model !== "object" || !model.initialState || !model.sources || !model.modules) return false;
  const states = Object.entries(model.initialState), sources = Object.entries(model.sources), modules = Object.entries(model.modules);
  if (states.length > 30 || sources.length > 20 || modules.length > 40 || !states.every(([k,v]) => isSafeKey(k) && typeof v === "string" && v.length <= 300)) return false;
  if (!sources.every(([k, src]) => {
    if (!isSafeKey(k) || !src || !["mock", "rest"].includes(src.kind)) return false;
    if (src.kind === "rest") return typeof src.url === "string" && isSafeUrl(src.url) && typeof src.dataPath === "string" && /^[\w.]*$/.test(src.dataPath);
    return Array.isArray(src.rows) && src.rows.length <= 1000 && src.rows.every((r) => r && typeof r === "object" && !Array.isArray(r) && Object.values(r).every((v) => isPlainValue(v)));
  })) return false;
  if (!modules.every(([key,m]) => isSafeKey(key) && typeof m?.name === "string" && m.name.length <= 60 && Number.isInteger(m.version) && m.version > 0 && validateNodes(m.content))) return false;
  // Acyclic module reference graph. Modules are shared definitions, not copies.
  const visited = new Set(), active = new Set();
  function dfs(id) {
    if (active.has(id)) return false;
    if (visited.has(id)) return true;
    visited.add(id); active.add(id);
    let valid = true;
    walkNodes(model.modules[id].content, (node) => {
      if (node.type === "ModuleBlock") {
        const child = node.props.moduleId;
        if (!model.modules[child] || !dfs(child)) valid = false;
      }
    });
    active.delete(id);
    return valid;
  }
  return modules.every(([id]) => dfs(id));
}
export function importProject(parsed) {
  if (parsed?.format === "puck-prototype" || (parsed?.content && parsed?.root)) {
    throw new Error("Puck-only v1 프로젝트는 v0.3의 레이아웃 모델과 달라 자동 가져오기를 지원하지 않습니다. v0.2로 변환하세요.");
  }
  if (parsed?.schemaVersion === 2 && validatePuck(parsed.data)) {
    const prevModel = parsed.model || {};
    const next = { ...createProject(), data: parsed.data, model: { initialState: prevModel.initialState || {}, sources: prevModel.sources || {}, modules: {} } };
    if (!validateModel(next.model)) throw new Error("v0.2 프로젝트 모델이 유효하지 않습니다.");
    return next;
  }
  if (!parsed || parsed.schemaVersion !== 3 || !validatePuck(parsed.data) || !validateModel(parsed.model)) throw new Error("프로젝트 JSON 스키마가 유효하지 않습니다.");
  return { format: "ui-studio", schemaVersion: 3, data: parsed.data, model: parsed.model };
}
