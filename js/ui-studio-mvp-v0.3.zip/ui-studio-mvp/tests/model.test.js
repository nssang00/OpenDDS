import test from "node:test";
import assert from "node:assert/strict";
import ts from "typescript";
import { createProject, defaultModel, filterRows, findNode, getPath, importProject, isSafeKey, reusableCandidates, validateModel, validatePuck } from "../src/rad-model.js";
import { generateTsx } from "../src/tsx-generator.js";

function parseTsx(source) {
  const syntax = ts.createSourceFile("CustomerPage.tsx", source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  assert.deepEqual(syntax.parseDiagnostics.map((d) => ts.flattenDiagnosticMessageText(d.messageText, " ")), []);
}

test("v3 project has reproducible sample + shared component", () => {
  const project = createProject();
  assert.equal(project.schemaVersion, 3);
  assert.equal(project.model.modules["searchPanel"].name, "SearchPanel");
  assert.deepEqual(importProject(JSON.parse(JSON.stringify(project))), project);
  assert.ok(validatePuck(project.data));
});
test("v2 project import migrates modules to empty registry", () => {
  const old = createProject();
  old.schemaVersion = 2;
  old.model = { initialState: { query: "" }, sources: old.model.sources };
  old.data = { root: {}, content: [{ type: "Heading", props: { id: "heading", text: "Legacy" } }] };
  const migrated = importProject(old);
  assert.equal(migrated.schemaVersion, 3);
  assert.deepEqual(migrated.model.modules, {});
});
test("binding filters rows and dotted path", () => {
  const rows = defaultModel.sources.customers.rows;
  assert.equal(filterRows(rows, "지은", "name,email").length, 1);
  assert.equal(filterRows(rows, "minsu@", "name,email").length, 1);
  assert.equal(filterRows(rows, "", "name,email").length, 3);
  assert.equal(filterRows(rows, "nobody", "name,email").length, 0);
  assert.deepEqual(getPath({ data: { items: [1, 2] } }, "data.items"), [1, 2]);
});
test("module candidate discovery and nested selection", () => {
  const project = createProject();
  const options = reusableCandidates(project.data);
  assert.equal(options.length, 2);
  assert.equal(findNode(project.data, "list-panel").type, "Panel");
});
test("model rejects unsafe keys, protocols and module cycles", () => {
  assert.ok(isSafeKey("customerName"));
  assert.ok(!isSafeKey("__proto__"));
  const model = structuredClone(defaultModel);
  model.sources.bad = { kind: "rest", url: "file:///etc/passwd", dataPath: "" };
  assert.equal(validateModel(model), false);
  delete model.sources.bad;
  model.modules.a = { name: "A", version: 1, content: [{ type: "ModuleBlock", props: { id: "a", moduleId: "b" } }] };
  model.modules.b = { name: "B", version: 1, content: [{ type: "ModuleBlock", props: { id: "b", moduleId: "a" } }] };
  assert.equal(validateModel(model), false);
  model.modules.b.content = [{ type: "Paragraph", props: { id: "b", text: "safe" } }];
  assert.equal(validateModel(model), true);
});
test("generated TSX expands shared module and has no Puck dependency", () => {
  const tsx = generateTsx(createProject());
  for (const token of ["useState", "useEffect", "filterRows(", "clearValue", "refresh", "fetch(", "runAction(", "customerName", "고객 검색", "검색 조건"]) assert.ok(tsx.includes(token), token);
  assert.ok(!tsx.includes("@puckeditor"));
  parseTsx(tsx);
});
test("TSX exports grid, dock, stack, select and checkbox", () => {
  const project = createProject();
  project.data.content = [{ type: "Dock", props: { id: "dock", top: [], main: [{ type: "Grid", props: { id: "grid", columns: "3", gap: 10, content: [
    { type: "SelectInput", props: { id: "select", label: "상태", options: "A,B", bindKey: "customerName" } },
    { type: "CheckBox", props: { id: "check", label: "확인", bindKey: "customerName" } },
    { type: "Separator", props: { id: "sep" } }
  ] } }], bottom: [] } }];
  const tsx = generateTsx(project);
  for (const token of ["rad-dock", "rad-grid", "<Select", "<Checkbox", "<Divider"]) assert.ok(tsx.includes(token), token);
  parseTsx(tsx);
});
test("React JSX string injection stays a string literal", () => {
  const project = createProject();
  project.data.content[0].props.text = '"}; alert(1337); //';
  const tsx = generateTsx(project);
  assert.ok(tsx.includes('>{"\\"}; alert(1337); //"}</Typography.Title>'));
  parseTsx(tsx);
});
