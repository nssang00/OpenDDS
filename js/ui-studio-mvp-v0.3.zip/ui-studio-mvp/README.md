# UI Studio — React + Ant Design MVP v0.3

MFC/WPF 사용자도 쉽고 빠르게 웹 화면을 조립하는 것을 목표로 만든 실행 가능한 **개발용 프로토타입**입니다.

## 1. 실행 (Node.js 20.19+ 또는 22.12+ 권장)

```bash
npm install
npm run dev
```

브라우저에서 터미널에 표시된 로컬 주소(일반적으로 `http://localhost:5173`)를 엽니다.

```bash
npm test       # 프로젝트 스키마·모듈·코드 생성 자동 테스트
npm run build  # 프로덕션 빌드
```

> 이 파일을 만든 환경에서는 npm 레지스트리로 패키지를 다운로드할 수 없어 실제 브라우저 실행 및 `npm run build`는 검증하지 못했습니다. 소스 구문과 데이터·코드 생성 테스트는 확인했습니다.

## 2. 5분 빠른 사용법

1. **실행**을 클릭하면 샘플 고객관리 화면에서 이름/이메일 필터링과 초기화 버튼을 시험할 수 있습니다.
2. **디자인**을 클릭하고 왼쪽 목록의 `Stack / 순차`, `Grid / 격자`, `Input`, `Button` 등을 중앙 캔버스로 끌어 옵니다.
3. 편집 중인 요소를 클릭하면 오른쪽 속성 패널에서 배치 방향/간격/문구를 변경할 수 있습니다.
4. `▧ 컴포넌트 저장`을 클릭하고 캔버스에서 만든 `Stack`, `Grid`, `Panel` 등의 컨테이너를 선택해 저장합니다.
5. 왼쪽 **내 컴포넌트 → 저장된 컴포넌트**를 캔버스에 배치합니다. 같은 컴포넌트를 여러 번 배치하고 속성창에서 저장된 정의를 선택할 수 있습니다.
6. `데이터 연결`에서 화면의 상태 변수나 샘플 JSON / REST GET을 등록한 뒤 Input의 `Binding/State` 또는 Table의 `DataSource`에 연결합니다.
7. **코드** 탭에서는 생성된 독립 React/AntD TSX를 보고 다운로드할 수 있고, **JSON** 탭에서는 프로젝트 스키마를 직접 편집·적용할 수 있습니다.

프로젝트 변경은 브라우저 `localStorage`에 자동 저장됩니다. 다른 PC로 옮길 때는 **JSON 저장 → JSON 열기**를 사용하세요.

## 3. 포함된 기능

| 항목 | 구현 상태 |
|---|---|
| 편집기 | Puck 기반 Drag & Drop, 요소 선택/속성 변경 |
| 레이아웃 | Stack(가로·세로), Grid(1~4열), Dock(상·중·하), 2열 Grid, Panel |
| UI | Heading, Text, TextInput, Select, CheckBox, Button, Table, Divider |
| 데이터 | 샘플 JSON, 인증 없는 REST GET, 문자열 상태 키, 테이블 필터 |
| 이벤트 | 알림, 상태 설정, 상태 초기화, 데이터 소스 새로고침 |
| 재사용 | 컨테이너를 공유 컴포넌트로 등록, 여러 인스턴스 참조, 정의 업데이트 |
| 저장 | JSON 프로젝트 검증, 내보내기·가져오기, v0.2 데이터 가져오기 |
| 실행 | 프로젝트 스키마 기반 실시간 Preview |
| 코드 | Puck 비의존 React/TypeScript + AntD TSX 파일 생성. 공유 모듈은 별도 함수 컴포넌트로 생성 |

## 4. 현 단계의 의도적인 제한

- **재사용 블록은 공유 UI 정의**입니다. 각 인스턴스의 Props 공개, 내부 State 분리, Module Event API, 모듈별 버전 고정은 아직 없습니다. 상태 바인딩은 페이지 단위로 공유됩니다.
- **코드 양방향 동기화**는 지원하지 않습니다. 생성된 TSX 수정 내용은 Designer로 자동 역변환되지 않습니다.
- **Freeform/좌표 편집**은 아직 없습니다. 기본 UI는 Stack/Grid를 사용합니다.
- **데이터 연동**은 인증 없는 GET JSON에 한정됩니다. CORS 정책에 따라 실제 서버가 요청을 허용해야 합니다. 서버 프록시나 인증·저장(POST/PUT/DELETE)은 아직 없습니다.
- **AntD 중심**입니다. MUI 어댑터와 사용자의 npm 컴포넌트 등록과 여러 페이지 관리 기능은 아직 없습니다.
- **배포 플랫폼**이 아닌 로컬 개발용 프로토타입입니다. 사용자 인증·권한·협업·서버 저장소가 없습니다.
- 공유 컴포넌트의 정의를 변경하려면 캔버스에서 별도 컨테이너를 수정한 후 `▧ 컴포넌트 저장 → 기존 컴포넌트 업데이트`로 반영합니다.

## 5. 프로젝트 구성

```text
src/
  studio.jsx           Puck 편집기, 속성 설정, 모듈 관리, 디자인/실행/코드/JSON 화면
  rad-model.js         프로젝트 스키마, 모듈 참조 검증, v0.2 마이그레이션
  rad-runtime.jsx      Preview의 상태, API, 액션 처리, AntD 래퍼
  tsx-generator.js     Puck 의존성 없는 React+AntD TSX 생성
  styles.css           Studio와 기본 컴포넌트 스타일
examples/
  demo-project.json    (후속 갱신 파일)
tests/
  model.test.js        8개 단위 테스트
```

## 6. 이후 확장 방향

1. 공유 컴포넌트에 **typed Props / Events / Slots / 내부 State scope** 구현
2. Form 레이아웃, Grid의 Span, 크기 Auto/Fill/Fixed, Breakpoints
3. OpenAPI import → Typed DataSource → CRUD 템플릿
4. 사용자 정의 npm React 컴포넌트 메타데이터 등록, MUI 렌더러
5. 자체 DSL↔JSON 양방향 변환과 분리된 사용자 코드 영역

## 참고

- Puck: https://puckeditor.com/docs/getting-started
- React: https://react.dev/
- Ant Design: https://ant.design/
