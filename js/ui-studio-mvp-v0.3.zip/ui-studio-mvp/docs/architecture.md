# UI Studio architecture (v0.3)

```text
Puck Designer ─┐
JSON Editor ───┼─> Serializable project {data, model}
Template ─────┘                │
                     ┌─────────┴──────────┐
                     │                    │
               Preview Render      React TSX Generator
                     │                    │
                AntD runtime       Standalone React + AntD
```

`model.modules` stores reusable block definitions (`content: PuckNode[]`).
A `ModuleBlock` page node references a definition by `moduleId`.
Updates to that definition affect all references in the preview; cycles are rejected.
Codegen emits one React function per module; no Puck dependency at runtime.

Current shared state is at page scope (one `initialState` and source registry).
Per-module props/state/action boundaries are a planned v0.4 feature.
The serialized data format is purposefully distinct from executable JavaScript.

Puck owns the canvas, component selection, and field editor. If the editor is
replaced, the schema model and generator must be adapted, but not rewritten as
Puck-specific runtime code. Some migration is still necessary because the page
node format currently aligns with Puck's Slot data shape.
