using SmartGISharp;

class Program {
    static void Main() {
        var t2 = example.make_tuple2(3, 4.5);           // ValueTuple<int,double>
        Console.WriteLine(t2);                          // (3, 4.5)

        var t3 = example.make_tuple3(7, 2.3, "hi");     // ValueTuple<int,double,string>
        Console.WriteLine(example.sum_tuple2(t2));      // 7.5
        Console.WriteLine(example.sum_tuple3(t3));      // 9.3
    }
}