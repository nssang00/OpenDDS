﻿using System.Windows;
using System.Windows.Controls;
using SmartGISharp.Wpf;

namespace NativeViewHostSample
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            NativeView.Loaded += (s, e) => 
            {
                MessageBox.Show($"{NativeView.Handle} WindowHandle2!", "Debug");
                //System.Diagnostics.Debug.WriteLine($"Handle: 0x{handle.ToString("X")}");
            };
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn)
            {
                MessageBox.Show($"{btn.Name} clicked!", "Debug");
            }
        }
    }
}
