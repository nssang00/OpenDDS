import { Tabs } from 'antd';
import { studioViewsRegistry } from './studioViews.registry.jsx';

function renderView(view) {
  const Component = studioViewsRegistry[view.component];

  if (!Component) {
    return (
      <div className="empty-state">
        Unknown view: {view.component}
      </div>
    );
  }

  return <Component config={view} />;
}

export default function StudioPanelRenderer({ panel }) {
  const visibleViews = panel.views.filter((view) => view.enabled !== false);
  const items = visibleViews.map((view) => ({
    key: view.id,
    label: view.label,
    children: renderView(view),
  }));

  return (
    <section className={`panel ${panel.panelClassName ?? `${panel.id}-panel`}`}>
      <Tabs
        className={panel.tabClassName ?? 'panel-tabs'}
        defaultActiveKey={panel.defaultActiveView ?? visibleViews[0]?.id}
        items={items}
      />
    </section>
  );
}
