import { Layout } from 'antd';
import AppHeader from '../components/AppHeader.jsx';
import StudioLayout from './StudioLayout.jsx';

export default function MainLayout() {
  return (
    <Layout className="app-shell">
      <AppHeader />
      <StudioLayout />
    </Layout>
  );
}
