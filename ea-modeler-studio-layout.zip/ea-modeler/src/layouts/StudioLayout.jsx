import { Splitter } from 'antd';
import { studioLayoutConfig } from './studioLayout.config.js';
import StudioPanelRenderer from './StudioPanelRenderer.jsx';

export default function StudioLayout() {
  return (
    <Splitter className="studio-layout">
      {studioLayoutConfig.panels.map((panel) => (
        <Splitter.Panel
          key={panel.id}
          defaultSize={panel.defaultSize}
          min={panel.min}
          max={panel.max}
          className={panel.className}
        >
          <StudioPanelRenderer panel={panel} />
        </Splitter.Panel>
      ))}
    </Splitter>
  );
}
