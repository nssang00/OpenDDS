import { Empty, Tree } from 'antd';
import { useMemo } from 'react';
import { useDesignerStore } from '../../stores/useDesignerStore.js';

const { DirectoryTree } = Tree;

function buildTreeData(elementsById) {
  if (!elementsById) return [];

  const childrenMap = new Map();

  Object.values(elementsById).forEach((element) => {
    const parentId = element.parentId ?? '__root__';

    if (!childrenMap.has(parentId)) {
      childrenMap.set(parentId, []);
    }

    childrenMap.get(parentId).push(element);
  });

  function buildNode(element) {
    const children = childrenMap.get(element.id) ?? [];

    return {
      key: element.id,
      title: element.name,
      children: children.map(buildNode),
    };
  }

  return (childrenMap.get('__root__') ?? []).map(buildNode);
}

export default function ModelView() {
  const model = useDesignerStore((state) => state.model);
  const selectedElementId = useDesignerStore((state) => state.selectedElementId);
  const selectElement = useDesignerStore((state) => state.selectElement);

  const treeData = useMemo(() => {
    return buildTreeData(model?.elementsById);
  }, [model]);

  if (!model) {
    return (
      <div className="panel-body model-view">
        <Empty description="No model loaded" />
      </div>
    );
  }

  return (
    <div className="panel-body model-view">
      <DirectoryTree
        blockNode
        defaultExpandAll
        selectedKeys={selectedElementId ? [selectedElementId] : []}
        treeData={treeData}
        onSelect={(selectedKeys) => {
          const selectedKey = selectedKeys[0];

          if (selectedKey) {
            selectElement(selectedKey);
          }
        }}
      />
    </div>
  );
}
