import { add as nativeAdd, multiply as nativeMultiply, greet as nativeGreet } from 'game';
import { add as pythonAdd, greet } from 'automation';
import { add as dotnetAdd, multiply as dotnetMultiply, isPositive, greet as dotnetGreet, subtract } from 'analytics';
function check(test, description) {
  if(!test)throw new Error('FAIL ' + description);
  console.log('[PASS] JS import: ' + description);
}
check(nativeAdd(10,20)===30, 'C++ native add(10,20) = 30');
check(nativeMultiply(2.5,3)===7.5, 'C++ native multiply(2.5,3) = 7.5');
check(nativeGreet('Xytron')==='Hello from C++, Xytron!', 'C++ native string return');
check(pythonAdd(7,8)===15, 'Python add(7,8) = 15');
check(greet('Xytron')==='Hello, Xytron!', 'Python greet string roundtrip');
check(dotnetAdd(5,6)===11, 'C# add(5,6) = 11');
check(dotnetMultiply(2,4)===8, 'C# multiply(2,4) = 8');
check(isPositive(-3)===false, 'C# bool return');
check(dotnetGreet('Xytron')==='Hello from C#, Xytron!', 'C# string return');
check(subtract(10,7)===3, 'C# [Export] alias');
console.log('JS IMPORT SMOKE TEST PASSED');
