#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo "=== XYTRON ONE-CLICK TEST (Linux) ==="
for cmd in cmake c++ python3; do
  if ! command -v "$cmd" >/dev/null 2>&1; then
    echo "[ERROR] missing prerequisite: $cmd"; exit 1
  fi
done
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel 2
if command -v dotnet >/dev/null 2>&1; then
  echo "[INFO] .NET SDK detected: building C# plug-in"
  if [ -z "${DOTNET_ROOT:-}" ]; then
    DOTNET_ROOT="$(dirname "$(readlink -f "$(command -v dotnet)")")"
    export DOTNET_ROOT
  fi
  dotnet build plugins/analytics/AnalyticsPlugin.csproj --configuration Release --output plugins/analytics/build
  cp plugins/analytics/AnalyticsPlugin.runtimeconfig.json plugins/analytics/build/
  if [ ! -f plugins/analytics/build/Xytron.Managed.dll ]; then echo "[ERROR] SDK DLL missing"; exit 1; fi
  ./build/xytron_test
  if command -v node >/dev/null 2>&1; then node js/main.mjs; else echo '[SKIP] Node.js missing: JS import test'; fi
  echo '[SUCCESS] All available runtime tests passed (C++, Python, .NET)'
else
  echo '[SKIP] dotnet missing: C# plugin cannot be built/tested. Install .NET 8+ SDK for all 3 languages.'
  ./build/xytron_test --test-basic
  if command -v node >/dev/null 2>&1; then node js/basic.mjs; else echo '[SKIP] Node.js missing: JS import test'; fi
  echo '[PARTIAL PASS] C++ and Python tested. C# NOT TESTED.'
fi
