// 플러그인 개발자가 작성하는 파일: [Export]만 붙이면 됩니다.
using Xytron;

namespace AnalyticsPlugin;

public static class Analytics
{
    [Export]
    public static long Add(long a, long b) => a + b;

    [Export]
    public static double Multiply(double a, double b) => a * b;

    [Export]
    public static bool IsPositive(long number) => number > 0;

    [Export]
    public static string Greet(string name) => $"Hello from C#, {name}!";

    [Export("subtract")]
    public static long Difference(long a, long b) => a - b;

    // [Export]가 없으므로 JavaScript에 노출되지 않습니다.
    public static long Hidden(long n) => n;
}
