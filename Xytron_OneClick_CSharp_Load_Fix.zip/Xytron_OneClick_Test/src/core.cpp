#include "core.hpp"
#include "xytron_native.h"
#include <Python.h>
#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <regex>
#include <sstream>
#include <string_view>

#ifdef _WIN32
# include <windows.h>
#else
# include <dlfcn.h>
#endif

namespace fs = std::filesystem;

static std::string readText(const fs::path& file) {
    std::ifstream in(file);
    if(!in) throw std::runtime_error("cannot open manifest: " + file.string());
    return std::string(std::istreambuf_iterator<char>(in), {});
}
// Small *demo-only* JSON string field reader; production uses a real JSON parser.
static std::string field(const std::string& json, const std::string& key) {
    std::regex re("\\\""+key+"\\\"\\s*:\\s*\\\"([^\\\"]+)\\\"");
    std::smatch m;
    if(!std::regex_search(json,m,re)) throw std::runtime_error("missing manifest field: " +key);
    return m[1];
}

class DynamicLibrary {
#ifdef _WIN32
    HMODULE handle_ = nullptr;
#else
    void* handle_ = nullptr;
#endif
public:
    DynamicLibrary()=default;
    DynamicLibrary(const DynamicLibrary&)=delete;
    DynamicLibrary& operator=(const DynamicLibrary&)=delete;
    ~DynamicLibrary(){close();}
    bool open(const fs::path& path) {
#ifdef _WIN32
        handle_ = LoadLibraryW(path.wstring().c_str());
#else
        handle_ = dlopen(path.c_str(), RTLD_NOW | RTLD_LOCAL);
#endif
        return handle_ != nullptr;
    }
    void* symbol(const char* name) const {
#ifdef _WIN32
        return reinterpret_cast<void*>(GetProcAddress(handle_,name));
#else
        return dlsym(handle_,name);
#endif
    }
    void close() {
        if(!handle_)return;
#ifdef _WIN32
        FreeLibrary(handle_);
#else
        dlclose(handle_);
#endif
        handle_=nullptr;
    }
    static std::string lastError() {
#ifdef _WIN32
        return "LoadLibrary/GetProcAddress error code: " + std::to_string(GetLastError());
#else
        const char* e = dlerror();return e?e:"dynamic library error";
#endif
    }
};

static XyValue toNative(const Value& v) {
    XyValue r;
    if(v.type()==typeid(int64_t)){r.tag=XY_INT64;r.i64=std::any_cast<int64_t>(v);}
    else if(v.type()==typeid(double)){r.tag=XY_DOUBLE;r.f64=std::any_cast<double>(v);}
    else if(v.type()==typeid(bool)){r.tag=XY_BOOL;r.i64=std::any_cast<bool>(v);}
    else if(v.type()==typeid(std::string)){r.tag=XY_STRING;r.text=std::any_cast<const std::string&>(v).c_str();}
    else throw std::runtime_error("unsupported native arg type");
    return r;
}
static Value fromNative(const XyValue& v) {
    switch(v.tag){
    case XY_VOID:return {};
    case XY_INT64:return Value(v.i64);
    case XY_DOUBLE:return Value(v.f64);
    case XY_BOOL:return Value(bool(v.i64 != 0));
    case XY_STRING:return Value(std::string(v.text?v.text:""));
    default:throw std::runtime_error("unknown value type from plugin");
    }
}

struct PluginManager::Item {
    PluginManifest manifest;
    enum class State { Discovered, Loading, Loaded, Failed } state = State::Discovered;
    std::unique_ptr<DynamicLibrary> library; // kept alive beyond module / invokers
    Module module;
};

static int registerNative(void* ptr, const char* name, XyInvokeFn fn, void* fnContext) {
    if(!ptr || !name || !fn) return 1;
    auto* m=static_cast<Module*>(ptr);
    try {
        m->addInvoker(name,[fn,fnContext](const Args& args)->Value{
            std::vector<XyValue> native;
            native.reserve(args.size());
            for(auto& a:args)native.push_back(toNative(a));
            XyValue result{};
            int rc=fn(fnContext,native.data(),native.size(),&result);
            if(rc!=0)throw std::runtime_error("native function rejected arguments; code="+std::to_string(rc));
            return fromNative(result);
        });
        return 0;
    }catch(...){return 2;}
}

static PyObject* toPython(const Value& v) {
    if(v.type()==typeid(int64_t))return PyLong_FromLongLong(std::any_cast<int64_t>(v));
    if(v.type()==typeid(double))return PyFloat_FromDouble(std::any_cast<double>(v));
    if(v.type()==typeid(bool))return PyBool_FromLong(std::any_cast<bool>(v));
    if(v.type()==typeid(std::string))return PyUnicode_FromString(std::any_cast<const std::string&>(v).c_str());
    throw std::runtime_error("unsupported python argument type");
}
static Value fromPython(PyObject* v) {
    if(v==Py_None)return {};
    if(PyBool_Check(v))return Value(v==Py_True);
    if(PyLong_Check(v)){
        auto n=PyLong_AsLongLong(v);
        if(PyErr_Occurred()) {PyErr_Print();throw std::runtime_error("python int overflow");}
        return Value(int64_t(n));
    }
    if(PyFloat_Check(v))return Value(PyFloat_AsDouble(v));
    if(PyUnicode_Check(v)){
        const char* s=PyUnicode_AsUTF8(v);
        if(!s){PyErr_Print();throw std::runtime_error("invalid python string");}
        return Value(std::string(s));
    }
    throw std::runtime_error("unsupported python return type");
}
static void loadPython(const PluginManifest& p, Module& module) {
    if(!Py_IsInitialized())Py_Initialize();
    // One-thread synchronous demo. A threaded host must enforce Python thread-state/GIL rules.
    PyObject* path=PySys_GetObject("path");
    PyObject* folder=PyUnicode_FromString(p.folder.string().c_str());
    if(!folder || PyList_Insert(path,0,folder)<0){Py_XDECREF(folder);throw std::runtime_error("python path initialization failed");}
    Py_DECREF(folder);
    auto name=p.entry.stem().string();
    PyObject* pyModule=PyImport_ImportModule(name.c_str());
    if(!pyModule){PyErr_Print();throw std::runtime_error("cannot import python module: "+name);}
    PyObject* dict=PyModule_GetDict(pyModule);
    Py_ssize_t pos=0;
    PyObject *key,*value;
    int num=0;
    while(PyDict_Next(dict,&pos,&key,&value)){
        if(!PyCallable_Check(value))continue;
        PyObject* mark=PyObject_GetAttrString(value,"__xytron_export__");
        if(!mark){PyErr_Clear();continue;}
        bool exported=PyObject_IsTrue(mark)==1;
        Py_DECREF(mark);
        if(!exported)continue;
        const char* nameUtf8=PyUnicode_AsUTF8(key);
        if(!nameUtf8)continue;
        Py_INCREF(value);
        module.addInvoker(nameUtf8,[value](const Args& args)->Value{
            PyObject* tuple=PyTuple_New(static_cast<Py_ssize_t>(args.size()));
            if(!tuple)throw std::runtime_error("cannot create python args");
            for(size_t i=0;i<args.size();++i){
                PyObject* obj=toPython(args[i]);
                if(!obj){Py_DECREF(tuple);throw std::runtime_error("python arg conversion failed");}
                PyTuple_SET_ITEM(tuple,static_cast<Py_ssize_t>(i),obj);
            }
            PyObject* result=PyObject_CallObject(value,tuple);
            Py_DECREF(tuple);
            if(!result){PyErr_Print();throw std::runtime_error("python invocation failed");}
            try{Value out=fromPython(result);Py_DECREF(result);return out;}
            catch(...){Py_DECREF(result);throw;}
        });
        ++num;
    }
    Py_DECREF(pyModule);
    if(num==0)throw std::runtime_error("python module has no exported functions");
}

// HostFxr subset based on official Microsoft native hosting API; Win-x64 and Linux-x64.
#ifdef _WIN32
using host_char = wchar_t;
#else
using host_char = char;
#endif
using host_string = std::basic_string<host_char>;
static host_string hostString(const fs::path& p) {return p.native();}
static host_string hostLiteral(const char* s) {
#ifdef _WIN32
    std::wstring w; while(*s)w.push_back(static_cast<unsigned char>(*s++));return w;
#else
    return s;
#endif
}

static fs::path dotnetRoot() {
    if(const char* e=std::getenv("DOTNET_ROOT"))return fs::path(e);
#ifdef _WIN32
    return "C:/Program Files/dotnet";
#else
    if(fs::exists("/usr/share/dotnet/host/fxr"))return "/usr/share/dotnet";
    if(const char* h=std::getenv("HOME"))return fs::path(h)/".dotnet";
    return "/usr/share/dotnet";
#endif
}
static fs::path findHostFxr() {
    auto fxrDir=dotnetRoot()/"host"/"fxr";
    if(!fs::exists(fxrDir))throw std::runtime_error(".NET runtime missing; host/fxr not found at " + fxrDir.string());
    fs::path newest;
    for(const auto& entry:fs::directory_iterator(fxrDir)){
        if(!entry.is_directory())continue;
#ifdef _WIN32
        fs::path file=entry.path()/"hostfxr.dll";
#else
        fs::path file=entry.path()/"libhostfxr.so";
#endif
        if(fs::exists(file) && (newest.empty() || entry.path().filename().string() > newest.parent_path().filename().string())) newest=file;
    }
    if(newest.empty())throw std::runtime_error("hostfxr shared library not found");
    return newest;
}
using hostfxr_init = int (*)(const host_char*,const void*,void**);
using hostfxr_delegate = int (*)(void*,int,void**);
using hostfxr_close = int (*)(void*);
using get_managed_fn = int (*)(const host_char*,const host_char*,const host_char*,const host_char*,void*,void**);
using load_plugin_fn = int (*)(const char*);
using count_fn = int (*)(int);
using name_fn = int (*)(int,int,char*,int);
using invoke_fn = int (*)(int,const char*,const XyValue*,int,XyValue*);
using free_string_fn = void (*)(const char*);

// SDK-owned bridge: user C# plugins need only [Export] methods.
// hostfxr/CoreCLR remain loaded until process termination in this demo.
static std::vector<std::unique_ptr<DynamicLibrary>> runtimeLibraries;
static void loadDotnet(const PluginManifest& p, Module& module) {
    auto hostfxr=std::make_unique<DynamicLibrary>();
    auto hostpath=findHostFxr();
    if(!hostfxr->open(hostpath))throw std::runtime_error("hostfxr load error: "+DynamicLibrary::lastError());
    auto init=reinterpret_cast<hostfxr_init>(hostfxr->symbol("hostfxr_initialize_for_runtime_config"));
    auto getDelegate=reinterpret_cast<hostfxr_delegate>(hostfxr->symbol("hostfxr_get_runtime_delegate"));
    auto close=reinterpret_cast<hostfxr_close>(hostfxr->symbol("hostfxr_close"));
    if(!init || !getDelegate || !close)throw std::runtime_error("hostfxr exports unavailable");
    fs::path assembly=fs::absolute(p.folder/p.entry);
    fs::path config=assembly.parent_path()/(assembly.stem().string()+".runtimeconfig.json");
    fs::path bridge=assembly.parent_path()/"Xytron.Managed.dll";
    if(!fs::exists(assembly))throw std::runtime_error("build C# plugin first: " + assembly.string());
    if(!fs::exists(config))throw std::runtime_error("missing .NET runtimeconfig: " + config.string());
    if(!fs::exists(bridge))throw std::runtime_error("missing Xytron.Managed SDK: " + bridge.string());
    void* handle=nullptr;
    auto hc=hostString(config);
    int rc=init(hc.c_str(),nullptr,&handle);
    if(rc<0 || !handle)throw std::runtime_error("hostfxr init error="+std::to_string(rc));
    void* loadAddress=nullptr;
    rc=getDelegate(handle,5,&loadAddress); // hdt_load_assembly_and_get_function_pointer
    close(handle);
    if(rc<0 || !loadAddress)throw std::runtime_error("cannot obtain .NET load delegate: "+std::to_string(rc));
    auto load=reinterpret_cast<get_managed_fn>(loadAddress);
    auto filename=hostString(bridge);
    auto typename_=hostLiteral("Xytron.Bridge, Xytron.Managed");
    // -1 requests a [UnmanagedCallersOnly] method (coreclr_delegates.h).
    auto getPtr=[&](const char* method)->void* {
        void* out=nullptr;
        auto m=hostLiteral(method);
        int code=load(filename.c_str(),typename_.c_str(),m.c_str(),reinterpret_cast<const host_char*>(-1),nullptr,&out);
        if(code!=0 || !out)throw std::runtime_error(std::string(".NET SDK method unavailable: ")+method+" rc="+std::to_string(code));
        return out;
    };
    auto openPlugin=reinterpret_cast<load_plugin_fn>(getPtr("Load"));
    auto count=reinterpret_cast<count_fn>(getPtr("Count"));
    auto name=reinterpret_cast<name_fn>(getPtr("Name"));
    auto invoke=reinterpret_cast<invoke_fn>(getPtr("Invoke"));
    auto freeString=reinterpret_cast<free_string_fn>(getPtr("FreeString"));
    auto pluginPath=assembly.u8string();
    const int id=openPlugin(pluginPath.c_str());
    if(id<=0)throw std::runtime_error(".NET SDK failed to load user assembly: "+assembly.string());
    int n=count(id);
    if(n<=0 || n>1000)throw std::runtime_error("invalid .NET export count");
    for(int i=0;i<n;++i){
        char buffer[256]{};
        if(name(id,i,buffer,sizeof(buffer))!=0)throw std::runtime_error(".NET export name failed");
        std::string exportName(buffer);
        module.addInvoker(exportName,[invoke,freeString,id,exportName](const Args& args)->Value {
            std::vector<XyValue> in;
            in.reserve(args.size());
            for(const auto& a:args)in.push_back(toNative(a));
            XyValue out{};
            int code=invoke(id,exportName.c_str(),in.data(),static_cast<int>(in.size()),&out);
            if(code!=0)throw std::runtime_error(".NET invocation error: "+std::to_string(code));
            if(out.tag==XY_STRING){
                // String allocated by .NET SDK via CoTaskMem; copy then free in .NET.
                try {
                    Value copied=fromNative(out);
                    freeString(out.text);
                    return copied;
                }catch(...){freeString(out.text);throw;}
            }
            return fromNative(out);
        });
    }
    runtimeLibraries.push_back(std::move(hostfxr));
}

PluginManager::PluginManager() = default;
PluginManager::~PluginManager() = default;
void PluginManager::discover(const fs::path& pluginsDir) {
    if(!fs::exists(pluginsDir))throw std::runtime_error("plugins directory missing: " + pluginsDir.string());
    for(const auto& entry:fs::directory_iterator(pluginsDir)){
        if(!entry.is_directory())continue;
        auto path=entry.path()/"plugin.json";
        if(!fs::exists(path))continue;
        auto json=readText(path);
        auto item=std::make_unique<Item>();
        item->manifest.name=field(json,"name");
        item->manifest.runtime=field(json,"runtime");
        item->manifest.folder=fs::absolute(entry.path());
        if(item->manifest.runtime=="native") {
#ifdef _WIN32
            item->manifest.entry=field(json,"win-x64");
#else
            item->manifest.entry=field(json,"linux-x64");
#endif
        }else item->manifest.entry=field(json,"entry");
        auto name=item->manifest.name;
        if(!plugins_.emplace(name,std::move(item)).second)throw std::runtime_error("duplicate plugin: "+name);
    }
}
Module& PluginManager::importModule(const std::string& name) {
    auto it=plugins_.find(name);
    if(it==plugins_.end())throw std::runtime_error("unknown plugin: " + name);
    Item& item=*it->second;
    if(item.state==Item::State::Loaded)return item.module;
    if(item.state!=Item::State::Discovered)throw std::runtime_error("plugin not loadable: "+name);
    item.state=Item::State::Loading;
    try {
        auto& p=item.manifest;
        if(p.runtime=="native") {
            item.library=std::make_unique<DynamicLibrary>();
            auto path=fs::absolute(p.folder/p.entry);
            if(!item.library->open(path))throw std::runtime_error("cannot load native plugin: "+path.string()+" "+DynamicLibrary::lastError());
            auto reg=reinterpret_cast<XyRegisterFn>(item.library->symbol("xytron_plugin_register"));
            if(!reg)throw std::runtime_error("native plugin entry missing");
            XyHostApi api{1,&item.module,registerNative};
            if(reg(&api)!=0)throw std::runtime_error("native registration rejected");
        }else if(p.runtime=="python")loadPython(p,item.module);
        else if(p.runtime=="dotnet")loadDotnet(p,item.module);
        else throw std::runtime_error("unknown runtime: "+p.runtime);
        item.state=Item::State::Loaded;
        return item.module;
    }catch(...){item.state=Item::State::Failed;throw;}
}
static std::string jsonEscape(const std::string& s){
    std::string r="\"";
    for(unsigned char c:s){
        if(c=='"'||c=='\\'){r+='\\';r+=char(c);}
        else if(c=='\n')r+="\\n";
        else if(c=='\r')r+="\\r";
        else if(c=='\t')r+="\\t";
        else if(c<32){char b[7];snprintf(b,sizeof b,"\\u%04x",c);r+=b;}
        else r+=char(c);
    }
    return r+'"';
}
std::string jsonValue(const Value& v){
    if(!v.has_value())return "null";
    if(v.type()==typeid(int64_t))return std::to_string(std::any_cast<int64_t>(v));
    if(v.type()==typeid(double)){std::ostringstream os;os<<std::setprecision(16)<<std::any_cast<double>(v);return os.str();}
    if(v.type()==typeid(bool))return std::any_cast<bool>(v)?"true":"false";
    if(v.type()==typeid(std::string))return jsonEscape(std::any_cast<const std::string&>(v));
    throw std::runtime_error("cannot serialize return value");
}
std::string showValue(const Value& v){return jsonValue(v);}
