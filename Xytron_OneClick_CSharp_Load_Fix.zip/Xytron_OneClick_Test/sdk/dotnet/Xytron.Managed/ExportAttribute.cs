using System;

namespace Xytron;

/// <summary>Expose a public static C# method to Xytron's JavaScript module.</summary>
[AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = false)]
public sealed class ExportAttribute : Attribute
{
    public string? Name { get; }
    public ExportAttribute() { }
    public ExportAttribute(string name) => Name = name;
}
