// Xytron runtime-owned bridge. Plugin authors should NOT copy or edit this file.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Loader;
using System.Text;

namespace Xytron;

[StructLayout(LayoutKind.Sequential)]
public unsafe struct NativeValue
{
    public int Tag;
    public int Reserved;
    public long Int64;
    public double Float64;
    public byte* Text;
}

public static unsafe class Bridge
{
    // Hostfxr loads Xytron.Managed into its own AssemblyLoadContext, not necessarily
    // AssemblyLoadContext.Default. A plugin loaded into Default may then fail to
    // resolve Xytron.Managed although Xytron.Managed.dll exists beside the plugin.
    // Keep SDK type identity shared; resolve each plugin's other dependencies in
    // its own context (based on its .deps.json or its output directory).
    private sealed class PluginLoadContext : AssemblyLoadContext
    {
        private readonly AssemblyDependencyResolver resolver;
        private readonly string directory;
        private readonly Assembly sdkAssembly = typeof(ExportAttribute).Assembly;

        public PluginLoadContext(string pluginPath) : base(isCollectible: false)
        {
            resolver = new AssemblyDependencyResolver(pluginPath);
            directory = System.IO.Path.GetDirectoryName(pluginPath)!;
        }

        protected override Assembly? Load(AssemblyName name)
        {
            // One shared ExportAttribute identity is required for Reflection.
            if (string.Equals(name.Name, sdkAssembly.GetName().Name,
                              StringComparison.OrdinalIgnoreCase))
                return sdkAssembly;

            string? path = resolver.ResolveAssemblyToPath(name);
            if (path == null && name.Name is not null)
            {
                string candidate = System.IO.Path.Combine(directory, name.Name + ".dll");
                if (System.IO.File.Exists(candidate)) path = candidate;
            }
            return path == null ? null : LoadFromAssemblyPath(path);
        }

        protected override IntPtr LoadUnmanagedDll(string name)
        {
            string? path = resolver.ResolveUnmanagedDllToPath(name);
            return path is null ? IntPtr.Zero : LoadUnmanagedDllFromPath(path);
        }
    }

    private sealed class PluginBindings
    {
        public PluginLoadContext Context { get; init; } = null!;
        public Dictionary<string, MethodInfo> Functions { get; } = new(StringComparer.Ordinal);
        public List<string> Names { get; } = new();
    }

    private static readonly object Gate = new();
    private static readonly Dictionary<int, PluginBindings> Modules = new();
    private static int nextId = 1;

    private static string JsName(MethodInfo method, ExportAttribute attr)
    {
        if (attr.Name is { Length: > 0 } alias) return alias;
        var name = method.Name;
        return char.ToLowerInvariant(name[0]) + name.Substring(1);
    }

    // Returned module ID is positive; -1 indicates error.
    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Load(byte* assemblyPath)
    {
        try
        {
            string? path = Marshal.PtrToStringUTF8((IntPtr)assemblyPath);
            if (string.IsNullOrWhiteSpace(path)) return -1;
            string fullPath = System.IO.Path.GetFullPath(path);
            if (!System.IO.File.Exists(fullPath))
                throw new System.IO.FileNotFoundException("C# plugin assembly is missing", fullPath);
            var context = new PluginLoadContext(fullPath);
            var assembly = context.LoadFromAssemblyPath(fullPath);
            var bindings = new PluginBindings { Context = context };
            foreach (var type in assembly.GetTypes())
            foreach (var method in type.GetMethods(BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly))
            {
                var export = method.GetCustomAttribute<ExportAttribute>();
                if (export == null) continue;
                if (method.ContainsGenericParameters || method.ReturnType.IsByRef || method.GetParameters().Any(p => p.ParameterType.IsByRef || p.IsOut))
                    throw new NotSupportedException($"Unsupported export signature: {method}");
                string name = JsName(method, export);
                if (!bindings.Functions.TryAdd(name, method))
                    throw new InvalidOperationException($"Duplicate exported name: {name}");
                bindings.Names.Add(name);
            }
            if (bindings.Names.Count == 0)
                throw new InvalidOperationException($"No public static [Export] methods found in {path}");
            bindings.Names.Sort(StringComparer.Ordinal);
            lock (Gate)
            {
                int id = nextId++;
                Modules.Add(id, bindings);
                return id;
            }
        }
        catch (ReflectionTypeLoadException e)
        {
            Console.Error.WriteLine("[xytron .NET load] " + e);
            foreach (Exception? cause in e.LoaderExceptions)
                if (cause != null) Console.Error.WriteLine("  [dependency] " + cause);
            return -1;
        }
        catch (Exception e)
        {
            Console.Error.WriteLine("[xytron .NET load] " + e);
            return -1;
        }
    }

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Count(int moduleId)
    {
        lock (Gate) return Modules.TryGetValue(moduleId, out var module) ? module.Names.Count : -1;
    }

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Name(int moduleId, int index, byte* buffer, int capacity)
    {
        if (buffer == null || capacity < 1) return -1;
        string name;
        lock (Gate)
        {
            if (!Modules.TryGetValue(moduleId, out var module) || index < 0 || index >= module.Names.Count) return -1;
            name = module.Names[index];
        }
        byte[] utf8 = Encoding.UTF8.GetBytes(name);
        if (utf8.Length + 1 > capacity) return -2;
        for (int i = 0; i < utf8.Length; i++) buffer[i] = utf8[i];
        buffer[utf8.Length] = 0;
        return 0;
    }

    private static object? FromNative(NativeValue value, Type target)
    {
        if (target == typeof(long) && value.Tag == 1) return value.Int64;
        if (target == typeof(int) && value.Tag == 1) return checked((int)value.Int64);
        if (target == typeof(double) && value.Tag == 2) return value.Float64;
        if (target == typeof(float) && value.Tag == 2) return checked((float)value.Float64);
        if (target == typeof(bool) && value.Tag == 3) return value.Int64 != 0;
        if (target == typeof(string) && value.Tag == 4)
            return Marshal.PtrToStringUTF8((IntPtr)value.Text);
        throw new ArgumentException($"Cannot convert ABI tag {value.Tag} to {target.Name}");
    }

    private static NativeValue ToNative(object? result)
    {
        var value = new NativeValue();
        switch (result)
        {
            case null: value.Tag = 0; break;
            case int n: value.Tag = 1; value.Int64 = n; break;
            case long n: value.Tag = 1; value.Int64 = n; break;
            case float n: value.Tag = 2; value.Float64 = n; break;
            case double n: value.Tag = 2; value.Float64 = n; break;
            case bool n: value.Tag = 3; value.Int64 = n ? 1 : 0; break;
            case string n:
                value.Tag = 4;
                value.Text = (byte*)Marshal.StringToCoTaskMemUTF8(n);
                break;
            default: throw new NotSupportedException($"Unsupported return type: {result.GetType().Name}");
        }
        return value;
    }

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static int Invoke(int moduleId, byte* functionName, NativeValue* args, int count, NativeValue* result)
    {
        try
        {
            if (result == null || count < 0 || (count != 0 && args == null)) return 1;
            string? name = Marshal.PtrToStringUTF8((IntPtr)functionName);
            MethodInfo? method;
            lock (Gate)
            {
                if (name == null || !Modules.TryGetValue(moduleId, out var module) || !module.Functions.TryGetValue(name, out method)) return 1;
            }
            var parameters = method.GetParameters();
            if (parameters.Length != count) return 2;
            var values = new object?[count];
            for (int i = 0; i < count; ++i) values[i] = FromNative(args[i], parameters[i].ParameterType);
            object? returned = method.Invoke(null, values);
            *result = ToNative(returned);
            return 0;
        }
        catch (Exception e)
        {
            Console.Error.WriteLine("[xytron .NET invoke] " + e);
            return 3;
        }
    }

    [UnmanagedCallersOnly(CallConvs = new[] { typeof(CallConvCdecl) })]
    public static void FreeString(byte* text)
    {
        if (text != null) Marshal.FreeCoTaskMem((IntPtr)text);
    }
}
