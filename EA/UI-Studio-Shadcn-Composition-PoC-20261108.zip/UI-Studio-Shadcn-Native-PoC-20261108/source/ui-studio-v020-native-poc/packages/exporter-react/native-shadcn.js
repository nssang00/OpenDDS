/**
 * Native shadcn/ui TSX exporter (restricted, intentionally fail-closed).
 * Converts a single simple v6 Component Definition into human-editable JSX.
 * This is NOT a substitute for the full UI Studio runtime: unsupported runtime
 * features are rejected instead of silently disappearing from generated code.
 */
import {validateDocument,walkNodes} from '../schema/index.js';

const COMPONENT_NAME=/^[A-Z][A-Za-z0-9_]*$/;
const IDENTIFIER=/^[A-Za-z_$][A-Za-z0-9_$]*$/;
const UNSAFE_KEYS=new Set(['__proto__','prototype','constructor']);
const RESERVED_COMPONENT_NAMES=new Set(['React','Fragment','useState','toText']);
const TYPE_MAP={string:'string',color:'string',enum:'string',boolean:'boolean',number:'number',array:'unknown[]',object:'Record<string, unknown>'};
const UI_IMPORTS={
  'core/Button':{button:['Button']},
  'core/Input':{input:['Input']},
  'core/Card':{card:['Card','CardHeader','CardTitle','CardDescription']},
  'core/Checkbox':{checkbox:['Checkbox'],label:['Label']},
  'core/Divider':{separator:['Separator']},
  'core/Tag':{badge:['Badge']},
  'core/Text':{}
};
const json=value=>value===undefined?'undefined':JSON.stringify(value);
const cap=value=>value[0].toUpperCase()+value.slice(1);
const indent=(level)=>'  '.repeat(level);
const fail=(where,message)=>{throw new Error(`Native shadcn Export · ${where}: ${message}`);};
const jsxAttribute=(key,value)=>` ${key}={${value}}`;

/** Emit code for a single Definition, not a hidden JSON runtime. */
export function generateNativeShadcnTsx(document,registry,definitionId){
  validateDocument(document,registry);
  if(!COMPONENT_NAME.test(definitionId) || RESERVED_COMPONENT_NAMES.has(definitionId) || !document.definitions[definitionId])fail(definitionId,'유효한 Component Definition을 선택하세요');
  const definition=document.definitions[definitionId];
  const propsMeta=definition.publicProps||{};
  const publicEvents=definition.publicEvents||{};
  const imports=new Map();
  const childImports=new Set();
  let usesToText=false;
  const addImport=(module,names)=>{const set=imports.get(module)||new Set();for(const name of names)set.add(name);imports.set(module,set);};
  const targets=new Map();
  for(const [name,spec] of Object.entries(propsMeta)){
    if(!IDENTIFIER.test(name)||UNSAFE_KEYS.has(name))fail(definitionId,`React에서 지원하지 않는 공개 Property 이름: ${name}`);
    if(spec.target){const key=`${spec.target.nodeId}.${spec.target.property}`;
      if(targets.has(key))fail(definitionId,`중복 공개 Property 대상: ${key}`);
      targets.set(key,name);
    }
  }
  const callbackNames=new Set();
  for(const [name,spec] of Object.entries(propsMeta))if(spec.twoWay){
    const callback=`on${cap(name)}Change`;
    if(Object.hasOwn(propsMeta,callback))fail(definitionId,`Callback과 Property 이름 충돌: ${callback}`);
    callbackNames.add(callback);
  }
  for(const [name,spec] of Object.entries(publicEvents)){
    if(!IDENTIFIER.test(name)||UNSAFE_KEYS.has(name)||!spec?.nodeId)fail(definitionId,`React에서 지원하지 않는 공개 Event 이름: ${name}`);
    const callback=`on${cap(name)}`;
    if(callbackNames.has(callback)||Object.hasOwn(propsMeta,callback))fail(definitionId,`Callback 이름 충돌: ${callback}`);
    callbackNames.add(callback);
  }
  // UI Studio's 'content' slot maps to React's conventional children prop.
  const slotProps=new Map();
  const slotByFrame=new Map();
  for(const [name,spec] of Object.entries(definition.slots||{})){
    const propName=name==='content'?'children':name;
    if(!IDENTIFIER.test(propName)||UNSAFE_KEYS.has(propName)||Object.hasOwn(propsMeta,propName))fail(definitionId,`Slot과 공개 Property 이름 충돌: ${propName}`);
    if(slotProps.has(propName))fail(definitionId,`중복 Slot: ${propName}`);
    slotProps.set(propName,name);
    slotByFrame.set(spec.nodeId,propName);
  }
  function valueForPublic(name){
    const spec=propsMeta[name];
    if(!spec)fail(definitionId,`공개 Props에 없는 값: ${name}`);
    return spec.twoWay?`current${cap(name)}`:`(props.${name} ?? ${json(spec.defaultValue)})`;
  }
  const twoWayFields=Object.entries(propsMeta).filter(([,spec])=>spec.twoWay);

  function readProvider(provider,where,propertyDefault=undefined){
    if(!provider)return json(propertyDefault);
    if(provider.kind==='literal')return json(provider.value);
    if(provider.kind==='resource'){
      if(!Object.hasOwn(document.resources||{},provider.key))fail(where,`Resource가 없습니다: ${provider.key}`);
      return json(document.resources[provider.key]);
    }
    if(provider.kind==='binding'){
      if(provider.source!=='props'||provider.path.length!==1||typeof provider.path[0]!=='string')fail(where,`Binding(${provider.source})은 지원하지 않습니다. 공개 Props로 연결하세요`);
      const name=provider.path[0];
      if(!Object.hasOwn(propsMeta,name))fail(where,`공개 Props에 없는 Binding: ${name}`);
      return valueForPublic(name);
    }
    fail(where,'지원하지 않는 Property provider');
  }
  function property(node,name){
    const where=`${node.id}.${name}`;
    const registryProp=registry.get(node.typeId)?.properties[name];
    if(!registryProp)fail(where,'등록되지 않은 속성');
    const published=targets.get(where);
    const underlying=readProvider(node.props?.[name],where,registryProp.defaultValue);
    if(published){
      if(node.props?.[name]?.kind==='binding' && node.props[name].source==='props' && node.props[name].path.length===1 && node.props[name].path[0]===published)return underlying;
      return propsMeta[published].twoWay?valueForPublic(published):`(props.${published} ?? ${underlying})`;
    }
    return underlying;
  }
  function propertyMeta(node,name){
    const where=`${node.id}.${name}`;
    const direct=targets.get(where);
    if(direct)return {name:direct,mode:propsMeta[direct].twoWay?'TwoWay':'OneWay',updateOn:node.props?.[name]?.updateOn};
    const provider=node.props?.[name];
    if(provider?.kind==='binding'&&provider.source==='props'&&provider.path.length===1){
      return {name:provider.path[0],mode:provider.mode,updateOn:provider.updateOn};
    }
    return null;
  }
  function onPublicEvent(node,event){
    const action=node.events?.[event];
    if(!action)return '';
    if(action.kind!=='emit')fail(node.id,`동작 ${action.kind}은 Native Export에서 지원하지 않습니다`);
    const definitionEvent=publicEvents[action.event];
    if(!definitionEvent||definitionEvent.nodeId!==node.id||definitionEvent.event!==event)fail(node.id,`공개되지 않은 Event: ${action.event}`);
    const payload=Object.hasOwn(propsMeta,'value')?`{value: ${valueForPublic('value')}}`:'{}';
    return ` onClick={() => props.on${cap(action.event)}?.(${payload})}`;
  }
  function sizeStyle(node){return node.size?` style={${json(node.size)}}`:'';}
  function emitControl(node,level){
    const type=node.typeId;
    if(!Object.hasOwn(UI_IMPORTS,type))fail(node.id,`${type} 컨트롤은 아직 Native Export를 지원하지 않습니다`);
    for(const [module,names] of Object.entries(UI_IMPORTS[type]))addImport(module,names);
    const id=json(node.id),pre=indent(level);
    const stringProp=(name)=>{usesToText=true;return `toText(${property(node,name)})`;};
    for(const event of Object.keys(node.events||{}))if(type!=='core/Button'||event!=='click')fail(node.id,`Event ${event}은 아직 Native Export를 지원하지 않습니다`);
    let markup;
    if(type==='core/Text'){
      const weight=property(node,'weight');
      const isHeading=weight===json('heading');
      markup=`<${isHeading?'h3':'span'} data-control-id={${id}}${isHeading?' className="text-lg font-semibold"':''}>{${stringProp('text')}}</${isHeading?'h3':'span'}>`;
    }else if(type==='core/Button'){
      const primary=property(node,'variant')===json('primary');
      const color=primary?` style={{backgroundColor: ${property(node,'color')}, borderColor: ${property(node,'color')}}}`:'';
      markup=`<Button type="button" data-control-id={${id}} variant="${primary?'default':'outline'}" disabled={Boolean(${property(node,'disabled')})}${color}${onPublicEvent(node,'click')}>{${stringProp('text')}}</Button>`;
    }else if(type==='core/Input'){
      const val=propertyMeta(node,'value');
      if(val?.mode==='TwoWay'&&!propsMeta[val.name]?.twoWay)fail(node.id,'TwoWay Input은 공개 TwoWay Prop이 필요합니다');
      if(val?.updateOn==='blur')fail(node.id,'blur 기반 입력 동기화는 아직 Native Export를 지원하지 않습니다');
      const valueExpr=property(node,'value');
      usesToText=true;
      const valueAttr=val?.mode==='TwoWay'?jsxAttribute('value',`toText(${valueExpr})`):val?.mode==='OneWay'?jsxAttribute('value',`toText(${valueExpr})`):jsxAttribute('defaultValue',`toText(${valueExpr})`);
      const callback=val?.mode==='TwoWay'?` onChange={(event) => update${cap(val.name)}(event.currentTarget.value)}`:'';
      const readOnly=val?.mode==='OneWay'?' readOnly':'';
      const placeholder=property(node,'placeholder');
      const label=property(node,'label');
      const input=`<Input id={${id}} data-control-id={${id}} aria-label={String(${placeholder} || ${label} || 'Input')} placeholder={${placeholder}} disabled={Boolean(${property(node,'disabled')})}${valueAttr}${readOnly}${callback} />`;
      if(label!==json(''))addImport('label',['Label']);
      markup=label!==json('')?`<div className="grid gap-2"><Label htmlFor={${id}}>{${stringProp('label')}}</Label>${input}</div>`:input;
    }else if(type==='core/Checkbox'){
      const checkedMeta=propertyMeta(node,'checked');
      if(checkedMeta?.mode==='TwoWay'&&!propsMeta[checkedMeta.name]?.twoWay)fail(node.id,'TwoWay Checkbox는 공개 TwoWay Prop이 필요합니다');
      const checkedAttr=checkedMeta?` checked={Boolean(${property(node,'checked')})}`:` defaultChecked={Boolean(${property(node,'checked')})}`;
      const onChange=checkedMeta?.mode==='TwoWay'?` onCheckedChange={(value) => update${cap(checkedMeta.name)}(value === true)}`:'';
      markup=`<div className="flex items-center gap-2"><Checkbox id={${id}} data-control-id={${id}}${checkedAttr} disabled={Boolean(${property(node,'disabled')})${checkedMeta?.mode==='OneWay'?' || true':''}}${onChange} /><Label htmlFor={${id}}>{${stringProp('text')}}</Label></div>`;
    }else if(type==='core/Card'){
      markup=`<Card data-control-id={${id}}><CardHeader><CardTitle>{${stringProp('title')}}</CardTitle><CardDescription>{${stringProp('description')}}</CardDescription></CardHeader></Card>`;
    }else if(type==='core/Divider'){
      markup=`<Separator data-control-id={${id}} />`;
    }else if(type==='core/Tag'){
      markup=`<Badge data-control-id={${id}} style={{color: ${property(node,'color')}}}>{${stringProp('text')}}</Badge>`;
    }
    if(node.size)markup=`<div${sizeStyle(node)}>${markup}</div>`;
    return `${pre}${markup}`;
  }
  function emitInstance(node,level){
    if(node.dataContext!==undefined)fail(node.id,'별도 DataContext는 Native Export에서 지원하지 않습니다');
    if(Object.keys(node.overrides||{}).length)fail(node.id,'중첩 Instance Override는 아직 지원하지 않습니다');
    if(!COMPONENT_NAME.test(node.definitionId)||RESERVED_COMPONENT_NAMES.has(node.definitionId))fail(node.id,`잘못된 중첩 Definition 이름: ${node.definitionId}`);
    const child=document.definitions[node.definitionId];
    childImports.add(node.definitionId);
    const pre=indent(level);
    const attributes=[];
    for(const [name,spec] of Object.entries(child.publicProps||{})){
      const where=`${node.id}.${name}`;
      const direct=targets.get(where);
      const assigned=node.bindings?.[name]||node.props?.[name];
      // Parent published properties have priority, matching projectNestedInstance.
      const value=direct?valueForPublic(direct):assigned?readProvider(assigned,where,spec.defaultValue):null;
      if(value!==null)attributes.push(`${name}={${value}}`);
      if(spec.twoWay){
        const mapped=direct||(assigned?.kind==='binding'&&assigned.source==='props'&&assigned.path.length===1&&assigned.mode==='TwoWay'?assigned.path[0]:null);
        if(assigned?.kind==='binding'&&assigned.mode==='TwoWay'&&!mapped)fail(where,'TwoWay 중첩 Binding은 공개 Props로 연결하세요');
        if(direct&&(!propsMeta[direct].twoWay))fail(where,'TwoWay 중첩 값에는 공개 TwoWay Prop이 필요합니다');
        if(mapped){
          if(!propsMeta[mapped]?.twoWay)fail(where,`공개 TwoWay Property가 아닙니다: ${mapped}`);
          attributes.push(`on${cap(name)}Change={(nextValue) => update${cap(mapped)}(nextValue)}`);
        }else if(assigned){
          fail(where,'고정 TwoWay 값은 변경을 반영할 수 없습니다. 공개 TwoWay Prop으로 연결하거나 값을 생략하세요');
        }
      }
    }
    const forwarded=new Set();
    for(const [outerName,ev] of Object.entries(publicEvents)){
      if(ev.nodeId!==node.id)continue;
      if(!child.publicEvents?.[ev.event])fail(node.id,`중첩 공개 Event가 없습니다: ${ev.event}`);
      if(forwarded.has(ev.event))fail(node.id,`하위 Event ${ev.event}를 여러 공개 Event로 중복 연결할 수 없습니다`);
      forwarded.add(ev.event);
      attributes.push(`on${cap(ev.event)}={(payload) => props.on${cap(outerName)}?.(payload)}`);
    }
    const slots=Object.entries(node.slots||{});
    let children='';
    for(const [slotName,fill] of slots){
      if(!Object.hasOwn(child.slots||{},slotName))fail(node.id,`없는 Slot: ${slotName}`);
      const content=fill.map(n=>emitNode(n,level+2)).join('\n');
      if(slotName==='content')children=content;
      else attributes.push(`${slotName}={<React.Fragment>\n${content}\n${indent(level+1)}</React.Fragment>}`);
    }
    // Empty arrays mean deliberately empty slots: do not restore fallback.
    const contentFilled=Object.hasOwn(node.slots||{},'content');
    if(contentFilled && !children){
      attributes.push('children={<React.Fragment />}');
    }
    const open=`<${node.definitionId}${attributes.length?' '+attributes.join(' '):''}`;
    const inner=contentFilled&&children
      ?`${pre}${open}>\n${children}\n${pre}</${node.definitionId}>`
      :`${pre}${open} />`;
    return node.size?`${pre}<div data-core-instance={${json(node.id)}} style={${json(node.size)}}>\n${inner}\n${pre}</div>`:inner;
  }
  function emitNode(node,level=2){
    if(node.dataContext!==undefined)fail(node.id,'별도 DataContext는 Native Export에서 지원하지 않습니다');
    if(node.when!==undefined||node.repeat!==undefined)fail(node.id,'When/Repeat는 아직 Native Export를 지원하지 않습니다');
    if(node.kind==='instance')return emitInstance(node,level);
    if(node.kind==='component')return emitControl(node,level);
    if(node.kind!=='frame')fail(node.id,'알 수 없는 노드 종류');
    const layout=node.layout;
    const klass={row:'flex flex-row',column:'flex flex-col',wrap:'flex flex-row flex-wrap',grid:'grid',overlay:'grid'}[layout.type];
    if(!klass)fail(node.id,`지원하지 않는 Layout: ${layout.type}`);
    const align=layout.align&&layout.align!=='stretch'?` items-${layout.align==='start'?'start':layout.align==='end'?'end':'center'}`:'';
    const style={minWidth:0,gap:layout.type==='overlay'?0:(layout.gap??0),padding:layout.padding??0};
    if(layout.background!==undefined)style.background=layout.background;
    if(layout.type==='grid')style.gridTemplateColumns=`repeat(${layout.columns??2}, minmax(0, 1fr))`;
    if(layout.type==='overlay')style.gridTemplateColumns='minmax(0, 1fr)';
    Object.assign(style,node.size||{});
    const children=node.children.map(child=>{
      const nested=emitNode(child,level+1);
      return layout.type==='overlay'?`${indent(level+1)}<div style={{gridArea: '1 / 1'}}>\n${nested}\n${indent(level+1)}</div>`:nested;
    });
    const content=children.length?'\n'+children.join('\n')+'\n'+indent(level):'';
    const slotName=slotByFrame.get(node.id);
    const childContent=slotName?`{props.${slotName} ?? (<React.Fragment>${content}</React.Fragment>)}`:content;
    return `${indent(level)}<div data-core-node={${json(node.id)}} className="${klass}${align} min-w-0" style={${json(style)}}>${childContent}</div>`;
  }
  const jsx=emitNode(definition.root);
  const emittedEvents=new Set();
  const scan=(node)=>{if(node.kind==='component'){for(const action of Object.values(node.events||{}))if(action?.kind==='emit')emittedEvents.add(action.event);}else if(node.kind==='frame')node.children.forEach(scan);else if(node.kind==='instance'){for(const [name,spec] of Object.entries(publicEvents))if(spec.nodeId===node.id)emittedEvents.add(name);for(const fill of Object.values(node.slots||{}))fill.forEach(scan);}};
  scan(definition.root);
  for(const name of Object.keys(publicEvents))if(!emittedEvents.has(name))fail(definitionId,`공개 Event ${name}의 처리 노드가 없습니다`);
  const fields=Object.entries(propsMeta);
  const eventFields=Object.keys(publicEvents);
  const types=[...slotProps.keys()].map(name=>`  ${name}?: React.ReactNode;`).concat([...fields.map(([name,spec])=>`  ${name}?: ${TYPE_MAP[spec.type]||'unknown'};`),
    ...fields.filter(([,spec])=>spec.twoWay).map(([name,spec])=>`  on${cap(name)}Change?: (value: ${TYPE_MAP[spec.type]||'unknown'}) => void;`),
    ...eventFields.map(name=>`  on${cap(name)}?: (payload: Record<string, unknown>) => void;`)]);
  const uiImports=[...imports.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([part,names])=>`import { ${[...names].join(', ')} } from '@/components/ui/${part}';`).join('\n');
  for(const [part,names] of imports){
    if(names.has(definitionId))fail(definitionId,`Component 이름과 shadcn UI import가 충돌합니다: ${part}`);
    for(const childId of childImports)if(names.has(childId))fail(definitionId,`중첩 이름과 shadcn UI import가 충돌합니다: ${childId} (${part})`);
  }
  const propsArgument=jsx.includes('props.')||twoWayFields.length?'props':'_props';
  const stateBody=twoWayFields.map(([name,spec])=>{
    const c=cap(name),type=TYPE_MAP[spec.type]||'unknown';
    return `  const [local${c}, setLocal${c}] = useState<${type}>(${json(spec.defaultValue??(spec.type==='boolean'?false:spec.type==='number'?0:''))});\n  const current${c} = props.${name} !== undefined ? props.${name} : local${c};\n  const update${c} = (nextValue: ${type}) => {\n    if (props.${name} === undefined) setLocal${c}(nextValue);\n    props.on${c}Change?.(nextValue);\n  };`;
  }).join('\n');
  const reactImports=[...(twoWayFields.length?['useState']:[])];
  const reactImportText=reactImports.length?`import { ${reactImports.join(', ')} } from 'react';\n`:'';
  const childImportText=[...childImports].sort().map(id=>`import ${id} from './${id}';`).join('\n');
  const hasSlots=slotProps.size>0||jsx.includes('React.Fragment');
  // React.Fragment is emitted as a JSX namespace expression for slot composition.
  const namespaceImport=hasSlots?`import * as React from 'react';\n`:'';
  const textHelper=usesToText?`const toText = (value: unknown): string => String(value ?? '');\n\n`:'';
  return `/** Generated by UI Studio from canonical JSON v6.\n * Native React TSX. Requires local shadcn/ui components (Base UI variant).\n * No UI Studio Runtime or Ant Design dependency.\n * Edit freely after export; reverse TSX -> Studio sync is NOT supported.\n */\n${namespaceImport}${reactImportText}${uiImports}${uiImports&&childImportText?'\n':''}${childImportText}\n\n${textHelper}export interface ${definitionId}Props {\n${types.join('\n')}\n}\n\nexport default function ${definitionId}(${propsArgument}: ${definitionId}Props) {\n${stateBody}${stateBody?'\n':''}  return (\n${jsx}\n  );\n}\n`;
}

/** Files for insertion into an EXISTING shadcn/ui project; not a self-contained npm package. */
export function createNativeShadcnFiles(document,registry,definitionId){
  validateDocument(document,registry);
  const visited=new Set();
  const output={};
  function collect(id){
    if(visited.has(id))return;
    visited.add(id);
    const definition=document.definitions[id];
    if(!definition)fail(id,'참조된 Component Definition이 없습니다');
    walkNodes(definition.root,node=>{if(node.kind==='instance')collect(node.definitionId);});
    output[`src/components/${id}.tsx`]=generateNativeShadcnTsx(document,registry,id);
  }
  collect(definitionId);
  const source=Object.values(output).join('\n');
  const imports=[...new Set([...source.matchAll(/from '@\/components\/ui\/([^']+)'/g)].map(match=>match[1]))].sort();
  const install=imports.length?`npx shadcn@latest add ${imports.join(' ')}`:'(필요한 shadcn UI 컴포넌트 없음)';
  const readme=`# ${definitionId} — Native shadcn/ui Export (experimental)\n\n이 파일은 **이미 shadcn/ui(Base UI) + Tailwind가 설정된 React 프로젝트**에서 사용하는 소스 코드입니다. UI Studio의 React Runtime이나 Ant Design이 포함되지 않습니다.\n\n1. 대상 프로젝트를 [공식 shadcn/ui 안내](https://ui.shadcn.com/docs/installation/vite)에 따라 구성하고 Base UI 프리셋을 선택합니다.\n2. 프로젝트 루트에서 필요한 컴포넌트를 추가합니다.\n\n\`\`\`bash\n${install}\n\`\`\`\n\n3. 이 ZIP의 \`src/components/*.tsx\` 파일 전체를 대상 프로젝트의 같은 위치에 복사합니다. 중첩 Definition은 별도 파일로 생성됩니다. \`@/\` 별칭이 \`src/\`를 가리키도록 설정돼 있어야 합니다.\n4. \`import ${definitionId} from '@/components/${definitionId}'\`로 사용합니다.\n\n## 지원 범위\n\n- Canvas Frame: row / column / wrap / grid / overlay; 레이아웃 크기, gap, padding\n- Controls: Text, Button, Input, Checkbox, Card, Divider, Tag\n- Definition 공개 Props, change 기반 TwoWay Input/Checkbox 콜백, Button 공개 click 이벤트\n- 중첩 Definition 별도 TSX 파일, 공개 Props 및 이벤트 전달, Slot 채우기와 기본 콘텐츠\n- TwoWay 공개 Props 미전달 시 로컬 상태로 동작, 전달 시 controlled 모드\n- Literal, Resource, 직접 공개 Props 바인딩\n\n## 아직 미지원 (변환 시 명시적으로 오류)\n\n- 중첩 Instance Override, 별도 DataContext, 조건/반복, Select/Table, 외부 state/sources/local/context Binding\n- blur 기반 TwoWay 동기화, set 동작, 임의의 React 코드 역가져오기, AntD와 시각·접근성 완전 동등성\n\n이 단계는 Native TSX 생성 가능성 검증용 PoC입니다. 기존 Runtime/AntD Export는 별도로 유지됩니다.\n`;
  return {...output,'README.md':readme};
}
