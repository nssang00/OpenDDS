# UI Studio shadcn Native TSX · Composition PoC handoff
Date: 2026-11-08
Status: **experimental source changes, not verified baseline**

## Product decision

One Studio remains the visual editor; canonical JSON v6 remains source of truth. The desired export is **editable React TSX in an existing shadcn/ui + Base UI + Tailwind project** without UI Studio Runtime or Ant Design. Preserve legacy AntD Export until a real independent consumer passes.

## Source location

`source/ui-studio-v020-native-poc/` contains the full modified project based on v0.20. No git commit or GitHub CI run was performed. This source is not a verified release or default exporter migration.

## Changes since previous Native TSX PoC

- `packages/exporter-react/native-shadcn.js`: transitive nested Definitions → separately generated `src/components/Name.tsx`; parent Props/TwoWay callbacks/public events forwarded to child; named ReactNode Slots with fallback and empty fills. Source uses local shadcn components and React useState, not embedded Studio runtime.
- Generated public TwoWay Props are controlled when set and uncontrolled with local state when absent.
- Unsupported overrides, global bindings, separate DataContext, missing event links, unsupported controls/actions/when/repeat still fail closed.
- `tools/verify-native-shadcn-tsx.mjs`: offline strict TS compilation with mock UI declarations (not actual shadcn types).
- `tools/verify-syntax.mjs` includes 3 extra Native TSX files; `package.json` exposes `npm run verify:native-tsx`.
- `tests/native-shadcn-export.test.js` now 10 cases (6 before).
- `examples/native-shadcn/SearchCard-v6.json` + `exports/SearchCard-shadcn-native.zip` and `exports/SearchBox-shadcn-native.zip` are included.
- See `source/ui-studio-v020-native-poc/NATIVE-SHADCN-POC.md` for exact supported/rejected contract.

## Evidence in this ZIP

- `npm test` **220/220 PASS** (previous 216)
- `npm run verify:runtime` **PASS** (existing runtime/mock renderer)
- `node tools/verify-syntax.mjs` **PASS** (58 source + 6 generated TSX)
- `npm run verify:native-tsx` **PASS with compile-only stubs** (SearchBox and SearchCard dependency chain)
- CLI generated both examples successfully.
- `npm ping --fetch-retries=0 --fetch-timeout=7000` failed with **EAI_AGAIN** (`registry.npmjs.org`). Thus no real dependency installation, Vite build, Chrome/Playwright, actual shadcn Base UI component typecheck, keyboard/ARIA or render parity test.
- No CI or independent React consumer verification. v0.19 is still the last established full CI baseline; v0.20 remains a candidate.

## Reproduction

```sh
cd source/ui-studio-v020-native-poc
npm test
npm run verify:runtime
node tools/verify-syntax.mjs
npm run verify:native-tsx
npm run export:shadcn
npm run export:shadcn -- examples/native-shadcn/SearchCard-v6.json SearchCard exports/SearchCard-shadcn-native.zip
# In network-enabled environment, install dependencies and run:
npm install --no-audit --no-fund
npm run build
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npm run test:e2e
```

## Next high-priority acceptance gate

1. Fresh Vite React app with official `shadcn init --base base`, Tailwind, `@/` alias. `shadcn add button input` and other referenced UI modules. Install all generated TSX files. Build with real types, not mock declarations.
2. Real Chromium tests: SearchBox keyboard typing, controlled vs uncontrolled `value`, `onValueChange`, onSearch event payload, SearchCard nested forwarding, fallback and empty Slot, accessible labeling. Compare UI Studio Canvas vs generated DOM.
3. Run v0.20 main Chrome E2E, prior v0.19 regressions, independent AntD consumer build/E2E and CI before promoting baseline or changing default exporter.
4. Expand native renderer/schema only after above gate; Select/Table, When/Repeat, local state actions and overrides are still unsupported.
