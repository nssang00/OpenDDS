import { KIND_OPTIONS, INF_TOKENS, COLORS } from './data.js'

export default function PropRow({ row, colorKey, onChange }) {
  const c = COLORS[colorKey]
  const strV = String(row.value)
  const isInf = INF_TOKENS.has(strV)
  const kindOpts = Object.values(KIND_OPTIONS).find(opts => opts.includes(strV))

  const baseInput = {
    fontSize: 10, fontFamily: 'monospace',
    background: c.badge, color: c.text,
    border: `1px solid ${c.border}55`,
    borderRadius: 4, padding: '2px 6px',
    flex: 1, outline: 'none', minWidth: 0,
  }

  let control
  if (isInf) {
    control = <span style={{ fontSize: 11, color: c.text + '55', fontStyle: 'italic' }}>∞</span>
  } else if (kindOpts) {
    control = (
      <select value={strV} onChange={e => onChange(e.target.value)}
        style={{ ...baseInput, cursor: 'pointer' }}>
        {kindOpts.map(o => (
          <option key={o} value={o}>{o.replace(/_QOS$/, '').replace(/_/g, ' ')}</option>
        ))}
      </select>
    )
  } else if (typeof row.value === 'boolean') {
    control = (
      <button onClick={() => onChange(!row.value)}
        style={{
          flex: 1, fontSize: 10, fontWeight: 700,
          background: row.value ? '#16a34a' : '#dc2626',
          color: '#fff', border: 'none', borderRadius: 4,
          padding: '2px 0', cursor: 'pointer',
        }}>
        {String(row.value)}
      </button>
    )
  } else {
    control = (
      <input
        type={typeof row.value === 'number' ? 'number' : 'text'}
        value={strV}
        onChange={e => onChange(typeof row.value === 'number' ? Number(e.target.value) : e.target.value)}
        style={baseInput}
      />
    )
  }

  const shortLabel = row.key.split('.').slice(-2).join('.')

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 6,
      padding: '3px 0', borderBottom: `1px solid ${c.badge}`,
    }}>
      <span style={{
        fontSize: 9, fontFamily: 'monospace', color: c.text + '88',
        minWidth: 112, flexShrink: 0,
        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
      }} title={row.key}>{shortLabel}</span>
      {control}
    </div>
  )
}
