export const RAW = {"qos_library":{"name":"DDSDefaultQoSLibrary","qos_profiles":[{"name":"QoSProfile1","domain_participant_qos":{"entity_factory":{"autoenable_created_entities":false},"user_data":{"value":"2344"}},"topic_qos":{"durability":{"kind":"PERSISTENT_DURABILITY_QOS"},"durability_service":{"service_cleanup_delay":{"sec":0,"nanosec":0},"history_depth":1,"history_kind":"KEEP_ALL_HISTORY_QOS","max_instances":"LENGTH_UNLIMITED","max_samples":"LENGTH_UNLIMITED","max_samples_per_instance":12},"deadline":{"period":{"sec":"DURATION_INFINITE_SEC","nanosec":"DURATION_INFINITE_NSEC"}},"latency_budget":{"duration":{"sec":0,"nanosec":0}},"liveliness":{"kind":"AUTOMATIC_LIVELINESS_QOS","lease_duration":{"sec":"DURATION_INFINITE_SEC","nanosec":"DURATION_INFINITE_NSEC"}},"reliability":{"kind":"BEST_EFFORT_RELIABILITY_QOS","max_blocking_time":{"sec":0,"nanosec":0}},"destination_order":{"kind":"BY_RECEPTION_TIMESTAMP_DESTINATIONORDER_QOS"},"history":{"kind":"KEEP_LAST_HISTORY_QOS","depth":1},"resource_limits":{"max_samples":"LENGTH_UNLIMITED","max_instances":"LENGTH_UNLIMITED","max_samples_per_instance":"LENGTH_UNLIMITED"},"transport_priority":{"value":1},"lifespan":{"duration":{"sec":"DURATION_INFINITE_SEC","nanosec":"DURATION_INFINITE_NSEC"}},"ownership":{"kind":"SHARED_OWNERSHIP_QOS"},"topic_data":{"value":"E38"}},"publisher_qos":{"entity_factory":{"autoenable_created_entities":true},"group_data":{"value":"223E"},"partition":{"name":{"element":["Partition1"]}},"presentation":{"access_scope":"INSTANCE_PRESENTATION_QOS","coherent_access":false,"ordered_access":false}},"subscriber_qos":{"entity_factory":{"autoenable_created_entities":true},"partition":{"name":{"element":["Partition1"]}},"presentation":{"access_scope":"INSTANCE_PRESENTATION_QOS","coherent_access":false,"ordered_access":false},"group_data":{"value":"22EF"}},"datawriter_qos":{"durability":{"kind":"VOLATILE_DURABILITY_QOS"},"deadline":{"period":{"sec":"DURATION_INFINITE_SEC","nanosec":"DURATION_INFINITE_NSEC"}},"latency_budget":{"duration":{"sec":0,"nanosec":0}},"liveliness":{"kind":"AUTOMATIC_LIVELINESS_QOS","lease_duration":{"sec":"DURATION_INFINITE_SEC","nanosec":"DURATION_INFINITE_NSEC"}},"reliability":{"kind":"BEST_EFFORT_RELIABILITY_QOS","max_blocking_time":{"sec":0,"nanosec":100000000}},"history":{"kind":"KEEP_LAST_HISTORY_QOS","depth":1},"ownership":{"kind":"SHARED_OWNERSHIP_QOS"},"ownership_strength":{"value":2},"writer_data_lifecycle":{"autodispose_unregistered_instances":false},"user_data":{"value":"223"}},"datareader_qos":{"durability":{"kind":"VOLATILE_DURABILITY_QOS"},"deadline":{"period":{"sec":"DURATION_INFINITE_SEC","nanosec":"DURATION_INFINITE_NSEC"}},"latency_budget":{"duration":{"sec":0,"nanosec":"DURATION_INFINITE_NSEC"}},"liveliness":{"kind":"AUTOMATIC_LIVELINESS_QOS","lease_duration":{"sec":"DURATION_INFINITE_SEC","nanosec":"DURATION_INFINITE_NSEC"}},"reliability":{"kind":"BEST_EFFORT_RELIABILITY_QOS","max_blocking_time":{"sec":0,"nanosec":0}},"history":{"depth":1,"kind":"KEEP_LAST_HISTORY_QOS"},"resource_limits":{"max_samples":"LENGTH_UNLIMITED","max_instances":1,"max_samples_per_instance":"LENGTH_UNLIMITED","initial_instances":1,"initial_samples":2},"ownership":{"kind":"EXCLUSIVE_OWNERSHIP_QOS"},"time_based_filter":{"minimum_separation":{"sec":0,"nanosec":0}},"reader_data_lifecycle":{"autopurge_disposed_samples_delay":{"sec":0,"nanosec":0},"autopurge_nowriter_samples_delay":{"sec":0,"nanosec":0}},"user_data":{"value":"2233"}}},{"name":"QosProfile2","base_name":"DDSDefaultQoSLibrary::QosProfile1","topic_qos":[{"name":"ReliableTopicQos","topic_filter":"A*","reliability":{"kind":"RELIABLE_RELIABILITY_QOS"}},{"name":"BestEffortTopicQos","topic_filter":"B*","reliability":{"kind":"BEST_EFFORT_RELIABILITY_QOS"}}],"datawriter_qos":[{"name":"ReliableDataWriterQos","topic_filter":"A*","reliability":{"kind":"RELIABLE_RELIABILITY_QOS"}},{"name":"BestEffortDataWriterQos","topic_filter":"B*","reliability":{"kind":"BEST_EFFORT_RELIABILITY_QOS"}}],"datareader_qos":[{"name":"ReliableDataReaderQos","topic_filter":"A*","reliability":{"kind":"RELIABLE_RELIABILITY_QOS"}},{"name":"BestEffortDataReaderQos","topic_filter":"B*","reliability":{"kind":"BEST_EFFORT_RELIABILITY_QOS"}}]}]}};

export const COLORS = {
  library:     { bg:'#0f172a', border:'#334155', text:'#f8fafc', badge:'#1e293b' },
  profile:     { bg:'#1e1b4b', border:'#4338ca', text:'#e0e7ff', badge:'#312e81' },
  participant: { bg:'#0c4a6e', border:'#0284c7', text:'#e0f2fe', badge:'#075985' },
  topic:       { bg:'#064e3b', border:'#059669', text:'#d1fae5', badge:'#065f46' },
  publisher:   { bg:'#713f12', border:'#d97706', text:'#fef3c7', badge:'#92400e' },
  subscriber:  { bg:'#581c87', border:'#9333ea', text:'#f3e8ff', badge:'#6b21a8' },
  datawriter:  { bg:'#7f1d1d', border:'#ef4444', text:'#fee2e2', badge:'#991b1b' },
  datareader:  { bg:'#1e3a5f', border:'#3b82f6', text:'#dbeafe', badge:'#1d4ed8' },
};

export const ENTITY_META = {
  domain_participant_qos: { icon:'🌐', colorKey:'participant', type:'DomainParticipant QoS' },
  topic_qos:              { icon:'📡', colorKey:'topic',       type:'Topic QoS' },
  publisher_qos:          { icon:'📤', colorKey:'publisher',   type:'Publisher QoS' },
  subscriber_qos:         { icon:'📥', colorKey:'subscriber',  type:'Subscriber QoS' },
  datawriter_qos:         { icon:'✍️',  colorKey:'datawriter',  type:'DataWriter QoS' },
  datareader_qos:         { icon:'📖', colorKey:'datareader',  type:'DataReader QoS' },
};

export const KIND_OPTIONS = {
  durability:        ['VOLATILE_DURABILITY_QOS','TRANSIENT_LOCAL_DURABILITY_QOS','TRANSIENT_DURABILITY_QOS','PERSISTENT_DURABILITY_QOS'],
  history:           ['KEEP_LAST_HISTORY_QOS','KEEP_ALL_HISTORY_QOS'],
  history_kind:      ['KEEP_LAST_HISTORY_QOS','KEEP_ALL_HISTORY_QOS'],
  liveliness:        ['AUTOMATIC_LIVELINESS_QOS','MANUAL_BY_PARTICIPANT_LIVELINESS_QOS','MANUAL_BY_TOPIC_LIVELINESS_QOS'],
  reliability:       ['BEST_EFFORT_RELIABILITY_QOS','RELIABLE_RELIABILITY_QOS'],
  destination_order: ['BY_RECEPTION_TIMESTAMP_DESTINATIONORDER_QOS','BY_SOURCE_TIMESTAMP_DESTINATIONORDER_QOS'],
  ownership:         ['SHARED_OWNERSHIP_QOS','EXCLUSIVE_OWNERSHIP_QOS'],
  access_scope:      ['INSTANCE_PRESENTATION_QOS','TOPIC_PRESENTATION_QOS','GROUP_PRESENTATION_QOS'],
};

export const INF_TOKENS = new Set(['DURATION_INFINITE_SEC','DURATION_INFINITE_NSEC','LENGTH_UNLIMITED']);

export function flatten(obj, prefix = '') {
  const rows = [];
  if (!obj || typeof obj !== 'object') return rows;
  for (const [k, v] of Object.entries(obj)) {
    if (k === 'name' || k === 'topic_filter') continue;
    const key = prefix ? `${prefix}.${k}` : k;
    if (v !== null && typeof v === 'object' && !Array.isArray(v)) {
      rows.push(...flatten(v, key));
    } else {
      rows.push({ key, value: Array.isArray(v) ? v.join(', ') : v });
    }
  }
  return rows;
}

export function buildGraph(raw) {
  const nodes = [];
  const edges = [];
  const lib = raw.qos_library;

  nodes.push({
    id: 'lib', type: 'libraryNode',
    position: { x: 40, y: 400 },
    data: { label: lib.name },
  });

  lib.qos_profiles.forEach((prof, pi) => {
    const profId = `prof_${pi}`;
    nodes.push({
      id: profId, type: 'profileNode',
      position: { x: 280, y: pi * 700 + 60 },
      data: { label: prof.name, baseName: prof.base_name },
    });
    edges.push({
      id: `e_lib_${profId}`, source: 'lib', target: profId,
      type: 'smoothstep', markerEnd: { type: 'arrowclosed', color: '#4338ca' },
      style: { stroke: '#4338ca', strokeWidth: 2 },
      label: 'profile', labelStyle: { fill: '#818cf8', fontSize: 9 },
      labelBgStyle: { fill: '#0f172a' },
    });

    let col = 0, row = 0, prevKey = null;
    Object.entries(ENTITY_META).forEach(([eKey, meta]) => {
      const val = prof[eKey];
      if (!val) return;
      const items = Array.isArray(val) ? val : [val];
      if (prevKey !== null) { col = Math.floor(Object.keys(ENTITY_META).indexOf(eKey) / 3); row = Object.keys(ENTITY_META).indexOf(eKey) % 3; }
      prevKey = eKey;

      items.forEach((item, ii) => {
        const nid = `${profId}_${eKey}_${ii}`;
        const ei = Object.keys(ENTITY_META).indexOf(eKey);
        const x = 560 + Math.floor(ei / 3) * 400;
        const y = pi * 700 + (ei % 3) * 250 + ii * 70;
        nodes.push({
          id: nid, type: 'qosNode',
          position: { x, y },
          data: {
            label: item.name ? `${meta.icon} ${item.name}` : `${meta.icon} ${eKey.replace(/_qos$/, '').replace(/_/g, ' ').toUpperCase()}`,
            subtitle: meta.type + (item.topic_filter ? ` [${item.topic_filter}]` : ''),
            colorKey: meta.colorKey,
            rows: flatten(item),
          },
        });
        edges.push({
          id: `e_${profId}_${nid}`, source: profId, target: nid,
          type: 'smoothstep',
          markerEnd: { type: 'arrowclosed', color: COLORS[meta.colorKey].border },
          style: { stroke: COLORS[meta.colorKey].border, strokeWidth: 1.5, strokeDasharray: '5 3' },
          label: eKey.replace(/_qos$/, ''), labelStyle: { fill: COLORS[meta.colorKey].border, fontSize: 8 },
          labelBgStyle: { fill: '#0f172a', fillOpacity: 0.85 },
        });
      });
    });
  });

  return { nodes, edges };
}
