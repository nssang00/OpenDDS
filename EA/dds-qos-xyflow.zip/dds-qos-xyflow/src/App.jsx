import { useCallback, useMemo } from 'react'
import {
  ReactFlow, Background, Controls, MiniMap,
  useNodesState, useEdgesState, MarkerType,
} from '@xyflow/react'
import '@xyflow/react/dist/style.css'

import { RAW, COLORS, buildGraph } from './data.js'
import { LibraryNode, ProfileNode, QoSNode } from './Nodes.jsx'

const nodeTypes = {
  libraryNode: LibraryNode,
  profileNode: ProfileNode,
  qosNode:     QoSNode,
}

const { nodes: initNodes, edges: initEdges } = buildGraph(RAW)

/* ── Legend ─────────────────────────────────────────────────────── */
function Legend() {
  const items = [
    { icon: '🌐', label: 'DomainParticipant', key: 'participant' },
    { icon: '📡', label: 'Topic',             key: 'topic' },
    { icon: '📤', label: 'Publisher',         key: 'publisher' },
    { icon: '📥', label: 'Subscriber',        key: 'subscriber' },
    { icon: '✍️',  label: 'DataWriter',        key: 'datawriter' },
    { icon: '📖', label: 'DataReader',        key: 'datareader' },
  ]
  return (
    <div style={{
      position: 'absolute', bottom: 14, left: 14, zIndex: 10,
      background: '#0f172acc', border: '1px solid #334155',
      borderRadius: 10, padding: '10px 14px',
      backdropFilter: 'blur(8px)',
      fontFamily: "'Inter','Segoe UI',sans-serif",
    }}>
      <div style={{ fontSize: 9, fontWeight: 700, color: '#94a3b8', letterSpacing: 1, marginBottom: 5 }}>
        LEGEND
      </div>
      {items.map(it => {
        const c = COLORS[it.key]
        return (
          <div key={it.key} style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 3 }}>
            <div style={{ width: 11, height: 11, background: c.bg, border: `2px solid ${c.border}`, borderRadius: 3 }} />
            <span style={{ fontSize: 10, color: '#cbd5e1' }}>{it.icon} {it.label}</span>
          </div>
        )
      })}
      <div style={{ fontSize: 8, color: '#475569', marginTop: 6, paddingTop: 6, borderTop: '1px solid #1e293b' }}>
        Click header to collapse · Edit values inline
      </div>
    </div>
  )
}

/* ── App ─────────────────────────────────────────────────────────── */
export default function App() {
  const [nodes, , onNodesChange] = useNodesState(initNodes)
  const [edges, , onEdgesChange] = useEdgesState(initEdges)

  return (
    <div style={{ width: '100vw', height: '100vh', background: '#020617' }}>
      {/* Toolbar */}
      <div style={{
        position: 'absolute', top: 14, left: '50%', transform: 'translateX(-50%)',
        zIndex: 10, background: '#0f172acc', border: '1px solid #334155',
        borderRadius: 10, padding: '8px 18px',
        display: 'flex', alignItems: 'center', gap: 12,
        backdropFilter: 'blur(10px)',
        fontFamily: "'Inter','Segoe UI',sans-serif",
        pointerEvents: 'none',
      }}>
        <div>
          <div style={{ fontSize: 14, fontWeight: 800, color: '#f8fafc', letterSpacing: .5 }}>
            🗂️ DDS QoS Configuration
          </div>
          <div style={{ fontSize: 10, color: '#64748b' }}>
            @xyflow/react · Editable Node Graph
          </div>
        </div>
      </div>

      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        nodeTypes={nodeTypes}
        fitView
        fitViewOptions={{ padding: 0.12 }}
        minZoom={0.05}
        maxZoom={2.5}
        defaultEdgeOptions={{ animated: false }}
        proOptions={{ hideAttribution: false }}
      >
        <Background color="#1e293b" gap={20} variant="dots" />
        <Controls style={{
          background: '#1e293b', border: '1px solid #334155', borderRadius: 8,
        }} />
        <MiniMap
          style={{ background: '#0f172a', border: '1px solid #334155', borderRadius: 8 }}
          nodeColor={n => COLORS[n.data?.colorKey]?.border || '#4338ca'}
          maskColor="#00000088"
        />
      </ReactFlow>

      <Legend />
    </div>
  )
}
