import { useState, useCallback } from 'react'
import { Handle, Position } from '@xyflow/react'
import { COLORS } from './data.js'
import PropRow from './PropRow.jsx'

/* ── Library root ─────────────────────────────────────────────── */
export function LibraryNode({ data }) {
  const c = COLORS.library
  return (
    <div style={{
      background: c.bg, border: `2px solid ${c.border}`,
      borderRadius: 12, padding: '14px 22px', textAlign: 'center',
      minWidth: 180, boxShadow: '0 8px 32px #00000088',
      fontFamily: "'Inter','Segoe UI',sans-serif",
    }}>
      <div style={{ fontSize: 24, marginBottom: 4 }}>🗂️</div>
      <div style={{ fontSize: 13, fontWeight: 800, color: c.text, letterSpacing: .5 }}>{data.label}</div>
      <div style={{ fontSize: 9, color: c.text + '66', marginTop: 2 }}>QoS Library</div>
      <Handle type="source" position={Position.Right}
        style={{ background: c.border, width: 10, height: 10 }} />
    </div>
  )
}

/* ── Profile ──────────────────────────────────────────────────── */
export function ProfileNode({ data }) {
  const c = COLORS.profile
  return (
    <div style={{
      background: c.bg + 'cc', border: `2px dashed ${c.border}`,
      borderRadius: 12, padding: '10px 16px', minWidth: 170,
      fontFamily: "'Inter','Segoe UI',sans-serif",
      boxShadow: `0 4px 16px ${c.border}22`,
    }}>
      <div style={{ fontSize: 12, fontWeight: 700, color: c.text }}>📋 {data.label}</div>
      {data.baseName && (
        <div style={{ fontSize: 9, color: c.text + '88', marginTop: 2 }}>extends: {data.baseName}</div>
      )}
      <Handle type="target" position={Position.Left} style={{ background: c.border }} />
      <Handle type="source" position={Position.Right} style={{ background: c.border }} />
    </div>
  )
}

/* ── QoS entity ───────────────────────────────────────────────── */
export function QoSNode({ data }) {
  const [collapsed, setCollapsed] = useState(false)
  const [rows, setRows] = useState(() => data.rows.map(r => ({ ...r })))
  const [changed, setChanged] = useState(false)
  const c = COLORS[data.colorKey] || COLORS.topic

  const handleChange = useCallback((key, val) => {
    setRows(prev => prev.map(r => r.key === key ? { ...r, value: val } : r))
    setChanged(true)
  }, [])

  return (
    <div style={{
      background: c.bg, border: `2px solid ${changed ? '#f59e0b' : c.border}`,
      borderRadius: 10, minWidth: 310, maxWidth: 330,
      boxShadow: `0 4px 20px ${c.border}44`,
      fontFamily: "'Inter','Segoe UI',sans-serif",
    }}>
      <Handle type="target" position={Position.Left}
        style={{ background: c.border, width: 10, height: 10 }} />

      {/* Header */}
      <div onClick={() => setCollapsed(v => !v)} style={{
        padding: '8px 11px', background: c.badge, cursor: 'pointer',
        borderRadius: collapsed ? 8 : '8px 8px 0 0',
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        userSelect: 'none',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
          <span style={{ fontSize: 15 }}>{data.label.split(' ')[0]}</span>
          <div>
            <div style={{ fontSize: 11, fontWeight: 700, color: c.text }}>
              {data.label.substring(data.label.indexOf(' ') + 1)}
            </div>
            <div style={{ fontSize: 9, color: c.text + '88', marginTop: 1 }}>{data.subtitle}</div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
          {changed && (
            <span style={{
              fontSize: 8, background: '#f59e0b', color: '#000',
              borderRadius: 3, padding: '1px 5px', fontWeight: 700,
            }}>EDITED</span>
          )}
          <span style={{ fontSize: 10, color: c.text + '88',
            transform: collapsed ? 'rotate(-90deg)' : 'rotate(0deg)',
            transition: 'transform .2s', display: 'inline-block' }}>▼</span>
        </div>
      </div>

      {/* Body */}
      {!collapsed && (
        <div style={{
          padding: '6px 10px',
          maxHeight: 300, overflowY: 'auto',
        }}>
          {rows.map(r => (
            <PropRow key={r.key} row={r} colorKey={data.colorKey}
              onChange={val => handleChange(r.key, val)} />
          ))}
        </div>
      )}

      <Handle type="source" position={Position.Right}
        style={{ background: c.border, width: 10, height: 10 }} />
    </div>
  )
}
