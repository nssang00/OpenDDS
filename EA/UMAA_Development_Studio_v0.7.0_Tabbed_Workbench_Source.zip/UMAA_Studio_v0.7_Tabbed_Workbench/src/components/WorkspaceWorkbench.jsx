import { useState } from 'react';
import { Alert, Button, Descriptions, Empty, Modal, Select, Space, Table, Tabs, Tag, Typography, message } from 'antd';
import { ApartmentOutlined, BuildOutlined, NodeIndexOutlined, PlusOutlined, ThunderboltOutlined } from '@ant-design/icons';
import { useEditorStore } from '../stores/useEditorStore.js';
import { Diagram } from './Diagram.jsx';
import { RuntimeSettings } from './DesignDetails.jsx';
import { CommunicationView } from './CommunicationView.jsx';
import { ServiceWorkbench, TopicWorkbench, OperationWorkbench, FunctionalAreaWorkbench, QosWorkbench } from './ContractWorkbench.jsx';
import { TypeWorkbench } from './TypeWorkbench.jsx';
import { deriveEndpoints } from '../logic/endpoints.js';
const {Text}=Typography;
export function WorkspaceWorkbench({ onNewComponent, onNewService, onGenerate }) {
  const snapshot=useEditorStore(s=>s.snapshot);
  const selection=useEditorStore(s=>s.selection);
  const select=useEditorStore(s=>s.select);
  const autoLayout=useEditorStore(s=>s.autoLayout);
  const [componentTab,setComponentTab]=useState('diagram');
  const [addBindingVisible,setAddBindingVisible]=useState(false);
  const [bindingService,setBindingService]=useState(null);
  const [bindingRole,setBindingRole]=useState('provider');
  const addBinding=useEditorStore(s=>s.addBinding);
  const kind=selection?.kind??'diagram';
  const component=kind==='component'?snapshot?.components.find(c=>c.id===selection.id):null;
  const isAssembly=['diagram','component'].includes(kind);
  if(!snapshot)return <Empty/>;
  if(isAssembly)return <div className="assembly-workbench">
    <div className="workspace-toolbar">
      <div><Typography.Title level={5} style={{margin:0}}><NodeIndexOutlined/> System Diagram · Component Assembly</Typography.Title>
        <Text type="secondary">서비스 포트의 P/C 논리 연결을 설계합니다. 연결선을 클릭하면 DDS 통신 상세가 열립니다.</Text></div>
      <Space wrap><Button size="small" onClick={()=>select({kind:'diagram',id:'system'})}>전체 다이어그램</Button><Button size="small" onClick={autoLayout}>자동 배치</Button><Button size="small" icon={<PlusOutlined/>} onClick={onNewComponent}>Component</Button><Button size="small" icon={<PlusOutlined/>} onClick={onNewService}>Custom Service</Button></Space>
    </div>
    {component&&<div className="component-context-tabs"><Tabs size="small" activeKey={componentTab} onChange={setComponentTab} items={[
      {key:'diagram',label:'Diagram'}, {key:'bindings',label:`Service Bindings (${snapshot.bindings.filter(b=>b.componentId===component.id).length})`}, {key:'runtime',label:'Runtime / QoS'}
    ]}/></div>}
    {(!component||componentTab==='diagram')&&<div className="canvas-section"><Diagram/></div>}
    {component&&componentTab==='bindings'&&<div className="assembly-details center-workbench"><div className="editor-heading"><div><h2>{component.name} · Service Bindings</h2><Text type="secondary">Service에서 패턴·Topic·Type 정의 → 여기서 Provider/Consumer 선택 → Diagram에서 연결</Text></div><Button type="primary" icon={<PlusOutlined/>} onClick={()=>{setBindingService(null);setAddBindingVisible(true);}}>Service Binding 추가</Button></div>
      <Table size="small" rowKey="id" pagination={false} dataSource={snapshot.bindings.filter(b=>b.componentId===component.id)} columns={[
        {title:'Service',render:(_,r)=><Button size="small" type="link" onClick={()=>select({kind:'service',id:r.serviceId})}>{snapshot.services.find(s=>s.id===r.serviceId)?.name}</Button>},
        {title:'Role',dataIndex:'role',render:v=><Tag color={v==='provider'?'blue':'orange'}>{v}</Tag>},
        {title:'DDS Endpoints',render:(_,r)=>deriveEndpoints(snapshot,component.id).filter(e=>e.bindingId===r.id).length},
        {title:'Pattern / 상세',render:(_,r)=><Space><Tag>{snapshot.services.find(s=>s.id===r.serviceId)?.flowControl}</Tag><Button size="small" onClick={()=>select({kind:'binding',id:r.id})}>DDS 구성 보기</Button></Space>}
      ]}/><Alert showIcon type="info" message="Service 계약과 P/C Binding은 분리됩니다." description="Binding 역할에 따라 Reader/Writer를 자동 파생하며, 명령 패턴은 Service에서 정의합니다."/></div>}
    {component&&componentTab==='runtime'&&<div className="assembly-details center-workbench"><h2>{component.name} · Runtime Configuration</h2><RuntimeSettings componentId={component.id}/></div>}
    <Modal title={`${component?.name??'Component'} · Service Binding 추가`} open={addBindingVisible} okText="추가" okButtonProps={{disabled:!bindingService}} destroyOnClose
      onCancel={()=>setAddBindingVisible(false)} onOk={()=>{ if(component && bindingService && addBinding(component.id,bindingService,bindingRole)){setAddBindingVisible(false);message.success('Service Binding 추가 완료 · DDS Endpoint가 자동 파생됩니다.');} else message.warning('이미 같은 역할의 바인딩이 있거나 Service가 없습니다.');}}>
      <p>Service 계약의 DDS Pattern·Topic·Type은 그대로 참조하며, 이 Component가 수행할 역할만 선택합니다.</p>
      <Select showSearch optionFilterProp="label" placeholder="Service 선택" style={{width:'100%',marginBottom:12}} value={bindingService} onChange={setBindingService}
        options={snapshot.services.map(s=>({value:s.id,label:`${s.functionalArea} / ${s.name} (${s.flowControl})`}))}/>
      <Select style={{width:'100%'}} value={bindingRole} onChange={setBindingRole} options={[{value:'provider',label:'Provider — 서비스 구현/응답'},{value:'consumer',label:'Consumer — 서비스 사용/명령'}]}/>
    </Modal>
  </div>;
  if(kind==='binding')return <BindingWorkbench bindingId={selection.id}/>;
  if(kind==='connection')return <CommunicationView connectionId={selection.id} onBack={()=>select({kind:'diagram',id:'system'})}/>;
  if(kind==='service')return <ServiceWorkbench key={selection.id} serviceId={selection.id}/>;
  if(kind==='interface')return <ServiceWorkbench key={selection.id} serviceId={snapshot.interfaces.find(i=>i.id===selection.id)?.serviceId}/>;
  if(kind==='operation')return <OperationWorkbench operationId={selection.id}/>;
  if(kind==='message'||kind==='dataType')return <TypeWorkbench key={selection.id} kind={kind} id={selection.id}/>;
  if(kind==='topic')return <TopicWorkbench topicId={selection.id}/>;
  if(kind==='functionalArea')return <FunctionalAreaWorkbench id={selection.id}/>;
  if(kind==='qos')return <QosWorkbench id={selection.id}/>;
  if(kind==='qosRuntime')return <div className="center-workbench"><h2>Component DDS Runtime / QoS</h2><RuntimeSettings componentId={selection.id}/></div>;
  if(kind==='build')return <div className="center-workbench"><div className="editor-heading"><div><Text type="secondary" className="editor-eyebrow">BUILD & DEPLOYMENT</Text><h2><BuildOutlined/> Component Wrapper / DLL / SO</h2></div><Button type="primary" icon={<ThunderboltOutlined/>} onClick={onGenerate}>Generate Files</Button></div>
    <Alert showIcon type="warning" message="현재는 DDS가 연결되지 않은 C++ 공유 라이브러리 골격입니다." description="Component별 Endpoint 목록, Custom IDL, C ABI, CMake 및 Config를 만듭니다. 공식 IDL 연동과 실제 DDS DomainParticipant/Reader/Writer 구현 및 Host 로딩은 미구현입니다."/>
    <Descriptions bordered column={1} style={{marginTop:16}}><Descriptions.Item label="Target">{snapshot.project.targetPlatform==='windows'?'Windows · DLL':'Linux · SO'}</Descriptions.Item><Descriptions.Item label="DDS vendor metadata">{snapshot.project.ddsVendor}</Descriptions.Item><Descriptions.Item label="Components">{snapshot.components.length}</Descriptions.Item><Descriptions.Item label="Contract bindings">{snapshot.bindings.length}</Descriptions.Item></Descriptions>
    <h3>Generation Targets</h3><Table size="small" rowKey="id" pagination={false} dataSource={snapshot.components.map(c=>({...c,endpointCount:deriveEndpoints(snapshot,c.id).length}))} columns={[
      {title:'Component',dataIndex:'name',render:(v,r)=><Button type="link" onClick={()=>select({kind:'component',id:r.id})}>{v}</Button>},
      {title:'DDS Endpoint specs',dataIndex:'endpointCount'},
      {title:'Artifact',render:()=>snapshot.project.targetPlatform==='windows'?'.dll scaffold':'.so scaffold'}]}/>
    <Button type="primary" onClick={onGenerate}>Generated C++ / IDL / Config 파일 미리보기 및 ZIP 다운로드</Button></div>;
  return <Empty description="왼쪽에서 편집할 객체를 선택하세요"/>;
}


function BindingWorkbench({bindingId}) {
  const snapshot=useEditorStore(s=>s.snapshot);
  const select=useEditorStore(s=>s.select);
  const binding=snapshot?.bindings.find(b=>b.id===bindingId);
  if(!snapshot||!binding)return <Empty description="Binding을 선택하세요"/>;
  const service=snapshot.services.find(s=>s.id===binding.serviceId);
  const component=snapshot.components.find(c=>c.id===binding.componentId);
  const endpoints=deriveEndpoints(snapshot,binding.componentId).filter(e=>e.bindingId===bindingId);
  const connections=snapshot.connections.filter(c=>c.providerBindingId===bindingId || c.consumerBindingId===bindingId);
  const operations=snapshot.operations.filter(op=>op.serviceId===binding.serviceId);
  return <div className="center-workbench">
    <div className="editor-heading"><div><Text type="secondary" className="editor-eyebrow">COMPONENT SERVICE BINDING</Text><h2>{component?.name} · {service?.name}</h2><Space><Tag color={binding.role==='provider'?'blue':'orange'}>{binding.role.toUpperCase()}</Tag><Tag>{service?.flowControl}</Tag></Space></div>
      <Button onClick={()=>select({kind:'component',id:binding.componentId})}>Component 열기</Button></div>
    <Alert showIcon type="info" message="이 Binding의 DDS Pattern은 Service 계약에서 자동 적용됩니다." description="아래 Reader/Writer는 Provider/Consumer 역할을 반영한 결과입니다. 서비스 계약은 수정하지 않으며, Topic → Type을 클릭해 정의를 추적할 수 있습니다."/>
    <Space style={{margin:'14px 0'}}><Button type="primary" onClick={()=>select({kind:'service',id:binding.serviceId})}>Service 계약·패턴 보기</Button><Button onClick={()=>select({kind:'diagram',id:'system'})}>Component 연결도</Button></Space>
    <h3>파생된 DDS Endpoints ({endpoints.length})</h3>
    <Table size="small" pagination={false} rowKey={r=>`${r.topicName}:${r.direction}:${r.bindingId}`} dataSource={endpoints} columns={[
      {title:'Direction',dataIndex:'direction',render:v=><Tag color={v==='writer'?'blue':'orange'}>{v.toUpperCase()}</Tag>},
      {title:'DDS Topic',dataIndex:'topicName',render:(v)=>{const t=snapshot.topics.find(t=>t.name===v);return t?<Button type="link" size="small" onClick={()=>select({kind:'topic',id:t.id})}>{v}</Button>:v;}},
      {title:'IDL MessageType',render:(_,r)=>{const topic=snapshot.topics.find(t=>t.name===r.topicName);const mt=snapshot.messages.find(m=>m.id===topic?.messageTypeId);return mt?<Button type="link" size="small" onClick={()=>select({kind:'message',id:mt.id})}>{mt.name}</Button>:'—';}}
    ]}/>
    <h3>Operation → DDS Action ({operations.length})</h3>
    <Table size="small" pagination={false} rowKey="id" dataSource={operations} columns={[
      {title:'Operation',dataIndex:'name',render:(v,r)=><Button type="link" size="small" onClick={()=>select({kind:'operation',id:r.id})}>{v}</Button>},
      {title:'Actor (Service 기준)',dataIndex:'actor'}, {title:'DDS Action',dataIndex:'action'}
    ]}/>
    <h3>연결된 Components ({connections.length})</h3>
    {connections.length?connections.map(c=><Button key={c.id} style={{marginRight:8}} onClick={()=>select({kind:'connection',id:c.id})}>DDS Communication View 열기</Button>):
      <Alert type="warning" showIcon message="아직 맞은편 Provider/Consumer Binding과 연결되지 않았습니다." description="Component 조립도에서 호환되는 Service 포트를 연결하세요. DDS는 실제 실행 시 Topic 기반으로 매칭되며 이 선은 논리 설계 관계입니다."/>}
    <div className="editor-note">Endpoint는 Service Operation으로부터 파생한 설계 정보입니다. 실제 DDS Reader/Writer 및 DLL/SO Runtime 구현은 미완료입니다.</div>
  </div>;
}
