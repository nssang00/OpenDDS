import { useEffect, useMemo, useState } from 'react';
import { Button, Empty, Input, Tag, Tree, Typography } from 'antd';
import {
  ApartmentOutlined, ApiOutlined, BuildOutlined, CodeOutlined, ControlOutlined,
  DatabaseOutlined, DeploymentUnitOutlined, FileTextOutlined, FolderOpenOutlined,
  LinkOutlined, NodeIndexOutlined, PlusOutlined
} from '@ant-design/icons';
import { useEditorStore } from '../stores/useEditorStore.js';

const TABS = [
  { key: 'services', label: 'Services', icon: <ApiOutlined /> },
  { key: 'components', label: 'Components', icon: <ApartmentOutlined /> },
  { key: 'types', label: 'Types', icon: <CodeOutlined /> },
  { key: 'topics', label: 'Topics', icon: <DatabaseOutlined /> },
  { key: 'qos', label: 'QoS', icon: <ControlOutlined /> },
  { key: 'build', label: 'Build', icon: <BuildOutlined /> },
];

export function selectionTab(kind) {
  if (['service', 'interface', 'operation', 'functionalArea'].includes(kind)) return 'services';
  if (['diagram', 'component', 'binding', 'connection'].includes(kind)) return 'components';
  if (['message', 'dataType'].includes(kind)) return 'types';
  if (kind === 'topic') return 'topics';
  if (['qos','qosRuntime'].includes(kind)) return 'qos';
  if (kind === 'build') return 'build';
  return null;
}

export function ProjectExplorer({ onCreate }) {
  const snapshot = useEditorStore(s => s.snapshot);
  const selection = useEditorStore(s => s.selection);
  const select = useEditorStore(s => s.select);
  const [tab, setTab] = useState('components');
  const [filter, setFilter] = useState('');
  const [expanded, setExpanded] = useState({
    services: ['std-areas', 'functionalArea:MO', 'custom-services'],
    components: ['my-components', 'component-connections'],
    types: ['types-custom', 'types-messages'],
    topics: ['topics-standard', 'topics-custom'],
    qos: ['qos-profiles'],
    build: ['build-components'],
  });

  useEffect(() => {
    const next = selectionTab(selection?.kind);
    if (next) setTab(t => t === next ? t : next);
  }, [selection?.kind, selection?.id]);

  const groups = useMemo(() => {
    if (!snapshot) return {};
    const keyword = filter.trim().toLowerCase();
    const matches = (...values) => !keyword || values.some(v => String(v ?? '').toLowerCase().includes(keyword));
    const section = (key, title, icon, children) => ({key, title, icon, children});
    const leaf = (kind, id, title, icon, extra) => ({
      key: `${kind}:${id}`, icon,
      title: <span className="explorer-row-label">{title}{extra}</span>
    });
    const ext = <Tag className="explorer-tag" color="purple">EXT</Tag>;
    const standard = <Tag className="explorer-tag">STD</Tag>;
    const serviceNode = svc => ({
      ...leaf('service', svc.id, svc.name, <ApiOutlined/>, svc.source === 'custom' ? ext : null),
      title: <span className="explorer-service-draggable" draggable
        title="Service 클릭: 계약 보기 · 드래그: Component Diagram에서 바인딩 추가"
        onDragStart={e => { e.stopPropagation(); e.dataTransfer.setData('application/umaa-service-id', svc.id); e.dataTransfer.effectAllowed = 'copy'; }}>
        {svc.name}{svc.source === 'custom' ? ext : null}
      </span>,
      children: keyword ? [] : snapshot.operations.filter(o => o.serviceId === svc.id).map(op =>
        leaf('operation', op.id, <>{op.name} <span className="explorer-secondary">{op.action}</span></>, <FileTextOutlined/>))
    });
    const areas = snapshot.functionalAreas.filter(a => a.source !== 'custom').map(area => section(
      `functionalArea:${area.id}`, <span>{area.id} · {area.name} <Tag className="explorer-tag">{snapshot.services.filter(s => s.functionalArea === area.id && s.source === 'standard').length}</Tag></span>,
      <DeploymentUnitOutlined/>, snapshot.services.filter(s => s.source === 'standard' && s.functionalArea === area.id && matches(s.name,area.id,area.name)).map(serviceNode)
    ));
    const custom = snapshot.services.filter(s => s.source === 'custom');
    const customAreas = snapshot.functionalAreas.filter(a => a.source === 'custom');
    const customMessages = snapshot.messages.filter(m => m.source === 'custom');
    const standardMessages = snapshot.messages.filter(m => m.source !== 'custom');
    const customServiceIds = new Set(custom.map(s => s.id));
    const customTopics = snapshot.topics.filter(t => snapshot.operations.some(o => o.topicId === t.id && customServiceIds.has(o.serviceId)));
    const customTopicIds = new Set(customTopics.map(t => t.id));
    const standardTopics = snapshot.topics.filter(t => !customTopicIds.has(t.id));
    const componentName = id => snapshot.components.find(c => c.id === id)?.name ?? id;
    const connectionTitle = c => {
      const pb = snapshot.bindings.find(b => b.id === c.providerBindingId);
      const cb = snapshot.bindings.find(b => b.id === c.consumerBindingId);
      const name = snapshot.services.find(s => s.id === pb?.serviceId)?.name ?? 'Unknown service';
      return `${name} · ${componentName(cb?.componentId)} ↔ ${componentName(pb?.componentId)}`;
    };
    const topicsNode = t => leaf('topic',t.id,t.name,<DatabaseOutlined/>,customTopicIds.has(t.id)?ext:standard);
    return {
      services: [
        section('std-areas', `UMAA 6.0 · 8 Functional Areas (READ ONLY)`, <FolderOpenOutlined/>, areas),
        section('custom-services', `Project Extensions · Services (${custom.length})`, <FolderOpenOutlined/>, [
          ...customAreas.filter(a=>matches(a.id,a.name)).map(a=>leaf('functionalArea',a.id,`${a.id} · ${a.name}`,<DeploymentUnitOutlined/>,ext)),
          ...custom.filter(s=>matches(s.name,s.functionalArea)).map(serviceNode)
        ])
      ],
      components: [
        leaf('diagram','system','System Assembly Diagram',<NodeIndexOutlined/>),
        section('my-components', `Project Components (${snapshot.components.length})`, <ApartmentOutlined/>, snapshot.components.filter(c=>matches(c.name,'component')).map(comp=>section(`component:${comp.id}`,comp.name,<ApartmentOutlined/>, snapshot.bindings.filter(b=>b.componentId===comp.id).map(b=>{
          const svc=snapshot.services.find(s=>s.id===b.serviceId);
          return leaf('binding',b.id,svc?.name??'Unknown service',<ApiOutlined/>,<Tag color={b.role==='provider'?'blue':'orange'} className="explorer-tag">{b.role==='provider'?'P':'C'}</Tag>);
        })))),
        section('component-connections',`Service Connections (${snapshot.connections.length})`,<LinkOutlined/>,snapshot.connections.filter(c=>matches(connectionTitle(c))).map(c=>leaf('connection',c.id,connectionTitle(c),<LinkOutlined/>)))
      ],
      types: [
        section('types-custom',`Custom IDL Types (${customMessages.length + (snapshot.dataTypes?.length??0)})`,<FolderOpenOutlined/>,[
          ...customMessages.filter(m=>matches(m.name)).map(m=>leaf('message',m.id,m.name,<FileTextOutlined/>,ext)),
          ...(snapshot.dataTypes??[]).filter(d=>matches(d.name,d.kind)).map(d=>leaf('dataType',d.id,`${d.name} (${d.kind})`,<CodeOutlined/>,ext))
        ]),
        section('types-messages',`UMAA Message Types (${standardMessages.length})`,<FolderOpenOutlined/>,standardMessages.filter(m=>matches(m.name)).map(m=>leaf('message',m.id,m.name,<FileTextOutlined/>,standard)))
      ],
      topics: [
        section('topics-custom',`Custom Topics (${customTopics.length})`,<FolderOpenOutlined/>,customTopics.filter(t=>matches(t.name)).map(topicsNode)),
        section('topics-standard',`UMAA Topics (${standardTopics.length})`,<FolderOpenOutlined/>,standardTopics.filter(t=>matches(t.name)).map(topicsNode))
      ],
      qos: [
        section('qos-profiles',`QoS Profiles (${snapshot.qosProfiles?.length??0})`,<ControlOutlined/>,(snapshot.qosProfiles??[]).filter(q=>matches(q.name)).map(q=>leaf('qos',q.id,q.name,<ControlOutlined/>))),
        section('qos-runtime','Runtime Settings by Component',<ApartmentOutlined/>,snapshot.components.filter(c=>matches(c.name)).map(c=>leaf('qosRuntime',c.id,c.name,<ApartmentOutlined/>)))
      ],
      build: [
        leaf('build','project','Component Wrapper · DLL/SO',<BuildOutlined/>),
        section('build-components','Build Targets',<FolderOpenOutlined/>,snapshot.components.filter(c=>matches(c.name)).map(c=>leaf('component',c.id,c.name,<ApartmentOutlined/>)))
      ]
    };
  }, [snapshot, filter]);

  if (!snapshot) return <Empty description="Loading project"/>;
  const currentTab = TABS.find(t => t.key === tab);
  const defaultForTab = key => {
    if(key==='components') return {kind:'diagram',id:'system'};
    if(key==='services') return {kind:'functionalArea',id:snapshot.functionalAreas.find(a=>a.id==='MO')?.id??snapshot.functionalAreas[0]?.id};
    if(key==='types') { const obj=snapshot.dataTypes?.[0]??snapshot.messages[0]; return obj&&{kind:snapshot.dataTypes?.length?'dataType':'message',id:obj.id}; }
    if(key==='topics') return snapshot.topics[0]&&{kind:'topic',id:snapshot.topics[0].id};
    if(key==='qos') return snapshot.qosProfiles?.[0]&&{kind:'qos',id:snapshot.qosProfiles[0].id};
    if(key==='build') return {kind:'build',id:'project'};
    return null;
  };
  const handleTab = key => {
    setTab(key);
    setFilter('');
    const first = defaultForTab(key);
    if (first?.id) select(first);
  };
  const nodes = groups[tab]??[];
  const filteredExpansion = [];
  const walk = list => list.forEach(n => { if(n.children?.length){filteredExpansion.push(n.key);walk(n.children);} });
  if(filter) walk(nodes);
  const selected = selection ? `${selection.kind}:${selection.id}` : '';
  return <div className="tabbed-project-explorer">
    <div className="explorer-project-caption"><FolderOpenOutlined/> <strong>{snapshot.project.name}</strong><span>UMAA {snapshot.project.standardVersion ?? '6.0'}</span></div>
    <div className="explorer-tab-grid" role="tablist" aria-label="Project Explorer categories">
      {TABS.map(item => <button key={item.key} type="button" role="tab" aria-selected={tab===item.key}
        className={`explorer-category-tab ${tab===item.key?'active':''}`} onClick={()=>handleTab(item.key)}>
        {item.icon}<span>{item.label}</span>
      </button>)}
    </div>
    <div className="explorer-category-topline">
      <Typography.Text strong>{currentTab?.label}</Typography.Text>
      <span>{tab==='services'?'규격 계약':tab==='components'?'서비스 조립':tab==='types'?'IDL 편집':tab==='topics'?'Topic–Type 매핑':tab==='qos'?'실행 정책':'라이브러리 생성'}</span>
    </div>
    <div className="explorer-actions">
      {tab==='services'&&<><Button size="small" icon={<PlusOutlined/>} onClick={()=>onCreate?.('service')}>Custom Service</Button><Button size="small" onClick={()=>onCreate?.('area')}>Custom Area</Button></>}
      {tab==='components'&&<><Button size="small" icon={<PlusOutlined/>} onClick={()=>onCreate?.('component')}>Component</Button><Button size="small" onClick={()=>select({kind:'diagram',id:'system'})}>Assembly</Button></>}
      {tab==='types'&&<Button size="small" icon={<PlusOutlined/>} onClick={()=>onCreate?.('type')}>Custom Type</Button>}
      {tab==='topics'&&<Typography.Text type="secondary" style={{fontSize:11}}>Custom Topic은 Service 계약에서 생성·연결합니다.</Typography.Text>}
      {tab==='qos'&&<Button size="small" icon={<PlusOutlined/>} onClick={()=>onCreate?.('qos')}>QoS Profile</Button>}
      {tab==='build'&&<Button size="small" onClick={()=>select({kind:'build',id:'project'})}>Build Targets 보기</Button>}
    </div>
    <Input.Search className="explorer-search" size="small" allowClear value={filter} onChange={e=>setFilter(e.target.value)} placeholder={`${currentTab?.label}에서 검색`}/>
    <div className="explorer-tree-scroll" role="tabpanel">
      <Tree showIcon showLine blockNode autoExpandParent={!!filter} treeData={nodes}
        expandedKeys={filter?filteredExpansion:expanded[tab]??[]}
        onExpand={keys=>setExpanded(old=>({...old,[tab]:keys}))}
        selectedKeys={selected?[selected]:[]}
        onSelect={keys=>{
          const raw=String(keys[0]??'');const idx=raw.indexOf(':');if(idx<0)return;
          const kind=raw.slice(0,idx);
          if(['diagram','build','functionalArea','component','service','operation','topic','message','dataType','qos','qosRuntime','binding','connection'].includes(kind)) select({kind,id:raw.slice(idx+1)});
        }}/>
    </div>
    <div className="explorer-context-help">
      {tab==='components'?'Component의 Bindings 탭에서 Service와 P/C 역할을 추가하세요. Connection을 누르면 DDS Reader/Writer 흐름이 열립니다.':
       tab==='services'?'공식 서비스는 읽기 전용입니다. Service는 Operation → DDS Action → Topic → Type을 정의합니다.':
       tab==='types'?'공식 IDL은 참조용, Custom Type은 필드와 Key/Optional을 편집할 수 있습니다.':
       tab==='topics'?'각 Topic은 메시지 IDL Type을 참조합니다. 동일 Type을 여러 Topic이 사용할 수 있습니다.':
       tab==='qos'?'QoS는 서비스 패턴이 아니라 Component별 Reader/Writer의 실행 설정입니다.':
       '현재는 DDS 미연결 C++ DLL/SO 생성 골격이며, 실제 실행은 DDS Runtime과 Host가 필요합니다.'}
    </div>
  </div>;
}
