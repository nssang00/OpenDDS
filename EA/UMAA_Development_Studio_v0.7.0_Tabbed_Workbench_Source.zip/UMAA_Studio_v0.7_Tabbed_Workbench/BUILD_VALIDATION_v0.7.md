# v0.7 Tabbed Workbench verification — 2026-11-04

## PASS
- `npm run check:static`: esbuild IIFE/file:// static layout requirements
- `npm run test:icd`: 14 Autopilot P/C, 56 operations, 32 topics, 32 derived endpoints
- `npm run test:design`: model/schema/codegen contracts
- `npm run test:workbench`: Command/Response and Request/Reply channel projection
- `npm run test:tabbed-ux`: six Explorer tabs and Contract→Binding→Endpoint navigation source assertions
- JS/JSX syntax parsing: 17 JSX source files, 0 parse errors (TypeScript parser used only for validation; source remains JS/JSX)
- Standalone offline HTML: HTML structure and embedded JS syntax parsed

## NOT VERIFIED
- React/Ant Design bundle build: `npm run build` fails with `ERR_MODULE_NOT_FOUND: esbuild`, because npm dependencies are not installed and registry has been inaccessible in this environment.
- Headless Chromium test: even `about:blank` does not exit in the current environment. Browser interaction with `preview/UMAA_Studio_v0.7_OfflinePreview.html` is unverified.
- Generated DLL/SO with real DDS messaging, QoS profile applied per DDS endpoint, and Component Host are not implemented. Do not interpret static codegen or schema tests as runtime compliance.

## Local run after npm dependencies are available
```
npm install
npm run test:icd
npm run test:design
npm run test:workbench
npm run test:tabbed-ux
npm run build
```
Then open `index.html` directly using `file://`, or open `preview/UMAA_Studio_v0.7_OfflinePreview.html` to inspect the independent tabbed UX preview without installing packages.
