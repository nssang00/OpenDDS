# UMAA Development Studio — Tabbed Explorer UX v0.7

## 결정 요약

좌측 Project Explorer를 **Services, Components, Types, Topics, QoS, Build 6개 명시적 탭**으로 분류한다. 프로젝트 이름은 탭 상단 공통 컨텍스트로 유지한다. 탭마다 독립적인 검색, 추가 액션, 객체 트리를 가진다. 중앙 편집기는 선택된 객체에 따라 자동으로 교체한다. 우측은 메타데이터/선택 객체 속성, 하단은 Validation / Output / Endpoint Matrix로 유지한다.

### 1. 6개 Explorer 탭의 책임

| 좌측 탭 | 탐색/관리할 객체 | 중앙 편집기 | 새 객체 생성 |
|---|---|---|---|
| Services | UMAA 8 Functional Areas, 공식 Services, Custom Areas/Services, Operations | Service Contract, DDS Pattern/Type Flow | Custom FA/Service |
| Components | System Assembly, Component, Provider/Consumer Service Binding, Connections | React Flow Assembly, Binding DDS Endpoint/Connection 상세 | Component, Service Binding, Connection |
| Types | 공식 IDL MessageType(외부 IDL 참조), Custom MessageType/DataType | IDL Type Designer / 참조 Topic | Custom Struct/Enum 및 필드 편집 |
| Topics | 표준/Custom DDS Topic | Topic → MessageType → 사용 Operation | Custom Topic은 Custom Service Contract에서 추가 |
| QoS | QoS Profiles, Component Runtime 정책 | Profile/Domain/Partition 설정 | QoS Profile |
| Build | Component Build Targets, Generated Artifact | Wrapper / DLL/SO 코드 생성 | 기존 codegen 파일 ZIP |

공식 UMAA 표준 정의는 읽기 전용. 사용자 정의는 `ProjectCustom` 등의 별도 네임스페이스로 분리하며 공식 적합성을 주장하지 않는다.

### 2. 역할과 데이터 계약의 구분

- **서비스 정의:** `FunctionalArea -> Service -> Operation -> DDS Action -> Topic -> MessageType -> DataType/Field`.
- **서비스 패턴:** Command/Response, Request/Reply는 UMAA ICD Flow Control 의미를 가진다. 주로 Service 계약의 하위 Operation과 DDS Action으로 표현한다. `query`는 Subscribe, `cancel`은 DDS Dispose일 수 있다. 모든 Operation에 새 Topic을 자동 생성하지 않는다.
- **컴포넌트 정의:** Component는 `ServiceBinding(serviceId, role=provider|consumer)`을 참조한다. Component에서 Flow Pattern을 다시 고르지 않는다.
- **연결:** 동일 Service의 Provider/Consumer Binding 간의 논리적 설계 연결. DDS 자체는 Topic 기반 다대다 통신으로, 연결선 자체가 네트워크 링크는 아니다.
- **파생 DDS Endpoint:** Publish Operation의 Actor가 자기 역할일 때 Writer, 반대이면 Reader. Query/Dispose는 기존 Topic의 Read/Dispose 동작이다. Endpoint의 실제 생성은 DDS SDK 및 Runtime 구현이 필요하다.
- **QoS:** 별도 Profile과 Component Runtime 설정으로 관리하며 Domain/Partition, QoS 호환성 검사 필요. 본 v0.7에서는 Endpoint별 Override 및 실제 벤더 적용이 아직 완성되지 않았다.

### 3. 대표 사용자 여정

1. **Services**: MO > GlobalVectorControl 열기. `DDS Pattern / Type Flow` 탭에서 Operation→Topic→IDL Type, Provider/Consumer의 Reader·Writer 관계 확인.
2. **Components**: Autopilot 선택 > Service Bindings > `Service Binding 추가`. GlobalVectorControl을 **Provider**로 선택. Mission Executor에는 같은 서비스를 **Consumer**로 추가.
3. **Components**: System Assembly React Flow에서 동일 Service의 두 Port 연결. `Service Connections`의 연결 선택.
4. **DDS Communication View**: Consumer Writer→Provider Reader Command, Provider Writer→Consumer Reader Status/Ack/ExecutionStatus를 채널별 확인.
5. **Topics**: 연결의 Topic 클릭 → `GlobalVectorCommandType`에 연결된 MessageType 확인.
6. **Types**: Type 클릭 → 공식 타입은 외부 IDL 참조 상태, 사용자 정의 Type은 Struct/Enum·Field·Key·Optional 편집.
7. **QoS**: Component Runtime Domain/Partition/QoS Profile 설정. 현재 호환성 검사의 범위를 확인.
8. **Build**: Component 선택 및 Codegen. 생성 DLL/SO는 **DDS 미연결 C++ 공유 라이브러리 골격**이며, 실제 DDS Runtime/Component Host는 아직 필요.

### 4. 추가 개선 과제 (중요)

- **공식 IDL Import**: 현재 Standard Type은 외부 참조만 보유하며 필드·타입 의존성이 완전하지 않음.
- **실제 벤더 DDS Runtime**: Reader/Writer 생성, QoS 정책 적용, GUID, Flow Control 상태 머신, Large Collection 수신 조립/동기화 필요.
- **Endpoint별 QoS Override**: 현재 Component 수준 공통 설정 위주. Topic/Endpoint 수준 적용 및 Offered/Requested 검증 필요.
- **Component Host**: DLL/SO 동적 로딩, ABI 버전, Configure/Start/Stop/Destroy, 장애 격리 및 프로세스 배치 필요.
- **패턴별 시각 검증**: 현재 Command/Response와 Report 동작의 파생 채널은 검사 가능하지만, 실제 DDS 메시지 교환 및 타이밍 검증은 미구현.

## 테스트 범위

- Node 정적 테스트, ICD 14-Service 테스트, Design Model 테스트, Workbench Model 테스트 수행.
- JSX 소스 구문은 TypeScript JS/JSX 파서로 검사.
- 별도 Offline Preview HTML은 HTML/JS 정적 구문 수준까지 검증. Chromium 환경에서 headless 실행 실패, 사용자 브라우저 직접 검증 필요.
- React/Ant Design/React Flow 실제 번들 빌드: npm 의존성 확보가 되지 않아 미검증.

## 우선순위

P0: 좌측 6개 탭 노출, Entity 클릭 시 중앙 Editor, Component Service Binding 추가 및 파생 DDS Endpoint 표시.
P1: 표준 IDL Import와 Custom Types 고급 문법, Endpoint 정책 검증.
P2: 실제 DDS SDK, Command State Machine, Component Host 및 DLL/SO 통합 테스트.
