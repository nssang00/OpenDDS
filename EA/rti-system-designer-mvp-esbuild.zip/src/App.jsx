import { useAuthStore } from './stores/useAuthStore.js';
import LoginPage from './pages/LoginPage.jsx';
import ProjectListPage from './pages/ProjectListPage.jsx';
import DesignerPage from './pages/DesignerPage.jsx';
import UserManagementPage from './pages/UserManagementPage.jsx';

export default function App() {
  const user = useAuthStore((state) => state.user);
  const currentPage = useAuthStore((state) => state.currentPage);

  if (!user) {
    return <LoginPage />;
  }

  if (currentPage === 'users') {
    return <UserManagementPage />;
  }

  if (currentPage === 'designer') {
    return <DesignerPage />;
  }

  return <ProjectListPage />;
}
