import MainLayout from '../layouts/MainLayout.jsx';
import ModelDiagram from '../components/ModelDiagram.jsx';

export default function DesignerPage() {
  return (
    <MainLayout>
      <ModelDiagram />
    </MainLayout>
  );
}
