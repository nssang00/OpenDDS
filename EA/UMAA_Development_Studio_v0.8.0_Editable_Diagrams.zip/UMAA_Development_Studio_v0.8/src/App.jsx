import { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Badge, Button, ConfigProvider, Divider, Flex, Form, Input, Layout, Modal, Select, Space, Spin, Table, Tabs, Tag, Tooltip, Typography, message } from 'antd';
import { ApiOutlined, ApartmentOutlined, AppstoreOutlined, CloudDownloadOutlined, DatabaseOutlined, DownloadOutlined, FileAddOutlined, PlusOutlined, ReloadOutlined, SaveOutlined, SafetyCertificateOutlined, ShareAltOutlined, UploadOutlined, FolderAddOutlined, ControlOutlined } from '@ant-design/icons';
import { WorkspaceWorkbench } from './components/WorkspaceWorkbench.jsx';
import { GenerationPanel } from './components/GenerationPanel.jsx';
import { ContextProperties } from './components/ContextProperties.jsx';
import { ProjectExplorer } from './components/ProjectExplorer.jsx';
import { FlowSimulationPanel } from './components/FlowSimulationPanel.jsx';
import { ContractMatrix } from './components/ContractMatrix.jsx';
import { AutopilotContract } from './components/AutopilotContract.jsx';
import { deriveEndpoints } from './logic/endpoints.js';
import { validateWorkspace } from './logic/validation.js';
import { useEditorStore } from './stores/useEditorStore.js';
import { canPersistLocally } from './repository/mockRepository.js';
import './styles.css';
const { Header, Sider, Content } = Layout;
const { Text, Title } = Typography;
function BottomPanel() {
    const snapshot = useEditorStore(s => s.snapshot);
    const select = useEditorStore(s => s.select);
    const issues = useMemo(() => snapshot ? validateWorkspace(snapshot) : [], [snapshot]);
    const endpoints = useMemo(() => snapshot?.components.flatMap(c => deriveEndpoints(snapshot, c.id).map(e => ({ ...e, componentName: c.name, id: `${e.bindingId}:${e.topicName}:${e.direction}` }))) ?? [], [snapshot]);
    return <div className="bottom-panel"><Tabs defaultActiveKey="autopilot" size="small" items={[
            { key: 'validation', label: <span><SafetyCertificateOutlined /> Validation <Badge size="small" count={issues.length} style={{ backgroundColor: issues.some(i => i.severity === 'error') ? '#cf5656' : '#738ca3' }}/></span>, children: issues.length === 0 ? <Alert type="success" showIcon message="Mock 모델 구조 검사를 통과했습니다. (UMAA Compliance 인증이 아닙니다)"/> :
                    <div className="issue-list">{issues.map((i, index) => <div key={`${i.code}-${index}`} className="issue-row">
        <Tag color={i.severity === 'error' ? 'red' : 'gold'}>{i.severity.toUpperCase()}</Tag>
        <Text>{i.message}</Text>
        {i.entityId && <Button size="small" type="link" onClick={() => {
                                    if (!snapshot)
                                        return;
                                    const kind = snapshot.bindings.some(b => b.id === i.entityId) ? 'binding'
                                        : snapshot.connections.some(c => c.id === i.entityId) ? 'connection'
                                            : snapshot.services.some(s => s.id === i.entityId) ? 'service'
                                                : snapshot.messages.some(m => m.id === i.entityId) ? 'message' : null;
                                    if (kind)
                                        select({ kind, id: i.entityId });
                                }}>이동</Button>}
      </div>)}</div> },
            { key: 'autopilot', label: <span><ApartmentOutlined /> Autopilot (14 Services)</span>, children: <AutopilotContract /> },
    { key: 'contract', label: <span><ApiOutlined /> ICD → Operation → Topic / IDL</span>, children: <ContractMatrix /> },
            { key: 'simulation', label: <span><ShareAltOutlined /> Mock Flow Simulation</span>, children: <FlowSimulationPanel /> },
            { key: 'matrix', label: <span><DatabaseOutlined /> DDS Endpoint Matrix <Tag>{endpoints.length}</Tag></span>, children: <Table size="small" pagination={{ pageSize: 4 }} rowKey="id" scroll={{ x: 700 }} dataSource={endpoints} columns={[
                        { title: 'Component', dataIndex: 'componentName', width: 160 },
                        { title: 'Service', dataIndex: 'serviceName', width: 185 },
                        { title: 'Role', dataIndex: 'role', width: 100 },
                        { title: 'Endpoint', dataIndex: 'direction', width: 95, render: (x) => <Tag color={x === 'writer' ? 'blue' : 'orange'}>{x}</Tag> },
                        { title: 'Topic / Message Type', dataIndex: 'topicName', width: 220 },
                    ]}/> },
        ]}/></div>;
}
function AddCustomServiceModal({ open, onClose }) {
    const [form] = Form.useForm();
    const createService = useEditorStore(s => s.addCustomService);
    const snapshot = useEditorStore(s => s.snapshot);
    return <Modal title="Custom Service 생성" open={open} okText="생성" onCancel={onClose} destroyOnClose onOk={async () => {
            try {
                const v = await form.validateFields();
                if (createService(v.name, v.flow, v.area)) {
                    message.success('Custom Service 및 메시지 정의를 생성했습니다.');
                    form.resetFields();
                    onClose();
                }
                else
                    message.error('서비스명 중복 또는 식별자 형식 오류');
            }
            catch { /* validation */ }
        }}>
    <Alert type="info" showIcon message="Custom Service는 UMAA 표준 Service가 아닙니다." description="생성되는 IDL은 프로젝트 정의이며, 규격 준수는 별도 검토해야 합니다." style={{ marginBottom: 16 }}/>
    <Form layout="vertical" form={form} initialValues={{ flow: 'request-reply', area: 'CUSTOM' }}>
      <Form.Item name="name" label="Service Name" rules={[{ required: true }, { pattern: /^[A-Za-z][A-Za-z0-9_]*$/, message: '영문자로 시작하는 이름을 사용하세요' }]}><Input placeholder="CustomSensorStatus"/></Form.Item>
      <Form.Item name="area" label="Functional Area 분류" rules={[{required:true}]}><Select options={[{value:'CUSTOM',label:'Project Extensions (독립)'},...(snapshot?.functionalAreas??[]).filter(a=>a.id!=='CUSTOM').map(a=>({value:a.id,label:`${a.id} — ${a.name} ${a.source==='custom'?'(Custom)':'(UMAA 분류 참조)'}`}))]}/></Form.Item>
      <Form.Item name="flow" label="Service Interaction Template"><Select options={[{ label: 'Request / Reply (구독 기반 조회 템플릿)', value: 'request-reply' }, { label: 'Command / Response (명령/상태 템플릿)', value: 'command-response' }]}/></Form.Item>
    </Form>
  </Modal>;
}
export default function App() {
    const snapshot = useEditorStore(s => s.snapshot);
    const loading = useEditorStore(s => s.loading);
    const saving = useEditorStore(s => s.saving);
    const dirty = useEditorStore(s => s.dirty);
    const load = useEditorStore(s => s.load);
    const save = useEditorStore(s => s.save);
    const reset = useEditorStore(s => s.reset);
    const importSnapshot = useEditorStore(s => s.importSnapshot);
    const jsonInputRef = useRef(null);
    const [canUseLocalStorage] = useState(() => canPersistLocally());
    const addComponent = useEditorStore(s => s.addComponent);
    const autoLayout = useEditorStore(s => s.autoLayout);
    const changeVendor = useEditorStore(s => s.changeVendor);
    const changePlatform = useEditorStore(s => s.changePlatform);
    const [componentModal, setComponentModal] = useState(false);
    const [serviceModal, setServiceModal] = useState(false);
    const [generationOpen, setGenerationOpen] = useState(false);
    const [createKind, setCreateKind] = useState(null);
    const [createForm] = Form.useForm();
    const addFunctionalArea = useEditorStore(s => s.addFunctionalArea);
    const addDataType = useEditorStore(s => s.addDataType);
    const addQosProfile = useEditorStore(s => s.addQosProfile);
    const [componentForm] = Form.useForm();
    const issues = useMemo(() => snapshot ? validateWorkspace(snapshot) : [], [snapshot]);
    useEffect(() => { void load(); }, [load]);
    const exportJson = () => {
        if (!snapshot)
            return;
        const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${snapshot.project.id}-workspace.json`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.setTimeout(() => URL.revokeObjectURL(url), 2000);
        message.success('프로젝트 JSON을 내보냈습니다.');
    };
    const importJson = async (file) => {
        if (!file)
            return;
        try {
            if (file.size > 8 * 1024 * 1024)
                throw new Error('8MB 이하의 프로젝트 JSON만 가져올 수 있습니다.');
            const json = JSON.parse(await file.text());
            importSnapshot(json);
            await useEditorStore.getState().save();
            message.success('프로젝트 JSON을 가져왔습니다.');
        }
        catch (error) {
            message.error(error instanceof Error ? error.message : '프로젝트를 가져올 수 없습니다.');
        }
        finally {
            if (jsonInputRef.current)
                jsonInputRef.current.value = '';
        }
    };
    return <ConfigProvider theme={{ token: { colorPrimary: '#3267ad', borderRadius: 8, colorBgLayout: '#f3f6fa', fontSize: 13 } }}>
    <Layout className="app-shell">
      <input ref={jsonInputRef} type="file" accept=".json,application/json" aria-label="프로젝트 JSON 가져오기" style={{ display: 'none' }} onChange={e => { void importJson(e.target.files?.[0]); }}/>
      <Header className="app-header">
        <Flex justify="space-between" align="center" gap={14} style={{ height: '100%' }}>
          <Space size={12} align="center"><div className="app-logo"><ShareAltOutlined /></div><div><div className="app-title">UMAA Development Studio</div><div className="app-subtitle">UMAA ICD 6.0 · Catalog → Contracts / IDL → Assembly → DDS Flow → Build</div></div></Space>
          <Space size={8} wrap>
            <Tag color="processing">{snapshot?.project.standardVersion ?? 'UMAA 6.0'}</Tag>{snapshot && <Tag>{snapshot.functionalAreas.length} FA / {snapshot.services.length} Services / {snapshot.components.length} Components</Tag>}
            {dirty ? <Tag color="gold">Unsaved</Tag> : <Tag color="green">Saved</Tag>}
            <Tooltip title="프로젝트 JSON 내보내기 — 파일로 영구 백업"><Button size="small" icon={<DownloadOutlined />} disabled={!snapshot} onClick={exportJson}>JSON 내보내기</Button></Tooltip>
            <Tooltip title="저장한 프로젝트 JSON 가져오기"><Button size="small" icon={<UploadOutlined />} onClick={() => jsonInputRef.current?.click()}>JSON 가져오기</Button></Tooltip>
            <Tooltip title="로컬 저장소의 Mock 상태를 초기화합니다"><Button size="small" icon={<ReloadOutlined />} disabled={!snapshot} onClick={() => Modal.confirm({ title: 'ICD 예제 데이터 다시 적용', content: '저장된 변경 사항을 삭제하고 확장된 UMAA ICD Mock 예제를 적용합니다. 계속할까요?', okText: '초기화', cancelText: '취소', onOk: async () => { await reset(); message.success('초기화했습니다.'); } })}>ICD 예제 초기화</Button></Tooltip>
            <Button size="small" icon={<SaveOutlined />} loading={saving} disabled={!snapshot} onClick={async () => { await save(); message.success('브라우저 Mock 저장소에 저장했습니다.'); }}>저장</Button>
            <Button type="primary" size="small" icon={<CloudDownloadOutlined />} disabled={!snapshot} onClick={() => setGenerationOpen(true)}>코드 생성</Button>
          </Space>
        </Flex>
      </Header>
      {!snapshot || loading ? <Content className="loading-content"><Spin size="large" tip="Mock 프로젝트 로딩 중"><div style={{ width: 300, height: 160 }}/></Spin></Content> : <Layout className="main-layout">
        <Sider width={324} theme="light" className="side-pane left-pane">
          <div className="pane-toolbar"><Text strong>Explorer</Text><Space>
            <Tooltip title="Custom Functional Area"><Button size="small" icon={<FolderAddOutlined />} onClick={()=>setCreateKind('area')}/></Tooltip>
            <Tooltip title="Custom Type"><Button size="small" icon={<DatabaseOutlined />} onClick={()=>setCreateKind('type')}/></Tooltip>
            <Tooltip title="QoS Profile"><Button size="small" icon={<ControlOutlined />} onClick={()=>setCreateKind('qos')}/></Tooltip>
            <Tooltip title="Custom Service"><Button size="small" icon={<FileAddOutlined />} onClick={()=>setServiceModal(true)}/></Tooltip>
          </Space></div>
          <ProjectExplorer onCreate={kind=>kind==='component'?setComponentModal(true):kind==='service'?setServiceModal(true):setCreateKind(kind)}/>
          <div className="side-footer"><Text type="secondary">My Project는 편집 가능 · UMAA Library는 읽기 전용</Text><br/>
            <Text type="secondary">Service 드래그 → Component · 연결선 클릭 → DDS 흐름</Text><br/>
            <Text type="secondary" style={{fontSize:11}}>{canUseLocalStorage?'저장: localStorage / JSON Export':'localStorage 제한 · JSON Export 권장'}</Text></div>
        </Sider>
        <Content className="workspace-pane">
          <div className="workspace-editor-body">
            <WorkspaceWorkbench onNewComponent={()=>setComponentModal(true)} onNewService={()=>setServiceModal(true)} onGenerate={()=>setGenerationOpen(true)}/>
          </div>
          <div className="workspace-bottom"><BottomPanel/></div>
        </Content>
        <Sider width={330} theme="light" className="side-pane right-pane">
          <ContextProperties />
          <Divider style={{margin:'10px 0'}}/>
          <div className="project-settings"><Text strong>Target / DDS Runtime</Text>
            <div style={{marginTop:10}}><Text type="secondary">Target Platform</Text><Select style={{width:'100%',marginTop:4}} value={snapshot.project.targetPlatform} onChange={changePlatform} options={[{label:'Linux (.so)',value:'linux'},{label:'Windows (.dll)',value:'windows'}]}/></div>
            <div style={{marginTop:10}}><Text type="secondary">DDS Vendor (설계 메타데이터)</Text><Select style={{width:'100%',marginTop:4}} value={snapshot.project.ddsVendor} onChange={changeVendor} options={[{label:'eProsima Fast DDS',value:'fastdds'},{label:'RTI Connext DDS',value:'connext'}]}/></div>
            <div style={{marginTop:14}}><Badge status={issues.some(i=>i.severity==='error')?'error':issues.length?'warning':'success'} text={<Text type="secondary">정적 검사 {issues.filter(i=>i.severity==='error').length} errors / {issues.filter(i=>i.severity==='warning').length} warnings</Text>}/></div>
          </div>
        </Sider>
      </Layout>}
    </Layout>
    <Modal title="Component 추가" open={componentModal} okText="추가" destroyOnClose onCancel={() => setComponentModal(false)} onOk={async () => {
            try {
                const v = await componentForm.validateFields();
                addComponent(v.name);
                setComponentModal(false);
                componentForm.resetFields();
                message.success('Component를 추가했습니다.');
            }
            catch { /* validation */ }
        }}><Form form={componentForm} layout="vertical"><Form.Item name="name" label="Component Name" rules={[{ required: true, message: '이름을 입력하세요' }]}><Input placeholder="Sensor Fusion"/></Form.Item></Form></Modal>
    <AddCustomServiceModal open={serviceModal} onClose={() => setServiceModal(false)}/>
    <GenerationPanel open={generationOpen} onClose={() => setGenerationOpen(false)}/>
    <Modal title={createKind==='area'?'사용자 정의 Functional Area':createKind==='type'?'사용자 정의 IDL Data Type':'DDS QoS Profile 추가'}
      open={!!createKind} onCancel={()=>{setCreateKind(null);createForm.resetFields();}} okText="추가" destroyOnClose onOk={async()=>{
        try{
          const v=await createForm.validateFields();
          const ok=createKind==='area'?addFunctionalArea(v.code,v.name):createKind==='type'?addDataType(v.name,v.typeKind):addQosProfile(v.name);
          if(!ok){message.error('중복된 이름 또는 잘못된 값입니다.');return;}
          createForm.resetFields();setCreateKind(null);message.success('Project Extension에 추가했습니다.');
        }catch{}
      }}>
      <Alert type="info" showIcon style={{marginBottom:12}} message="공식 UMAA Catalog는 변경하지 않습니다." description="사용자가 만든 영역·타입·QoS Profile은 프로젝트 확장 항목이며, 표준 UMAA 명세로 표시하지 않습니다."/>
      <Form form={createForm} layout="vertical" key={createKind} initialValues={{typeKind:'struct'}}>
        {createKind==='area'&&<Form.Item label="영역 코드" name="code" rules={[{required:true},{pattern:/^[A-Za-z][A-Za-z0-9_]{1,11}$/}]}><Input placeholder="SF"/></Form.Item>}
        <Form.Item label={createKind==='area'?'영역 이름':createKind==='type'?'IDL Type 이름':'QoS Profile 이름'} name="name" rules={[{required:true}]}><Input placeholder={createKind==='area'?'Sensor Fusion':createKind==='type'?'FusionMeasurementType':'LowLatencyReliable'}/></Form.Item>
        {createKind==='type'&&<Form.Item label="Type Kind" name="typeKind"><Select options={[{label:'Struct',value:'struct'},{label:'Enum',value:'enum'}]}/></Form.Item>}
      </Form>
    </Modal>
  </ConfigProvider>;
}
