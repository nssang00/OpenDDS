# React UI Structure Refactor Notes

이번 리팩터링은 `Pane` 폴더를 별도로 만들지 않고, WPF 개발자도 파일명만 보고 수정 위치를 찾기 쉽게 `Layout / Panel / View / Component` 기준으로 정리했습니다.

## 적용된 구조

```txt
src/
  layouts/
    MainLayout.jsx          # 전체 Shell
    WorkspaceLayout.jsx     # 좌/중앙/우 Splitter 배치

  components/
    AppHeader.jsx           # 상단 Header / 프로젝트 선택 / 사용자 메뉴
    MemberTable.jsx
    ModelDiagram.jsx
    ModelTree.jsx
    PropertyForm.jsx
    TextEditor.jsx

  panels/
    ExplorerPanel.jsx       # 좌측 영역 Tabs
    WorkspacePanel.jsx      # 중앙 영역 Tabs
    InspectorPanel.jsx      # 우측 영역 Tabs

  views/
    explorer/
      ModelView.jsx
      SearchView.jsx

    workspace/
      DiagramView.jsx
      IdlView.jsx
      QosXmlView.jsx
      ValidationView.jsx

    inspector/
      PropertiesView.jsx
      MembersView.jsx
      QosView.jsx
```

## 책임 기준

- `layouts/`: 화면 배치, Splitter 크기, Shell 구조
- `panels/`: 영역별 Tabs 구성과 기능 묶음
- `views/`: 탭 안의 실제 화면 내용
- `components/`: 여러 곳에서 재사용 가능한 작은 UI 조각
- `stores/`: WPF의 ViewModel에 가까운 상태 관리

## 주요 변경

1. `MainLayout.jsx`에서 Header 로직을 제거하고 `components/AppHeader.jsx`로 분리했습니다.
2. `WorkspaceLayout.jsx`가 직접 `ExplorerPanel`, `WorkspacePanel`, `InspectorPanel`을 배치하도록 단순화했습니다.
3. 기존 `src/views/*.jsx` 파일을 영역 기준 하위 폴더로 이동했습니다.
4. 이동된 View들의 import 경로를 모두 수정했습니다.
5. `styles.css`의 layout class를 `workspace-layout__explorer`, `workspace-layout__main`, `workspace-layout__inspector` 기준으로 정리했습니다.

## 검증

`npm ci` 후 `npm run build`로 빌드 성공을 확인했습니다.
