import { Tabs } from 'antd';
import ModelView from '../views/explorer/ModelView.jsx';
import SearchView from '../views/explorer/SearchView.jsx';

export default function ExplorerPanel() {
  const items = [
    { key: 'model', label: 'Model', children: <ModelView /> },
    { key: 'search', label: 'Search', children: <SearchView /> },
  ];

  return (
    <section className="panel explorer-panel">
      <Tabs className="panel-tabs" defaultActiveKey="model" items={items} />
    </section>
  );
}
