import { Tabs } from 'antd';
import DiagramView from '../views/workspace/DiagramView.jsx';
import IdlView from '../views/workspace/IdlView.jsx';
import QosXmlView from '../views/workspace/QosXmlView.jsx';
import ValidationView from '../views/workspace/ValidationView.jsx';

export default function WorkspacePanel() {
  const items = [
    { key: 'diagram', label: 'Diagram', children: <DiagramView /> },
    { key: 'idl', label: 'IDL', children: <IdlView /> },
    { key: 'qosXml', label: 'QoS XML', children: <QosXmlView /> },
    { key: 'validation', label: 'Validation', children: <ValidationView /> },
  ];

  return (
    <section className="panel workspace-panel">
      <Tabs className="workspace-tabs" defaultActiveKey="diagram" items={items} />
    </section>
  );
}
