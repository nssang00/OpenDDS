import { Tabs } from 'antd';
import MembersView from '../views/inspector/MembersView.jsx';
import PropertiesView from '../views/inspector/PropertiesView.jsx';
import QosView from '../views/inspector/QosView.jsx';

export default function InspectorPanel() {
  const items = [
    { key: 'properties', label: 'Properties', children: <PropertiesView /> },
    { key: 'members', label: 'Members', children: <MembersView /> },
    { key: 'qos', label: 'QoS', children: <QosView /> },
  ];

  return (
    <section className="panel inspector-panel">
      <Tabs className="panel-tabs" defaultActiveKey="properties" items={items} />
    </section>
  );
}
