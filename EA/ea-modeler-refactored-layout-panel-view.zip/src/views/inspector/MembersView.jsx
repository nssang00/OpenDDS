import { Empty } from 'antd';
import MemberTable from '../../components/MemberTable.jsx';
import { useDesignerStore } from '../../stores/useDesignerStore.js';

export default function MembersView() {
  const model = useDesignerStore((state) => state.model);
  const selectedElementId = useDesignerStore((state) => state.selectedElementId);
  const element = selectedElementId ? model.elementsById[selectedElementId] : null;
  const members = element?.properties?.members;

  if (!element) {
    return <div className="empty-state">Select an element.</div>;
  }

  if (!Array.isArray(members)) {
    return (
      <div className="panel-body">
        <Empty description="Selected element has no members." />
      </div>
    );
  }

  return (
    <div className="panel-body">
      <MemberTable elementId={element.id} members={members} />
    </div>
  );
}
