import { Empty, Typography } from 'antd';
import TextEditor from '../../components/TextEditor.jsx';
import { useDesignerStore } from '../../stores/useDesignerStore.js';

const { Text } = Typography;

export default function QosView() {
  const model = useDesignerStore((state) => state.model);
  const selectedElementId = useDesignerStore((state) => state.selectedElementId);
  const updateProperty = useDesignerStore((state) => state.updateProperty);
  const element = selectedElementId ? model.elementsById[selectedElementId] : null;
  const qosXml = element?.properties?.qosXml;

  if (!element) {
    return <div className="empty-state">Select an element.</div>;
  }

  if (typeof qosXml !== 'string') {
    return (
      <div className="panel-body">
        <Empty description="Selected element has no QoS XML." />
      </div>
    );
  }

  return (
    <div className="panel-body">
      <Text type="secondary">QoS XML for {element.name}</Text>
      <div style={{ marginTop: 12 }}>
        <TextEditor value={qosXml} onChange={(nextValue) => updateProperty(element.id, 'qosXml', nextValue)} />
      </div>
    </div>
  );
}
