import ModelTree from '../../components/ModelTree.jsx';

export default function ModelView() {
  return (
    <div className="panel-body">
      <ModelTree />
    </div>
  );
}
