import { Empty } from 'antd';

export default function SearchView() {
  return (
    <div className="panel-body">
      <Empty description="Model search will be added here." />
    </div>
  );
}
