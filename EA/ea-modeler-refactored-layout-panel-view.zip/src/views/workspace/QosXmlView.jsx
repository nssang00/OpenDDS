import { Empty } from 'antd';
import TextEditor from '../../components/TextEditor.jsx';
import { useDesignerStore } from '../../stores/useDesignerStore.js';

export default function QosXmlView() {
  const model = useDesignerStore((state) => state.model);
  const qosProfiles = Object.values(model.elementsById).filter((element) => typeof element.properties?.qosXml === 'string');

  if (qosProfiles.length === 0) {
    return (
      <div className="tab-panel">
        <Empty description="No QoS XML profiles in this model." />
      </div>
    );
  }

  return (
    <div className="tab-panel">
      <TextEditor
        value={qosProfiles.map((profile) => `<!-- ${profile.name} -->\n${profile.properties.qosXml}`).join('\n\n')}
        onChange={() => {}}
      />
    </div>
  );
}
