import { Card, Descriptions } from 'antd';
import { useDesignerStore } from '../../stores/useDesignerStore.js';
import { generateModelSummary } from '../../utils/documentGenerator.js';

export default function ValidationView() {
  const model = useDesignerStore((state) => state.model);
  const summary = generateModelSummary(model);

  return (
    <div className="tab-panel">
      <Card title="Model Summary" size="small">
        <Descriptions bordered size="small" column={1}>
          <Descriptions.Item label="Topics">{summary.topics}</Descriptions.Item>
          <Descriptions.Item label="Struct Types">{summary.structs}</Descriptions.Item>
          <Descriptions.Item label="QoS Profiles">{summary.qosProfiles}</Descriptions.Item>
        </Descriptions>
      </Card>
    </div>
  );
}
