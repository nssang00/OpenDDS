import { create } from 'zustand';
import { mockProjects } from '../api/mockData.js';

export const useProjectStore = create((set, get) => ({
  projects: mockProjects,
  currentProject: null,

  selectProject: (projectId) => {
    const project = get().projects.find((item) => item.id === projectId) || null;
    set({ currentProject: project });
  },
}));
