import { create } from 'zustand';
import { getMockModel } from '../api/mockData.js';

const defaultModel = getMockModel('project-vehicle');

export const useDesignerStore = create((set, get) => ({
  model: defaultModel,
  selectedElementId: 'topic-vehicle-status',
  dirty: false,

  loadProjectModel: (projectId) => {
    const model = getMockModel(projectId);
    const firstElementId = Object.keys(model.elementsById)[0];
    set({ model, selectedElementId: firstElementId, dirty: false });
  },

  selectElement: (id) => set({ selectedElementId: id }),

  updateElement: (id, patch) => {
    const current = get().model.elementsById[id];
    if (!current) return;

    set({
      model: {
        ...get().model,
        elementsById: {
          ...get().model.elementsById,
          [id]: { ...current, ...patch },
        },
      },
      dirty: true,
    });
  },

  updateProperty: (id, key, value) => {
    const current = get().model.elementsById[id];
    if (!current) return;

    set({
      model: {
        ...get().model,
        elementsById: {
          ...get().model.elementsById,
          [id]: {
            ...current,
            properties: {
              ...current.properties,
              [key]: value,
            },
          },
        },
      },
      dirty: true,
    });
  },

  updateMembers: (id, members) => {
    const current = get().model.elementsById[id];
    if (!current) return;

    set({
      model: {
        ...get().model,
        elementsById: {
          ...get().model.elementsById,
          [id]: {
            ...current,
            properties: {
              ...current.properties,
              members,
            },
          },
        },
      },
      dirty: true,
    });
  },
}));
