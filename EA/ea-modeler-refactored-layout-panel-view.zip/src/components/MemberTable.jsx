import { Button, Input, Popconfirm, Space, Table } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { useDesignerStore } from '../stores/useDesignerStore.js';

export default function MemberTable({ elementId, members }) {
  const updateMembers = useDesignerStore((state) => state.updateMembers);

  const patchMember = (memberId, patch) => {
    updateMembers(
      elementId,
      members.map((member) => (member.id === memberId ? { ...member, ...patch } : member))
    );
  };

  const addMember = () => {
    const nextIndex = members.length + 1;
    updateMembers(elementId, [
      ...members,
      { id: `m-${Date.now()}`, name: `member${nextIndex}`, type: 'string', defaultValue: '' },
    ]);
  };

  const removeMember = (memberId) => {
    updateMembers(
      elementId,
      members.filter((member) => member.id !== memberId)
    );
  };

  const columns = [
    {
      title: 'name',
      dataIndex: 'name',
      render: (_, record) => <Input value={record.name} onChange={(event) => patchMember(record.id, { name: event.target.value })} />,
    },
    {
      title: 'type',
      dataIndex: 'type',
      render: (_, record) => <Input value={record.type} onChange={(event) => patchMember(record.id, { type: event.target.value })} />,
    },
    {
      title: 'default',
      dataIndex: 'defaultValue',
      render: (_, record) => <Input value={record.defaultValue} onChange={(event) => patchMember(record.id, { defaultValue: event.target.value })} />,
    },
    {
      title: '',
      width: 80,
      render: (_, record) => (
        <Popconfirm title="Remove member?" onConfirm={() => removeMember(record.id)}>
          <Button size="small" danger>Delete</Button>
        </Popconfirm>
      ),
    },
  ];

  return (
    <Space direction="vertical" style={{ width: '100%' }}>
      <Button icon={<PlusOutlined />} onClick={addMember} block>Add member</Button>
      <Table size="small" rowKey="id" columns={columns} dataSource={members} pagination={false} />
    </Space>
  );
}
