import { Tree } from 'antd';
import { ApartmentOutlined, DatabaseOutlined, NodeIndexOutlined, SettingOutlined } from '@ant-design/icons';
import { useDesignerStore } from '../stores/useDesignerStore.js';

function iconForType(type) {
  if (type === 'Package') return <ApartmentOutlined />;
  if (type === 'Struct') return <DatabaseOutlined />;
  if (type === 'QosProfile') return <SettingOutlined />;
  return <NodeIndexOutlined />;
}

function buildTree(elementsById) {
  const elements = Object.values(elementsById);

  return elements
    .filter((element) => element.parentId === null)
    .map((root) => ({
      key: root.id,
      title: root.name,
      icon: iconForType(root.type),
      children: elements
        .filter((element) => element.parentId === root.id)
        .map((child) => ({
          key: child.id,
          title: child.name,
          icon: iconForType(child.type),
        })),
    }));
}

export default function ModelTree() {
  const model = useDesignerStore((state) => state.model);
  const selectedElementId = useDesignerStore((state) => state.selectedElementId);
  const selectElement = useDesignerStore((state) => state.selectElement);

  return (
    <Tree.DirectoryTree
      showIcon
      defaultExpandAll
      selectedKeys={selectedElementId ? [selectedElementId] : []}
      treeData={buildTree(model.elementsById)}
      onSelect={(keys) => {
        if (keys[0]) selectElement(keys[0]);
      }}
    />
  );
}
