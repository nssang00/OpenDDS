import { useMemo } from 'react';
import { ReactFlow, Background, Controls, MiniMap } from '@xyflow/react';
import { useDesignerStore } from '../stores/useDesignerStore.js';

function ModelNode({ data, selected }) {
  return (
    <div className={`model-node ${selected ? 'selected-node' : ''}`}>
      <strong>{data.label}</strong>
      <div className="model-node-type">{data.type}</div>
    </div>
  );
}

const nodeTypes = {
  modelNode: ModelNode,
};

export default function ModelDiagram() {
  const model = useDesignerStore((state) => state.model);
  const selectedElementId = useDesignerStore((state) => state.selectedElementId);
  const selectElement = useDesignerStore((state) => state.selectElement);

  const nodes = useMemo(() => {
    return model.diagram.nodes.map((node) => {
      const element = model.elementsById[node.id];
      return {
        id: node.id,
        type: 'modelNode',
        position: node.position,
        selected: node.id === selectedElementId,
        data: {
          label: element?.name ?? node.id,
          type: element?.type ?? 'Unknown',
        },
      };
    });
  }, [model, selectedElementId]);

  const edges = useMemo(() => {
    return model.diagram.edges.map((edge) => ({
      ...edge,
      animated: edge.source === selectedElementId || edge.target === selectedElementId,
    }));
  }, [model, selectedElementId]);

  return (
    <div className="diagram-wrapper">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        fitView
        onNodeClick={(_, node) => selectElement(node.id)}
      >
        <Background />
        <Controls />
        <MiniMap />
      </ReactFlow>
    </div>
  );
}
