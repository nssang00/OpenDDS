import { Splitter } from 'antd';
import ExplorerPanel from '../panels/ExplorerPanel.jsx';
import WorkspacePanel from '../panels/WorkspacePanel.jsx';
import InspectorPanel from '../panels/InspectorPanel.jsx';

export default function WorkspaceLayout() {
  return (
    <Splitter className="workspace-layout">
      <Splitter.Panel
        defaultSize={300}
        min={240}
        max={480}
        className="workspace-layout__explorer"
      >
        <ExplorerPanel />
      </Splitter.Panel>

      <Splitter.Panel
        min={520}
        className="workspace-layout__main"
      >
        <WorkspacePanel />
      </Splitter.Panel>

      <Splitter.Panel
        defaultSize={390}
        min={320}
        max={560}
        className="workspace-layout__inspector"
      >
        <InspectorPanel />
      </Splitter.Panel>
    </Splitter>
  );
}
