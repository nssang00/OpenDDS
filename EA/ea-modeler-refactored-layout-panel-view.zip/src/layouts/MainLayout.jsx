import { Layout } from 'antd';
import AppHeader from '../components/AppHeader.jsx';
import WorkspaceLayout from './WorkspaceLayout.jsx';

export default function MainLayout() {
  return (
    <Layout className="app-shell">
      <AppHeader />
      <WorkspaceLayout />
    </Layout>
  );
}
