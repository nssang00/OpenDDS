import MainLayout from '../layouts/MainLayout.jsx';

export default function WorkspacePage() {
  return <MainLayout />;
}
