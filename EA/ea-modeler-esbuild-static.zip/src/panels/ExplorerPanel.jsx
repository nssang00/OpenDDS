import { Tabs } from 'antd';
import ModelView from '../views/ModelView.jsx';
import SearchView from '../views/SearchView.jsx';

export default function ExplorerPanel() {
  return (
    <Tabs
      className="panel-tabs"
      items={[
        { key: 'model', label: 'Model', children: <ModelView /> },
        { key: 'search', label: 'Search', children: <SearchView /> },
      ]}
    />
  );
}
