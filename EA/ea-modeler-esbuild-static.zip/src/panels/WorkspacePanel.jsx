import { Tabs } from 'antd';
import DiagramView from '../views/DiagramView.jsx';
import IdlView from '../views/IdlView.jsx';
import QosXmlView from '../views/QosXmlView.jsx';
import ValidationView from '../views/ValidationView.jsx';

export default function WorkspacePanel() {
  return (
    <Tabs
      className="workspace-tabs"
      items={[
        { key: 'diagram', label: 'Diagram', children: <DiagramView /> },
        { key: 'idl', label: 'IDL', children: <IdlView /> },
        { key: 'qosXml', label: 'QoS XML', children: <QosXmlView /> },
        { key: 'validation', label: 'Validation', children: <ValidationView /> },
      ]}
    />
  );
}
