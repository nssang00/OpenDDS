import { Tabs } from 'antd';
import MembersView from '../views/MembersView.jsx';
import PropertiesView from '../views/PropertiesView.jsx';
import QosView from '../views/QosView.jsx';

export default function InspectorPanel() {
  return (
    <Tabs
      className="panel-tabs"
      items={[
        { key: 'properties', label: 'Properties', children: <PropertiesView /> },
        { key: 'members', label: 'Members', children: <MembersView /> },
        { key: 'qos', label: 'QoS', children: <QosView /> },
      ]}
    />
  );
}
