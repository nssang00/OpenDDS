import TextEditor from '../components/TextEditor.jsx';
import { useDesignerStore } from '../stores/useDesignerStore.js';
import { generateIdl } from '../utils/idlGenerator.js';

export default function IdlView() {
  const model = useDesignerStore((state) => state.model);

  return (
    <div className="tab-panel">
      <TextEditor value={generateIdl(model)} onChange={() => {}} />
    </div>
  );
}
