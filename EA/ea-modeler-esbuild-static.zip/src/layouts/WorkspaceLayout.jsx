import { Splitter } from 'antd';

export default function WorkspaceLayout({ explorer, workspace, inspector }) {
  return (
    <Splitter className="app-content">
      <Splitter.Panel defaultSize={300} min={240} max={480} className="explorer-panel">
        {explorer}
      </Splitter.Panel>

      <Splitter.Panel min={520} className="workspace-panel">
        {workspace}
      </Splitter.Panel>

      <Splitter.Panel defaultSize={390} min={320} max={560} className="inspector-panel">
        {inspector}
      </Splitter.Panel>
    </Splitter>
  );
}
