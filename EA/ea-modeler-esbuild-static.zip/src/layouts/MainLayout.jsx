import { Button, Layout, Select, Space, Tag, Typography } from 'antd';
import { ProjectOutlined, TeamOutlined } from '@ant-design/icons';
import ExplorerPanel from '../panels/ExplorerPanel.jsx';
import InspectorPanel from '../panels/InspectorPanel.jsx';
import WorkspacePanel from '../panels/WorkspacePanel.jsx';
import { useAuthStore } from '../stores/useAuthStore.js';
import { useProjectStore } from '../stores/useProjectStore.js';
import { useDesignerStore } from '../stores/useDesignerStore.js';
import WorkspaceLayout from './WorkspaceLayout.jsx';

const { Header } = Layout;
const { Text } = Typography;

export default function MainLayout() {
  const user = useAuthStore((state) => state.user);
  const setPage = useAuthStore((state) => state.setPage);
  const logout = useAuthStore((state) => state.logout);
  const projects = useProjectStore((state) => state.projects);
  const currentProject = useProjectStore((state) => state.currentProject);
  const selectProject = useProjectStore((state) => state.selectProject);
  const dirty = useDesignerStore((state) => state.dirty);
  const loadProjectModel = useDesignerStore((state) => state.loadProjectModel);

  const openProject = (projectId) => {
    selectProject(projectId);
    loadProjectModel(projectId);
    setPage('designer');
  };

  return (
    <Layout className="app-shell">
      <Header className="app-header">
        <div className="app-title">RTI System Designer MVP</div>
        <Tag color={dirty ? 'orange' : 'green'}>{dirty ? 'modified' : 'clean'}</Tag>
        <Select
          className="project-switcher"
          placeholder="Select project"
          value={currentProject?.id}
          options={projects.map((project) => ({ label: project.name, value: project.id }))}
          onChange={openProject}
        />
        <Space className="header-actions">
          <Button size="small" icon={<ProjectOutlined />} onClick={() => setPage('projects')}>
            Manage
          </Button>
          <Button size="small" icon={<TeamOutlined />} onClick={() => setPage('users')}>
            Users
          </Button>
          <Text className="header-user">{user?.name}</Text>
          <Button size="small" onClick={logout}>Logout</Button>
        </Space>
      </Header>

      <WorkspaceLayout
        explorer={<ExplorerPanel />}
        workspace={<WorkspacePanel />}
        inspector={<InspectorPanel />}
      />
    </Layout>
  );
}
