# EA Modeler JS - esbuild Static Build Version

기존 Vite 예제를 **esbuild 기반 정적 번들**로 바꾼 버전입니다.

## 포함된 기술

- React
- JavaScript, TypeScript 없음
- Ant Design v5
- Zustand 상태 관리
- React Flow diagram
- Mock model data
- esbuild 단일 entry 번들

## 핵심 차이

Vite 버전은 `index.html`에서 ESM을 로드합니다.

```html
<script type="module" src="/src/main.jsx"></script>
```

이 esbuild 버전은 webpack 스타일에 가깝게 일반 script로 빌드합니다.

```html
<script src="./app.js"></script>
```

빌드 결과는 다음처럼 단순합니다.

```text
dist/
 ├─ index.html
 ├─ app.js
 └─ app.css
```

`app.js`는 `format: 'iife'`로 생성되므로 `type="module"`이 필요 없습니다.

## 설치

```bash
npm install
```

## 개발 실행

```bash
npm run dev
```

브라우저에서 아래 주소를 엽니다.

```text
http://localhost:5173
```

esbuild의 watch/serve를 사용합니다. Vite처럼 React Fast Refresh는 없습니다.

## 정적 빌드

```bash
npm run build
```

빌드 후에는 아래 파일을 열면 됩니다.

```text
dist/index.html
```

정적 서버로 확인하려면:

```bash
npm run preview
```

또는:

```bash
cd dist
python -m http.server 8080
```

## esbuild 설정 핵심

```js
format: 'iife'
outfile: 'dist/app.js'
jsx: 'automatic'
bundle: true
```

CSS import는 esbuild가 자동으로 `dist/app.css`로 분리합니다.
Ant Design v5의 `antd/dist/reset.css`와 React Flow CSS도 함께 처리됩니다.

## 먼저 볼 파일

```text
esbuild.config.mjs                      esbuild 빌드/개발 서버 설정
src/main.jsx                            React entry
src/model/mockModel.js                  샘플 모델 데이터
src/store/modelStore.js                 Zustand 상태 저장소
src/app/AppShell.jsx                    전체 3분할 화면
src/features/explorer/ModelTree.jsx     Tree
src/features/diagram/ModelDiagram.jsx   React Flow diagram
src/features/properties/PropertyPanel.jsx 속성 패널
src/features/members/MemberTable.jsx    구조체 멤버 테이블
src/features/text-editor/TextEditor.jsx IDL/QoS TextArea
```

## 판단 기준

이 프로젝트처럼 `dist/index.html + app.js + app.css` 형태를 원하면 esbuild가 Vite보다 더 직접적입니다.
반대로 HMR, React Fast Refresh, 플러그인 생태계가 중요하면 Vite가 더 편합니다.
