import { useEffect, useMemo, useRef } from 'react';
import { Button, Empty, Segmented, Space, Tag, Typography, Upload, message } from 'antd';
import { CheckCircleOutlined, DownloadOutlined, FileWordOutlined, UploadOutlined } from '@ant-design/icons';
import { useModelStore } from '../stores/useModelStore.js';
import { useDocumentStore } from '../document/documentStore.js';
import { createDocumentData } from '../document/documentMapper.js';
import { loadDocxTemplate, validateTemplate } from '../document/docxTemplate.js';
import { downloadDocx, previewDocx, renderDocx } from '../document/docxRenderer.js';
import { clearDocxTagHighlight, scheduleDocxTagHighlight } from '../document/docxTagHighlight.js';

const { Text } = Typography;

export default function DocumentView() {
  const model = useModelStore((state) => state.model);
  const previewRef = useRef(null);

  const {
    templateBuffer,
    templateName,
    validationResult,
    generatedBlob,
    generatedBuffer,
    previewMode,
    setTemplate,
    setDetectedTags,
    setValidationResult,
    setGeneratedDocument,
    setPreviewMode,
  } = useDocumentStore();

  const documentData = useMemo(() => createDocumentData(model), [model]);
  const previewSource = previewMode === 'generated' ? generatedBuffer : templateBuffer;

  useEffect(() => {
    if (!previewSource || !previewRef.current) return;

    let cancelHighlight = () => {};
    let disposed = false;

    previewDocx(previewSource, previewRef.current)
      .then(() => {
        if (disposed || previewMode !== 'template') return;
        // Highlight only after docx-preview has finished. The CSS Highlight API
        // paints over text ranges without changing docx-preview's DOM or layout.
        cancelHighlight = scheduleDocxTagHighlight(previewRef.current);
      })
      .catch((error) => message.error(error.message));

    return () => {
      disposed = true;
      cancelHighlight();
      clearDocxTagHighlight();
    };
  }, [previewSource, previewMode]);

  const applyValidation = (buffer) => {
    const result = validateTemplate(buffer, documentData);
    setDetectedTags(result.detectedTags);
    setValidationResult(result);
    return result;
  };

  const handleOpen = async (file) => {
    try {
      const buffer = await loadDocxTemplate(file);
      setTemplate(file, buffer);
      setPreviewMode('template');
      message.success(`Template loaded: ${file.name}`);

      // Keep opening responsive: validate only when the browser is idle.
      const validateWhenIdle = () => {
        try {
          applyValidation(buffer);
        } catch (error) {
          message.error(error.message);
        }
      };
      if ('requestIdleCallback' in window) {
        window.requestIdleCallback(validateWhenIdle, { timeout: 1500 });
      } else {
        window.setTimeout(validateWhenIdle, 250);
      }
    } catch (error) {
      message.error(error.message);
    }
    return false;
  };

  const handleGenerate = async () => {
    if (!templateBuffer) return;
    const result = applyValidation(templateBuffer);
    if (!result.valid) {
      message.error('Fix template validation errors before generating');
      return;
    }

    try {
      const generated = await renderDocx(templateBuffer, documentData);
      setGeneratedDocument(generated.generatedBlob, generated.generatedBuffer);
      setPreviewMode('generated');
      message.success('Document generated');
    } catch (error) {
      message.error(error.message);
    }
  };

  return (
    <div className="document-view">
      <div className="document-toolbar">
        <Space wrap>
          <Upload accept=".docxtpl,.docx" beforeUpload={handleOpen} showUploadList={false}>
            <Button icon={<UploadOutlined />}>Open Template</Button>
          </Upload>
          <Button
            icon={<CheckCircleOutlined />}
            disabled={!templateBuffer || previewMode !== 'template'}
            onClick={() => applyValidation(templateBuffer)}
          >
            Validate
          </Button>
          <Button
            type="primary"
            icon={<FileWordOutlined />}
            disabled={!templateBuffer}
            onClick={handleGenerate}
          >
            Generate
          </Button>
          <Button
            icon={<DownloadOutlined />}
            disabled={!generatedBlob}
            onClick={() => downloadDocx(generatedBlob, generatedName(templateName))}
          >
            Download
          </Button>
        </Space>

        <Space size="small" wrap>
          {templateName && <Text type="secondary">{templateName}</Text>}
          {validationResult && previewMode === 'template' && (
            <Tag color={validationResult.valid ? (validationResult.warnings.length ? 'gold' : 'green') : 'red'}>
              {validationResult.errors.length} errors · {validationResult.warnings.length} warnings
            </Tag>
          )}
          <Segmented
            size="small"
            value={previewMode}
            options={[
              { label: 'Template', value: 'template' },
              { label: 'Generated', value: 'generated', disabled: !generatedBuffer },
            ]}
            onChange={setPreviewMode}
          />
        </Space>
      </div>

      <div className="document-preview-panel">
        {!templateBuffer ? (
          <Empty description="Open a DOCX template (.docxtpl) to start" />
        ) : previewMode === 'generated' && !generatedBuffer ? (
          <Empty description="Generate the document to preview the result" />
        ) : (
          <div ref={previewRef} className="document-docx-preview" />
        )}
      </div>
    </div>
  );
}

function generatedName(templateName) {
  if (!templateName) return 'generated-document.docx';
  return templateName.replace(/\.(docxtpl|docx)$/i, '-generated.docx');
}
