import Docxtemplater from 'docxtemplater';
import expressionParser from 'docxtemplater/expressions.js';
import PizZip from 'pizzip';
import { renderAsync } from 'docx-preview';

const parser = expressionParser.configure({ csp: true });
export function downloadDocx(blob, filename = 'generated-document.docx') {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
