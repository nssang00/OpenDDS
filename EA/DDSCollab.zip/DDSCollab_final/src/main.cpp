#include <iostream>
#include <fstream>
#include <string>
#include <functional>
#include "ea/EAReader.h"
#include "ea/EAConverter.h"
#include "repository/SQLiteRepository.h"
#include "dds/DDSModels.h"
#include "dds/DDSLoader.h"

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cout << "사용법: DDSCollab <qea_file> <output_db> [project_name]\n";
        return 1;
    }

    std::string qea_path     = argv[1];
    std::string db_path      = argv[2];
    std::string project_name = argc > 3 ? argv[3] : "DDS Project";

    std::cout << "=== DDS Collab Converter ===\n";
    std::cout << "QEA: " << qea_path << "\n";
    std::cout << "DB:  " << db_path  << "\n\n";

    // 1. Repository 초기화
    Repo::SQLiteRepository repo;
    if (!repo.open(db_path)) {
        std::cerr << "DB 열기 실패: " << repo.getLastError() << "\n";
        return 1;
    }
    if (!repo.initSchema("dds_collab.sql")) {
        std::cout << "[경고] DDL 파일 없음. 기존 스키마 사용\n";
    }

    Repo::Project project;
    project.id          = "proj-001";
    project.name        = project_name;
    project.description = "QEA 변환 프로젝트";
    project.version     = "1.0";
    repo.saveProject(project);

    // 2. EA → Repository 변환
    EA::EAReader reader;
    if (!reader.open(qea_path)) {
        std::cerr << "QEA 열기 실패: " << reader.getLastError() << "\n";
        return 1;
    }

    Converter::EAConverter converter(reader, repo);
    auto result = converter.convert(project.id, qea_path);
    reader.close();

    std::cout << "=== 변환 결과 ===\n";
    std::cout << "packages:     " << result.packages     << "\n";
    std::cout << "types:        " << result.types        << "\n";
    std::cout << "type_members: " << result.type_members << "\n";
    std::cout << "domains:      " << result.domains      << "\n";
    std::cout << "topics:       " << result.topics       << "\n";
    std::cout << "participants: " << result.participants << "\n";

    for (const auto& e : result.errors) {
        std::cerr << "[오류] " << e << "\n";
    }

    // 3. DDS Model 로드
    std::cout << "\n=== DDS Model 로드 ===\n";
    DDS::DDSLoader loader(repo);
    DDS::DDSProject dds_project = loader.loadProject(project.id);

    std::cout << "프로젝트: " << dds_project.name << "\n";
    std::cout << "패키지:   " << dds_project.packages.size()     << "개\n";
    std::cout << "도메인:   " << dds_project.domains.size()      << "개\n";
    std::cout << "QoS:      " << dds_project.qos_profiles.size() << "개\n";
    std::cout << "참여자:   " << dds_project.participants.size()  << "개\n";

    // 전체 타입 수 계산
    int total_types = 0;
    std::function<void(const DDS::DDSPackage&)> countTypes =
        [&](const DDS::DDSPackage& pkg) {
            total_types += static_cast<int>(pkg.types.size());
            for (const auto& child : pkg.children) countTypes(child);
        };
    for (const auto& pkg : dds_project.packages) countTypes(pkg);
    std::cout << "타입:     " << total_types << "개\n";

    // 4. 도메인 JSON 출력 샘플
    std::cout << "\n=== toJson() 샘플 ===\n";
    if (!dds_project.domains.empty()) {
        std::cout << "도메인[0]:\n";
        std::cout << dds_project.domains[0].toJson() << "\n";
    }

    // DDS 타입 2개만 출력
    int printed = 0;
    std::function<void(const DDS::DDSPackage&)> printTypes =
        [&](const DDS::DDSPackage& pkg) {
            for (const auto& t : pkg.types) {
                if (printed >= 2) return;
                if (t.ea_stereotype == "idlStruct" ||
                    t.ea_stereotype == "struct") {
                    std::cout << "\n타입 [" << t.name << "]:\n";
                    std::string j = t.toJson();
                    std::cout << j.substr(0, 400);
                    if (j.size() > 400) std::cout << "...";
                    std::cout << "\n";
                    printed++;
                }
            }
            for (const auto& child : pkg.children) printTypes(child);
        };
    for (const auto& pkg : dds_project.packages) printTypes(pkg);

    // 5. 전체 JSON 파일 저장
    std::string json_path = db_path + ".json";
    std::ofstream json_file(json_path);
    if (json_file.is_open()) {
        json_file << dds_project.toJson();
        json_file.close();
        std::cout << "\nJSON 저장: " << json_path << "\n";
    }

    repo.close();
    std::cout << "\n완료!\n";
    return 0;
}
