#pragma once
#include "IRepository.h"
#include <sqlite3.h>
#include <string>

namespace Repo {

// ============================================================
// SQLiteRepository
// IRepository의 SQLite 구현
// ============================================================
class SQLiteRepository : public IRepository {
public:
    SQLiteRepository();
    ~SQLiteRepository();

    bool open(const std::string& db_path) override;
    void close() override;
    bool isOpen() const override;
    bool initSchema(const std::string& ddl_path) override;

    // projects
    bool     saveProject(const Project& p) override;
    Project  loadProject(const std::string& id) override;
    std::vector<Project> loadAllProjects() override;

    // packages
    bool     savePackage(const Package& p) override;
    Package  loadPackage(const std::string& id) override;
    std::vector<Package> loadPackages(const std::string& project_id) override;
    std::vector<Package> loadChildPackages(const std::string& parent_id) override;
    std::string findPackageByEaGuid(const std::string& ea_guid) override;

    // types
    bool     saveType(const Type& t) override;
    Type     loadType(const std::string& id) override;
    std::vector<Type> loadTypes(const std::string& project_id) override;
    std::vector<Type> loadTypesByPackage(const std::string& package_id) override;
    std::string findTypeByEaGuid(const std::string& ea_guid) override;
    std::string findTypeByName(const std::string& project_id,
                               const std::string& name) override;

    // type_members
    bool     saveMember(const TypeMember& m) override;
    std::vector<TypeMember> loadMembers(const std::string& type_id) override;
    std::string findMemberByEaGuid(const std::string& ea_guid) override;

    // domains
    bool     saveDomain(const Domain& d) override;
    Domain   loadDomain(const std::string& id) override;
    std::vector<Domain> loadDomains(const std::string& project_id) override;
    std::string findDomainByEaGuid(const std::string& ea_guid) override;

    // register_types
    bool     saveRegisterType(const RegisterType& rt) override;
    std::vector<RegisterType> loadRegisterTypes(
        const std::string& domain_id) override;

    // topics
    bool     saveTopic(const Topic& t) override;
    Topic    loadTopic(const std::string& id) override;
    std::vector<Topic> loadTopics(const std::string& project_id) override;
    std::vector<Topic> loadTopicsByDomain(const std::string& domain_id) override;
    std::string findTopicByEaGuid(const std::string& ea_guid) override;

    // qos_profiles
    bool        saveQosProfile(const QosProfile& p) override;
    QosProfile  loadQosProfile(const std::string& id) override;
    std::vector<QosProfile> loadQosProfiles(
        const std::string& project_id) override;

    // qos_policies
    bool     saveQosPolicy(const QosPolicy& p) override;
    std::vector<QosPolicy> loadQosPolicies(
        const std::string& profile_id) override;

    // participants
    bool     saveParticipant(const Participant& p) override;
    std::vector<Participant> loadParticipants(
        const std::string& project_id) override;
    std::string findParticipantByEaGuid(const std::string& ea_guid) override;

    // publishers
    bool     savePublisher(const Publisher& p) override;
    std::vector<Publisher> loadPublishers(
        const std::string& participant_id) override;

    // subscribers
    bool     saveSubscriber(const Subscriber& s) override;
    std::vector<Subscriber> loadSubscribers(
        const std::string& participant_id) override;

    // writers
    bool     saveWriter(const Writer& w) override;
    std::vector<Writer> loadWriters(const std::string& publisher_id) override;

    // readers
    bool     saveReader(const Reader& r) override;
    std::vector<Reader> loadReaders(
        const std::string& subscriber_id) override;

    // audit_log
    bool     saveAuditLog(const AuditLog& log) override;
    std::vector<AuditLog> loadAuditLogs(
        const std::string& project_id,
        int limit = 100) override;

    // 트랜잭션
    bool beginTransaction() override;
    bool commitTransaction() override;
    bool rollbackTransaction() override;

    std::string getLastError() const override { return last_error_; }

private:
    sqlite3*    db_         = nullptr;
    std::string last_error_;

    // 헬퍼
    bool        exec(const std::string& sql);
    std::string getString(sqlite3_stmt* stmt, int col);
    int         getInt(sqlite3_stmt* stmt, int col);
};

} // namespace Repo
