#pragma once
#include <string>
#include <vector>

namespace EA {

// ============================================================
// EA Model 구조체
// Sparx EA QEA 파일의 핵심 테이블을 C++ 구조체로 표현
// ============================================================

struct EAPackage {
    int         package_id   = 0;
    std::string name;
    int         parent_id    = 0;
    std::string notes;
    std::string ea_guid;
    int         t_pos        = 0;
};

struct EAObject {
    int         object_id    = 0;
    std::string name;
    std::string object_type;   // 'Class'|'Interface'|'Enumeration'|'DataType'
                               // 'Part'|'Component'|'Port'|'Package'
    std::string stereotype;
    int         package_id   = 0;
    std::string note;
    std::string ea_guid;
    std::string classifier_guid;
    int         classifier   = 0;
    int         parent_id    = 0;
};

struct EAAttribute {
    int         id           = 0;
    int         object_id    = 0;
    std::string name;
    std::string type;          // 타입 문자열 (primitive or 복합 타입명)
    std::string stereotype;    // 'idlField'|'key'|'foreignKey'|'dlrlAttribute'
    std::string lower_bound;
    std::string upper_bound;
    std::string default_val;
    std::string notes;
    int         pos          = 0;
    int         classifier   = 0;   // → t_object.Object_ID 참조
    int         length       = 0;   // string bound
    std::string ea_guid;
};

struct EAAttributeTag {
    int         property_id  = 0;
    int         element_id   = 0;   // → t_attribute.ID
    std::string property;           // 'isDCPSKey'|'isOptional'|'mappedField'...
    std::string value;
    std::string ea_guid;
};

struct EAConnector {
    int         connector_id    = 0;
    std::string connector_type; // 'Generalization'|'Association'|'Aggregation'
                                // 'Dependency'|'Realization'|'Connector'
    std::string stereotype;
    std::string sub_type;       // 'use' 등
    int         start_object_id = 0;
    int         end_object_id   = 0;
    std::string ea_guid;
};

struct EAObjectProperty {
    int         id          = 0;
    int         object_id   = 0;
    std::string property;   // 'type'|'domain'|'typedef'|'typeSynonyms'...
    std::string value;
    std::string ea_guid;
};

struct EATaggedValue {
    std::string property_id;
    std::string element_id;
    std::string base_class;
    std::string tag_value;
    std::string notes;
};

} // namespace EA
