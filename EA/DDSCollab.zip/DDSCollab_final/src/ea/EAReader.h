#pragma once
#include <string>
#include <vector>
#include <set>
#include "EAModels.h"
#include <sqlite3.h>

namespace EA {

// ============================================================
// EAReader
// QEA 파일(SQLite)에서 EA Model 데이터를 읽어오는 클래스
// ============================================================
class EAReader {
public:
    EAReader();
    ~EAReader();

    // QEA 파일 열기/닫기
    bool open(const std::string& qea_path);
    void close();
    bool isOpen() const;

    // t_package 읽기
    std::vector<EAPackage> readPackages();
    EAPackage readPackage(int package_id);

    // t_object 읽기
    // DDS 대상: Object_Type IN ('Class','Interface','Enumeration','DataType')
    std::vector<EAObject> readDDSObjects();

    // t_object 전체 (Part, Component, Port 포함)
    std::vector<EAObject> readObjectsByPackage(int package_id);
    EAObject readObject(int object_id);

    // t_attribute 읽기
    std::vector<EAAttribute> readAttributes(int object_id);
    std::vector<EAAttribute> readAttributesByObjects(
        const std::set<int>& object_ids);

    // t_attributetag 읽기
    std::vector<EAAttributeTag> readAttributeTags(int attribute_id);
    std::vector<EAAttributeTag> readAttributeTagsByElements(
        const std::set<int>& element_ids);

    // t_connector 읽기
    std::vector<EAConnector> readConnectors(
        const std::set<int>& object_ids);

    // t_objectproperties 읽기
    std::vector<EAObjectProperty> readObjectProperties(
        const std::set<int>& object_ids);

    // t_taggedvalue 읽기
    std::vector<EATaggedValue> readTaggedValues(
        const std::set<int>& object_ids);

    // 필요한 package ID 재귀 수집
    // (DDS 대상 object들의 상위 package 전체)
    std::set<int> collectRequiredPackageIds(
        const std::vector<EAObject>& objects);

    std::string getLastError() const { return last_error_; }

private:
    sqlite3*    db_          = nullptr;
    std::string last_error_;

    // 내부 헬퍼
    bool        execQuery(const std::string& sql,
                          int (*callback)(void*, int, char**, char**),
                          void* data);
    std::string escapeString(const std::string& str);
};

} // namespace EA
