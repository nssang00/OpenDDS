#pragma once
#include <string>
#include <vector>
#include <map>
#include <set>
#include "../ea/EAModels.h"
#include "../ea/EAReader.h"
#include "../repository/IRepository.h"

namespace Converter {

// ============================================================
// 변환 결과 통계
// ============================================================
struct ConvertResult {
    int packages     = 0;
    int types        = 0;
    int type_members = 0;
    int domains      = 0;
    int register_types = 0;
    int topics       = 0;
    int participants = 0;
    int publishers   = 0;
    int subscribers  = 0;
    int writers      = 0;
    int readers      = 0;
    std::vector<std::string> warnings;
    std::vector<std::string> errors;
};

// ============================================================
// EAConverter
// EA Model → Repository 변환
// ============================================================
class EAConverter {
public:
    EAConverter(EA::EAReader& reader, Repo::IRepository& repo);

    // 전체 변환 실행
    ConvertResult convert(const std::string& project_id,
                          const std::string& qea_path);

private:
    EA::EAReader&       reader_;
    Repo::IRepository&  repo_;

    // ea_guid → Repository id 매핑 캐시
    std::map<std::string, std::string> pkg_guid_to_id_;
    std::map<int, std::string>         pkg_id_to_repo_id_;  // EA Package_ID → repo id
    std::map<std::string, std::string> type_guid_to_id_;
    std::map<std::string, std::string> domain_guid_to_id_;
    std::map<std::string, std::string> topic_guid_to_id_;
    std::map<int, std::string>         obj_id_to_type_id_;   // Object_ID → type id
    std::map<int, std::string>         obj_id_to_domain_id_; // Object_ID → domain id
    std::map<int, std::string>         obj_id_to_topic_id_;  // Object_ID → topic id

    // --------------------------------------------------------
    // Step 1: t_package → packages
    // --------------------------------------------------------
    void convertPackages(
        const std::string& project_id,
        const std::set<int>& required_pkg_ids,
        const std::vector<EA::EAPackage>& all_packages,
        ConvertResult& result);

    // --------------------------------------------------------
    // Step 2: t_object → types / domains / topics / participants
    // --------------------------------------------------------
    void convertObjects(
        const std::string& project_id,
        const std::vector<EA::EAObject>& objects,
        ConvertResult& result);

    void convertToType(
        const std::string& project_id,
        const EA::EAObject& obj,
        ConvertResult& result);

    void convertToDomain(
        const std::string& project_id,
        const EA::EAObject& obj,
        ConvertResult& result);

    void convertToTopic(
        const std::string& project_id,
        const EA::EAObject& obj,
        ConvertResult& result);

    void convertToParticipant(
        const std::string& project_id,
        const EA::EAObject& obj,
        ConvertResult& result);

    void convertToPublisher(
        const std::string& project_id,
        const EA::EAObject& obj,
        ConvertResult& result);

    void convertToSubscriber(
        const std::string& project_id,
        const EA::EAObject& obj,
        ConvertResult& result);

    void convertToWriter(
        const std::string& project_id,
        const EA::EAObject& obj,
        ConvertResult& result);

    void convertToReader(
        const std::string& project_id,
        const EA::EAObject& obj,
        ConvertResult& result);

    // --------------------------------------------------------
    // Step 3: t_attribute → type_members
    // --------------------------------------------------------
    void convertAttributes(
        const std::string& project_id,
        const std::vector<EA::EAAttribute>& attributes,
        const std::vector<EA::EAAttributeTag>& attr_tags,
        ConvertResult& result);

    // --------------------------------------------------------
    // Step 4: t_objectproperties → 연결 처리
    // --------------------------------------------------------
    void processObjectProperties(
        const std::vector<EA::EAObjectProperty>& props,
        ConvertResult& result);

    // --------------------------------------------------------
    // Step 5: t_connector → 관계 처리
    // --------------------------------------------------------
    void processConnectors(
        const std::vector<EA::EAConnector>& connectors,
        ConvertResult& result);

    // --------------------------------------------------------
    // 헬퍼 함수
    // --------------------------------------------------------

    // Object_Type + Stereotype → types.kind 변환
    std::string resolveTypeKind(
        const std::string& object_type,
        const std::string& stereotype);

    // EA 타입 문자열 → primitive_type 변환
    // 반환값이 비어있으면 복합 타입 (ref_type_id로 처리)
    std::string resolvePrimitiveType(const std::string& ea_type);

    // LowerBound/UpperBound → 컬렉션 정보 파생
    void resolveCollection(
        const std::string& lower_bound,
        const std::string& upper_bound,
        Repo::TypeMember& member);

    // member_kind 결정
    std::string resolveMemberKind(
        const std::string& type_kind,
        const std::string& ea_stereotype);

    // UUID 생성
    std::string generateUUID();

    // qualified_name 조합 (패키지 계층)
    std::string buildQualifiedName(
        const std::string& package_id,
        const std::string& name);
};

} // namespace Converter
