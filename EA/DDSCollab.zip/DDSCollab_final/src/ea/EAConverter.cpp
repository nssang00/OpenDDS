#include "EAConverter.h"
#include <algorithm>
#include <sstream>
#include <iostream>
#include <ctime>
#include <random>
#include <iomanip>
#include <functional>

namespace Converter {

// ============================================================
// 생성자
// ============================================================
EAConverter::EAConverter(EA::EAReader& reader, Repo::IRepository& repo)
    : reader_(reader), repo_(repo)
{}

// ============================================================
// UUID 생성 (C++11 기반)
// ============================================================
std::string EAConverter::generateUUID() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> dis(0, 15);
    static std::uniform_int_distribution<> dis2(8, 11);

    std::stringstream ss;
    ss << std::hex;
    for (int i = 0; i < 8;  i++) ss << dis(gen);
    ss << "-";
    for (int i = 0; i < 4;  i++) ss << dis(gen);
    ss << "-4";
    for (int i = 0; i < 3;  i++) ss << dis(gen);
    ss << "-";
    ss << dis2(gen);
    for (int i = 0; i < 3;  i++) ss << dis(gen);
    ss << "-";
    for (int i = 0; i < 12; i++) ss << dis(gen);
    return ss.str();
}

// ============================================================
// Object_Type + Stereotype → types.kind 변환
// ============================================================
std::string EAConverter::resolveTypeKind(
    const std::string& object_type,
    const std::string& stereotype)
{
    // Enumeration → enum
    if (object_type == "Enumeration") return "enum";

    // DataType → typedef
    if (object_type == "DataType") return "typedef";

    // Interface → struct
    if (object_type == "Interface") return "struct";

    // Class → stereotype 기반 판별
    if (object_type == "Class") {
        if (stereotype == "struct"      ||
            stereotype == "idlStruct")   return "struct";
        if (stereotype == "enumeration") return "enum";
        if (stereotype == "union")       return "union";
        if (stereotype == "typedef"     ||
            stereotype == "alias")       return "typedef";
        // 기본값
        return "struct";
    }

    // 알 수 없는 경우 빈 문자열 (사용자 지정 필요)
    return "";
}

// ============================================================
// EA 타입 문자열 → DDS primitive_type 변환
// ============================================================
std::string EAConverter::resolvePrimitiveType(const std::string& ea_type) {
    // 소문자 변환 후 비교
    std::string t = ea_type;
    std::transform(t.begin(), t.end(), t.begin(), ::tolower);

    // 공백 제거
    t.erase(std::remove(t.begin(), t.end(), ' '), t.end());

    if (t == "boolean" || t == "bool")          return "boolean";
    if (t == "octet"   || t == "byte")          return "octet";
    if (t == "char"    || t == "char8")         return "char";
    if (t == "wchar"   || t == "char16")        return "wchar";
    if (t == "int8")                            return "int8";
    if (t == "uint8")                           return "uint8";
    if (t == "short"   || t == "int16")         return "int16";
    if (t == "unsignedshort" || t == "uint16")  return "uint16";
    if (t == "long"    || t == "int"   ||
        t == "int32")                           return "int32";
    if (t == "unsignedlong" || t == "uint32")   return "uint32";
    if (t == "longlong" || t == "int64")        return "int64";
    if (t == "unsignedlonglong" || t == "uint64") return "uint64";
    if (t == "float"   || t == "float32")       return "float32";
    if (t == "double"  || t == "float64")       return "float64";
    if (t == "longdouble" || t == "float128")   return "float128";
    if (t == "string"  || t == "char*")         return "string";
    if (t == "wstring")                         return "wstring";

    // 복합 타입 (ref_type_id로 처리)
    return "";
}

// ============================================================
// LowerBound/UpperBound → 컬렉션 정보 파생
// ============================================================
void EAConverter::resolveCollection(
    const std::string& lower_bound,
    const std::string& upper_bound,
    Repo::TypeMember& member)
{
    member.lower_bound = lower_bound;
    member.upper_bound = upper_bound;

    if (upper_bound.empty() || upper_bound == "1") {
        // 단일 멤버
        if (lower_bound == "0" && upper_bound == "1") {
            member.is_optional = 1;
        }
        return;
    }

    // unbounded sequence
    if (upper_bound == "0" || upper_bound == "*") {
        member.is_sequence    = 1;
        member.sequence_bound = -1;  // unbounded
        return;
    }

    // 숫자 변환 시도
    try {
        int lower = lower_bound.empty() ? 1 : std::stoi(lower_bound);
        int upper = std::stoi(upper_bound);

        if (lower == upper && upper > 1) {
            // array
            member.is_array         = 1;
            member.array_dimensions = "[" + std::to_string(upper) + "]";
        }
        else if (lower < upper) {
            // bounded sequence
            member.is_sequence    = 1;
            member.sequence_bound = upper;
        }
    }
    catch (...) {
        // 변환 실패 → 원본만 보존
    }
}

// ============================================================
// member_kind 결정
// ============================================================
std::string EAConverter::resolveMemberKind(
    const std::string& type_kind,
    const std::string& ea_stereotype)
{
    if (type_kind == "enum")  return "literal";
    if (type_kind == "union") {
        if (ea_stereotype == "discriminator") return "discriminator";
        return "case";
    }
    return "field";
}

// ============================================================
// 전체 변환 실행
// ============================================================
ConvertResult EAConverter::convert(
    const std::string& project_id,
    const std::string& qea_path)
{
    ConvertResult result;

    if (!reader_.isOpen()) {
        result.errors.push_back("QEA 파일이 열려있지 않습니다.");
        return result;
    }

    repo_.beginTransaction();

    try {
        // Step 1. DDS 대상 t_object 전체 읽기
        auto all_objects = reader_.readDDSObjects();

        // Object_ID set 수집
        std::set<int> obj_ids;
        for (const auto& obj : all_objects) {
            obj_ids.insert(obj.object_id);
        }

        // Step 2. 필요한 package ID 재귀 수집
        auto required_pkg_ids = reader_.collectRequiredPackageIds(all_objects);

        // Step 3. t_package 전체 읽기 후 필요한 것만 변환
        auto all_packages = reader_.readPackages();
        convertPackages(project_id, required_pkg_ids,
                        all_packages, result);

        // Step 4. t_object → types / domains / topics / participants
        convertObjects(project_id, all_objects, result);

        // Step 5. t_attribute → type_members
        std::set<int> type_obj_ids;
        for (const auto& obj : all_objects) {
            if (obj.object_type == "Class"       ||
                obj.object_type == "Interface"   ||
                obj.object_type == "Enumeration" ||
                obj.object_type == "DataType")
            {
                type_obj_ids.insert(obj.object_id);
            }
        }

        auto attributes = reader_.readAttributesByObjects(type_obj_ids);

        std::set<int> attr_ids;
        for (const auto& attr : attributes) {
            attr_ids.insert(attr.id);
        }

        auto attr_tags = reader_.readAttributeTagsByElements(attr_ids);
        convertAttributes(project_id, attributes, attr_tags, result);

        // Step 6. t_objectproperties → 연결 처리
        auto obj_props = reader_.readObjectProperties(obj_ids);
        processObjectProperties(obj_props, result);

        // Step 7. t_connector → 관계 처리
        auto connectors = reader_.readConnectors(obj_ids);
        processConnectors(connectors, result);

        // Step 8. audit_log 기록
        Repo::AuditLog log;
        log.id          = generateUUID();
        log.project_id  = project_id;
        log.target_kind = "project";
        log.target_id   = project_id;
        log.action      = "ea_sync";
        log.changed_by  = "ea_import";
        log.diff        = "{\"source\":\"" + qea_path + "\","
                          "\"types\":"        + std::to_string(result.types) +
                          ",\"type_members\":" + std::to_string(result.type_members) +
                          ",\"domains\":"     + std::to_string(result.domains) +
                          ",\"topics\":"      + std::to_string(result.topics) + "}";
        repo_.saveAuditLog(log);

        repo_.commitTransaction();
    }
    catch (const std::exception& e) {
        repo_.rollbackTransaction();
        result.errors.push_back(std::string("변환 중 오류: ") + e.what());
    }

    return result;
}

// ============================================================
// Step 1: packages 변환
// ============================================================
void EAConverter::convertPackages(
    const std::string& project_id,
    const std::set<int>& required_pkg_ids,
    const std::vector<EA::EAPackage>& all_packages,
    ConvertResult& result)
{
    // Package_ID → EAPackage 맵
    std::map<int, EA::EAPackage> pkg_map;
    for (const auto& pkg : all_packages) {
        pkg_map[pkg.package_id] = pkg;
    }

    // 부모 먼저 처리되도록 정렬 (parent_id 기준)
    // BFS 방식으로 처리
    std::vector<int> ordered;
    std::set<int> visited;

    std::function<void(int)> visit = [&](int pkg_id) {
        if (visited.count(pkg_id)) return;
        if (!required_pkg_ids.count(pkg_id)) return;

        auto it = pkg_map.find(pkg_id);
        if (it == pkg_map.end()) return;

        // 부모 먼저
        if (it->second.parent_id > 0) {
            visit(it->second.parent_id);
        }

        visited.insert(pkg_id);
        ordered.push_back(pkg_id);
    };

    for (int pkg_id : required_pkg_ids) {
        visit(pkg_id);
    }

    // 순서대로 변환
    for (int pkg_id : ordered) {
        auto it = pkg_map.find(pkg_id);
        if (it == pkg_map.end()) continue;

        const EA::EAPackage& ea_pkg = it->second;

        // 이미 존재하는지 확인 (재동기화)
        std::string existing_id = repo_.findPackageByEaGuid(ea_pkg.ea_guid);

        Repo::Package repo_pkg;
        repo_pkg.id         = existing_id.empty() ? generateUUID() : existing_id;
        repo_pkg.project_id = project_id;
        repo_pkg.name       = ea_pkg.name;
        repo_pkg.description = ea_pkg.notes;
        repo_pkg.ordinal    = ea_pkg.t_pos;
        repo_pkg.ea_guid    = ea_pkg.ea_guid;
        repo_pkg.source     = "ea";
        repo_pkg.kind       = "module";  // 기본값, 사용자가 변경 가능

        // 부모 package ID 설정
        if (ea_pkg.parent_id > 0) {
            auto parent_it = pkg_map.find(ea_pkg.parent_id);
            if (parent_it != pkg_map.end()) {
                auto cached = pkg_guid_to_id_.find(parent_it->second.ea_guid);
                if (cached != pkg_guid_to_id_.end()) {
                    repo_pkg.parent_id = cached->second;
                }
            }
        }

        if (repo_.savePackage(repo_pkg)) {
            pkg_guid_to_id_[ea_pkg.ea_guid]         = repo_pkg.id;
            pkg_id_to_repo_id_[ea_pkg.package_id]   = repo_pkg.id;
            result.packages++;
        }
    }
}

// ============================================================
// Step 2: objects 변환
// ============================================================
void EAConverter::convertObjects(
    const std::string& project_id,
    const std::vector<EA::EAObject>& objects,
    ConvertResult& result)
{
    for (const auto& obj : objects) {
        const std::string& ot = obj.object_type;
        const std::string& st = obj.stereotype;

        // types
        if (ot == "Class"      ||
            ot == "Interface"  ||
            ot == "Enumeration"||
            ot == "DataType")
        {
            convertToType(project_id, obj, result);
        }
        // domain
        else if (ot == "Part" && st == "domain") {
            convertToDomain(project_id, obj, result);
        }
        // topic
        else if (ot == "Part" && st == "topic") {
            convertToTopic(project_id, obj, result);
        }
        // participant
        else if (ot == "Component" && st == "domainParticipant") {
            convertToParticipant(project_id, obj, result);
        }
        // publisher
        else if (ot == "Part" && st == "publisher") {
            convertToPublisher(project_id, obj, result);
        }
        // subscriber
        else if (ot == "Part" && st == "subscriber") {
            convertToSubscriber(project_id, obj, result);
        }
        // writer
        else if (ot == "Port" && st == "dataWriter") {
            convertToWriter(project_id, obj, result);
        }
        // reader
        else if (ot == "Port" && st == "dataReader") {
            convertToReader(project_id, obj, result);
        }
        // 그 외 무시
    }
}

void EAConverter::convertToType(
    const std::string& project_id,
    const EA::EAObject& obj,
    ConvertResult& result)
{
    std::string existing_id = repo_.findTypeByEaGuid(obj.ea_guid);

    Repo::Type t;
    t.id            = existing_id.empty() ? generateUUID() : existing_id;
    t.project_id    = project_id;
    t.name          = obj.name;
    t.description   = obj.note;
    t.ea_guid       = obj.ea_guid;
    t.ea_object_type = obj.object_type;
    t.ea_stereotype  = obj.stereotype;
    t.source        = "ea";
    t.kind          = resolveTypeKind(obj.object_type, obj.stereotype);
    t.extensibility = "appendable";  // 기본값

    // package_id 연결 (EA Package_ID → repo UUID)
    auto pkg_it = pkg_id_to_repo_id_.find(obj.package_id);
    if (pkg_it != pkg_id_to_repo_id_.end()) {
        t.package_id = pkg_it->second;
    }

    if (repo_.saveType(t)) {
        type_guid_to_id_[obj.ea_guid]    = t.id;
        obj_id_to_type_id_[obj.object_id] = t.id;
        result.types++;
    }
}

void EAConverter::convertToDomain(
    const std::string& project_id,
    const EA::EAObject& obj,
    ConvertResult& result)
{
    std::string existing_id = repo_.findDomainByEaGuid(obj.ea_guid);

    Repo::Domain d;
    d.id            = existing_id.empty() ? generateUUID() : existing_id;
    d.project_id    = project_id;
    d.name          = obj.name;
    d.description   = obj.note;
    d.ea_guid       = obj.ea_guid;
    d.ea_stereotype = obj.stereotype;
    d.source        = "ea";

    if (repo_.saveDomain(d)) {
        domain_guid_to_id_[obj.ea_guid]    = d.id;
        obj_id_to_domain_id_[obj.object_id] = d.id;
        result.domains++;
    }
}

void EAConverter::convertToTopic(
    const std::string& project_id,
    const EA::EAObject& obj,
    ConvertResult& result)
{
    std::string existing_id = repo_.findTopicByEaGuid(obj.ea_guid);

    Repo::Topic t;
    t.id            = existing_id.empty() ? generateUUID() : existing_id;
    t.project_id    = project_id;
    t.name          = obj.name;
    t.description   = obj.note;
    t.ea_guid       = obj.ea_guid;
    t.ea_stereotype = obj.stereotype;
    t.source        = "ea";
    // register_type_id, domain_id → processObjectProperties에서 설정

    if (repo_.saveTopic(t)) {
        topic_guid_to_id_[obj.ea_guid]    = t.id;
        obj_id_to_topic_id_[obj.object_id] = t.id;
        result.topics++;
    }
}

void EAConverter::convertToParticipant(
    const std::string& project_id,
    const EA::EAObject& obj,
    ConvertResult& result)
{
    Repo::Participant p;
    p.id            = generateUUID();
    p.project_id    = project_id;
    p.name          = obj.name;
    p.description   = obj.note;
    p.ea_guid       = obj.ea_guid;
    p.ea_stereotype = obj.stereotype;
    p.source        = "ea";

    if (repo_.saveParticipant(p)) {
        result.participants++;
    }
}

void EAConverter::convertToPublisher(
    const std::string& project_id,
    const EA::EAObject& obj,
    ConvertResult& result)
{
    Repo::Publisher p;
    p.id            = generateUUID();
    p.name          = obj.name;
    p.description   = obj.note;
    p.ea_guid       = obj.ea_guid;
    p.ea_stereotype = obj.stereotype;
    p.source        = "ea";
    // participant_id → connector로 연결

    if (repo_.savePublisher(p)) {
        result.publishers++;
    }
}

void EAConverter::convertToSubscriber(
    const std::string& project_id,
    const EA::EAObject& obj,
    ConvertResult& result)
{
    Repo::Subscriber s;
    s.id            = generateUUID();
    s.name          = obj.name;
    s.description   = obj.note;
    s.ea_guid       = obj.ea_guid;
    s.ea_stereotype = obj.stereotype;
    s.source        = "ea";

    if (repo_.saveSubscriber(s)) {
        result.subscribers++;
    }
}

void EAConverter::convertToWriter(
    const std::string& project_id,
    const EA::EAObject& obj,
    ConvertResult& result)
{
    Repo::Writer w;
    w.id            = generateUUID();
    w.name          = obj.name;
    w.description   = obj.note;
    w.ea_guid       = obj.ea_guid;
    w.ea_stereotype = obj.stereotype;
    w.source        = "ea";

    if (repo_.saveWriter(w)) {
        result.writers++;
    }
}

void EAConverter::convertToReader(
    const std::string& project_id,
    const EA::EAObject& obj,
    ConvertResult& result)
{
    Repo::Reader r;
    r.id            = generateUUID();
    r.name          = obj.name;
    r.description   = obj.note;
    r.ea_guid       = obj.ea_guid;
    r.ea_stereotype = obj.stereotype;
    r.source        = "ea";

    if (repo_.saveReader(r)) {
        result.readers++;
    }
}

// ============================================================
// Step 3: attributes → type_members
// ============================================================
void EAConverter::convertAttributes(
    const std::string& project_id,
    const std::vector<EA::EAAttribute>& attributes,
    const std::vector<EA::EAAttributeTag>& attr_tags,
    ConvertResult& result)
{
    // attribute_id → tags 맵 구성
    std::map<int, std::vector<EA::EAAttributeTag>> tag_map;
    for (const auto& tag : attr_tags) {
        tag_map[tag.element_id].push_back(tag);
    }

    for (const auto& attr : attributes) {
        // 부모 type id 찾기
        auto type_it = obj_id_to_type_id_.find(attr.object_id);
        if (type_it == obj_id_to_type_id_.end()) continue;

        const std::string& type_id = type_it->second;

        // type kind 가져오기
        Repo::Type parent_type = repo_.loadType(type_id);

        Repo::TypeMember m;
        m.id           = generateUUID();
        m.type_id      = type_id;
        m.name         = attr.name;
        m.ordinal      = attr.pos;
        m.ea_guid      = attr.ea_guid;
        m.ea_stereotype = attr.stereotype;
        m.ea_type_name = attr.type;
        m.source       = "ea";
        m.default_value = attr.default_val;
        m.description  = attr.notes;

        // member_kind 결정
        m.member_kind = resolveMemberKind(parent_type.kind, attr.stereotype);

        // is_key (Stereotype 기반)
        if (attr.stereotype == "key" || attr.stereotype == "Key") {
            m.is_key = 1;
        }

        // primitive_type / ref_type_id 판별
        std::string prim = resolvePrimitiveType(attr.type);
        if (!prim.empty()) {
            m.primitive_type = prim;
        }
        else if (attr.classifier > 0) {
            // Classifier로 복합 타입 참조
            auto ref_it = obj_id_to_type_id_.find(attr.classifier);
            if (ref_it != obj_id_to_type_id_.end()) {
                m.ref_type_id = ref_it->second;
            }
            else {
                // 이름으로 fallback
                m.ref_type_id = repo_.findTypeByName(project_id, attr.type);
            }
        }

        // string bound
        if (attr.length > 0) {
            m.string_bound = attr.length;
        }

        // 컬렉션 파생
        resolveCollection(attr.lower_bound, attr.upper_bound, m);

        // AttributeTag 처리
        auto tag_it = tag_map.find(attr.id);
        if (tag_it != tag_map.end()) {
            std::string annotations = "{";
            bool first = true;

            for (const auto& tag : tag_it->second) {
                if (tag.property == "isDCPSKey" ||
                    tag.property == "isKey"     ||
                    tag.property == "Key")
                {
                    if (tag.value == "true" || tag.value == "True") {
                        m.is_key = 1;
                    }
                }
                else if (tag.property == "isOptional" ||
                         tag.property == "Optional")
                {
                    if (tag.value == "true" || tag.value == "True") {
                        m.is_optional = 1;
                    }
                }
                else {
                    // 나머지 → annotations JSON
                    if (!first) annotations += ",";
                    annotations += "\"" + tag.property + "\":\""
                                 + tag.value + "\"";
                    first = false;
                }
            }
            annotations += "}";
            if (annotations != "{}") {
                m.annotations = annotations;
            }
        }

        // enum 리터럴인 경우 enum_value 설정
        if (m.member_kind == "literal" && !attr.default_val.empty()) {
            try {
                m.enum_value     = std::stoi(attr.default_val);
                m.has_enum_value = true;
            }
            catch (...) {}
        }

        if (repo_.saveMember(m)) {
            result.type_members++;
        }
    }
}

// ============================================================
// Step 4: objectproperties → 연결 처리
// ============================================================
void EAConverter::processObjectProperties(
    const std::vector<EA::EAObjectProperty>& props,
    ConvertResult& result)
{
    for (const auto& prop : props) {
        // topic → type 연결
        if (prop.property == "type") {
            auto topic_it = obj_id_to_topic_id_.find(prop.object_id);
            auto type_it  = type_guid_to_id_.find(prop.value);

            if (topic_it != obj_id_to_topic_id_.end() &&
                type_it  != type_guid_to_id_.end())
            {
                // register_types 생성
                Repo::RegisterType rt;
                rt.id        = generateUUID();
                rt.type_id   = type_it->second;
                // domain_id는 participant의 domain으로부터 추론 필요
                // 일단 topic의 domain_id 사용
                repo_.saveRegisterType(rt);
                result.register_types++;
            }
        }
        // participant → domain 연결
        else if (prop.property == "domain") {
            auto domain_it = domain_guid_to_id_.find(prop.value);
            if (domain_it != domain_guid_to_id_.end()) {
                // participant의 domain_id 업데이트 필요
                // (현재 구조에서는 UPDATE가 필요)
            }
        }
    }
}

// ============================================================
// Step 5: connectors → 관계 처리
// ============================================================
void EAConverter::processConnectors(
    const std::vector<EA::EAConnector>& connectors,
    ConvertResult& result)
{
    for (const auto& conn : connectors) {
        // Generalization → types.base_type_id
        if (conn.connector_type == "Generalization") {
            auto child_it  = obj_id_to_type_id_.find(conn.start_object_id);
            auto parent_it = obj_id_to_type_id_.find(conn.end_object_id);

            if (child_it != obj_id_to_type_id_.end() &&
                parent_it != obj_id_to_type_id_.end())
            {
                // types.base_type_id UPDATE 필요
                // (IRepository에 updateTypeBaseId 추가 필요)
            }
        }
        // Dependency(use) → type 참조
        else if (conn.connector_type == "Dependency" &&
                 (conn.sub_type == "use" || conn.stereotype == "use"))
        {
            // type_members.ref_type_id 처리
        }
        // 그 외 무시
    }
}

} // namespace Converter
