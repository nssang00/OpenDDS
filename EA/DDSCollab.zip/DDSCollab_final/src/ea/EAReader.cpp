#include "EAReader.h"
#include <sstream>
#include <iostream>

namespace EA {

EAReader::EAReader() : db_(nullptr) {}

EAReader::~EAReader() {
    close();
}

bool EAReader::open(const std::string& qea_path) {
    int rc = sqlite3_open_v2(
        qea_path.c_str(), &db_,
        SQLITE_OPEN_READONLY, nullptr);

    if (rc != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        sqlite3_close(db_);
        db_ = nullptr;
        return false;
    }
    return true;
}

void EAReader::close() {
    if (db_) {
        sqlite3_close(db_);
        db_ = nullptr;
    }
}

bool EAReader::isOpen() const {
    return db_ != nullptr;
}

// ============================================================
// t_package 읽기
// ============================================================
std::vector<EAPackage> EAReader::readPackages() {
    std::vector<EAPackage> result;
    if (!db_) return result;

    const char* sql =
        "SELECT Package_ID, Name, Parent_ID, Notes, ea_guid, TPos "
        "FROM t_package "
        "ORDER BY Parent_ID, TPos;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return result;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAPackage pkg;
        pkg.package_id = sqlite3_column_int(stmt, 0);
        pkg.name       = sqlite3_column_text(stmt, 1)
                         ? (const char*)sqlite3_column_text(stmt, 1) : "";
        pkg.parent_id  = sqlite3_column_int(stmt, 2);
        pkg.notes      = sqlite3_column_text(stmt, 3)
                         ? (const char*)sqlite3_column_text(stmt, 3) : "";
        pkg.ea_guid    = sqlite3_column_text(stmt, 4)
                         ? (const char*)sqlite3_column_text(stmt, 4) : "";
        pkg.t_pos      = sqlite3_column_int(stmt, 5);
        result.push_back(pkg);
    }

    sqlite3_finalize(stmt);
    return result;
}

EAPackage EAReader::readPackage(int package_id) {
    EAPackage pkg;
    if (!db_) return pkg;

    std::string sql =
        "SELECT Package_ID, Name, Parent_ID, Notes, ea_guid, TPos "
        "FROM t_package WHERE Package_ID = " +
        std::to_string(package_id) + ";";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return pkg;
    }

    if (sqlite3_step(stmt) == SQLITE_ROW) {
        pkg.package_id = sqlite3_column_int(stmt, 0);
        pkg.name       = sqlite3_column_text(stmt, 1)
                         ? (const char*)sqlite3_column_text(stmt, 1) : "";
        pkg.parent_id  = sqlite3_column_int(stmt, 2);
        pkg.notes      = sqlite3_column_text(stmt, 3)
                         ? (const char*)sqlite3_column_text(stmt, 3) : "";
        pkg.ea_guid    = sqlite3_column_text(stmt, 4)
                         ? (const char*)sqlite3_column_text(stmt, 4) : "";
        pkg.t_pos      = sqlite3_column_int(stmt, 5);
    }

    sqlite3_finalize(stmt);
    return pkg;
}

// ============================================================
// t_object 읽기
// ============================================================
std::vector<EAObject> EAReader::readDDSObjects() {
    std::vector<EAObject> result;
    if (!db_) return result;

    // DDS 타입 관련 Object_Type 필터
    const char* sql =
        "SELECT Object_ID, Name, Object_Type, Stereotype, "
        "       Package_ID, Note, ea_guid, Classifier_guid, "
        "       Classifier, ParentID "
        "FROM t_object "
        "WHERE Object_Type IN "
        "      ('Class','Interface','Enumeration','DataType',"
        "       'Part','Component','Port') "
        "ORDER BY Package_ID, Object_ID;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return result;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAObject obj;
        obj.object_id        = sqlite3_column_int(stmt, 0);
        obj.name             = sqlite3_column_text(stmt, 1)
                               ? (const char*)sqlite3_column_text(stmt, 1) : "";
        obj.object_type      = sqlite3_column_text(stmt, 2)
                               ? (const char*)sqlite3_column_text(stmt, 2) : "";
        obj.stereotype       = sqlite3_column_text(stmt, 3)
                               ? (const char*)sqlite3_column_text(stmt, 3) : "";
        obj.package_id       = sqlite3_column_int(stmt, 4);
        obj.note             = sqlite3_column_text(stmt, 5)
                               ? (const char*)sqlite3_column_text(stmt, 5) : "";
        obj.ea_guid          = sqlite3_column_text(stmt, 6)
                               ? (const char*)sqlite3_column_text(stmt, 6) : "";
        obj.classifier_guid  = sqlite3_column_text(stmt, 7)
                               ? (const char*)sqlite3_column_text(stmt, 7) : "";
        obj.classifier       = sqlite3_column_int(stmt, 8);
        obj.parent_id        = sqlite3_column_int(stmt, 9);
        result.push_back(obj);
    }

    sqlite3_finalize(stmt);
    return result;
}

EAObject EAReader::readObject(int object_id) {
    EAObject obj;
    if (!db_) return obj;

    std::string sql =
        "SELECT Object_ID, Name, Object_Type, Stereotype, "
        "       Package_ID, Note, ea_guid, Classifier_guid, "
        "       Classifier, ParentID "
        "FROM t_object WHERE Object_ID = " +
        std::to_string(object_id) + ";";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return obj;
    }

    if (sqlite3_step(stmt) == SQLITE_ROW) {
        obj.object_id       = sqlite3_column_int(stmt, 0);
        obj.name            = sqlite3_column_text(stmt, 1)
                              ? (const char*)sqlite3_column_text(stmt, 1) : "";
        obj.object_type     = sqlite3_column_text(stmt, 2)
                              ? (const char*)sqlite3_column_text(stmt, 2) : "";
        obj.stereotype      = sqlite3_column_text(stmt, 3)
                              ? (const char*)sqlite3_column_text(stmt, 3) : "";
        obj.package_id      = sqlite3_column_int(stmt, 4);
        obj.note            = sqlite3_column_text(stmt, 5)
                              ? (const char*)sqlite3_column_text(stmt, 5) : "";
        obj.ea_guid         = sqlite3_column_text(stmt, 6)
                              ? (const char*)sqlite3_column_text(stmt, 6) : "";
        obj.classifier_guid = sqlite3_column_text(stmt, 7)
                              ? (const char*)sqlite3_column_text(stmt, 7) : "";
        obj.classifier      = sqlite3_column_int(stmt, 8);
        obj.parent_id       = sqlite3_column_int(stmt, 9);
    }

    sqlite3_finalize(stmt);
    return obj;
}

// ============================================================
// t_attribute 읽기
// ============================================================
std::vector<EAAttribute> EAReader::readAttributes(int object_id) {
    std::set<int> ids = { object_id };
    return readAttributesByObjects(ids);
}

std::vector<EAAttribute> EAReader::readAttributesByObjects(
    const std::set<int>& object_ids)
{
    std::vector<EAAttribute> result;
    if (!db_ || object_ids.empty()) return result;

    // IN 절 생성
    std::string in_clause;
    for (auto it = object_ids.begin(); it != object_ids.end(); ++it) {
        if (it != object_ids.begin()) in_clause += ",";
        in_clause += std::to_string(*it);
    }

    std::string sql =
        "SELECT ID, Object_ID, Name, Type, Stereotype, "
        "       LowerBound, UpperBound, \"Default\", Notes, "
        "       Pos, Classifier, Length, ea_guid "
        "FROM t_attribute "
        "WHERE Object_ID IN (" + in_clause + ") "
        "ORDER BY Object_ID, Pos;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return result;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAAttribute attr;
        attr.id          = sqlite3_column_int(stmt, 0);
        attr.object_id   = sqlite3_column_int(stmt, 1);
        attr.name        = sqlite3_column_text(stmt, 2)
                           ? (const char*)sqlite3_column_text(stmt, 2) : "";
        attr.type        = sqlite3_column_text(stmt, 3)
                           ? (const char*)sqlite3_column_text(stmt, 3) : "";
        attr.stereotype  = sqlite3_column_text(stmt, 4)
                           ? (const char*)sqlite3_column_text(stmt, 4) : "";
        attr.lower_bound = sqlite3_column_text(stmt, 5)
                           ? (const char*)sqlite3_column_text(stmt, 5) : "";
        attr.upper_bound = sqlite3_column_text(stmt, 6)
                           ? (const char*)sqlite3_column_text(stmt, 6) : "";
        attr.default_val = sqlite3_column_text(stmt, 7)
                           ? (const char*)sqlite3_column_text(stmt, 7) : "";
        attr.notes       = sqlite3_column_text(stmt, 8)
                           ? (const char*)sqlite3_column_text(stmt, 8) : "";
        attr.pos         = sqlite3_column_int(stmt, 9);
        attr.classifier  = sqlite3_column_int(stmt, 10);
        attr.length      = sqlite3_column_int(stmt, 11);
        attr.ea_guid     = sqlite3_column_text(stmt, 12)
                           ? (const char*)sqlite3_column_text(stmt, 12) : "";
        result.push_back(attr);
    }

    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// t_attributetag 읽기
// ============================================================
std::vector<EAAttributeTag> EAReader::readAttributeTags(int attribute_id) {
    std::set<int> ids = { attribute_id };
    return readAttributeTagsByElements(ids);
}

std::vector<EAAttributeTag> EAReader::readAttributeTagsByElements(
    const std::set<int>& element_ids)
{
    std::vector<EAAttributeTag> result;
    if (!db_ || element_ids.empty()) return result;

    std::string in_clause;
    for (auto it = element_ids.begin(); it != element_ids.end(); ++it) {
        if (it != element_ids.begin()) in_clause += ",";
        in_clause += std::to_string(*it);
    }

    std::string sql =
        "SELECT PropertyID, ElementID, Property, VALUE, ea_guid "
        "FROM t_attributetag "
        "WHERE ElementID IN (" + in_clause + ");";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return result;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAAttributeTag tag;
        tag.property_id = sqlite3_column_int(stmt, 0);
        tag.element_id  = sqlite3_column_int(stmt, 1);
        tag.property    = sqlite3_column_text(stmt, 2)
                          ? (const char*)sqlite3_column_text(stmt, 2) : "";
        tag.value       = sqlite3_column_text(stmt, 3)
                          ? (const char*)sqlite3_column_text(stmt, 3) : "";
        tag.ea_guid     = sqlite3_column_text(stmt, 4)
                          ? (const char*)sqlite3_column_text(stmt, 4) : "";
        result.push_back(tag);
    }

    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// t_connector 읽기
// ============================================================
std::vector<EAConnector> EAReader::readConnectors(
    const std::set<int>& object_ids)
{
    std::vector<EAConnector> result;
    if (!db_ || object_ids.empty()) return result;

    std::string in_clause;
    for (auto it = object_ids.begin(); it != object_ids.end(); ++it) {
        if (it != object_ids.begin()) in_clause += ",";
        in_clause += std::to_string(*it);
    }

    // Start 또는 End가 대상 object인 connector 전체
    std::string sql =
        "SELECT Connector_ID, Connector_Type, Stereotype, SubType, "
        "       Start_Object_ID, End_Object_ID, ea_guid "
        "FROM t_connector "
        "WHERE Start_Object_ID IN (" + in_clause + ") "
        "   OR End_Object_ID   IN (" + in_clause + ");";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return result;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAConnector conn;
        conn.connector_id     = sqlite3_column_int(stmt, 0);
        conn.connector_type   = sqlite3_column_text(stmt, 1)
                                ? (const char*)sqlite3_column_text(stmt, 1) : "";
        conn.stereotype       = sqlite3_column_text(stmt, 2)
                                ? (const char*)sqlite3_column_text(stmt, 2) : "";
        conn.sub_type         = sqlite3_column_text(stmt, 3)
                                ? (const char*)sqlite3_column_text(stmt, 3) : "";
        conn.start_object_id  = sqlite3_column_int(stmt, 4);
        conn.end_object_id    = sqlite3_column_int(stmt, 5);
        conn.ea_guid          = sqlite3_column_text(stmt, 6)
                                ? (const char*)sqlite3_column_text(stmt, 6) : "";
        result.push_back(conn);
    }

    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// t_objectproperties 읽기
// ============================================================
std::vector<EAObjectProperty> EAReader::readObjectProperties(
    const std::set<int>& object_ids)
{
    std::vector<EAObjectProperty> result;
    if (!db_ || object_ids.empty()) return result;

    std::string in_clause;
    for (auto it = object_ids.begin(); it != object_ids.end(); ++it) {
        if (it != object_ids.begin()) in_clause += ",";
        in_clause += std::to_string(*it);
    }

    std::string sql =
        "SELECT ID, Object_ID, Property, Value, ea_guid "
        "FROM t_objectproperties "
        "WHERE Object_ID IN (" + in_clause + ") "
        "AND Property IN ('type','domain','typedef','typeSynonyms',"
        "                 'kind','extensibility');";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return result;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAObjectProperty prop;
        prop.id        = sqlite3_column_int(stmt, 0);
        prop.object_id = sqlite3_column_int(stmt, 1);
        prop.property  = sqlite3_column_text(stmt, 2)
                         ? (const char*)sqlite3_column_text(stmt, 2) : "";
        prop.value     = sqlite3_column_text(stmt, 3)
                         ? (const char*)sqlite3_column_text(stmt, 3) : "";
        prop.ea_guid   = sqlite3_column_text(stmt, 4)
                         ? (const char*)sqlite3_column_text(stmt, 4) : "";
        result.push_back(prop);
    }

    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// t_taggedvalue 읽기
// ============================================================
std::vector<EATaggedValue> EAReader::readTaggedValues(
    const std::set<int>& object_ids)
{
    std::vector<EATaggedValue> result;
    if (!db_ || object_ids.empty()) return result;

    // t_taggedvalue.ElementID는 ea_guid 형태
    // object의 ea_guid를 먼저 수집
    std::string in_clause;
    for (auto it = object_ids.begin(); it != object_ids.end(); ++it) {
        if (it != object_ids.begin()) in_clause += ",";
        in_clause += std::to_string(*it);
    }

    // Object_ID로 ea_guid 수집
    std::string guid_sql =
        "SELECT ea_guid FROM t_object "
        "WHERE Object_ID IN (" + in_clause + ");";

    sqlite3_stmt* guid_stmt = nullptr;
    std::vector<std::string> guids;

    if (sqlite3_prepare_v2(db_, guid_sql.c_str(), -1, &guid_stmt, nullptr)
        == SQLITE_OK)
    {
        while (sqlite3_step(guid_stmt) == SQLITE_ROW) {
            if (sqlite3_column_text(guid_stmt, 0)) {
                guids.push_back(
                    (const char*)sqlite3_column_text(guid_stmt, 0));
            }
        }
        sqlite3_finalize(guid_stmt);
    }

    if (guids.empty()) return result;

    std::string guid_in;
    for (size_t i = 0; i < guids.size(); ++i) {
        if (i > 0) guid_in += ",";
        guid_in += "'" + guids[i] + "'";
    }

    std::string sql =
        "SELECT PropertyID, ElementID, BaseClass, TagValue, Notes "
        "FROM t_taggedvalue "
        "WHERE ElementID IN (" + guid_in + ");";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        return result;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EATaggedValue tv;
        tv.property_id = sqlite3_column_text(stmt, 0)
                         ? (const char*)sqlite3_column_text(stmt, 0) : "";
        tv.element_id  = sqlite3_column_text(stmt, 1)
                         ? (const char*)sqlite3_column_text(stmt, 1) : "";
        tv.base_class  = sqlite3_column_text(stmt, 2)
                         ? (const char*)sqlite3_column_text(stmt, 2) : "";
        tv.tag_value   = sqlite3_column_text(stmt, 3)
                         ? (const char*)sqlite3_column_text(stmt, 3) : "";
        tv.notes       = sqlite3_column_text(stmt, 4)
                         ? (const char*)sqlite3_column_text(stmt, 4) : "";
        result.push_back(tv);
    }

    sqlite3_finalize(stmt);
    return result;
}

// ============================================================
// 필요한 package ID 재귀 수집
// ============================================================
std::set<int> EAReader::collectRequiredPackageIds(
    const std::vector<EAObject>& objects)
{
    std::set<int> required;
    if (!db_) return required;

    // DDS object들의 Package_ID 수집
    for (const auto& obj : objects) {
        if (obj.package_id > 0) {
            required.insert(obj.package_id);
        }
    }

    // 상위 Package 재귀 추적
    bool changed = true;
    while (changed) {
        changed = false;
        std::set<int> new_ids;

        for (int pkg_id : required) {
            std::string sql =
                "SELECT Parent_ID FROM t_package "
                "WHERE Package_ID = " + std::to_string(pkg_id) + ";";

            sqlite3_stmt* stmt = nullptr;
            if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr)
                == SQLITE_OK)
            {
                if (sqlite3_step(stmt) == SQLITE_ROW) {
                    int parent_id = sqlite3_column_int(stmt, 0);
                    if (parent_id > 0 &&
                        required.find(parent_id) == required.end())
                    {
                        new_ids.insert(parent_id);
                        changed = true;
                    }
                }
                sqlite3_finalize(stmt);
            }
        }

        for (int id : new_ids) {
            required.insert(id);
        }
    }

    return required;
}

} // namespace EA
