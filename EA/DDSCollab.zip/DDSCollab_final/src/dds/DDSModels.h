#pragma once
#include <string>
#include <vector>
#include <map>
#include <memory>
#include "../Any.h"

namespace DDS {

// ============================================================
// 전방 선언
// ============================================================
class DDSMember;
class DDSType;
class DDSPackage;
class DDSTopic;
class DDSDomain;
class DDSQosProfile;
class DDSParticipant;
class DDSProject;

// ============================================================
// DDSMember
// ============================================================
class DDSMember {
public:
    std::string id;
    std::string type_id;
    std::string name;
    int         ordinal       = 0;
    std::string member_kind;

    std::string primitive_type;
    std::string ref_type_id;
    std::string ref_type_name;

    std::string ea_type_name;
    std::string lower_bound;
    std::string upper_bound;

    bool        is_sequence    = false;
    int         sequence_bound = -1;
    bool        is_array       = false;
    std::vector<int> array_dimensions;
    int         string_bound   = 0;

    bool        is_key         = false;
    bool        is_optional    = false;
    std::string annotations;

    int         enum_value     = 0;
    bool        has_enum_value = false;

    std::vector<std::string> case_labels;

    std::string default_value;
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source;

    Any         toAny()   const;
    std::string toJson()  const;
};

// ============================================================
// DDSType
// ============================================================
class DDSType {
public:
    std::string id;
    std::string project_id;
    std::string package_id;
    std::string name;
    std::string kind;
    std::string base_type_id;
    std::string base_type_name;
    std::string extensibility;
    std::string description;
    std::string annotations;
    std::string ea_guid;
    std::string ea_object_type;
    std::string ea_stereotype;
    std::string source;

    std::vector<DDSMember> members;

    Any         toAny()   const;
    std::string toJson()  const;
};

// ============================================================
// DDSPackage
// ============================================================
class DDSPackage {
public:
    std::string id;
    std::string project_id;
    std::string parent_id;
    std::string name;
    std::string kind;
    std::string description;
    int         ordinal = 0;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source;

    std::vector<DDSType>    types;
    std::vector<DDSPackage> children;

    std::string qualifiedName(const std::string& separator = "::") const;
    Any         toAny()  const;
    std::string toJson() const;
};

// ============================================================
// DDSQosPolicy
// ============================================================
class DDSQosPolicy {
public:
    std::string id;
    std::string profile_id;
    std::string entity_kind;
    std::string policy_name;
    std::string policy_value;

    Any         toAny()  const;
    std::string toJson() const;
};

// ============================================================
// DDSQosProfile
// ============================================================
class DDSQosProfile {
public:
    std::string id;
    std::string project_id;
    std::string name;
    std::string base_profile_id;
    std::string description;

    std::vector<DDSQosPolicy> policies;

    Any         toAny()  const;
    std::string toJson() const;
};

// ============================================================
// DDSRegisterType
// ============================================================
class DDSRegisterType {
public:
    std::string id;
    std::string domain_id;
    std::string type_id;
    std::string type_name;
    std::string register_name;

    std::string effectiveName() const {
        return register_name.empty() ? type_name : register_name;
    }

    Any         toAny()  const;
    std::string toJson() const;
};

// ============================================================
// DDSTopic
// ============================================================
class DDSTopic {
public:
    std::string id;
    std::string project_id;
    std::string package_id;
    std::string domain_id;
    std::string name;
    std::string register_type_id;
    std::string type_name;
    std::string qos_profile_id;
    std::string qos_profile_name;
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source;

    Any         toAny()  const;
    std::string toJson() const;
};

// ============================================================
// DDSDomain
// ============================================================
class DDSDomain {
public:
    std::string id;
    std::string project_id;
    std::string package_id;
    std::string name;
    int         domain_id = -1;
    std::string description;
    std::string ea_guid;
    std::string ea_stereotype;
    std::string source;

    std::vector<DDSRegisterType> register_types;
    std::vector<DDSTopic>        topics;

    Any         toAny()  const;
    std::string toJson() const;
};

// ============================================================
// DDSWriter / DDSReader
// ============================================================
class DDSWriter {
public:
    std::string id;
    std::string publisher_id;
    std::string topic_id;
    std::string topic_name;
    std::string name;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string source;

    Any         toAny()  const;
    std::string toJson() const;
};

class DDSReader {
public:
    std::string id;
    std::string subscriber_id;
    std::string topic_id;
    std::string topic_name;
    std::string name;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string source;

    Any         toAny()  const;
    std::string toJson() const;
};

// ============================================================
// DDSPublisher / DDSSubscriber
// ============================================================
class DDSPublisher {
public:
    std::string id;
    std::string participant_id;
    std::string name;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string source;

    std::vector<DDSWriter> writers;

    Any         toAny()  const;
    std::string toJson() const;
};

class DDSSubscriber {
public:
    std::string id;
    std::string participant_id;
    std::string name;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string source;

    std::vector<DDSReader> readers;

    Any         toAny()  const;
    std::string toJson() const;
};

// ============================================================
// DDSParticipant
// ============================================================
class DDSParticipant {
public:
    std::string id;
    std::string project_id;
    std::string domain_id;
    std::string domain_name;
    std::string name;
    std::string qos_profile_id;
    std::string description;
    std::string ea_guid;
    std::string source;

    std::vector<DDSPublisher>  publishers;
    std::vector<DDSSubscriber> subscribers;

    Any         toAny()  const;
    std::string toJson() const;
};

// ============================================================
// DDSProject
// ============================================================
class DDSProject {
public:
    std::string id;
    std::string name;
    std::string description;
    std::string version;

    std::vector<DDSPackage>     packages;
    std::vector<DDSDomain>      domains;
    std::vector<DDSQosProfile>  qos_profiles;
    std::vector<DDSParticipant> participants;

    std::map<std::string, DDSType*> type_index;

    Any         toAny()  const;
    std::string toJson() const;
};

} // namespace DDS
