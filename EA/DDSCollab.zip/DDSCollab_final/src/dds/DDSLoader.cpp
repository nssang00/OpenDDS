#include "DDSLoader.h"
#include <algorithm>
#include <sstream>

namespace DDS {

DDSLoader::DDSLoader(Repo::IRepository& repo) : repo_(repo) {}

// ============================================================
// 프로젝트 전체 로드
// ============================================================
DDSProject DDSLoader::loadProject(const std::string& project_id) {
    DDSProject project;

    // 기본 정보
    Repo::Project rp = repo_.loadProject(project_id);
    project.id          = rp.id;
    project.name        = rp.name;
    project.description = rp.description;
    project.version     = rp.version;

    // 타입 전체 로드 (id → name 인덱스 먼저 구성)
    auto repo_types = repo_.loadTypes(project_id);
    std::map<std::string, std::string> type_id_to_name;
    for (const auto& t : repo_types) {
        type_id_to_name[t.id] = t.name;
    }

    // 타입 + 멤버 로드
    std::map<std::string, std::vector<DDSType>> pkg_type_map;
    for (const auto& rt : repo_types) {
        DDSType dds_type = loadTypeWithMembers(rt, type_id_to_name);
        pkg_type_map[rt.package_id].push_back(dds_type);

        // type_index 구성
        // (포인터 안정성을 위해 나중에 별도 처리)
    }

    // 패키지 트리 구성
    project.packages = buildPackageTree(project_id);

    // 패키지에 타입 채우기
    for (auto& pkg : project.packages) {
        fillPackageTypes(pkg, pkg_type_map);
    }

    // 도메인 로드
    project.domains = loadDomains(project_id);

    // QoS 프로파일 로드
    project.qos_profiles = loadQosProfiles(project_id);

    // 참여자 로드
    project.participants = loadParticipants(project_id);

    return project;
}

// ============================================================
// 패키지 트리 구성
// ============================================================
std::vector<DDSPackage> DDSLoader::buildPackageTree(
    const std::string& project_id)
{
    auto repo_pkgs = repo_.loadPackages(project_id);

    // 트리 구성 - id→DDSPackage 맵으로 구성 후 parent 연결
    std::map<std::string, DDSPackage> pkg_map;
    for (const auto& rp : repo_pkgs) {
        DDSPackage pkg;
        pkg.id            = rp.id;
        pkg.project_id    = rp.project_id;
        pkg.parent_id     = rp.parent_id;
        pkg.name          = rp.name;
        pkg.kind          = rp.kind;
        pkg.description   = rp.description;
        pkg.ordinal       = rp.ordinal;
        pkg.ea_guid       = rp.ea_guid;
        pkg.ea_stereotype = rp.ea_stereotype;
        pkg.source        = rp.source;
        pkg_map[rp.id]    = pkg;
    }

    // 자식을 부모에 추가 (순서 보장을 위해 repo_pkgs 순서 유지)
    for (const auto& rp : repo_pkgs) {
        if (!rp.parent_id.empty()) {
            auto parent_it = pkg_map.find(rp.parent_id);
            if (parent_it != pkg_map.end()) {
                parent_it->second.children.push_back(pkg_map[rp.id]);
            }
        }
    }

    std::vector<DDSPackage> roots;
    for (const auto& rp : repo_pkgs) {
        if (rp.parent_id.empty()) {
            roots.push_back(pkg_map[rp.id]);
        }
    }

    return roots;
}

// ============================================================
// 패키지에 타입 채우기 (재귀)
// ============================================================
void DDSLoader::fillPackageTypes(
    DDSPackage& pkg,
    const std::map<std::string, std::vector<DDSType>>& type_map)
{
    auto it = type_map.find(pkg.id);
    if (it != type_map.end()) {
        pkg.types = it->second;
    }

    for (auto& child : pkg.children) {
        fillPackageTypes(child, type_map);
    }
}

// ============================================================
// type + members 로드
// ============================================================
DDSType DDSLoader::loadTypeWithMembers(
    const Repo::Type& rt,
    const std::map<std::string, std::string>& type_id_to_name)
{
    DDSType t;
    t.id             = rt.id;
    t.project_id     = rt.project_id;
    t.package_id     = rt.package_id;
    t.name           = rt.name;
    t.kind           = rt.kind;
    t.base_type_id   = rt.base_type_id;
    t.extensibility  = rt.extensibility;
    t.description    = rt.description;
    t.annotations    = rt.annotations;
    t.ea_guid        = rt.ea_guid;
    t.ea_object_type = rt.ea_object_type;
    t.ea_stereotype  = rt.ea_stereotype;
    t.source         = rt.source;

    // base_type_name 조회
    auto base_it = type_id_to_name.find(rt.base_type_id);
    if (base_it != type_id_to_name.end()) {
        t.base_type_name = base_it->second;
    }

    // 멤버 로드
    auto repo_members = repo_.loadMembers(rt.id);
    for (const auto& rm : repo_members) {
        t.members.push_back(convertMember(rm, type_id_to_name));
    }

    return t;
}

// ============================================================
// member 변환
// ============================================================
DDSMember DDSLoader::convertMember(
    const Repo::TypeMember& m,
    const std::map<std::string, std::string>& type_id_to_name)
{
    DDSMember dm;
    dm.id             = m.id;
    dm.type_id        = m.type_id;
    dm.name           = m.name;
    dm.ordinal        = m.ordinal;
    dm.member_kind    = m.member_kind;
    dm.primitive_type = m.primitive_type;
    dm.ref_type_id    = m.ref_type_id;
    dm.ea_type_name   = m.ea_type_name;
    dm.lower_bound    = m.lower_bound;
    dm.upper_bound    = m.upper_bound;
    dm.is_sequence    = (m.is_sequence != 0);
    dm.sequence_bound = m.sequence_bound;
    dm.is_array       = (m.is_array != 0);
    dm.string_bound   = m.string_bound;
    dm.is_key         = (m.is_key != 0);
    dm.is_optional    = (m.is_optional != 0);
    dm.annotations    = m.annotations;
    dm.enum_value     = m.enum_value;
    dm.has_enum_value = m.has_enum_value;
    dm.default_value  = m.default_value;
    dm.description    = m.description;
    dm.ea_guid        = m.ea_guid;
    dm.ea_stereotype  = m.ea_stereotype;
    dm.source         = m.source;

    // ref_type_name 조회
    auto ref_it = type_id_to_name.find(m.ref_type_id);
    if (ref_it != type_id_to_name.end()) {
        dm.ref_type_name = ref_it->second;
    }
    else if (!m.ea_type_name.empty()) {
        dm.ref_type_name = m.ea_type_name;
    }

    // array_dimensions 파싱 "[3,4]" → {3,4}
    if (!m.array_dimensions.empty()) {
        std::string dims = m.array_dimensions;
        // '[', ']' 제거
        dims.erase(std::remove(dims.begin(), dims.end(), '['), dims.end());
        dims.erase(std::remove(dims.begin(), dims.end(), ']'), dims.end());
        std::istringstream ss(dims);
        std::string token;
        while (std::getline(ss, token, ',')) {
            try { dm.array_dimensions.push_back(std::stoi(token)); }
            catch (...) {}
        }
    }

    // case_labels 파싱 '["0","1"]' → {"0","1"}
    if (!m.case_labels.empty()) {
        std::string labels = m.case_labels;
        labels.erase(std::remove(labels.begin(), labels.end(), '['), labels.end());
        labels.erase(std::remove(labels.begin(), labels.end(), ']'), labels.end());
        labels.erase(std::remove(labels.begin(), labels.end(), '"'), labels.end());
        std::istringstream ss(labels);
        std::string token;
        while (std::getline(ss, token, ',')) {
            if (!token.empty()) dm.case_labels.push_back(token);
        }
    }

    return dm;
}

// ============================================================
// 도메인 로드
// ============================================================
std::vector<DDSDomain> DDSLoader::loadDomains(const std::string& project_id) {
    std::vector<DDSDomain> result;

    auto repo_domains = repo_.loadDomains(project_id);
    for (const auto& rd : repo_domains) {
        DDSDomain d;
        d.id           = rd.id;
        d.project_id   = rd.project_id;
        d.package_id   = rd.package_id;
        d.name         = rd.name;
        d.domain_id    = rd.domain_id;
        d.description  = rd.description;
        d.ea_guid      = rd.ea_guid;
        d.ea_stereotype = rd.ea_stereotype;
        d.source       = rd.source;

        // register_types 로드
        auto rts = repo_.loadRegisterTypes(rd.id);
        for (const auto& rt : rts) {
            DDSRegisterType drt;
            drt.id            = rt.id;
            drt.domain_id     = rt.domain_id;
            drt.type_id       = rt.type_id;
            drt.register_name = rt.register_name;
            // type_name은 별도 조회
            Repo::Type t = repo_.loadType(rt.type_id);
            drt.type_name = t.name;
            d.register_types.push_back(drt);
        }

        // topics 로드
        auto repo_topics = repo_.loadTopicsByDomain(rd.id);
        for (const auto& rt2 : repo_topics) {
            DDSTopic topic;
            topic.id               = rt2.id;
            topic.project_id       = rt2.project_id;
            topic.package_id       = rt2.package_id;
            topic.domain_id        = rt2.domain_id;
            topic.name             = rt2.name;
            topic.register_type_id = rt2.register_type_id;
            topic.qos_profile_id   = rt2.qos_profile_id;
            topic.description      = rt2.description;
            topic.ea_guid          = rt2.ea_guid;
            topic.ea_stereotype    = rt2.ea_stereotype;
            topic.source           = rt2.source;

            // type_name 조회
            if (!rt2.register_type_id.empty()) {
                auto rts2 = repo_.loadRegisterTypes(rd.id);
                for (const auto& rtype : rts2) {
                    if (rtype.id == rt2.register_type_id) {
                        Repo::Type t2 = repo_.loadType(rtype.type_id);
                        topic.type_name = t2.name;
                        break;
                    }
                }
            }

            d.topics.push_back(topic);
        }

        result.push_back(d);
    }

    return result;
}

// ============================================================
// QoS 프로파일 로드
// ============================================================
std::vector<DDSQosProfile> DDSLoader::loadQosProfiles(
    const std::string& project_id)
{
    std::vector<DDSQosProfile> result;

    auto repo_profiles = repo_.loadQosProfiles(project_id);
    for (const auto& rp : repo_profiles) {
        DDSQosProfile qp;
        qp.id              = rp.id;
        qp.project_id      = rp.project_id;
        qp.name            = rp.name;
        qp.base_profile_id = rp.base_profile_id;
        qp.description     = rp.description;

        // policies 로드
        auto repo_policies = repo_.loadQosPolicies(rp.id);
        for (const auto& pol : repo_policies) {
            DDSQosPolicy dp;
            dp.id           = pol.id;
            dp.profile_id   = pol.profile_id;
            dp.entity_kind  = pol.entity_kind;
            dp.policy_name  = pol.policy_name;
            dp.policy_value = pol.policy_value;
            qp.policies.push_back(dp);
        }

        result.push_back(qp);
    }

    return result;
}

// ============================================================
// 참여자 로드
// ============================================================
std::vector<DDSParticipant> DDSLoader::loadParticipants(
    const std::string& project_id)
{
    std::vector<DDSParticipant> result;

    auto repo_parts = repo_.loadParticipants(project_id);
    for (const auto& rp : repo_parts) {
        DDSParticipant p;
        p.id             = rp.id;
        p.project_id     = rp.project_id;
        p.domain_id      = rp.domain_id;
        p.name           = rp.name;
        p.qos_profile_id = rp.qos_profile_id;
        p.description    = rp.description;
        p.ea_guid        = rp.ea_guid;
        p.source         = rp.source;

        // domain_name 조회
        if (!rp.domain_id.empty()) {
            Repo::Domain d = repo_.loadDomain(rp.domain_id);
            p.domain_name = d.name;
        }

        // publishers 로드
        auto repo_pubs = repo_.loadPublishers(rp.id);
        for (const auto& rpub : repo_pubs) {
            DDSPublisher pub;
            pub.id             = rpub.id;
            pub.participant_id = rpub.participant_id;
            pub.name           = rpub.name;
            pub.qos_profile_id = rpub.qos_profile_id;
            pub.description    = rpub.description;
            pub.ea_guid        = rpub.ea_guid;
            pub.source         = rpub.source;

            // writers 로드
            auto repo_writers = repo_.loadWriters(rpub.id);
            for (const auto& rw : repo_writers) {
                DDSWriter w;
                w.id             = rw.id;
                w.publisher_id   = rw.publisher_id;
                w.topic_id       = rw.topic_id;
                w.name           = rw.name;
                w.qos_profile_id = rw.qos_profile_id;
                w.description    = rw.description;
                w.ea_guid        = rw.ea_guid;
                w.source         = rw.source;

                // topic_name 조회
                if (!rw.topic_id.empty()) {
                    Repo::Topic t = repo_.loadTopic(rw.topic_id);
                    w.topic_name = t.name;
                }
                pub.writers.push_back(w);
            }

            p.publishers.push_back(pub);
        }

        // subscribers 로드
        auto repo_subs = repo_.loadSubscribers(rp.id);
        for (const auto& rsub : repo_subs) {
            DDSSubscriber sub;
            sub.id             = rsub.id;
            sub.participant_id = rsub.participant_id;
            sub.name           = rsub.name;
            sub.qos_profile_id = rsub.qos_profile_id;
            sub.description    = rsub.description;
            sub.ea_guid        = rsub.ea_guid;
            sub.source         = rsub.source;

            // readers 로드
            auto repo_readers = repo_.loadReaders(rsub.id);
            for (const auto& rr : repo_readers) {
                DDSReader r;
                r.id             = rr.id;
                r.subscriber_id  = rr.subscriber_id;
                r.topic_id       = rr.topic_id;
                r.name           = rr.name;
                r.qos_profile_id = rr.qos_profile_id;
                r.description    = rr.description;
                r.ea_guid        = rr.ea_guid;
                r.source         = rr.source;

                if (!rr.topic_id.empty()) {
                    Repo::Topic t = repo_.loadTopic(rr.topic_id);
                    r.topic_name = t.name;
                }
                sub.readers.push_back(r);
            }

            p.subscribers.push_back(sub);
        }

        result.push_back(p);
    }

    return result;
}

} // namespace DDS
