# DDS Collab - Sparx EA → DDS 협업 DB 변환 도구

## 개요
Sparx EA QEA 파일을 OMG DDS JSON 기반 협업 DB(SQLite)로 변환합니다.

## 레이어 구조
```
EA Model (QEA) → Repository (SQLite) → DDS Model (C++) → JSON/IDL/MD
```

## 빌드 방법

### Linux/Mac
```bash
g++ -std=c++11 \
    -I/usr/include \
    -I./src \
    src/main.cpp \
    src/ea/EAReader.cpp \
    src/ea/EAConverter.cpp \
    src/repository/SQLiteRepository.cpp \
    src/dds/DDSModels.cpp \
    src/dds/DDSLoader.cpp \
    -lsqlite3 \
    -o dds_collab
```

### Visual Studio 2019
- 프로젝트 타입: Console Application
- C++ 표준: /std:c++11
- 추가 포함 디렉토리: src
- 추가 라이브러리: sqlite3.lib

## 사용 방법
```bash
# 1. DB 초기화
sqlite3 collab.db < dds_collab.sql

# 2. 변환 실행
./dds_collab <qea_file> <output_db> [project_name]

# 예시
./dds_collab DDS_Example.qea collab.db "국과연 DDS 프로젝트"
```

## 출력
- collab.db: 협업 SQLite DB
- collab.db.json: 전체 DDS Model JSON

## 폴더 구조
```
src/
  ea/                  ← EA Model 레이어
    EAModels.h         ← EA 구조체
    EAReader.h/.cpp    ← QEA 읽기
    EAConverter.h/.cpp ← EA→Repository 변환
  repository/          ← Repository 레이어
    IRepository.h      ← 인터페이스
    RepositoryModels.h ← DB 구조체
    SQLiteRepository.h/.cpp ← SQLite 구현
  dds/                 ← DDS Model 레이어
    DDSValue.h         ← C++11 범용 값 타입
    DDSModels.h/.cpp   ← DDS 클래스 + toJson()/toAny()
    DDSLoader.h/.cpp   ← Repository → DDS Model 로드
  main.cpp
dds_collab.sql         ← SQLite DDL (15개 테이블)
```

## 다음 단계 (미구현)
- generator/IDLGenerator   ← generateIDL()
- generator/MarkdownGenerator ← generateMarkdown()

## Any.h 사용 안내
```
Any.h - C++11 호환 범용 값 타입 (std::any 대신 사용)
  typedef VariantDict = map<string, Any>
  typedef VariantList = vector<Any>

  toAny() 반환값 사용 예:
    Any result = type.toAny();
    VariantDict dict = AnyCast<VariantDict>(result);
    std::string name = AnyCast<std::string>(dict["name"]);

수정 사항:
  Any.h 19~21줄 namespace std { ... } 블록 주석처리
  (g++ 환경에서 std::type_info 재정의 오류 방지)
  MSVC에서는 원본 그대로 사용 가능
```
