
using Idl.Model;

namespace Ea.Automation;

/// <summary>
/// Generates the Enterprise Architect model directly through the EA Automation object model.
/// The repository argument is expected to be an EA.Repository instance in production.
/// </summary>
public sealed class EaModelGenerator
{
    private readonly EaTypeMapper _typeMapper;
    private readonly Dictionary<string, object> _elements = new(StringComparer.Ordinal);
    private readonly Dictionary<string, object> _packages = new(StringComparer.Ordinal);

    public EaModelGenerator(EaTypeMapper? typeMapper = null) => _typeMapper = typeMapper ?? new EaTypeMapper();

    public IReadOnlyDictionary<string, object> Elements => _elements;

    public void Generate(IdlModule model, dynamic repository, string rootPackageName = "IDL Modules", Action<int, int>? progress = null)
    {
        ArgumentNullException.ThrowIfNull(model);
        ArgumentNullException.ThrowIfNull(repository);

        _elements.Clear();
        _packages.Clear();

        dynamic root = AddRootPackage(repository, rootPackageName);
        _packages["::"] = root;

        // Pass 1: create the package/type skeleton.
        var declarations = model.IsSynthetic
            ? model.Declarations
            : new IdlDeclaration[] { model };
        var semanticCount = CountSemanticDeclarations(declarations);
        var sourceCount = model.SourcePaths.Count();
        var totalWork = semanticCount * 2 + sourceCount;
        var completedWork = 0;
        Action reportProgress = () => progress?.Invoke(++completedWork, totalWork);

        CreateDeclarations((object)root, declarations, Array.Empty<string>(), null, reportProgress);

        // Pass 2: populate details after all target ElementIDs exist.
        PopulateDeclarations(declarations, Array.Empty<string>(), reportProgress);

        CreateSourceTree(model.SourcePaths, (object)repository, reportProgress);
        TryRefreshModel(repository);
    }

    private void CreateDeclarations(dynamic package, IEnumerable<IdlDeclaration> declarations, IReadOnlyList<string> scope, string? inheritedSourcePath, Action progress)
    {
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
            {
                var moduleScope = scope.Append(module.Name).ToArray();
                var packageKey = "::" + string.Join("::", moduleScope);
                if (!_packages.TryGetValue(packageKey, out var cached))
                {
                    dynamic child = AddPackage(package, module.Name);
                    cached = child;
                    _packages[packageKey] = cached;
                }

                CreateDeclarations((dynamic)cached, module.Declarations, moduleScope, module.SourcePath ?? inheritedSourcePath, progress);
                continue;
            }

            var mapping = _typeMapper.MapDeclaration(declaration);
            dynamic element = AddElement(package, declaration.Name, mapping.ElementType, mapping.Stereotype);
            ApplyAnnotations(element, declaration.Annotations);
            AddElementTag(element, "idl.sourcePath", declaration.SourcePath ?? inheritedSourcePath ?? string.Empty);
            AddElementTag(element, "idl.scopedName", Scoped(scope, declaration.Name));
            _elements[Scoped(scope, declaration.Name)] = element;
            progress();
        }
    }

    private void PopulateDeclarations(IEnumerable<IdlDeclaration> declarations, IReadOnlyList<string> scope, Action progress)
    {
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
            {
                PopulateDeclarations(module.Declarations, [.. scope, module.Name], progress);
                continue;
            }

            if (!_elements.TryGetValue(Scoped(scope, declaration.Name), out var cached))
                continue;

            dynamic element = cached;
            switch (declaration)
            {
                case IdlStruct s:
                    foreach (var field in s.Fields) AddField(element, field);
                    break;
                case IdlEnum e:
                    foreach (var value in e.Values) AddAttribute(element, value, string.Empty, "enum");
                    break;
                case IdlUnion u:
                    PopulateUnion(element, u);
                    break;
                case IdlTypedef t:
                    PopulateTypedef(element, t);
                    break;
                case IdlConstant c:
                    PopulateConstant(element, c);
                    break;
            }
            progress();
        }
    }

    private static void CreateSourceTree(IEnumerable<string> sourcePaths, dynamic repository, Action progress)
    {
        dynamic root = AddRootPackage(repository, "IDL Sources");
        var packages = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase) { [string.Empty] = root };

        foreach (var sourcePath in sourcePaths.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            var normalized = sourcePath.Replace('\\', '/').Trim('/');
            var parts = normalized.Split('/', StringSplitOptions.RemoveEmptyEntries);
            dynamic current = root;
            var currentPath = string.Empty;

            foreach (var folder in parts.Take(Math.Max(0, parts.Length - 1)))
            {
                currentPath = currentPath.Length == 0 ? folder : currentPath + "/" + folder;
                if (!packages.TryGetValue(currentPath, out var cached))
                {
                    dynamic next = AddPackage(current, folder);
                    cached = next;
                    packages[currentPath] = cached;
                }
                current = (dynamic)cached;
            }

            var fileName = parts.Length == 0 ? sourcePath : parts[^1];
            dynamic artifact = AddElement(current, fileName, "Artifact", "IDLFile");
            AddElementTag(artifact, "idl.sourcePath", sourcePath);
            progress();
        }
    }


    private static int CountSemanticDeclarations(IEnumerable<IdlDeclaration> declarations)
    {
        var count = 0;
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
                count += CountSemanticDeclarations(module.Declarations);
            else
                count++;
        }
        return count;
    }

    private void PopulateUnion(dynamic element, IdlUnion union)
    {
        AddTypeMetadata(element, union.DiscriminatorType, "idl.discriminator");
        AddElementTag(element, "idl.discriminatorType", _typeMapper.MapAttributeType(union.DiscriminatorType));
        var index = 0;
        foreach (var unionCase in union.Cases)
        {
            dynamic attribute = AddField(element, unionCase.Field);
            AddAttributeTag(attribute, "idl.union.caseIndex", index++.ToString());
            AddAttributeTag(attribute, "idl.union.labels", string.Join(",", unionCase.Labels));
            if (unionCase.IsDefault) AddAttributeTag(attribute, "idl.union.default", "true");
        }
    }

    private void PopulateTypedef(dynamic element, IdlTypedef typedef)
    {
        AddTypeMetadata(element, typedef.UnderlyingType, "idl.underlying");
        AddElementTag(element, "idl.underlyingType", _typeMapper.MapAttributeType(typedef.UnderlyingType));
        if (typedef.ArrayDimensions.Count > 0)
            AddElementTag(element, "idl.arrayDimensions", string.Join(",", typedef.ArrayDimensions));
    }

    private void PopulateConstant(dynamic element, IdlConstant constant)
    {
        AddTypeMetadata(element, constant.Type, "idl.type");
        AddElementTag(element, "idl.type", _typeMapper.MapAttributeType(constant.Type));
        AddElementTag(element, "idl.value", constant.ValueExpression);
    }

    private void AddTypeMetadata(dynamic element, IdlTypeReference type, string prefix)
    {
        AddElementTag(element, $"{prefix}.kind", _typeMapper.MapTypeKind(type));
        if (type.BoundExpression is not null)
            AddElementTag(element, $"{prefix}.bound", type.BoundExpression);
        if (type.ElementType is not null)
            AddElementTag(element, $"{prefix}.elementType", _typeMapper.MapAttributeType(type.ElementType));
        if (type.KeyType is not null)
            AddElementTag(element, $"{prefix}.keyType", _typeMapper.MapAttributeType(type.KeyType));
        if (type.ResolvedScopedName is not null)
            AddElementTag(element, $"{prefix}.resolved", type.ResolvedScopedName);
    }

    private dynamic AddField(dynamic owner, IdlField field)
    {
        dynamic attribute = AddAttribute(owner, field.Name, _typeMapper.MapAttributeType(field.Type));
        if (field.Type.Kind == IdlTypeKind.Named && field.Type.ResolvedScopedName is { } resolved && _elements.TryGetValue(resolved, out var target))
        {
            dynamic targetElement = target;
            attribute.ClassifierID = (int)targetElement.ElementID;
            EnsureUpdated(attribute, $"attribute {field.Name}");
        }

        if (field.Dimensions.Count > 0)
            AddAttributeTag(attribute, "idl.arrayDimensions", string.Join(",", field.Dimensions));
        if (field.Type.BoundExpression is not null)
            AddAttributeTag(attribute, "idl.bound", field.Type.BoundExpression);

        foreach (var annotation in field.Annotations)
        {
            var value = annotation.Arguments ?? "true";
            AddAttributeTag(attribute, $"idl.annotation.{annotation.Name}", value);
            ApplyCanonicalAnnotation(attribute, annotation.Name, value);
        }

        return attribute;
    }

    private static void ApplyAnnotations(dynamic element, IEnumerable<IdlAnnotation> annotations)
    {
        foreach (var annotation in annotations)
        {
            var value = annotation.Arguments ?? "true";
            AddElementTag(element, $"idl.annotation.{annotation.Name}", value);
            switch (annotation.Name.ToLowerInvariant())
            {
                case "nested": AddElementTag(element, "idl.nested", value); break;
                case "key": AddElementTag(element, "idl.key", value); break;
                case "optional": AddElementTag(element, "idl.optional", value); break;
            }
        }
    }

    private static void ApplyCanonicalAnnotation(dynamic attribute, string name, string value)
    {
        switch (name.ToLowerInvariant())
        {
            case "key": AddAttributeTag(attribute, "idl.key", value); break;
            case "optional": AddAttributeTag(attribute, "idl.optional", value); break;
            case "nested": AddAttributeTag(attribute, "idl.nested", value); break;
        }
    }

    private static dynamic AddRootPackage(dynamic repository, string name)
    {
        dynamic models = repository.Models;
        dynamic package = models.AddNew(name, "");
        EnsureUpdated(package, $"root package {name}");
        models.Refresh();
        return package;
    }

    private static dynamic AddPackage(dynamic parent, string name)
    {
        dynamic packages = parent.Packages;
        dynamic package = packages.AddNew(name, "");
        EnsureUpdated(package, $"package {name}");
        packages.Refresh();
        return package;
    }

    private static dynamic AddElement(dynamic package, string name, string type, string? stereotype = null)
    {
        dynamic elements = package.Elements;
        dynamic element = elements.AddNew(name, type);
        if (!string.IsNullOrWhiteSpace(stereotype)) element.Stereotype = stereotype;
        EnsureUpdated(element, $"element {name}");
        elements.Refresh();
        return element;
    }

    private static dynamic AddAttribute(dynamic element, string name, string typeName, string? stereotype = null)
    {
        dynamic attributes = element.Attributes;
        dynamic attribute = attributes.AddNew(name, typeName);
        if (!string.IsNullOrWhiteSpace(stereotype)) attribute.Stereotype = stereotype;
        EnsureUpdated(attribute, $"attribute {name}");
        attributes.Refresh();
        return attribute;
    }

    private static void AddElementTag(dynamic element, string name, string value)
    {
        dynamic tag = element.TaggedValues.AddNew(name, "string");
        tag.Value = value;
        EnsureUpdated(tag, $"tag {name}");
        element.TaggedValues.Refresh();
    }

    private static void AddAttributeTag(dynamic attribute, string name, string value)
    {
        dynamic tag = attribute.TaggedValues.AddNew(name, "string");
        tag.Value = value;
        EnsureUpdated(tag, $"attribute tag {name}");
        attribute.TaggedValues.Refresh();
    }

    private static void EnsureUpdated(dynamic item, string description)
    {
        if ((bool)item.Update()) return;
        string error;
        try { error = (string)item.GetLastError(); }
        catch { error = "Unknown EA Automation error."; }
        throw new InvalidOperationException($"Failed to update EA {description}: {error}");
    }

    private static void TryRefreshModel(dynamic repository)
    {
        try { repository.RefreshModelView(0); }
        catch { /* Repository content is already persisted by each Update(). */ }
    }

    private static string Scoped(IReadOnlyList<string> scope, string name) => "::" + string.Join("::", scope.Append(name));
}
