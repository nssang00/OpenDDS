using System.IO.Compression;
using Idl.Parsing.Sources;

namespace Idl.Parsing.Sources;

public sealed class IdlSourceLoader
{
    public IdlSourceSet Load(string inputPath)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(inputPath);

        if (Directory.Exists(inputPath))
        {
            return LoadDirectory(inputPath);
        }

        if (File.Exists(inputPath) &&
            string.Equals(Path.GetExtension(inputPath), ".zip", StringComparison.OrdinalIgnoreCase))
        {
            return LoadZip(inputPath);
        }

        throw new FileNotFoundException($"IDL input was not found: {inputPath}", inputPath);
    }

    public IdlSourceSet LoadDirectory(string rootDirectory)
    {
        var fullRoot = Path.GetFullPath(rootDirectory);
        var result = new IdlSourceSet();

        foreach (var filePath in Directory.EnumerateFiles(fullRoot, "*", SearchOption.AllDirectories)
                     .Where(path => string.Equals(Path.GetExtension(path), ".idl", StringComparison.OrdinalIgnoreCase)))
        {
            var relativePath = IdlPath.Normalize(Path.GetRelativePath(fullRoot, filePath));
            result.AddFile(new IdlSourceFile(relativePath, File.ReadAllText(filePath)));
        }

        return result;
    }

    public IdlSourceSet LoadZip(string zipPath)
    {
        var result = new IdlSourceSet();

        using var archive = ZipFile.OpenRead(zipPath);
        foreach (var entry in archive.Entries)
        {
            if (!entry.FullName.EndsWith(".idl", StringComparison.OrdinalIgnoreCase))
            {
                continue;
            }

            using var stream = entry.Open();
            using var reader = new StreamReader(stream);
            var content = reader.ReadToEnd();
            var relativePath = IdlPath.Normalize(entry.FullName);
            result.AddFile(new IdlSourceFile(relativePath, content));
        }

        return result;
    }
}
