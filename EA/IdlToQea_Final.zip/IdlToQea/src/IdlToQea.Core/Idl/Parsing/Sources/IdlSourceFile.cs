namespace Idl.Parsing.Sources;

public sealed class IdlSourceFile
{
    private readonly List<IdlInclude> _includes = [];

    public IdlSourceFile(string relativePath, string content)
    {
        RelativePath = relativePath;
        Content = content;
    }

    public string RelativePath { get; }
    public string Content { get; }
    public IReadOnlyList<IdlInclude> Includes => _includes;

    public string DirectoryPath
    {
        get
        {
            var index = RelativePath.LastIndexOf('/');
            return index < 0 ? string.Empty : RelativePath[..index];
        }
    }

    public string FileName
    {
        get
        {
            var index = RelativePath.LastIndexOf('/');
            return index < 0 ? RelativePath : RelativePath[(index + 1)..];
        }
    }

    public void AddInclude(IdlInclude include) => _includes.Add(include);
}
