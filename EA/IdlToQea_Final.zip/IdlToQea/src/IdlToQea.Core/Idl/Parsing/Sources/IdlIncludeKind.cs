namespace Idl.Parsing.Sources;

public enum IdlIncludeKind
{
    Quoted,
    AngleBracket
}
