using Antlr4.Runtime;
using Idl.Model;
using Idl.Parsing.Sources;
using Idl.Parsing;
using Idl.Parsing.PreProcessor;

namespace Idl.Parsing;

public sealed class IdlDocumentParser
{
    private readonly IdlPreprocessor _preprocessor = new();
    public IdlParseResult Parse(IdlSourceFile sourceFile)
    {
        ArgumentNullException.ThrowIfNull(sourceFile);
        return Parse(sourceFile.Content, sourceFile.RelativePath);
    }

    public IdlParseResult Parse(string content, string sourcePath = "<memory>")
    {
        ArgumentNullException.ThrowIfNull(content);

        var document = new IdlDocument(sourcePath);
        var result = new IdlParseResult(document);

        var preprocessed = _preprocessor.Process(content, sourcePath);
        foreach (var diagnostic in preprocessed.Diagnostics)
        {
            result.AddDiagnostic(diagnostic);
        }
        if (!preprocessed.Success)
        {
            return result;
        }

        var input = new AntlrInputStream(preprocessed.Content);
        var lexer = new IDLLexer(input);
        lexer.RemoveErrorListeners();
        lexer.AddErrorListener(new IdlLexerErrorListener(result, sourcePath));

        var tokens = new CommonTokenStream(lexer);
        var parser = new IDLParser(tokens);
        parser.RemoveErrorListeners();
        parser.AddErrorListener(new IdlParseErrorListener(result, sourcePath));

        var tree = parser.specification();
        if (!result.Success)
        {
            return result;
        }

        var visitor = new IdlModelBuilderVisitor();
        foreach (var definition in tree.definition())
        {
            var declaration = visitor.Visit(definition);
            if (declaration is not null)
            {
                document.Add(declaration);
            }
        }

        return result;
    }
}
