/*
 * UMAA 6.0 IDL grammar profile.
 * The rule shapes follow the public antlr/grammars-v4 OMG IDL grammar,
 * but this file intentionally limits itself to constructs exercised by the
 * UMAA 6.0 IDL distribution plus the parser features already supported by
 * Idl.Models.
 */
grammar IDL;

specification
    : definition* EOF
    ;

definition
    : annapps (
        module
        | type_decl
        | interface_decl
        | const_decl
      ) SEMICOLON
    ;

module
    : KW_MODULE identifier LEFT_BRACE definition* RIGHT_BRACE
    ;

type_decl
    : KW_TYPEDEF annapps type_spec declarators
    | struct_type
    | union_type
    | enum_type
    ;

struct_type
    : KW_STRUCT identifier (COLON scoped_name)? LEFT_BRACE member* RIGHT_BRACE
    ;

member
    : annapps type_spec declarators SEMICOLON
    ;

enum_type
    : KW_ENUM identifier LEFT_BRACE enumerator (COMMA enumerator)* RIGHT_BRACE
    ;

enumerator
    : identifier
    ;

union_type
    : KW_UNION identifier KW_SWITCH LEFT_BRACKET annapps switch_type_spec RIGHT_BRACKET LEFT_BRACE union_case+ RIGHT_BRACE
    ;

switch_type_spec
    : primitive_type
    | scoped_name
    | enum_type
    ;

union_case
    : union_label+ annapps type_spec declarator SEMICOLON
    ;

union_label
    : annapps (KW_CASE const_expression COLON | KW_DEFAULT COLON)
    ;

const_decl
    : KW_CONST const_type identifier EQUAL const_expression
    ;

const_type
    : primitive_type
    | string_type
    | wstring_type
    | scoped_name
    ;

const_expression
    : or_expr
    ;

or_expr
    : xor_expr (PIPE xor_expr)*
    ;

xor_expr
    : and_expr (CARET and_expr)*
    ;

and_expr
    : shift_expr (AMPERSAND shift_expr)*
    ;

shift_expr
    : add_expr ((RIGHT_SHIFT | LEFT_SHIFT) add_expr)*
    ;

add_expr
    : mult_expr ((PLUS | MINUS) mult_expr)*
    ;

mult_expr
    : unary_expr ((STAR | SLASH | PERCENT) unary_expr)*
    ;

unary_expr
    : unary_operator primary_expr
    | primary_expr
    ;

unary_operator
    : MINUS | PLUS | TILDE
    ;

primary_expr
    : scoped_name
    | literal
    | LEFT_BRACKET const_expression RIGHT_BRACKET
    ;

literal
    : HEX_LITERAL
    | OCTAL_LITERAL
    | INTEGER_LITERAL
    | FLOATING_PT_LITERAL
    | STRING_LITERAL
    | CHARACTER_LITERAL
    | BOOLEAN_LITERAL
    ;

interface_decl
    : KW_INTERFACE identifier interface_inheritance_spec? LEFT_BRACE interface_export* RIGHT_BRACE
    ;

interface_inheritance_spec
    : COLON scoped_name (COMMA scoped_name)*
    ;

interface_export
    : operation_decl SEMICOLON
    ;

operation_decl
    : (type_spec | KW_VOID) identifier LEFT_BRACKET parameter_list? RIGHT_BRACKET
    ;

parameter_list
    : parameter_decl (COMMA parameter_decl)*
    ;

parameter_decl
    : annapps parameter_direction annapps type_spec annapps identifier
    ;

parameter_direction
    : KW_IN | KW_OUT | KW_INOUT
    ;

type_spec
    : primitive_type
    | sequence_type
    | set_type
    | map_type
    | string_type
    | wstring_type
    | scoped_name
    ;

sequence_type
    : KW_SEQUENCE LEFT_ANG_BRACKET annapps type_spec (COMMA positive_int_const)? RIGHT_ANG_BRACKET
    ;

set_type
    : KW_SET LEFT_ANG_BRACKET annapps type_spec (COMMA positive_int_const)? RIGHT_ANG_BRACKET
    ;

map_type
    : KW_MAP LEFT_ANG_BRACKET annapps type_spec COMMA annapps type_spec (COMMA positive_int_const)? RIGHT_ANG_BRACKET
    ;

string_type
    : KW_STRING (LEFT_ANG_BRACKET positive_int_const RIGHT_ANG_BRACKET)?
    ;

wstring_type
    : KW_WSTRING (LEFT_ANG_BRACKET positive_int_const RIGHT_ANG_BRACKET)?
    ;

primitive_type
    : KW_FLOAT
    | KW_DOUBLE
    | KW_LONG KW_DOUBLE
    | KW_SHORT
    | KW_LONG
    | KW_LONG KW_LONG
    | KW_UNSIGNED KW_SHORT
    | KW_UNSIGNED KW_LONG
    | KW_UNSIGNED KW_LONG KW_LONG
    | KW_CHAR
    | KW_BOOLEAN
    | KW_OCTET
    | KW_INT8
    | KW_UINT8
    | KW_INT16
    | KW_UINT16
    | KW_INT32
    | KW_UINT32
    | KW_INT64
    | KW_UINT64
    ;

declarators
    : declarator (COMMA declarator)*
    ;

declarator
    : annapps (simple_declarator | array_declarator)
    ;

simple_declarator
    : ID
    ;

array_declarator
    : ID fixed_array_size+
    ;

fixed_array_size
    : LEFT_SQUARE_BRACKET positive_int_const RIGHT_SQUARE_BRACKET
    ;

positive_int_const
    : const_expression
    ;

scoped_name
    : DOUBLE_COLON? ID (DOUBLE_COLON ID)*
    ;

identifier
    : annapps ID
    ;

annapps
    : annotation_appl*
    ;

annotation_appl
    : AT scoped_name (LEFT_BRACKET annotation_appl_params RIGHT_BRACKET)?
    ;

annotation_appl_params
    : const_expression
    | annotation_appl_param (COMMA annotation_appl_param)*
    ;

annotation_appl_param
    : ID EQUAL const_expression
    ;

SEMICOLON : ';';
COLON : ':';
COMMA : ',';
LEFT_BRACE : '{';
RIGHT_BRACE : '}';
LEFT_BRACKET : '(';
RIGHT_BRACKET : ')';
LEFT_SQUARE_BRACKET : '[';
RIGHT_SQUARE_BRACKET : ']';
LEFT_ANG_BRACKET : '<';
RIGHT_ANG_BRACKET : '>';
TILDE : '~';
SLASH : '/';
STAR : '*';
PLUS : '+';
MINUS : '-';
CARET : '^';
AMPERSAND : '&';
PIPE : '|';
EQUAL : '=';
PERCENT : '%';
DOUBLE_COLON : '::';
RIGHT_SHIFT : '>>';
LEFT_SHIFT : '<<';
AT : '@';

KW_MODULE : 'module';
KW_TYPEDEF : 'typedef';
KW_STRUCT : 'struct';
KW_ENUM : 'enum';
KW_INTERFACE : 'interface';
KW_UNION : 'union';
KW_SWITCH : 'switch';
KW_CASE : 'case';
KW_DEFAULT : 'default';
KW_CONST : 'const';
KW_IN : 'in';
KW_OUT : 'out';
KW_INOUT : 'inout';
KW_VOID : 'void';
KW_SEQUENCE : 'sequence';
KW_SET : 'set';
KW_MAP : 'map';
KW_STRING : 'string';
KW_WSTRING : 'wstring';
KW_BOOLEAN : 'boolean';
KW_CHAR : 'char';
KW_OCTET : 'octet';
KW_SHORT : 'short';
KW_LONG : 'long';
KW_FLOAT : 'float';
KW_DOUBLE : 'double';
KW_UNSIGNED : 'unsigned';
KW_INT8 : 'int8';
KW_UINT8 : 'uint8';
KW_INT16 : 'int16';
KW_UINT16 : 'uint16';
KW_INT32 : 'int32';
KW_UINT32 : 'uint32';
KW_INT64 : 'int64';
KW_UINT64 : 'uint64';

HEX_LITERAL
    : '0' [xX] [0-9a-fA-F]+ [lL]?
    ;

OCTAL_LITERAL
    : '0' [0-7]+ [lL]?
    ;

FLOATING_PT_LITERAL
    : [0-9]+ '.' [0-9]* EXPONENT? [fFdD]?
    | '.' [0-9]+ EXPONENT? [fFdD]?
    | [0-9]+ EXPONENT [fFdD]?
    | [0-9]+ [fFdD]
    ;

INTEGER_LITERAL
    : ('0' | [1-9] [0-9]*) [lL]?
    ;

STRING_LITERAL
    : '"' (ESCAPE_SEQUENCE | ~[\\"])* '"'
    ;

CHARACTER_LITERAL
    : '\'' (ESCAPE_SEQUENCE | ~['\\]) '\''
    ;

BOOLEAN_LITERAL
    : 'TRUE' | 'FALSE'
    ;

fragment EXPONENT
    : [eE] [+-]? [0-9]+
    ;

fragment ESCAPE_SEQUENCE
    : '\\' [btnfr"'\\]
    | '\\' 'u' [0-9a-fA-F] [0-9a-fA-F] [0-9a-fA-F] [0-9a-fA-F]
    | '\\' [0-7] [0-7]? [0-7]?
    ;

ID
    : [a-zA-Z_] [a-zA-Z_0-9]*
    ;

WS
    : [ \t\r\n\f]+ -> channel(HIDDEN)
    ;

COMMENT
    : '/*' .*? '*/' -> channel(HIDDEN)
    ;

LINE_COMMENT
    : '//' ~[\r\n]* -> channel(HIDDEN)
    ;
