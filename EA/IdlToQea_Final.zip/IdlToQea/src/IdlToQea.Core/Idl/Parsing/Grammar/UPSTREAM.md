# IDL Grammar Source

Target upstream grammar:

- Repository: `antlr/grammars-v4`
- Path: `idl/IDL.g4`
- Pinned commit: `4020a60197dc5afdcd8c88656b42e9f047ffcaf2`
- Upstream file SHA: `14a06d358215cb67e9a6664ae0cf2d31a59a2b3f`
- License: BSD-3-Clause (header is present in the upstream grammar)

Milestone 2 keeps only the rules required to prove the C# parse-tree-to-model path
(module, struct, enum and basic field types). Before UMAA-wide syntax coverage, replace
`Grammar/IDL.g4` with the pinned upstream file and add compatibility tests for UMAA.
