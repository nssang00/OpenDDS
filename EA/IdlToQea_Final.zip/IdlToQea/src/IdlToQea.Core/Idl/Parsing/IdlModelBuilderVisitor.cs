using Idl.Model;

namespace Idl.Parsing;

internal sealed class IdlModelBuilderVisitor : IDLBaseVisitor<IdlDeclaration?>
{
    public override IdlDeclaration? VisitDefinition(IDLParser.DefinitionContext context)
    {
        IdlDeclaration? declaration = context.module() is not null ? Visit(context.module())
            : context.type_decl() is not null ? Visit(context.type_decl())
            : context.interface_decl() is not null ? Visit(context.interface_decl())
            : context.const_decl() is not null ? Visit(context.const_decl())
            : null;
        if (declaration is not null) ApplyAnnotations(declaration, context.annapps());
        return declaration;
    }

    public override IdlDeclaration? VisitModule(IDLParser.ModuleContext context)
    {
        var module = new IdlModule(context.identifier().ID().GetText());
        foreach (var definition in context.definition())
        {
            var declaration = Visit(definition);
            if (declaration is not null) module.Add(declaration);
        }
        return module;
    }

    public override IdlDeclaration? VisitType_decl(IDLParser.Type_declContext context)
    {
        if (context.struct_type() is not null) return Visit(context.struct_type());
        if (context.enum_type() is not null) return Visit(context.enum_type());
        if (context.union_type() is not null) return Visit(context.union_type());
        if (context.KW_TYPEDEF() is not null)
        {
            var type = BuildType(context.type_spec());
            var declarator = context.declarators().declarator().Single();
            var (name, dims) = ReadDeclarator(declarator);
            return new IdlTypedef(name, type, dims);
        }
        return null;
    }

    public override IdlDeclaration? VisitStruct_type(IDLParser.Struct_typeContext context)
    {
        var model = new IdlStruct(
            context.identifier().ID().GetText(),
            context.scoped_name() is { } baseType ? BuildNamed(baseType.GetText()) : null);

        foreach (var member in context.member())
        {
            var type = BuildType(member.type_spec());
            foreach (var declarator in member.declarators().declarator())
            {
                var (name, dims) = ReadDeclarator(declarator);
                var field = new IdlField(name, type, dims);
                ApplyAnnotations(field, member.annapps());
                ApplyAnnotations(field, declarator.annapps());
                model.AddField(field);
            }
        }
        return model;
    }

    public override IdlDeclaration? VisitEnum_type(IDLParser.Enum_typeContext context)
    {
        var model = new IdlEnum(context.identifier().ID().GetText());
        foreach (var value in context.enumerator())
            model.AddValue(value.identifier().ID().GetText());
        return model;
    }

    public override IdlDeclaration? VisitUnion_type(IDLParser.Union_typeContext context)
    {
        var model = new IdlUnion(context.identifier().ID().GetText(), BuildType(context.switch_type_spec()));
        foreach (var unionCase in context.union_case())
        {
            var labels = unionCase.union_label()
                .Where(x => x.KW_CASE() is not null)
                .Select(x => x.const_expression().GetText())
                .ToArray();
            var isDefault = unionCase.union_label().Any(x => x.KW_DEFAULT() is not null);
            var (name, dims) = ReadDeclarator(unionCase.declarator());
            var field = new IdlField(name, BuildType(unionCase.type_spec()), dims);
            ApplyAnnotations(field, unionCase.annapps());
            ApplyAnnotations(field, unionCase.declarator().annapps());
            model.AddCase(new IdlUnionCase(labels, field, isDefault));
        }
        return model;
    }

    public override IdlDeclaration? VisitConst_decl(IDLParser.Const_declContext context) =>
        new IdlConstant(context.identifier().ID().GetText(), BuildType(context.const_type()), context.const_expression().GetText());

    public override IdlDeclaration? VisitInterface_decl(IDLParser.Interface_declContext context)
    {
        var model = new IdlInterface(context.identifier().ID().GetText());
        if (context.interface_inheritance_spec() is { } inheritance)
            foreach (var scoped in inheritance.scoped_name()) model.AddBaseInterface(BuildNamed(scoped.GetText()));

        foreach (var export in context.interface_export())
        {
            var op = export.operation_decl();
            IdlTypeReference? returnType = op.KW_VOID() is null ? BuildType(op.type_spec()) : null;
            var operation = new IdlOperation(op.identifier().ID().GetText(), returnType);
            if (op.parameter_list() is { } parameters)
            {
                foreach (var parameter in parameters.parameter_decl())
                {
                    var direction = parameter.parameter_direction().KW_OUT() is not null ? IdlParameterDirection.Out
                        : parameter.parameter_direction().KW_INOUT() is not null ? IdlParameterDirection.InOut
                        : IdlParameterDirection.In;
                    operation.AddParameter(new IdlParameter(
                        parameter.identifier().ID().GetText(),
                        BuildType(parameter.type_spec()),
                        direction));
                }
            }
            model.AddOperation(operation);
        }
        return model;
    }

    private static IdlTypeReference BuildType(IDLParser.Const_typeContext context)
    {
        if (context.string_type() is { } str)
            return new IdlTypeReference("string", IdlTypeKind.String, null, str.positive_int_const()?.GetText());

        if (context.wstring_type() is { } wstr)
            return new IdlTypeReference("wstring", IdlTypeKind.WString, null, wstr.positive_int_const()?.GetText());

        if (context.primitive_type() is not null)
            return new IdlTypeReference(context.primitive_type().GetText(), IdlTypeKind.Primitive);

        return BuildNamed(context.scoped_name().GetText());
    }

    private static IdlTypeReference BuildType(IDLParser.Switch_type_specContext context)
    {
        if (context.primitive_type() is not null)
            return new IdlTypeReference(context.primitive_type().GetText(), IdlTypeKind.Primitive);

        if (context.scoped_name() is not null)
            return BuildNamed(context.scoped_name().GetText());

        // Inline enum discriminators are legal OMG IDL. UMAA 6.0 does not currently use them,
        // but keep a structural type reference so the parser does not discard the syntax.
        return new IdlTypeReference(context.enum_type().GetText(), IdlTypeKind.Primitive);
    }

    private static IdlTypeReference BuildType(IDLParser.Type_specContext context)
    {
        if (context.sequence_type() is { } seq)
            return new IdlTypeReference(seq.GetText(), IdlTypeKind.Sequence, BuildType(seq.type_spec()), seq.positive_int_const()?.GetText());

        if (context.set_type() is { } set)
            return new IdlTypeReference(set.GetText(), IdlTypeKind.Set, BuildType(set.type_spec()), set.positive_int_const()?.GetText());

        if (context.map_type() is { } map)
        {
            var types = map.type_spec();
            return new IdlTypeReference(map.GetText(), IdlTypeKind.Map, BuildType(types[1]), map.positive_int_const()?.GetText(), BuildType(types[0]));
        }

        if (context.string_type() is { } str)
            return new IdlTypeReference("string", IdlTypeKind.String, null, str.positive_int_const()?.GetText());

        if (context.wstring_type() is { } wstr)
            return new IdlTypeReference("wstring", IdlTypeKind.WString, null, wstr.positive_int_const()?.GetText());

        if (context.primitive_type() is not null)
            return new IdlTypeReference(context.primitive_type().GetText(), IdlTypeKind.Primitive);

        return BuildNamed(context.scoped_name().GetText());
    }

    private static IdlTypeReference BuildNamed(string text) => new(text, IdlTypeKind.Named);

    private static (string Name, IReadOnlyList<string> Dimensions) ReadDeclarator(IDLParser.DeclaratorContext context)
    {
        if (context.simple_declarator() is { } simple) return (simple.ID().GetText(), Array.Empty<string>());
        var array = context.array_declarator();
        return (array.ID().GetText(), array.fixed_array_size().Select(x => x.positive_int_const().GetText()).ToArray());
    }

    private static void ApplyAnnotations(IdlDeclaration declaration, IDLParser.AnnappsContext context)
    {
        foreach (var annotation in ReadAnnotations(context)) declaration.AddAnnotation(annotation);
    }

    private static void ApplyAnnotations(IdlField field, IDLParser.AnnappsContext context)
    {
        foreach (var annotation in ReadAnnotations(context)) field.AddAnnotation(annotation);
    }

    private static IEnumerable<IdlAnnotation> ReadAnnotations(IDLParser.AnnappsContext context)
    {
        foreach (var app in context.annotation_appl())
        {
            var name = app.scoped_name().GetText();
            var args = app.annotation_appl_params()?.GetText();
            yield return new IdlAnnotation(name, args);
        }
    }
}
