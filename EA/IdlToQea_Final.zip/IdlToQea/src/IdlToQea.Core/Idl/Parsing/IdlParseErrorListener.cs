using Antlr4.Runtime;
using Idl.Model;

namespace Idl.Parsing;

internal sealed class IdlParseErrorListener(IdlParseResult result, string sourcePath) : BaseErrorListener
{
    public override void SyntaxError(
        TextWriter output,
        IRecognizer recognizer,
        IToken offendingSymbol,
        int line,
        int charPositionInLine,
        string msg,
        RecognitionException e)
    {
        result.AddDiagnostic(new IdlDiagnostic(
            "IDL100",
            IdlDiagnosticSeverity.Error,
            $"{msg} (column {charPositionInLine + 1})",
            sourcePath,
            line));
    }
}
