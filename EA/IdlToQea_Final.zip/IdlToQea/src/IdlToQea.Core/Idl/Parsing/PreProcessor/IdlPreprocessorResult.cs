using Idl.Model;

namespace Idl.Parsing.PreProcessor;

public sealed class IdlPreprocessorResult
{
    private readonly List<IdlDiagnostic> _diagnostics = [];

    public IdlPreprocessorResult(string content)
    {
        Content = content;
    }

    public string Content { get; }
    public IReadOnlyList<IdlDiagnostic> Diagnostics => _diagnostics;
    public bool Success => _diagnostics.All(x => x.Severity != IdlDiagnosticSeverity.Error);

    internal void AddDiagnostic(IdlDiagnostic diagnostic) => _diagnostics.Add(diagnostic);
}
