using System.Text;
using System.Text.RegularExpressions;
using Idl.Model;

namespace Idl.Parsing.PreProcessor;

/// <summary>
/// Preprocesses the directive subset used by UMAA 6.0 IDL.
/// Supported directives: #include, #ifndef, #define and #endif.
/// Include expansion is deliberately not performed here; include relationships
/// are resolved separately by IdlIncludeResolver so file identity is preserved.
/// </summary>
public sealed partial class IdlPreprocessor
{
    [GeneratedRegex(@"^\s*#\s*(?<directive>[A-Za-z_][A-Za-z0-9_]*)\b(?<rest>.*)$")]
    private static partial Regex DirectiveRegex();

    [GeneratedRegex(@"^\s*(?<name>[A-Za-z_][A-Za-z0-9_]*)\s*$")]
    private static partial Regex MacroNameRegex();

    public IdlPreprocessorResult Process(string content, string sourcePath = "<memory>")
    {
        ArgumentNullException.ThrowIfNull(content);

        var macros = new HashSet<string>(StringComparer.Ordinal);
        var conditions = new Stack<ConditionalFrame>();
        var output = new StringBuilder(content.Length);
        var diagnostics = new List<IdlDiagnostic>();

        using var reader = new StringReader(content);
        string? line;
        var lineNumber = 0;

        while ((line = reader.ReadLine()) is not null)
        {
            lineNumber++;
            var match = DirectiveRegex().Match(line);
            if (!match.Success)
            {
                output.AppendLine(IsActive(conditions) ? line : string.Empty);
                continue;
            }

            var directive = match.Groups["directive"].Value;
            var rest = match.Groups["rest"].Value.Trim();

            switch (directive)
            {
                case "include":
                    // Include resolution is intentionally a separate phase.
                    // Keep the same line count for diagnostics by masking it.
                    output.AppendLine();
                    break;

                case "ifndef":
                {
                    var macro = ReadMacroName(rest, sourcePath, lineNumber, directive, diagnostics);
                    if (macro is null)
                    {
                        output.AppendLine();
                        break;
                    }

                    var parentActive = IsActive(conditions);
                    conditions.Push(new ConditionalFrame(parentActive, parentActive && !macros.Contains(macro)));
                    output.AppendLine();
                    break;
                }

                case "define":
                {
                    if (IsActive(conditions))
                    {
                        var macro = ReadMacroName(rest, sourcePath, lineNumber, directive, diagnostics);
                        if (macro is not null)
                        {
                            macros.Add(macro);
                        }
                    }
                    output.AppendLine();
                    break;
                }

                case "endif":
                    if (conditions.Count == 0)
                    {
                        diagnostics.Add(Error("IDLPP003", "Unexpected #endif.", sourcePath, lineNumber));
                    }
                    else
                    {
                        conditions.Pop();
                    }
                    output.AppendLine();
                    break;

                default:
                    diagnostics.Add(Error(
                        "IDLPP001",
                        $"Unsupported preprocessor directive '#{directive}'.",
                        sourcePath,
                        lineNumber));
                    output.AppendLine();
                    break;
            }
        }

        if (conditions.Count > 0)
        {
            diagnostics.Add(Error(
                "IDLPP004",
                "Unterminated #ifndef block: missing #endif.",
                sourcePath,
                lineNumber));
        }

        var result = new IdlPreprocessorResult(output.ToString());
        foreach (var diagnostic in diagnostics)
        {
            result.AddDiagnostic(diagnostic);
        }
        return result;
    }

    private static bool IsActive(Stack<ConditionalFrame> conditions) =>
        conditions.Count == 0 || conditions.Peek().Active;

    private static string? ReadMacroName(
        string rest,
        string sourcePath,
        int lineNumber,
        string directive,
        ICollection<IdlDiagnostic> diagnostics)
    {
        var match = MacroNameRegex().Match(rest);
        if (match.Success)
        {
            return match.Groups["name"].Value;
        }

        diagnostics.Add(Error(
            "IDLPP002",
            $"Invalid #{directive} macro declaration '{rest}'. UMAA preprocessing supports name-only macros.",
            sourcePath,
            lineNumber));
        return null;
    }

    private static IdlDiagnostic Error(string code, string message, string sourcePath, int lineNumber) =>
        new(code, IdlDiagnosticSeverity.Error, message, sourcePath, lineNumber);

    private readonly record struct ConditionalFrame(bool ParentActive, bool Active);
}
