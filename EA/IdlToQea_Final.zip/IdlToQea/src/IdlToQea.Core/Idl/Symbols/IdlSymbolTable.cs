using Idl.Model;

namespace Idl.Symbols;

public sealed class IdlSymbolTable
{
    private readonly Dictionary<string, IdlDeclaration> _symbols = new(StringComparer.Ordinal);

    public int Count => _symbols.Count;
    public IReadOnlyDictionary<string, IdlDeclaration> Symbols => _symbols;

    public void Clear() => _symbols.Clear();

    public bool TryAdd(string scopedName, IdlDeclaration declaration) => _symbols.TryAdd(scopedName, declaration);

    public string? Resolve(string name, IReadOnlyList<string> scope)
    {
        if (name.StartsWith("::", StringComparison.Ordinal))
            return _symbols.ContainsKey(name) ? name : null;

        var parts = name.Split("::", StringSplitOptions.RemoveEmptyEntries);
        for (var length = scope.Count; length >= 0; length--)
        {
            var candidate = "::" + string.Join("::", scope.Take(length).Concat(parts));
            if (_symbols.ContainsKey(candidate)) return candidate;
        }

        return null;
    }
}
