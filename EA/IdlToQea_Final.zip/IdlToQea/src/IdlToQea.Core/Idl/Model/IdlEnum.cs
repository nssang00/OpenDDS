namespace Idl.Model;

public sealed class IdlEnum : IdlDeclaration
{
    private readonly List<string> _values = [];
    public IdlEnum(string name) : base(name) { }
    public IReadOnlyList<string> Values => _values;
    public void AddValue(string value) => _values.Add(value);
}
