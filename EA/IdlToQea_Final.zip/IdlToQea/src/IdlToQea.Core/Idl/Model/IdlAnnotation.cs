namespace Idl.Model;

public sealed record IdlAnnotation(string Name, string? Arguments = null);
