namespace Idl.Model;

public enum IdlDiagnosticSeverity
{
    Info,
    Warning,
    Error
}
