namespace Idl.Model;

public sealed class IdlTypedef : IdlDeclaration
{
    public IdlTypedef(string name, IdlTypeReference underlyingType, IReadOnlyList<string>? arrayDimensions = null) : base(name)
    {
        UnderlyingType = underlyingType;
        ArrayDimensions = arrayDimensions ?? Array.Empty<string>();
    }

    public IdlTypeReference UnderlyingType { get; }
    public IReadOnlyList<string> ArrayDimensions { get; }
}
