namespace Idl.Model;

public sealed record IdlTypeReference(
    string Name,
    IdlTypeKind Kind = IdlTypeKind.Named,
    IdlTypeReference? ElementType = null,
    string? BoundExpression = null,
    IdlTypeReference? KeyType = null)
{
    public bool IsScoped => Name.Contains("::", StringComparison.Ordinal);
    public string? ResolvedScopedName { get; set; }
}
