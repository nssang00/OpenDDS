namespace Idl.Model;

public enum IdlTypeKind
{
    Primitive,
    Named,
    Sequence,
    Set,
    Map,
    String,
    WString
}
