namespace Idl.Model;

public sealed class IdlDocument
{
    private readonly List<IdlDeclaration> _declarations = [];

    public IdlDocument(string sourcePath) => SourcePath = sourcePath;

    public string SourcePath { get; }
    public IReadOnlyList<IdlDeclaration> Declarations => _declarations;
    public void Add(IdlDeclaration declaration) => _declarations.Add(declaration);
}
