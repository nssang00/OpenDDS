using Idl.Parsing;
using Idl.Symbols;

namespace Idl.Parser.Tests;

public sealed class UmaaCorpusAcceptanceTests
{
    public void OfficialUmaa60Corpus_ParsesAndResolvesWithoutErrors()
    {
        var zipPath = Environment.GetEnvironmentVariable("UMAA_IDL_ZIP");
        if (string.IsNullOrWhiteSpace(zipPath) || !File.Exists(zipPath))
        {
            // Portable unit-test runs do not carry the copyrighted/external UMAA corpus.
            // Set UMAA_IDL_ZIP to enable the strict acceptance test.
            return;
        }

        var workspace = new IdlSourceWorkspace();
        var sourceSet = workspace.Load(zipPath);

        Assert.Equal(594, sourceSet.Files.Count);
        Assert.Equal(1705, sourceSet.Files.Sum(x => x.Includes.Count));
        Assert.All(sourceSet.Files.SelectMany(x => x.Includes), include => Assert.True(include.IsResolved));
        Assert.DoesNotContain(sourceSet.Diagnostics, d => d.Severity == Idl.Model.IdlDiagnosticSeverity.Error);

        var builder = new IdlModelResolver();
        var model = builder.Resolve(sourceSet);

        Assert.True(
            builder.Success,
            string.Join(Environment.NewLine, builder.Diagnostics.Select(x => $"{x.Code}: {x.SourcePath}:{x.LineNumber} {x.Message}")));
        Assert.Equal(594, builder.DocumentCount);
        Assert.Equal(858, builder.SymbolCount);
        Assert.DoesNotContain(builder.Diagnostics, d => d.Code == "IDL2002");
    }
}
