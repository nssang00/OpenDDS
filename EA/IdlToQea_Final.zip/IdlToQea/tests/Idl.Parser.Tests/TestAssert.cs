using System.Collections;

namespace Idl.Parser.Tests;

internal static class Assert
{
    public static void True(bool condition, string? message = null)
    {
        if (!condition) throw new TestFailureException(message ?? "Expected true but was false.");
    }

    public static void False(bool condition, string? message = null)
    {
        if (condition) throw new TestFailureException(message ?? "Expected false but was true.");
    }

    public static void Null(object? value)
    {
        if (value is not null) throw new TestFailureException($"Expected null but was {value}.");
    }

    public static void NotNull(object? value)
    {
        if (value is null) throw new TestFailureException("Expected non-null value.");
    }

    public static void Empty<T>(IEnumerable<T> values)
    {
        if (values.Any()) throw new TestFailureException("Expected empty collection.");
    }

    public static T Single<T>(IEnumerable<T> values)
    {
        var array = values.ToArray();
        if (array.Length != 1) throw new TestFailureException($"Expected single item but found {array.Length}.");
        return array[0];
    }

    public static T IsType<T>(object? value)
    {
        if (value is T typed) return typed;
        throw new TestFailureException($"Expected type {typeof(T).Name} but was {value?.GetType().Name ?? "null"}.");
    }

    public static void Equal<T>(T expected, T actual)
    {
        if (expected is string || actual is string || expected is not IEnumerable expectedEnumerable || actual is not IEnumerable actualEnumerable)
        {
            if (!EqualityComparer<T>.Default.Equals(expected, actual))
                throw new TestFailureException($"Expected '{expected}' but was '{actual}'.");
            return;
        }

        var expectedItems = expectedEnumerable.Cast<object?>().ToArray();
        var actualItems = actualEnumerable.Cast<object?>().ToArray();
        if (!expectedItems.SequenceEqual(actualItems))
            throw new TestFailureException($"Sequences differ. Expected [{string.Join(", ", expectedItems)}], actual [{string.Join(", ", actualItems)}].");
    }

    public static void Contains(string expectedSubstring, string actual)
    {
        if (!actual.Contains(expectedSubstring, StringComparison.Ordinal))
            throw new TestFailureException($"Expected substring '{expectedSubstring}' was not found.");
    }

    public static void DoesNotContain(string unexpectedSubstring, string actual)
    {
        if (actual.Contains(unexpectedSubstring, StringComparison.Ordinal))
            throw new TestFailureException($"Unexpected substring '{unexpectedSubstring}' was found.");
    }

    public static void Contains<T>(T expected, IEnumerable<T> values)
    {
        if (!values.Contains(expected)) throw new TestFailureException($"Expected item '{expected}' was not found.");
    }

    public static void Contains<T>(IEnumerable<T> values, Func<T, bool> predicate)
    {
        if (!values.Any(predicate)) throw new TestFailureException("Expected matching item was not found.");
    }

    public static void Contains<T>(IEnumerable<T> values, T expected)
    {
        if (!values.Contains(expected)) throw new TestFailureException($"Expected item '{expected}' was not found.");
    }

    public static void DoesNotContain<T>(IEnumerable<T> values, Func<T, bool> predicate)
    {
        if (values.Any(predicate)) throw new TestFailureException("Unexpected matching item was found.");
    }

    public static void All<T>(IEnumerable<T> values, Action<T> assertion)
    {
        foreach (var value in values) assertion(value);
    }

    public static void Collection<T>(IEnumerable<T> values, params Action<T>[] inspectors)
    {
        var array = values.ToArray();
        if (array.Length != inspectors.Length)
            throw new TestFailureException($"Expected {inspectors.Length} items but found {array.Length}.");
        for (var i = 0; i < array.Length; i++) inspectors[i](array[i]);
    }
}

internal sealed class TestFailureException(string message) : Exception(message);
