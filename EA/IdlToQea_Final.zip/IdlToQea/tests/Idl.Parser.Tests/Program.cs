using System.Reflection;

namespace Idl.Parser.Tests;

internal static class Program
{
    private static int Main(string[] args)
    {
        if (args.Length > 0 && !string.IsNullOrWhiteSpace(args[0]))
            Environment.SetEnvironmentVariable("UMAA_IDL_ZIP", args[0]);

        var assembly = typeof(Program).Assembly;
        var testMethods = assembly.GetTypes()
            .Where(t => t.IsClass && t.Namespace == "Idl.Parser.Tests" && t.Name.EndsWith("Tests", StringComparison.Ordinal))
            .SelectMany(t => t.GetMethods(BindingFlags.Instance | BindingFlags.Public | BindingFlags.DeclaredOnly)
                .Where(m => m.ReturnType == typeof(void) && m.GetParameters().Length == 0)
                .Select(m => (Type: t, Method: m)))
            .OrderBy(x => x.Type.Name)
            .ThenBy(x => x.Method.Name)
            .ToArray();

        var passed = 0;
        var failed = 0;

        foreach (var test in testMethods)
        {
            try
            {
                var instance = Activator.CreateInstance(test.Type)!;
                test.Method.Invoke(instance, null);
                Console.WriteLine($"PASS {test.Type.Name}.{test.Method.Name}");
                passed++;
            }
            catch (TargetInvocationException ex)
            {
                failed++;
                var error = ex.InnerException ?? ex;
                Console.WriteLine($"FAIL {test.Type.Name}.{test.Method.Name}");
                Console.WriteLine($"     {error.GetType().Name}: {error.Message}");
            }
            catch (Exception ex)
            {
                failed++;
                Console.WriteLine($"FAIL {test.Type.Name}.{test.Method.Name}");
                Console.WriteLine($"     {ex.GetType().Name}: {ex.Message}");
            }
        }

        Console.WriteLine();
        Console.WriteLine($"Tests: {testMethods.Length}, Passed: {passed}, Failed: {failed}");
        return failed == 0 ? 0 : 1;
    }
}
