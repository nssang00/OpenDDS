using Idl.Model;
using Idl.Parsing;
using Idl.Symbols;

namespace Idl.Parser.Tests;

public sealed class IdlDocumentParserTests
{
    public void Parse_ModuleStructAndEnum_BuildsModel()
    {
        const string idl = """
            module UMAA {
                module Common {
                    enum Status { Unknown, Ready, Failed };
                    struct Position {
                        double latitude;
                        double longitude;
                        Status status;
                    };
                };
            };
            """;

        var result = new IdlDocumentParser().Parse(idl, "Common/Position.idl");

        Assert.True(result.Success);
        Assert.Empty(result.Diagnostics);
        var umaa = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        Assert.Equal("UMAA", umaa.Name);
        var common = Assert.IsType<IdlModule>(Assert.Single(umaa.Declarations));
        Assert.Equal("Common", common.Name);

        var status = Assert.IsType<IdlEnum>(common.Declarations[0]);
        Assert.Equal(new[] { "Unknown", "Ready", "Failed" }, status.Values);

        var position = Assert.IsType<IdlStruct>(common.Declarations[1]);
        Assert.Collection(position.Fields,
            x => { Assert.Equal("latitude", x.Name); Assert.Equal("double", x.Type.Name); },
            x => { Assert.Equal("longitude", x.Name); Assert.Equal("double", x.Type.Name); },
            x => { Assert.Equal("status", x.Name); Assert.Equal("Status", x.Type.Name); });
    }

    public void Parse_ScopedType_PreservesQualifiedName()
    {
        const string idl = """
            module UMAA {
                struct Track {
                    ::UMAA::Common::Position position;
                };
            };
            """;

        var result = new IdlDocumentParser().Parse(idl);
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        var track = Assert.IsType<IdlStruct>(Assert.Single(module.Declarations));

        Assert.True(result.Success);
        Assert.Equal("::UMAA::Common::Position", Assert.Single(track.Fields).Type.Name);
        Assert.True(Assert.Single(track.Fields).Type.IsScoped);
    }

    public void Parse_PreprocessorInclude_IsMaskedBeforeAntlrParsing()
    {
        const string idl = """
            #include "Common.idl"
            module UMAA { struct A { long value; }; };
            """;

        var result = new IdlDocumentParser().Parse(idl, "A.idl");

        Assert.True(result.Success);
        Assert.Single(result.Document.Declarations);
    }

    public void Parse_InvalidSyntax_ReturnsDiagnosticWithSourceLocation()
    {
        const string idl = "module UMAA { struct Broken { double value } ; };";

        var result = new IdlDocumentParser().Parse(idl, "Broken.idl");

        Assert.False(result.Success);
        var diagnostic = result.Diagnostics.First(x => x.Code == "IDL100");
        Assert.Equal("Broken.idl", diagnostic.SourcePath);
        Assert.NotNull(diagnostic.LineNumber);
    }

    public void Parser_ReportsLexerErrors()
    {
        const string idl = "module UMAA { struct A { long value; }; }; `";

        var result = new IdlDocumentParser().Parse(idl);

        Assert.False(result.Success);
        Assert.Contains(result.Diagnostics, x => x.Code == "IDL099");
    }
}
