using System.IO.Compression;
using Idl.Model;
using Idl.Parsing.Sources;
using Idl.Parsing;
using Idl.Symbols;
using Idl.Parsing.PreProcessor;

namespace Idl.Parser.Tests;

public sealed class IdlSourceWorkspaceTests
{
    public void DirectoryLoader_LoadsOnlyIdlFiles_AndPreservesRelativePaths()
    {
        using var temp = new TempDirectory();
        temp.Write("Common/A.idl", "struct A {};");
        temp.Write("Common/readme.txt", "ignored");
        temp.Write("Feature/B.IDL", "struct B {};");

        var sourceSet = new IdlSourceLoader().LoadDirectory(temp.Path);

        Assert.Equal(2, sourceSet.Files.Count);
        Assert.Contains(sourceSet.Files, x => x.RelativePath == "Common/A.idl");
        Assert.Contains(sourceSet.Files, x => x.RelativePath == "Feature/B.IDL");
    }

    public void ZipLoader_LoadsNestedIdlEntries()
    {
        using var temp = new TempDirectory();
        var zipPath = System.IO.Path.Combine(temp.Path, "umaa.zip");

        using (var archive = ZipFile.Open(zipPath, ZipArchiveMode.Create))
        {
            WriteEntry(archive, "Common/A.idl", "struct A {};");
            WriteEntry(archive, "Vehicle/B.idl", "struct B {};");
            WriteEntry(archive, "Vehicle/readme.md", "ignored");
        }

        var sourceSet = new IdlSourceLoader().LoadZip(zipPath);

        Assert.Equal(2, sourceSet.Files.Count);
        Assert.Contains(sourceSet.Files, x => x.RelativePath == "Common/A.idl");
        Assert.Contains(sourceSet.Files, x => x.RelativePath == "Vehicle/B.idl");
    }

    public void IncludeScanner_RecognizesQuotedAndAngleBracketIncludes()
    {
        const string idl = """
            #include "../Common/A.idl"
            # include <Shared/B.idl>
            struct X {};
            """;

        var includes = new IdlIncludeScanner().Scan(idl);

        Assert.Collection(
            includes,
            first =>
            {
                Assert.Equal("../Common/A.idl", first.Path);
                Assert.Equal(IdlIncludeKind.Quoted, first.Kind);
                Assert.Equal(1, first.LineNumber);
            },
            second =>
            {
                Assert.Equal("Shared/B.idl", second.Path);
                Assert.Equal(IdlIncludeKind.AngleBracket, second.Kind);
                Assert.Equal(2, second.LineNumber);
            });
    }

    public void Workspace_ResolvesRelativeIncludeAgainstCurrentFileDirectory()
    {
        using var temp = new TempDirectory();
        temp.Write("Common/Types.idl", "struct CommonType {};");
        temp.Write("Vehicle/Vehicle.idl", "#include \"../Common/Types.idl\"\nstruct Vehicle {};");

        var model = new IdlSourceWorkspace().Load(temp.Path);
        var vehicle = Assert.Single(model.Files.Where(x => x.RelativePath == "Vehicle/Vehicle.idl"));
        var include = Assert.Single(vehicle.Includes);

        Assert.True(include.IsResolved);
        Assert.Equal("Common/Types.idl", include.ResolvedPath);
        Assert.Empty(model.Diagnostics);
    }

    public void Resolver_UsesFullRelativePath_WhenDuplicateFileNamesExist()
    {
        using var temp = new TempDirectory();
        temp.Write("A/Types.idl", "struct AType {};");
        temp.Write("B/Types.idl", "struct BType {};");
        temp.Write("A/Feature.idl", "#include \"Types.idl\"\nstruct Feature {};");

        var model = new IdlSourceWorkspace().Load(temp.Path);
        var feature = Assert.Single(model.Files.Where(x => x.RelativePath == "A/Feature.idl"));

        Assert.Equal("A/Types.idl", Assert.Single(feature.Includes).ResolvedPath);
    }

    public void Workspace_RejectsIncludeThatEscapesSourceRoot()
    {
        using var temp = new TempDirectory();
        temp.Write("A.idl", "#include \"../../Outside.idl\"\nstruct A {};");

        var model = new IdlSourceWorkspace().Load(temp.Path);

        var diagnostic = Assert.Single(model.Diagnostics);
        Assert.Equal("IDL002", diagnostic.Code);
        Assert.Equal(IdlDiagnosticSeverity.Error, diagnostic.Severity);
    }

    public void Workspace_ReportsUnresolvedInclude()
    {
        using var temp = new TempDirectory();
        temp.Write("A.idl", "#include \"Missing.idl\"\nstruct A {};");

        var model = new IdlSourceWorkspace().Load(temp.Path);

        var diagnostic = Assert.Single(model.Diagnostics);
        Assert.Equal("IDL001", diagnostic.Code);
        Assert.Equal(IdlDiagnosticSeverity.Error, diagnostic.Severity);
        Assert.Equal("A.idl", diagnostic.SourcePath);
        Assert.Equal(1, diagnostic.LineNumber);
    }

    public void Workspace_ResolvesAngleIncludeFromConfiguredIncludeRoot()
    {
        using var temp = new TempDirectory();
        temp.Write("Shared/Common.idl", "struct Common {};");
        temp.Write("Feature.idl", "#include <Common.idl>\nstruct Feature {};");

        var model = new IdlSourceWorkspace().Load(temp.Path, ["Shared"]);
        var feature = Assert.Single(model.Files.Where(x => x.RelativePath == "Feature.idl"));

        Assert.Equal("Shared/Common.idl", Assert.Single(feature.Includes).ResolvedPath);
        Assert.Empty(model.Diagnostics);
    }

    private static void WriteEntry(ZipArchive archive, string path, string content)
    {
        var entry = archive.CreateEntry(path);
        using var writer = new StreamWriter(entry.Open());
        writer.Write(content);
    }

    private sealed class TempDirectory : IDisposable
    {
        public TempDirectory()
        {
            Path = System.IO.Path.Combine(System.IO.Path.GetTempPath(), $"IdlToQea-{Guid.NewGuid():N}");
            Directory.CreateDirectory(Path);
        }

        public string Path { get; }

        public void Write(string relativePath, string content)
        {
            var fullPath = System.IO.Path.Combine(Path, relativePath.Replace('/', System.IO.Path.DirectorySeparatorChar));
            Directory.CreateDirectory(System.IO.Path.GetDirectoryName(fullPath)!);
            File.WriteAllText(fullPath, content);
        }

        public void Dispose()
        {
            if (Directory.Exists(Path))
            {
                Directory.Delete(Path, recursive: true);
            }
        }
    }
}
