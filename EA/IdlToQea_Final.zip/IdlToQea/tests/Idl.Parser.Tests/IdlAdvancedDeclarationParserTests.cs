using Idl.Parsing;
using Idl.Model;

namespace Idl.Parser.Tests;

public sealed class IdlAdvancedDeclarationParserTests
{
    public void Parse_UnionAndConst_BuildsModels()
    {
        const string idl = """
            module UMAA {
                const long MaxTracks = 100;
                union Value switch(long) {
                    case 0: long integerValue;
                    case 1: string textValue;
                    default: octet rawValue;
                };
            };
            """;

        var result = new IdlDocumentParser().Parse(idl);

        Assert.True(result.Success, string.Join(Environment.NewLine, result.Diagnostics.Select(x => x.Message)));
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        var constant = Assert.IsType<IdlConstant>(module.Declarations[0]);
        Assert.Equal("100", constant.ValueExpression);
        var union = Assert.IsType<IdlUnion>(module.Declarations[1]);
        Assert.Equal(3, union.Cases.Count);
        Assert.True(union.Cases[2].IsDefault);
    }

    public void Parse_InterfaceOperation_PreservesReturnAndParameters()
    {
        const string idl = """
            module UMAA {
                interface Service {
                    ::UMAA::Result execute(in ::UMAA::Request request, out long status);
                    void reset();
                };
            };
            """;

        var result = new IdlDocumentParser().Parse(idl);

        Assert.True(result.Success, string.Join(Environment.NewLine, result.Diagnostics.Select(x => x.Message)));
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        var service = Assert.IsType<IdlInterface>(Assert.Single(module.Declarations));
        Assert.Equal(2, service.Operations.Count);
        Assert.Equal("::UMAA::Result", service.Operations[0].ReturnType!.Name);
        Assert.Equal(IdlParameterDirection.In, service.Operations[0].Parameters[0].Direction);
        Assert.Equal(IdlParameterDirection.Out, service.Operations[0].Parameters[1].Direction);
        Assert.Null(service.Operations[1].ReturnType);
    }
}
