using Idl.Symbols;
using Idl.Model;
using Idl.Parsing.Sources;

namespace Idl.Parser.Tests;

public sealed class IdlModelResolverTests
{
    public void Build_MultipleFiles_ResolvesAbsoluteAndRelativeTypes()
    {
        var sources = new IdlSourceSet();
        sources.AddFile(new IdlSourceFile("Common/Types.idl", """
            module UMAA { module Common { struct TrackType { long id; }; }; };
            """));
        sources.AddFile(new IdlSourceFile("Vehicle/Vehicle.idl", """
            module UMAA { module Vehicle {
                struct VehicleState {
                    ::UMAA::Common::TrackType absoluteTrack;
                    CommonAlias relativeTrack;
                };
                typedef ::UMAA::Common::TrackType CommonAlias;
            }; };
            """));

        var builder = new IdlModelResolver();
        var model = builder.Resolve(sources);

        Assert.True(builder.Success, string.Join(Environment.NewLine, builder.Diagnostics.Select(x => x.Message)));
        Assert.Contains("::UMAA::Common::TrackType", builder.Symbols.Keys);
        Assert.Contains("::UMAA::Vehicle::VehicleState", builder.Symbols.Keys);
        var vehicle = Assert.IsType<IdlStruct>(builder.Symbols["::UMAA::Vehicle::VehicleState"]);
        Assert.Equal("::UMAA::Common::TrackType", vehicle.Fields[0].Type.ResolvedScopedName);
        Assert.Equal("::UMAA::Vehicle::CommonAlias", vehicle.Fields[1].Type.ResolvedScopedName);
    }

    public void Build_UnresolvedType_ProducesDiagnostic()
    {
        var sources = new IdlSourceSet();
        sources.AddFile(new IdlSourceFile("Broken.idl", "module UMAA { struct A { MissingType value; }; };"));

        var builder = new IdlModelResolver();
        var model = builder.Resolve(sources);

        Assert.False(builder.Success);
        Assert.Contains(builder.Diagnostics, x => x.Code == "IDL2002" && x.Message.Contains("MissingType"));
    }

    public void Build_SameModuleAcrossFiles_MergesNamespaceForResolution()
    {
        var sources = new IdlSourceSet();
        sources.AddFile(new IdlSourceFile("A.idl", "module UMAA { struct A { long value; }; };"));
        sources.AddFile(new IdlSourceFile("B.idl", "module UMAA { struct B { A value; }; };"));

        var builder = new IdlModelResolver();
        var model = builder.Resolve(sources);

        Assert.True(builder.Success);
        var b = Assert.IsType<IdlStruct>(builder.Symbols["::UMAA::B"]);
        Assert.Equal("::UMAA::A", Assert.Single(b.Fields).Type.ResolvedScopedName);
    }
    public void Resolve_RootModuleName_ComesFromInput()
    {
        var sources = new IdlSourceSet();
        sources.AddFile(new IdlSourceFile("Sample.idl", "module SampleRoot { struct A { long value; }; };"));

        var resolver = new IdlModelResolver();
        var model = resolver.Resolve(sources);

        Assert.True(resolver.Success);
        Assert.Equal("SampleRoot", model.Name);
        Assert.False(model.IsSynthetic);
        Assert.Contains("::SampleRoot::A", resolver.Symbols.Keys);
    }

    public void Resolve_ReportsParsingProgressToCompletion()
    {
        var sources = new IdlSourceSet();
        sources.AddFile(new IdlSourceFile("A.idl", "module UMAA { struct A { long value; }; };"));
        sources.AddFile(new IdlSourceFile("B.idl", "module UMAA { struct B { long value; }; };"));

        var resolver = new IdlModelResolver();
        var progress = new List<(int Current, int Total)>();
        resolver.Resolve(sources, (current, total) => progress.Add((current, total)));

        Assert.True(resolver.Success);
        Assert.Equal(2, progress.Count);
        Assert.Equal((2, 2), progress[^1]);
    }

    public void Resolve_MultipleRootModules_UsesSyntheticContainerWithoutChangingScopedNames()
    {
        var sources = new IdlSourceSet();
        sources.AddFile(new IdlSourceFile("A.idl", "module Alpha { struct A { long value; }; };"));
        sources.AddFile(new IdlSourceFile("B.idl", "module Beta { struct B { long value; }; };"));

        var resolver = new IdlModelResolver();
        var model = resolver.Resolve(sources);

        Assert.True(resolver.Success);
        Assert.True(model.IsSynthetic);
        Assert.Contains(model.Declarations.OfType<IdlModule>(), x => x.Name == "Alpha");
        Assert.Contains(model.Declarations.OfType<IdlModule>(), x => x.Name == "Beta");
        Assert.Contains("::Alpha::A", resolver.Symbols.Keys);
        Assert.Contains("::Beta::B", resolver.Symbols.Keys);
    }

}
