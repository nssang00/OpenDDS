using Ea.Automation;
using Idl.Model;

var tests = new (string Name, Action Body)[]
{
    ("TypeMapper maps IDL declarations", TestTypeMapper),
    ("Generator creates module/struct/field", TestModuleStructField),
    ("Generator connects named field classifier", TestClassifier),
    ("Generator preserves annotations", TestAnnotations),
    ("Generator creates enum literals", TestEnumLiterals),
    ("Generator preserves constants", TestConstants),
    ("Generator preserves typedef sequence and array metadata", TestTypedefMetadata),
    ("Generator preserves union discriminator and cases", TestUnion),
    ("Generator writes canonical UMAA annotation tags", TestCanonicalAnnotations),
    ("Generator preserves source traceability", TestSourceTraceability),
    ("Generator merges repeated modules across files", TestRepeatedModuleMerge),
    ("Generator creates physical source tree", TestSourceTree),
    ("Generator reports progress to completion", TestProgress)
};

foreach (var test in tests)
{
    test.Body();
    Console.WriteLine($"PASS {test.Name}");
}
Console.WriteLine($"PASS {tests.Length}/{tests.Length}");

static void TestTypeMapper()
{
    var mapper = new EaTypeMapper();
    Equal("Class", mapper.MapDeclaration(new IdlStruct("S")).ElementType);
    Equal("Enumeration", mapper.MapDeclaration(new IdlEnum("E")).ElementType);
    Equal("Interface", mapper.MapDeclaration(new IdlInterface("I")).ElementType);
}

static void TestModuleStructField()
{
    var model = ModelWithModule(out var module);
    var s = new IdlStruct("Position");
    s.AddField(new IdlField("latitude", new IdlTypeReference("double", IdlTypeKind.Primitive)));
    module.Add(s);

    var repo = new FakeEaRepository();
    new EaModelGenerator().Generate(model, repo);

    var root = repo.RootPackages.Single(x => x.Name == "IDL Modules");
    var umaa = root.Children.Single(x => x.Name == "UMAA");
    var element = umaa.Elements.Items.Single(x => x.Name == "Position");
    Equal("Class", element.Type);
    Equal("double", element.Attributes.Items.Single().Type);
}

static void TestClassifier()
{
    var model = ModelWithModule(out var module);
    var position = new IdlStruct("Position");
    var state = new IdlStruct("State");
    var refType = new IdlTypeReference("Position") { ResolvedScopedName = "::UMAA::Position" };
    state.AddField(new IdlField("position", refType));
    module.Add(position); module.Add(state);

    var repo = new FakeEaRepository();
    var generator = new EaModelGenerator();
    generator.Generate(model, repo);

    dynamic positionElement = generator.Elements["::UMAA::Position"];
    var stateElement = repo.RootPackages.Single(x => x.Name == "IDL Modules").Children.Single(x => x.Name == "UMAA").Elements.Items.Single(x => x.Name == "State");
    Equal((int)positionElement.ElementID, stateElement.Attributes.Items.Single().ClassifierID);
}

static void TestAnnotations()
{
    var model = ModelWithModule(out var module);
    var s = new IdlStruct("Keyed"); s.AddAnnotation(new IdlAnnotation("appendable"));
    var field = new IdlField("id", new IdlTypeReference("long", IdlTypeKind.Primitive)); field.AddAnnotation(new IdlAnnotation("key"));
    s.AddField(field); module.Add(s);

    var repo = new FakeEaRepository(); new EaModelGenerator().Generate(model, repo);
    var e = repo.RootPackages.Single(x => x.Name == "IDL Modules").Children.Single(x => x.Name == "UMAA").Elements.Items.Single();
    Equal("true", e.Tags["idl.annotation.appendable"]);
    Equal("true", e.Attributes.Items.Single().Tags["idl.annotation.key"]);
}

static void TestEnumLiterals()
{
    var model = ModelWithModule(out var module);
    var e = new IdlEnum("Mode"); e.AddValue("Idle"); e.AddValue("Active"); module.Add(e);
    var repo = new FakeEaRepository(); new EaModelGenerator().Generate(model, repo);
    var element = repo.RootPackages.Single(x => x.Name == "IDL Modules").Children.Single(x => x.Name == "UMAA").Elements.Items.Single();
    Equal(2, element.Attributes.Items.Count);
    Equal("Idle", element.Attributes.Items[0].Name);
    Equal("enum", element.Attributes.Items[0].Stereotype);
    Equal("Active", element.Attributes.Items[1].Name);
}

static void TestConstants()
{
    var model = ModelWithModule(out var module);
    var c = new IdlConstant("MaxCount", new IdlTypeReference("unsigned long", IdlTypeKind.Primitive), "100");
    module.Add(c);
    var repo = new FakeEaRepository(); new EaModelGenerator().Generate(model, repo);
    var element = repo.RootPackages.Single(x => x.Name == "IDL Modules").Children.Single(x => x.Name == "UMAA").Elements.Items.Single();
    Equal("DataType", element.Type); Equal("IDLConstant", element.Stereotype);
    Equal("unsigned long", element.Tags["idl.type"]); Equal("primitive", element.Tags["idl.type.kind"]); Equal("100", element.Tags["idl.value"]);
}

static void TestTypedefMetadata()
{
    var model = ModelWithModule(out var module);
    var sequence = new IdlTypeReference("sequence", IdlTypeKind.Sequence, ElementType: new IdlTypeReference("octet", IdlTypeKind.Primitive), BoundExpression: "256");
    var t = new IdlTypedef("Payload", sequence, new[] { "4" }); module.Add(t);
    var repo = new FakeEaRepository(); new EaModelGenerator().Generate(model, repo);
    var element = repo.RootPackages.Single(x => x.Name == "IDL Modules").Children.Single(x => x.Name == "UMAA").Elements.Items.Single();
    Equal("sequence<octet,256>", element.Tags["idl.underlyingType"]); Equal("sequence", element.Tags["idl.underlying.kind"]);
    Equal("256", element.Tags["idl.underlying.bound"]); Equal("octet", element.Tags["idl.underlying.elementType"]); Equal("4", element.Tags["idl.arrayDimensions"]);
}

static void TestUnion()
{
    var model = ModelWithModule(out var module);
    var u = new IdlUnion("Value", new IdlTypeReference("long", IdlTypeKind.Primitive));
    u.AddCase(new IdlUnionCase(new[] { "0", "1" }, new IdlField("number", new IdlTypeReference("long", IdlTypeKind.Primitive))));
    u.AddCase(new IdlUnionCase(Array.Empty<string>(), new IdlField("text", new IdlTypeReference("string", IdlTypeKind.String)), true));
    module.Add(u);
    var repo = new FakeEaRepository(); new EaModelGenerator().Generate(model, repo);
    var e = repo.RootPackages.Single(x => x.Name == "IDL Modules").Children.Single(x => x.Name == "UMAA").Elements.Items.Single();
    Equal("long", e.Tags["idl.discriminatorType"]); Equal("0,1", e.Attributes.Items.Single(x => x.Name == "number").Tags["idl.union.labels"]);
    Equal("true", e.Attributes.Items.Single(x => x.Name == "text").Tags["idl.union.default"]);
}

static void TestCanonicalAnnotations()
{
    var model = ModelWithModule(out var module);
    var s = new IdlStruct("Record"); s.AddAnnotation(new IdlAnnotation("nested"));
    var id = new IdlField("id", new IdlTypeReference("long", IdlTypeKind.Primitive)); id.AddAnnotation(new IdlAnnotation("key"));
    var note = new IdlField("note", new IdlTypeReference("string", IdlTypeKind.String)); note.AddAnnotation(new IdlAnnotation("optional"));
    s.AddField(id); s.AddField(note); module.Add(s);
    var repo = new FakeEaRepository(); new EaModelGenerator().Generate(model, repo);
    var e = repo.RootPackages.Single(x => x.Name == "IDL Modules").Children.Single(x => x.Name == "UMAA").Elements.Items.Single();
    Equal("true", e.Tags["idl.nested"]); Equal("true", e.Attributes.Items.Single(x => x.Name == "id").Tags["idl.key"]);
    Equal("true", e.Attributes.Items.Single(x => x.Name == "note").Tags["idl.optional"]);
}

static void TestSourceTraceability()
{
    var model = ModelWithModule(out var module); var s = new IdlStruct("S"); module.Add(s);
    var repo = new FakeEaRepository(); new EaModelGenerator().Generate(model, repo);
    var e = repo.RootPackages.Single(x => x.Name == "IDL Modules").Children.Single(x => x.Name == "UMAA").Elements.Items.Single();
    Equal("sample.idl", e.Tags["idl.sourcePath"]); Equal("::UMAA::S", e.Tags["idl.scopedName"]);
}

static void TestRepeatedModuleMerge()
{
    var model = new IdlModule("UMAA");
    model.AddSourcePath("a.idl"); model.AddSourcePath("b.idl");
    model.Add(new IdlStruct("a") { SourcePath = "a.idl" });
    model.Add(new IdlStruct("b") { SourcePath = "b.idl" });
    var repo = new FakeEaRepository(); new EaModelGenerator().Generate(model, repo);
    var root = repo.RootPackages.Single(x => x.Name == "IDL Modules");
    Equal(1, root.Children.Count(x => x.Name == "UMAA")); Equal(2, root.Children.Single(x => x.Name == "UMAA").Elements.Items.Count);
}

static void TestProgress()
{
    var model = ModelWithModule(out var module);
    module.Add(new IdlStruct("State") { SourcePath = "sample.idl" });
    var progress = new List<(int Current, int Total)>();
    var repo = new FakeEaRepository();

    new EaModelGenerator().Generate(model, repo, progress: (current, total) => progress.Add((current, total)));

    if (progress.Count == 0) throw new Exception("Expected progress callbacks.");
    Equal(progress[^1].Total, progress[^1].Current);
}

static void TestSourceTree()
{
    var model = new IdlModule("UMAA");
    model.AddSourcePath("Services/Vehicle/State.idl");
    model.Add(new IdlStruct("State") { SourcePath = "Services/Vehicle/State.idl" });
    var repo = new FakeEaRepository(); new EaModelGenerator().Generate(model, repo);
    var file = repo.RootPackages.Single(x => x.Name == "IDL Sources").Children.Single(x => x.Name == "Services").Children.Single(x => x.Name == "Vehicle").Elements.Items.Single();
    Equal("State.idl", file.Name); Equal("Artifact", file.Type); Equal("IDLFile", file.Stereotype); Equal("Services/Vehicle/State.idl", file.Tags["idl.sourcePath"]);
}

static IdlModule ModelWithModule(out IdlModule module)
{
    module = new IdlModule("UMAA");
    module.AddSourcePath("sample.idl");
    return module;
}

static void Equal<T>(T expected, T actual)
{
    if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception($"Expected {expected}, actual {actual}");
}

// Test-only in-memory objects shaped like the EA Automation object model.
public sealed class FakeEaRepository
{
    public FakePackageCollection Models { get; } = new();
    public IReadOnlyList<FakePackage> RootPackages => Models.Items;
    public void RefreshModelView(int packageId) { }
}

public sealed class FakePackageCollection
{
    public List<FakePackage> Items { get; } = [];
    public FakePackage AddNew(string name, string type) { var x = new FakePackage(name); Items.Add(x); return x; }
    public void Refresh() { }
}

public sealed class FakePackage(string name)
{
    public string Name { get; set; } = name;
    public FakePackageCollection Packages { get; } = new();
    public List<FakePackage> Children => Packages.Items;
    public FakeElementCollection Elements { get; } = new();
    public bool Update() => true;
    public string GetLastError() => string.Empty;
}

public sealed class FakeElementCollection
{
    public List<FakeElement> Items { get; } = [];
    public FakeElement AddNew(string name, string type) { var x = new FakeElement(name, type); Items.Add(x); return x; }
    public void Refresh() { }
}

public sealed class FakeElement
{
    private static int _next = 1;
    public FakeElement(string name, string type)
    {
        Name = name; Type = type; TaggedValues = new FakeTaggedValueCollection(Tags);
    }
    public int ElementID { get; } = _next++;
    public string Name { get; set; }
    public string Type { get; set; }
    public string? Stereotype { get; set; }
    public FakeAttributeCollection Attributes { get; } = new();
    public FakeTaggedValueCollection TaggedValues { get; }
    public Dictionary<string, string> Tags { get; } = [];
    public bool Update() => true;
    public string GetLastError() => string.Empty;
}

public sealed class FakeAttributeCollection
{
    public List<FakeAttribute> Items { get; } = [];
    public FakeAttribute AddNew(string name, string type) { var x = new FakeAttribute(name, type); Items.Add(x); return x; }
    public void Refresh() { }
}

public sealed class FakeAttribute
{
    public FakeAttribute(string name, string type)
    {
        Name = name; Type = type; TaggedValues = new FakeTaggedValueCollection(Tags);
    }
    public string Name { get; set; }
    public string Type { get; set; }
    public string? Stereotype { get; set; }
    public int? ClassifierID { get; set; }
    public FakeTaggedValueCollection TaggedValues { get; }
    public Dictionary<string, string> Tags { get; } = [];
    public bool Update() => true;
    public string GetLastError() => string.Empty;
}

public sealed class FakeTaggedValueCollection
{
    private readonly Dictionary<string, string> _target;
    public FakeTaggedValueCollection(Dictionary<string, string> target) => _target = target;
    public FakeTaggedValue AddNew(string name, string type) => new(name, _target);
    public void Refresh() { }
}

public sealed class FakeTaggedValue(string name, Dictionary<string, string> target)
{
    public string Name { get; } = name;
    public string Value { get; set; } = string.Empty;
    public bool Update() { target[Name] = Value; return true; }
    public string GetLastError() => string.Empty;
}
