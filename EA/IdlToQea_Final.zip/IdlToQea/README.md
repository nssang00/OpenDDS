# IdlToQea

UMAA 6.0 OMG IDL을 읽어 Sparx Enterprise Architect `.qea` 모델로 변환하는 C#/.NET 8 CLI 도구입니다.

## Project structure

```text
IdlToQea/
├─ src/
│  ├─ IdlToQea.Core/
│  └─ IdlToQea.Cli/
├─ tests/
│  ├─ Idl.Parser.Tests/
│  └─ Ea.Automation.Tests/
├─ IdlToQea.sln
└─ README.md
```

## Requirements

- Windows
- .NET 8 SDK
- Sparx Enterprise Architect installed
- `EABase.qea` is bundled in `src/IdlToQea.Cli/Resources`

## Build

Run from the directory containing `IdlToQea.sln`:

```powershell
dotnet restore
dotnet build -c Release
```

## Run

ZIP input:

```powershell
dotnet run --project src\IdlToQea.Cli -- `
  --input "C:\UMAA\umaa-6.0-idl-with-exp-services.zip" `
  --output "C:\Output\UMAA.qea"
```

Folder input:

```powershell
dotnet run --project src\IdlToQea.Cli -- `
  --input "C:\UMAA\IDL" `
  --output "C:\Output\UMAA.qea"
```

The folder input is searched recursively for `.idl` files.

## Tests

Tests use simple console runners and do not require xUnit or another test framework.

```powershell
dotnet run --project tests\Idl.Parser.Tests -- "C:\UMAA\umaa-6.0-idl-with-exp-services.zip"
dotnet run --project tests\Ea.Automation.Tests
```

## UMAA 6.0 validation

- IDL files: 594
- Includes: 1705
- Symbols: 858
- Parser errors: 0
- Parser tests: PASS
- Automation tests: PASS
