#include "importer/EaImporter.h"
#include "db/SqliteDynamic.h"

#include <algorithm>
#include <cctype>
#include <map>
#include <sstream>
#include <vector>

namespace eatransform {
namespace importer {

namespace {

std::string lower(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
        return static_cast<char>(std::tolower(c));
    });
    return value;
}

void bindOptionalText(db::Statement& stmt, int index, const std::string& value) {
    if (value.empty()) {
        stmt.bindNull(index);
    } else {
        stmt.bind(index, value);
    }
}

}  // namespace

EaImporter::EaImporter(db::Connection& output) : output_(output) {}

int EaImporter::importFrom(db::Connection& ea, const ImportOptions& options) {
    clearOutput();
    const int projectId = insertProject(options);
    importPackages(ea, projectId);
    importTypes(ea, projectId);
    importMembers(ea, projectId);
    importRelations(ea, projectId);
    return projectId;
}

void EaImporter::clearOutput() {
    packageIdByEaPackageId_.clear();
    moduleIdByEaPackageId_.clear();
    moduleQNameByEaPackageId_.clear();
    typeIdByEaObjectId_.clear();

    output_.exec("PRAGMA foreign_keys = OFF;");
    output_.exec("DELETE FROM relations;");
    output_.exec("DELETE FROM application_participants;");
    output_.exec("DELETE FROM applications;");
    output_.exec("DELETE FROM application_libraries;");
    output_.exec("DELETE FROM qos_policies;");
    output_.exec("DELETE FROM qos_entities;");
    output_.exec("DELETE FROM qos_profiles;");
    output_.exec("DELETE FROM qos_libraries;");
    output_.exec("DELETE FROM data_readers;");
    output_.exec("DELETE FROM subscribers;");
    output_.exec("DELETE FROM data_writers;");
    output_.exec("DELETE FROM publishers;");
    output_.exec("DELETE FROM topics;");
    output_.exec("DELETE FROM registered_types;");
    output_.exec("DELETE FROM participants;");
    output_.exec("DELETE FROM domain_participant_libraries;");
    output_.exec("DELETE FROM domains;");
    output_.exec("DELETE FROM domain_libraries;");
    output_.exec("DELETE FROM type_members;");
    output_.exec("DELETE FROM type_definitions;");
    output_.exec("DELETE FROM modules;");
    output_.exec("DELETE FROM packages;");
    output_.exec("DELETE FROM projects;");
    output_.exec("PRAGMA foreign_keys = ON;");
    output_.exec("VACUUM;");
}

int EaImporter::insertProject(const ImportOptions& options) {
    auto stmt = output_.prepare("INSERT INTO projects(name, source_path) VALUES(?, ?);");
    stmt.bind(1, options.projectName);
    bindOptionalText(stmt, 2, options.sourcePath);
    stmt.execute();
    return static_cast<int>(sqlite3_last_insert_rowid(output_.handle()));
}

void EaImporter::importPackages(db::Connection& ea, int projectId) {
    auto query = ea.prepare(R"sql(
WITH RECURSIVE selected_packages AS (
    SELECT DISTINCT Package_ID
    FROM t_object o
    WHERE o.Object_Type IN ('Class', 'Enumeration', 'DataType')
      AND EXISTS (
          SELECT 1
          FROM t_attribute a
          WHERE a.Object_ID = o.Object_ID
      )
),
package_tree AS (
    SELECT p.Package_ID, p.Parent_ID, p.Name
    FROM t_package p
    JOIN selected_packages sp ON p.Package_ID = sp.Package_ID
    UNION
    SELECT parent.Package_ID, parent.Parent_ID, parent.Name
    FROM t_package parent
    JOIN package_tree child ON child.Parent_ID = parent.Package_ID
)
SELECT DISTINCT Package_ID, Parent_ID, Name
FROM package_tree
ORDER BY Parent_ID, Package_ID;
)sql");

    std::map<int, PackageRow> rows;
    while (query.step()) {
        PackageRow row;
        row.eaPackageId = query.columnInt(0);
        row.parentEaPackageId = query.columnIsNull(1) ? 0 : query.columnInt(1);
        row.name = query.columnText(2);
        rows[row.eaPackageId] = row;
    }

    auto insertPackage = output_.prepare(R"sql(
INSERT INTO packages(project_id, parent_id, name, qualified_name, source_kind, source_ref, sort_order)
VALUES(?, ?, ?, ?, ?, ?, ?);
)sql");

    auto insertModule = output_.prepare(R"sql(
INSERT INTO modules(project_id, package_id, parent_id, name, qualified_name, sort_order)
VALUES(?, ?, ?, ?, ?, ?);
)sql");

    bool madeProgress = true;
    int sortOrder = 0;
    while (moduleIdByEaPackageId_.size() < rows.size() && madeProgress) {
        madeProgress = false;
        for (std::map<int, PackageRow>::const_iterator it = rows.begin(); it != rows.end(); ++it) {
            const int eaId = it->first;
            const PackageRow& row = it->second;
            if (moduleIdByEaPackageId_.count(eaId) != 0) {
                continue;
            }
            const bool hasParent = row.parentEaPackageId != 0 && rows.count(row.parentEaPackageId) != 0;
            if (hasParent && moduleIdByEaPackageId_.count(row.parentEaPackageId) == 0) {
                continue;
            }

            const int parentPackageId = hasParent ? packageIdByEaPackageId_.at(row.parentEaPackageId) : 0;
            const int parentModuleId = hasParent ? moduleIdByEaPackageId_.at(row.parentEaPackageId) : 0;
            const std::string parentName = hasParent ? moduleQNameByEaPackageId_.at(row.parentEaPackageId) : "";
            const std::string moduleQName = qualifiedName(parentName, row.name);

            insertPackage.bind(1, projectId);
            if (parentPackageId == 0) {
                insertPackage.bindNull(2);
            } else {
                insertPackage.bind(2, parentPackageId);
            }
            insertPackage.bind(3, row.name);
            insertPackage.bind(4, moduleQName);
            insertPackage.bind(5, "sparx_ea");
            insertPackage.bindNull(6);
            insertPackage.bind(7, sortOrder);
            insertPackage.execute();
            const int packageId = static_cast<int>(sqlite3_last_insert_rowid(output_.handle()));
            packageIdByEaPackageId_[eaId] = packageId;
            insertPackage.reset();

            insertModule.bind(1, projectId);
            insertModule.bind(2, packageId);
            if (parentModuleId == 0) {
                insertModule.bindNull(3);
            } else {
                insertModule.bind(3, parentModuleId);
            }
            insertModule.bind(4, row.name);
            insertModule.bind(5, moduleQName);
            insertModule.bind(6, sortOrder++);
            insertModule.execute();
            moduleIdByEaPackageId_[eaId] = static_cast<int>(sqlite3_last_insert_rowid(output_.handle()));
            moduleQNameByEaPackageId_[eaId] = moduleQName;
            insertModule.reset();
            madeProgress = true;
        }
    }
}

void EaImporter::importTypes(db::Connection& ea, int projectId) {
    auto query = ea.prepare(R"sql(
SELECT Object_ID, ea_guid, Name, Object_Type, Stereotype, Package_ID, Note, Alias
FROM t_object o
WHERE o.Object_Type IN ('Class', 'Enumeration', 'DataType')
  AND EXISTS (
      SELECT 1
      FROM t_attribute a
      WHERE a.Object_ID = o.Object_ID
  )
ORDER BY Package_ID, Object_ID;
)sql");

    auto insert = output_.prepare(R"sql(
INSERT INTO type_definitions(project_id, package_id, module_id, name, qualified_name, kind, type_kind, base_type_name, sort_order)
VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?);
)sql");

    int sortOrder = 0;
    while (query.step()) {
        const int objectId = query.columnInt(0);
        const std::string name = query.columnText(2);
        const std::string objectType = query.columnText(3);
        const std::string stereotype = query.columnText(4);
        const int eaPackageId = query.columnIsNull(5) ? 0 : query.columnInt(5);
        const std::string alias = query.columnText(7);
        const int packageId = packageIdByEaPackageId_.count(eaPackageId) ? packageIdByEaPackageId_.at(eaPackageId) : 0;
        const int moduleId = moduleIdByEaPackageId_.count(eaPackageId) ? moduleIdByEaPackageId_.at(eaPackageId) : 0;
        const std::string moduleQName = moduleQNameByEaPackageId_.count(eaPackageId) ? moduleQNameByEaPackageId_.at(eaPackageId) : "";
        const std::string kind = classifyObject(objectType, stereotype);
        const std::string baseType = alias.empty() ? "" : alias;

        insert.bind(1, projectId);
        if (packageId == 0) {
            insert.bindNull(2);
        } else {
            insert.bind(2, packageId);
        }
        if (moduleId == 0) {
            insert.bindNull(3);
        } else {
            insert.bind(3, moduleId);
        }
        insert.bind(4, name);
        insert.bind(5, qualifiedName(moduleQName, name));
        insert.bind(6, kind);
        bindOptionalText(insert, 7, kind == "typedef" ? typeKindForEaType(baseType) : "");
        bindOptionalText(insert, 8, baseType);
        insert.bind(9, sortOrder++);
        insert.execute();
        typeIdByEaObjectId_[objectId] = static_cast<int>(sqlite3_last_insert_rowid(output_.handle()));
        insert.reset();
    }
}

void EaImporter::importMembers(db::Connection& ea, int projectId) {
    auto query = ea.prepare(R"sql(
SELECT a.ID, a.ea_guid, a.Object_ID, a.Name, a.Type, a.Classifier, a.Stereotype,
       a.LowerBound, a.UpperBound, a.[Default], a.Notes, a.Pos, o.Object_Type
FROM t_attribute a
JOIN t_object o ON o.Object_ID = a.Object_ID
WHERE o.Object_Type IN ('Class', 'DataType', 'Enumeration')
ORDER BY a.Object_ID, a.Pos;
)sql");

    auto insert = output_.prepare(R"sql(
INSERT INTO type_members(project_id, type_definition_id, name, member_kind,
                         type_kind, type_name, type_ref_id, lower_bound, upper_bound, default_value, sort_order)
VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
)sql");

    while (query.step()) {
        const int ownerObjectId = query.columnInt(2);
        if (typeIdByEaObjectId_.count(ownerObjectId) == 0) {
            continue;
        }
        const std::string objectType = query.columnText(12);
        const std::string typeName = query.columnText(4);
        const int classifier = query.columnIsNull(5) ? 0 : query.columnInt(5);
        const int typeRefId = classifier != 0 && typeIdByEaObjectId_.count(classifier) ? typeIdByEaObjectId_.at(classifier) : 0;

        insert.bind(1, projectId);
        insert.bind(2, typeIdByEaObjectId_.at(ownerObjectId));
        insert.bind(3, query.columnText(3));
        insert.bind(4, objectType == "Enumeration" ? "enumerator" : "field");
        bindOptionalText(insert, 5, typeKindForEaType(typeName));
        bindOptionalText(insert, 6, typeName);
        if (typeRefId == 0) {
            insert.bindNull(7);
        } else {
            insert.bind(7, typeRefId);
        }
        bindOptionalText(insert, 8, query.columnText(7));
        bindOptionalText(insert, 9, query.columnText(8));
        bindOptionalText(insert, 10, query.columnText(9));
        insert.bind(11, query.columnIsNull(11) ? 0 : query.columnInt(11));
        insert.execute();
        insert.reset();
    }
}

void EaImporter::importRelations(db::Connection& ea, int projectId) {
    auto query = ea.prepare(R"sql(
WITH selected_objects AS (
    SELECT Object_ID
    FROM t_object o
    WHERE o.Object_Type IN ('Class', 'Enumeration', 'DataType')
      AND EXISTS (
          SELECT 1
          FROM t_attribute a
          WHERE a.Object_ID = o.Object_ID
      )
)
SELECT c.Connector_ID, c.ea_guid, c.Name, c.Connector_Type, c.Stereotype,
       c.Start_Object_ID, c.End_Object_ID, c.SourceRole, c.DestRole,
       c.SourceCard, c.DestCard, c.Notes
FROM t_connector c
WHERE c.Connector_Type IN ('Association', 'Dependency', 'Realisation', 'Aggregation', 'Generalization')
AND (
    c.Start_Object_ID IN (SELECT Object_ID FROM selected_objects)
    OR c.End_Object_ID IN (SELECT Object_ID FROM selected_objects)
)
ORDER BY c.Connector_ID;
)sql");

    auto insert = output_.prepare(R"sql(
INSERT INTO relations(project_id, source_type_id, target_type_id, relation_kind,
                      name, source_role, target_role, source_cardinality, target_cardinality, annotations_json)
VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
)sql");

    while (query.step()) {
        const int sourceObjectId = query.columnInt(5);
        const int targetObjectId = query.columnInt(6);
        const int sourceTypeId = typeIdByEaObjectId_.count(sourceObjectId) ? typeIdByEaObjectId_.at(sourceObjectId) : 0;
        const int targetTypeId = typeIdByEaObjectId_.count(targetObjectId) ? typeIdByEaObjectId_.at(targetObjectId) : 0;
        if (sourceTypeId == 0 && targetTypeId == 0) {
            continue;
        }

        insert.bind(1, projectId);
        if (sourceTypeId == 0) {
            insert.bindNull(2);
        } else {
            insert.bind(2, sourceTypeId);
        }
        if (targetTypeId == 0) {
            insert.bindNull(3);
        } else {
            insert.bind(3, targetTypeId);
        }
        insert.bind(4, lower(query.columnText(3)));
        bindOptionalText(insert, 5, query.columnText(2));
        bindOptionalText(insert, 6, query.columnText(7));
        bindOptionalText(insert, 7, query.columnText(8));
        bindOptionalText(insert, 8, query.columnText(9));
        bindOptionalText(insert, 9, query.columnText(10));
        bindOptionalText(insert, 10, "");
        insert.execute();
        insert.reset();
    }
}

std::string EaImporter::classifyObject(const std::string& objectType, const std::string& stereotype) {
    const std::string s = lower(stereotype);
    if (objectType == "Enumeration") {
        return "enum";
    }
    if (objectType == "Interface") {
        return "interface";
    }
    if (s.find("union") != std::string::npos) {
        return "union";
    }
    if (objectType == "DataType" || s.find("typedef") != std::string::npos) {
        return "typedef";
    }
    if (objectType == "Class") {
        return "struct";
    }
    return "unknown";
}

std::string EaImporter::qualifiedName(const std::string& packageName, const std::string& localName) {
    if (packageName.empty()) {
        return localName;
    }
    return packageName + "::" + localName;
}

std::string EaImporter::typeKindForEaType(const std::string& typeName) {
    const std::string t = lower(typeName);
    if (t == "bool" || t == "boolean") {
        return "boolean";
    }
    if (t == "char") {
        return "char8";
    }
    if (t == "wchar" || t == "wchar_t") {
        return "char16";
    }
    if (t == "byte" || t == "octet") {
        return "byte";
    }
    if (t == "short" || t == "int16") {
        return "int16";
    }
    if (t == "unsigned short" || t == "uint16") {
        return "uint16";
    }
    if (t == "int" || t == "long" || t == "int32") {
        return "int32";
    }
    if (t == "unsigned int" || t == "unsigned long" || t == "uint32") {
        return "uint32";
    }
    if (t == "long long" || t == "int64") {
        return "int64";
    }
    if (t == "unsigned long long" || t == "uint64") {
        return "uint64";
    }
    if (t == "float" || t == "float32") {
        return "float32";
    }
    if (t == "double" || t == "float64") {
        return "float64";
    }
    if (t == "string" || t == "std::string") {
        return "string";
    }
    if (t == "wstring" || t == "std::wstring") {
        return "wstring";
    }
    return typeName.empty() ? "unknown" : "named";
}

}  // namespace importer
}  // namespace eatransform
