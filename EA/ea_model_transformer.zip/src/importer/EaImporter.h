#pragma once

#include "db/SqliteConnection.h"

#include <string>
#include <unordered_map>

namespace eatransform {
namespace importer {

struct ImportOptions {
    std::string sourcePath;
    std::string projectName = "EA Import";
};

class EaImporter {
public:
    explicit EaImporter(db::Connection& output);

    int importFrom(db::Connection& ea, const ImportOptions& options);

private:
    struct PackageRow {
        int eaPackageId = 0;
        int parentEaPackageId = 0;
        std::string name;
    };

    static std::string classifyObject(const std::string& objectType, const std::string& stereotype);
    static std::string qualifiedName(const std::string& packageName, const std::string& localName);
    static std::string typeKindForEaType(const std::string& typeName);

    void clearOutput();
    int insertProject(const ImportOptions& options);
    void importPackages(db::Connection& ea, int projectId);
    void importTypes(db::Connection& ea, int projectId);
    void importMembers(db::Connection& ea, int projectId);
    void importRelations(db::Connection& ea, int projectId);

    db::Connection& output_;
    std::unordered_map<int, int> packageIdByEaPackageId_;
    std::unordered_map<int, int> moduleIdByEaPackageId_;
    std::unordered_map<int, std::string> moduleQNameByEaPackageId_;
    std::unordered_map<int, int> typeIdByEaObjectId_;
};

}  // namespace importer
}  // namespace eatransform
