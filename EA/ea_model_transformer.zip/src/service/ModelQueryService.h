#pragma once

#include "repository/ModelRepository.h"
#include "serializer/DdsJsonSerializer.h"

#include <string>

namespace eatransform {
namespace service {

class ModelQueryService {
public:
    ModelQueryService(repository::ModelRepository& repository, serializer::DdsJsonSerializer& serializer)
        : repository_(repository), serializer_(serializer) {}

    std::string getTypesJson(int projectId) const;
    std::string getDomainsJson(int projectId) const;
    std::string getDomainParticipantsJson(int projectId) const;
    std::string getQosJson(int projectId) const;
    std::string getApplicationsJson(int projectId) const;

private:
    repository::ModelRepository& repository_;
    serializer::DdsJsonSerializer& serializer_;
};

}  // namespace service
}  // namespace eatransform
