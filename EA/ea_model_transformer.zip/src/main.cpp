#include "db/SqliteConnection.h"
#include "generator/IdlGenerator.h"
#include "importer/EaImporter.h"
#include "model/IntermediateSchema.h"

#include <fstream>
#include <cstdlib>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {

struct CliOptions {
    std::string inputPath;
    std::string outputPath = "out_intermediate.db";
    std::string idlPath = "generated_model.idl";
    std::string projectName = "EA Import";
};

void printUsage() {
    std::cout
        << "Usage:\n"
        << "  ea_model_transformer --input <model.qea> [--output out.db] [--idl model.idl] [--project-name name]\n";
}

CliOptions parseArgs(int argc, char** argv) {
    CliOptions options;
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        auto needValue = [&](const std::string& option) -> std::string {
            if (i + 1 >= argc) {
                throw std::runtime_error("missing value for " + option);
            }
            return argv[++i];
        };

        if (arg == "--input") {
            options.inputPath = needValue(arg);
        } else if (arg == "--output") {
            options.outputPath = needValue(arg);
        } else if (arg == "--idl") {
            options.idlPath = needValue(arg);
        } else if (arg == "--project-name") {
            options.projectName = needValue(arg);
        } else if (arg == "--help" || arg == "-h") {
            printUsage();
            std::exit(0);
        } else {
            throw std::runtime_error("unknown argument: " + arg);
        }
    }

    if (options.inputPath.empty()) {
        throw std::runtime_error("--input is required");
    }
    return options;
}

void resetOutputSchema(eatransform::db::Connection& output) {
    output.exec(R"sql(
PRAGMA foreign_keys = OFF;
DROP TABLE IF EXISTS relations;
DROP TABLE IF EXISTS application_participants;
DROP TABLE IF EXISTS applications;
DROP TABLE IF EXISTS application_libraries;
DROP TABLE IF EXISTS qos_policies;
DROP TABLE IF EXISTS qos_entities;
DROP TABLE IF EXISTS qos_profiles;
DROP TABLE IF EXISTS qos_libraries;
DROP TABLE IF EXISTS data_readers;
DROP TABLE IF EXISTS subscribers;
DROP TABLE IF EXISTS data_writers;
DROP TABLE IF EXISTS publishers;
DROP TABLE IF EXISTS topics;
DROP TABLE IF EXISTS registered_types;
DROP TABLE IF EXISTS participants;
DROP TABLE IF EXISTS domain_participant_libraries;
DROP TABLE IF EXISTS domains;
DROP TABLE IF EXISTS domain_libraries;
DROP TABLE IF EXISTS type_members;
DROP TABLE IF EXISTS type_definitions;
DROP TABLE IF EXISTS modules;
DROP TABLE IF EXISTS packages;
DROP TABLE IF EXISTS projects;
PRAGMA foreign_keys = ON;
)sql");
}

}  // namespace

int main(int argc, char** argv) {
    try {
        const CliOptions options = parseArgs(argc, argv);

        std::ifstream inputCheck(options.inputPath.c_str(), std::ios::binary);
        if (!inputCheck) {
            throw std::runtime_error("input QEA file does not exist: " + options.inputPath);
        }
        inputCheck.close();

        auto ea = eatransform::db::Connection::openReadOnly(options.inputPath);
        auto output = eatransform::db::Connection::openReadWriteCreate(options.outputPath);
        resetOutputSchema(output);
        output.exec(eatransform::model::kIntermediateSchema);

        eatransform::importer::EaImporter importer(output);
        eatransform::importer::ImportOptions importOptions;
        importOptions.sourcePath = options.inputPath;
        importOptions.projectName = options.projectName;
        const int projectId = importer.importFrom(ea, importOptions);

        std::ofstream idl(options.idlPath, std::ios::binary);
        if (!idl) {
            throw std::runtime_error("failed to open IDL output: " + options.idlPath);
        }
        eatransform::generator::IdlGenerator generator(output);
        generator.generate(projectId, idl);

        std::cout << "Imported " << options.inputPath << "\n";
        std::cout << "Intermediate DB: " << options.outputPath << "\n";
        std::cout << "IDL: " << options.idlPath << "\n";
        return 0;
    } catch (const std::exception& ex) {
        std::cerr << "error: " << ex.what() << "\n";
        printUsage();
        return 1;
    }
}
