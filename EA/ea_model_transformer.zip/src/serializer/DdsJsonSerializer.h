#pragma once

#include "model/application/ApplicationModel.h"
#include "model/domain/DomainModel.h"
#include "model/participant/DomainParticipantModel.h"
#include "model/qos/QosModel.h"
#include "model/types/TypeModel.h"

#include <string>

namespace eatransform {
namespace serializer {

class DdsJsonSerializer {
public:
    std::string serializeTypes(const model::TypeLibrary& library) const;
    std::string serializeDomains(const model::DomainLibrary& library) const;
    std::string serializeDomainParticipants(const model::DomainParticipantLibrary& library) const;
    std::string serializeQos(const model::QosLibrary& library) const;
    std::string serializeApplications(const model::ApplicationLibrary& library) const;
};

}  // namespace serializer
}  // namespace eatransform
