#pragma once

namespace eatransform {
namespace model {

static const char kIntermediateSchema[] = R"sql(
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    source_path TEXT,
    description TEXT,
    model_version TEXT DEFAULT '1',
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS packages (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    parent_id INTEGER REFERENCES packages(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    qualified_name TEXT NOT NULL,
    source_kind TEXT DEFAULT 'sparx_ea',
    source_ref TEXT,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0,
    UNIQUE(project_id, qualified_name)
);

CREATE TABLE IF NOT EXISTS modules (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    package_id INTEGER REFERENCES packages(id) ON DELETE SET NULL,
    parent_id INTEGER REFERENCES modules(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    qualified_name TEXT NOT NULL,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0,
    UNIQUE(project_id, qualified_name)
);

CREATE TABLE IF NOT EXISTS type_definitions (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    package_id INTEGER REFERENCES packages(id) ON DELETE SET NULL,
    module_id INTEGER REFERENCES modules(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    qualified_name TEXT NOT NULL,
    kind TEXT NOT NULL CHECK(kind IN ('struct', 'union', 'enum', 'typedef', 'annotation', 'const', 'bitmask', 'bitset', 'unknown')),
    type_kind TEXT,
    base_type_name TEXT,
    discriminator_type_kind TEXT,
    discriminator_type_name TEXT,
    extensibility TEXT CHECK(extensibility IS NULL OR extensibility IN ('final', 'appendable', 'mutable')),
    autoid TEXT CHECK(autoid IS NULL OR autoid IN ('hash', 'sequential')),
    bit_bound INTEGER,
    value_json TEXT,
    type_json TEXT,
    annotations_json TEXT,
    verbatim_json TEXT,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS type_members (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    type_definition_id INTEGER NOT NULL REFERENCES type_definitions(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    member_kind TEXT NOT NULL CHECK(member_kind IN ('field', 'union_case', 'enumerator', 'annotation_member', 'parameter', 'bitfield', 'bitflag')),
    type_kind TEXT,
    type_name TEXT,
    type_ref_id INTEGER REFERENCES type_definitions(id) ON DELETE SET NULL,
    bound TEXT,
    lower_bound TEXT,
    upper_bound TEXT,
    string_max_length TEXT,
    sequence_max_length TEXT,
    array_dimensions_json TEXT,
    map_key_type_kind TEXT,
    map_key_type_name TEXT,
    map_value_type_kind TEXT,
    map_value_type_name TEXT,
    default_value TEXT,
    value_json TEXT,
    case_labels_json TEXT,
    bit_bound INTEGER,
    bit_position INTEGER,
    member_id INTEGER,
    hashid TEXT,
    is_key INTEGER DEFAULT 0 CHECK(is_key IN (0, 1)),
    is_optional INTEGER DEFAULT 0 CHECK(is_optional IN (0, 1)),
    is_external INTEGER DEFAULT 0 CHECK(is_external IN (0, 1)),
    must_understand INTEGER DEFAULT 0 CHECK(must_understand IN (0, 1)),
    try_construct TEXT CHECK(try_construct IS NULL OR try_construct IN ('discard', 'use_default', 'trim')),
    annotations_json TEXT,
    verbatim_json TEXT,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS domain_libraries (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0,
    UNIQUE(project_id, name)
);

CREATE TABLE IF NOT EXISTS domains (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    domain_library_id INTEGER REFERENCES domain_libraries(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    domain_id INTEGER DEFAULT 0,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0,
    UNIQUE(project_id, name)
);

CREATE TABLE IF NOT EXISTS registered_types (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    domain_id INTEGER REFERENCES domains(id) ON DELETE CASCADE,
    participant_id INTEGER REFERENCES participants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    type_ref TEXT NOT NULL,
    type_definition_id INTEGER REFERENCES type_definitions(id) ON DELETE SET NULL,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0,
    CHECK(domain_id IS NOT NULL OR participant_id IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    domain_id INTEGER REFERENCES domains(id) ON DELETE CASCADE,
    participant_id INTEGER REFERENCES participants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    register_type_ref TEXT NOT NULL,
    type_definition_id INTEGER REFERENCES type_definitions(id) ON DELETE SET NULL,
    topic_qos_json TEXT,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0,
    CHECK(domain_id IS NOT NULL OR participant_id IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS domain_participant_libraries (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0,
    UNIQUE(project_id, name)
);

CREATE TABLE IF NOT EXISTS participants (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    participant_library_id INTEGER REFERENCES domain_participant_libraries(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    base_name TEXT,
    domain_ref TEXT,
    domain_id INTEGER,
    participant_qos_json TEXT,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS publishers (
    id INTEGER PRIMARY KEY,
    participant_id INTEGER NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    publisher_qos_json TEXT,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS data_writers (
    id INTEGER PRIMARY KEY,
    publisher_id INTEGER NOT NULL REFERENCES publishers(id) ON DELETE CASCADE,
    topic_ref TEXT NOT NULL,
    name TEXT NOT NULL,
    writer_qos_json TEXT,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS subscribers (
    id INTEGER PRIMARY KEY,
    participant_id INTEGER NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    subscriber_qos_json TEXT,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS data_readers (
    id INTEGER PRIMARY KEY,
    subscriber_id INTEGER NOT NULL REFERENCES subscribers(id) ON DELETE CASCADE,
    topic_ref TEXT NOT NULL,
    name TEXT NOT NULL,
    content_filter_json TEXT,
    status_condition_json TEXT,
    read_condition_json TEXT,
    reader_qos_json TEXT,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS qos_libraries (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    base_name TEXT,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0,
    UNIQUE(project_id, name)
);

CREATE TABLE IF NOT EXISTS qos_profiles (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    qos_library_id INTEGER REFERENCES qos_libraries(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    base_name TEXT,
    domain_participant_qos_json TEXT,
    topic_qos_json TEXT,
    publisher_qos_json TEXT,
    subscriber_qos_json TEXT,
    datawriter_qos_json TEXT,
    datareader_qos_json TEXT,
    qos_json TEXT,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0,
    UNIQUE(project_id, name)
);

CREATE TABLE IF NOT EXISTS qos_entities (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    qos_library_id INTEGER REFERENCES qos_libraries(id) ON DELETE CASCADE,
    qos_profile_id INTEGER REFERENCES qos_profiles(id) ON DELETE CASCADE,
    entity_kind TEXT NOT NULL CHECK(entity_kind IN ('domain_participant', 'topic', 'publisher', 'subscriber', 'data_writer', 'data_reader')),
    name TEXT,
    base_name TEXT,
    qos_json TEXT NOT NULL,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS qos_policies (
    id INTEGER PRIMARY KEY,
    qos_profile_id INTEGER REFERENCES qos_profiles(id) ON DELETE CASCADE,
    qos_entity_id INTEGER REFERENCES qos_entities(id) ON DELETE CASCADE,
    entity_kind TEXT NOT NULL CHECK(entity_kind IN ('domain_participant', 'topic', 'publisher', 'subscriber', 'data_writer', 'data_reader')),
    policy_name TEXT NOT NULL,
    policy_json TEXT NOT NULL,
    CHECK(qos_profile_id IS NOT NULL OR qos_entity_id IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS application_libraries (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0,
    UNIQUE(project_id, name)
);

CREATE TABLE IF NOT EXISTS applications (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    application_library_id INTEGER REFERENCES application_libraries(id) ON DELETE SET NULL,
    name TEXT NOT NULL,
    annotations_json TEXT,
    sort_order INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS application_participants (
    id INTEGER PRIMARY KEY,
    application_id INTEGER NOT NULL REFERENCES applications(id) ON DELETE CASCADE,
    participant_id INTEGER NOT NULL REFERENCES participants(id) ON DELETE CASCADE,
    sort_order INTEGER DEFAULT 0,
    UNIQUE(application_id, participant_id)
);

CREATE TABLE IF NOT EXISTS relations (
    id INTEGER PRIMARY KEY,
    project_id INTEGER NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
    source_type_id INTEGER REFERENCES type_definitions(id) ON DELETE SET NULL,
    target_type_id INTEGER REFERENCES type_definitions(id) ON DELETE SET NULL,
    relation_kind TEXT NOT NULL,
    name TEXT,
    source_role TEXT,
    target_role TEXT,
    source_cardinality TEXT,
    target_cardinality TEXT,
    annotations_json TEXT
);

CREATE INDEX IF NOT EXISTS idx_packages_project_parent ON packages(project_id, parent_id);
CREATE INDEX IF NOT EXISTS idx_modules_project_parent ON modules(project_id, parent_id);
CREATE INDEX IF NOT EXISTS idx_type_definitions_project_kind ON type_definitions(project_id, kind);
CREATE INDEX IF NOT EXISTS idx_type_members_type ON type_members(type_definition_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_domains_library ON domains(domain_library_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_registered_types_domain ON registered_types(domain_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_registered_types_participant ON registered_types(participant_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_topics_domain ON topics(domain_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_topics_participant ON topics(participant_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_participants_library ON participants(participant_library_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_publishers_participant ON publishers(participant_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_subscribers_participant ON subscribers(participant_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_qos_profiles_library ON qos_profiles(qos_library_id, sort_order);
CREATE INDEX IF NOT EXISTS idx_qos_entities_scope ON qos_entities(qos_library_id, qos_profile_id, entity_kind);
CREATE INDEX IF NOT EXISTS idx_applications_library ON applications(application_library_id, sort_order);
)sql";

}  // namespace model
}  // namespace eatransform
