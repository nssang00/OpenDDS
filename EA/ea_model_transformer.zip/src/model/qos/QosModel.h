#pragma once

#include "model/common/JsonFragment.h"

#include <string>
#include <vector>

namespace eatransform {
namespace model {

struct QosPolicyModel {
    int id = 0;
    std::string entityKind;
    std::string policyName;
    JsonFragment policy;
};

struct QosEntityModel {
    int id = 0;
    std::string entityKind;
    std::string name;
    std::string baseName;
    JsonFragment qos;
    JsonFragment annotations;
    int sortOrder = 0;
    std::vector<QosPolicyModel> policies;
};

struct QosProfileModel {
    int id = 0;
    std::string name;
    std::string baseName;
    JsonFragment domainParticipantQos;
    JsonFragment topicQos;
    JsonFragment publisherQos;
    JsonFragment subscriberQos;
    JsonFragment dataWriterQos;
    JsonFragment dataReaderQos;
    JsonFragment qos;
    JsonFragment annotations;
    int sortOrder = 0;
    std::vector<QosEntityModel> entities;
    std::vector<QosPolicyModel> policies;
};

struct QosLibrary {
    int id = 0;
    std::string name;
    std::string baseName;
    JsonFragment annotations;
    std::vector<QosProfileModel> profiles;
    std::vector<QosEntityModel> entities;
};

}  // namespace model
}  // namespace eatransform
