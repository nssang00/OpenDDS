#pragma once

#include "model/common/JsonFragment.h"

#include <string>
#include <vector>

namespace eatransform {
namespace model {

struct TypeMemberModel {
    int id = 0;
    std::string name;
    std::string memberKind;
    std::string typeKind;
    std::string typeName;
    std::string defaultValue;
    std::string lowerBound;
    std::string upperBound;
    std::string stringMaxLength;
    std::string sequenceMaxLength;
    JsonFragment arrayDimensions;
    JsonFragment caseLabels;
    JsonFragment value;
    JsonFragment annotations;
    JsonFragment verbatim;
    int typeRefId = 0;
    int memberId = 0;
    std::string hashid;
    bool isKey = false;
    bool isOptional = false;
    bool isExternal = false;
    bool mustUnderstand = false;
    std::string tryConstruct;
    int sortOrder = 0;
};

struct TypeDefinitionModel {
    int id = 0;
    int packageId = 0;
    int moduleId = 0;
    std::string name;
    std::string qualifiedName;
    std::string kind;
    std::string typeKind;
    std::string baseTypeName;
    std::string discriminatorTypeKind;
    std::string discriminatorTypeName;
    std::string extensibility;
    std::string autoid;
    int bitBound = 0;
    JsonFragment value;
    JsonFragment type;
    JsonFragment annotations;
    JsonFragment verbatim;
    int sortOrder = 0;
    std::vector<TypeMemberModel> members;
};

struct ModuleModel {
    int id = 0;
    int packageId = 0;
    int parentId = 0;
    std::string name;
    std::string qualifiedName;
    JsonFragment annotations;
    int sortOrder = 0;
    std::vector<ModuleModel> children;
    std::vector<TypeDefinitionModel> types;
};

struct TypeLibrary {
    std::vector<ModuleModel> modules;
    std::vector<TypeDefinitionModel> rootTypes;
};

}  // namespace model
}  // namespace eatransform
