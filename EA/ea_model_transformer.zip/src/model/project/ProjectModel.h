#pragma once

#include "model/application/ApplicationModel.h"
#include "model/domain/DomainModel.h"
#include "model/package/PackageModel.h"
#include "model/participant/DomainParticipantModel.h"
#include "model/qos/QosModel.h"
#include "model/types/TypeModel.h"

#include <string>
#include <vector>

namespace eatransform {
namespace model {

struct ProjectModel {
    int id = 0;
    std::string name;
    std::string sourcePath;
    std::string description;
    std::string modelVersion;

    std::vector<PackageModel> packages;
    TypeLibrary typeLibrary;
    DomainLibrary domainLibrary;
    DomainParticipantLibrary domainParticipantLibrary;
    QosLibrary qosLibrary;
    ApplicationLibrary applicationLibrary;
};

}  // namespace model
}  // namespace eatransform
