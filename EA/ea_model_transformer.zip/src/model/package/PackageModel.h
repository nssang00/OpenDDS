#pragma once

#include "model/common/JsonFragment.h"

#include <string>
#include <vector>

namespace eatransform {
namespace model {

struct PackageModel {
    int id = 0;
    int parentId = 0;
    std::string name;
    std::string qualifiedName;
    std::string sourceKind;
    std::string sourceRef;
    JsonFragment annotations;
    int sortOrder = 0;
    std::vector<PackageModel> children;
};

}  // namespace model
}  // namespace eatransform
