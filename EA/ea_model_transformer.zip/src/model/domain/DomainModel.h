#pragma once

#include "model/common/JsonFragment.h"

#include <string>
#include <vector>

namespace eatransform {
namespace model {

struct RegisteredTypeModel {
    int id = 0;
    std::string name;
    std::string typeRef;
    int typeDefinitionId = 0;
    JsonFragment annotations;
    int sortOrder = 0;
};

struct TopicModel {
    int id = 0;
    std::string name;
    std::string registerTypeRef;
    int typeDefinitionId = 0;
    JsonFragment topicQos;
    JsonFragment annotations;
    int sortOrder = 0;
};

struct DomainModel {
    int id = 0;
    std::string name;
    int domainId = 0;
    JsonFragment annotations;
    int sortOrder = 0;
    std::vector<RegisteredTypeModel> registeredTypes;
    std::vector<TopicModel> topics;
};

struct DomainLibrary {
    int id = 0;
    std::string name;
    JsonFragment annotations;
    std::vector<DomainModel> domains;
};

}  // namespace model
}  // namespace eatransform
