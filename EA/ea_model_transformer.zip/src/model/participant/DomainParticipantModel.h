#pragma once

#include "model/common/JsonFragment.h"
#include "model/domain/DomainModel.h"

#include <string>
#include <vector>

namespace eatransform {
namespace model {

struct DataWriterModel {
    int id = 0;
    std::string name;
    std::string topicRef;
    JsonFragment qos;
    JsonFragment annotations;
    int sortOrder = 0;
};

struct PublisherModel {
    int id = 0;
    std::string name;
    JsonFragment qos;
    JsonFragment annotations;
    int sortOrder = 0;
    std::vector<DataWriterModel> dataWriters;
};

struct DataReaderModel {
    int id = 0;
    std::string name;
    std::string topicRef;
    JsonFragment contentFilter;
    JsonFragment statusCondition;
    JsonFragment readCondition;
    JsonFragment qos;
    JsonFragment annotations;
    int sortOrder = 0;
};

struct SubscriberModel {
    int id = 0;
    std::string name;
    JsonFragment qos;
    JsonFragment annotations;
    int sortOrder = 0;
    std::vector<DataReaderModel> dataReaders;
};

struct DomainParticipantModel {
    int id = 0;
    std::string name;
    std::string baseName;
    std::string domainRef;
    int domainId = 0;
    JsonFragment qos;
    JsonFragment annotations;
    int sortOrder = 0;
    std::vector<RegisteredTypeModel> registeredTypes;
    std::vector<TopicModel> topics;
    std::vector<PublisherModel> publishers;
    std::vector<SubscriberModel> subscribers;
};

struct DomainParticipantLibrary {
    int id = 0;
    std::string name;
    JsonFragment annotations;
    std::vector<DomainParticipantModel> participants;
};

}  // namespace model
}  // namespace eatransform
