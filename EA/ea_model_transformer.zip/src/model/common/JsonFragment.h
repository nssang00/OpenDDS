#pragma once

#include <string>

namespace eatransform {
namespace model {

struct JsonFragment {
    std::string text;

    bool empty() const {
        return text.empty();
    }
};

}  // namespace model
}  // namespace eatransform
