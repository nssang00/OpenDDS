#pragma once

#include "model/common/JsonFragment.h"

#include <string>
#include <vector>

namespace eatransform {
namespace model {

struct ApplicationParticipantRef {
    int participantId = 0;
    int sortOrder = 0;
};

struct ApplicationModel {
    int id = 0;
    std::string name;
    JsonFragment annotations;
    int sortOrder = 0;
    std::vector<ApplicationParticipantRef> participants;
};

struct ApplicationLibrary {
    int id = 0;
    std::string name;
    JsonFragment annotations;
    std::vector<ApplicationModel> applications;
};

}  // namespace model
}  // namespace eatransform
