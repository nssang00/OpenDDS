#include "generator/IdlGenerator.h"

#include <algorithm>
#include <cctype>
#include <ostream>
#include <set>
#include <vector>

namespace eatransform {
namespace generator {

namespace {

std::vector<std::string> splitModules(const std::string& qualifiedName) {
    std::vector<std::string> parts;
    std::string current;
    for (size_t i = 0; i < qualifiedName.size(); ++i) {
        if (qualifiedName[i] == ':' && i + 1 < qualifiedName.size() && qualifiedName[i + 1] == ':') {
            if (!current.empty()) {
                parts.push_back(current);
                current.clear();
            }
            ++i;
        } else {
            current += qualifiedName[i];
        }
    }
    if (!current.empty()) {
        parts.push_back(current);
    }
    return parts;
}

}  // namespace

IdlGenerator::IdlGenerator(db::Connection& input) : input_(input) {}

void IdlGenerator::generate(int projectId, std::ostream& out) {
    out << "// Generated from EA intermediate SQLite model.\n\n";

    auto types = input_.prepare(R"sql(
SELECT td.id, td.name, td.kind, td.base_type_name, COALESCE(m.qualified_name, '')
FROM type_definitions td
LEFT JOIN modules m ON m.id = td.module_id
WHERE td.project_id = ?
AND td.kind IN ('typedef', 'enum', 'struct', 'union')
ORDER BY td.kind = 'typedef' DESC, td.kind = 'enum' DESC, td.kind = 'struct' DESC, td.sort_order, td.name;
)sql");
    types.bind(1, projectId);

    while (types.step()) {
        const int id = types.columnInt(0);
        const std::string name = sanitizeIdentifier(types.columnText(1));
        const std::string kind = types.columnText(2);
        const std::string baseType = types.columnText(3);
        const std::vector<std::string> modules = splitModules(types.columnText(4));

        for (size_t i = 0; i < modules.size(); ++i) {
            out << indent(i) << "module " << sanitizeIdentifier(modules[i]) << " {\n";
        }

        const size_t typeIndent = modules.size();
        if (kind == "enum") {
            emitEnum(id, name, typeIndent, out);
        } else if (kind == "struct" || kind == "union") {
            emitStruct(id, name, typeIndent, out);
        } else if (kind == "typedef") {
            emitTypedef(id, name, baseType, typeIndent, out);
        }

        for (auto it = modules.rbegin(); it != modules.rend(); ++it) {
            const size_t level = static_cast<size_t>(it - modules.rbegin());
            out << indent(modules.size() - level - 1) << "}; // module " << sanitizeIdentifier(*it) << "\n";
        }
        out << "\n";
    }
}

void IdlGenerator::emitEnum(int typeId, const std::string& name, size_t indentLevel, std::ostream& out) {
    out << indent(indentLevel) << "enum " << name << " {\n";
    auto members = input_.prepare(R"sql(
SELECT name, default_value
FROM type_members
WHERE type_definition_id = ? AND member_kind = 'enumerator'
ORDER BY sort_order, id;
)sql");
    members.bind(1, typeId);

    bool first = true;
    while (members.step()) {
        if (!first) {
            out << ",\n";
        }
        first = false;
        out << indent(indentLevel + 1) << sanitizeIdentifier(members.columnText(0));
        if (!members.columnText(1).empty()) {
            out << " = " << members.columnText(1);
        }
    }
    out << "\n" << indent(indentLevel) << "};\n";
}

void IdlGenerator::emitStruct(int typeId, const std::string& name, size_t indentLevel, std::ostream& out) {
    out << indent(indentLevel) << "struct " << name << " {\n";
    auto members = input_.prepare(R"sql(
SELECT name, type_kind, type_name, upper_bound
FROM type_members
WHERE type_definition_id = ? AND member_kind = 'field'
ORDER BY sort_order, id;
)sql");
    members.bind(1, typeId);

    while (members.step()) {
        const std::string memberName = sanitizeIdentifier(members.columnText(0));
        const std::string type = idlType(members.columnText(1), members.columnText(2));
        const std::string upper = members.columnText(3);

        out << indent(indentLevel + 1) << type << " " << memberName;
        if (!upper.empty() && upper != "1" && upper != "*") {
            out << "[" << upper << "]";
        }
        out << ";\n";
    }
    out << indent(indentLevel) << "};\n";
}

void IdlGenerator::emitTypedef(int, const std::string& name, const std::string& baseType, size_t indentLevel, std::ostream& out) {
    const std::string type = baseType.empty() ? "long" : idlType("", baseType);
    out << indent(indentLevel) << "typedef " << type << " " << name << ";\n";
}

std::string IdlGenerator::idlType(const std::string& typeKind, const std::string& typeName) {
    const std::string source = typeKind.empty() || typeKind == "named" || typeKind == "unknown" ? typeName : typeKind;
    const std::string lowered = [&source] {
        std::string value = source;
        std::transform(value.begin(), value.end(), value.begin(), [](unsigned char c) {
            return static_cast<char>(std::tolower(c));
        });
        return value;
    }();

    if (lowered == "boolean" || lowered == "bool") {
        return "boolean";
    }
    if (lowered == "byte" || lowered == "octet") {
        return "octet";
    }
    if (lowered == "char8" || lowered == "char") {
        return "char";
    }
    if (lowered == "char16" || lowered == "wchar") {
        return "wchar";
    }
    if (lowered == "int16" || lowered == "short") {
        return "short";
    }
    if (lowered == "uint16" || lowered == "unsigned short") {
        return "unsigned short";
    }
    if (lowered == "int32" || lowered == "int" || lowered == "long") {
        return "long";
    }
    if (lowered == "uint32" || lowered == "unsigned int" || lowered == "unsigned long") {
        return "unsigned long";
    }
    if (lowered == "int64" || lowered == "long long") {
        return "long long";
    }
    if (lowered == "uint64" || lowered == "unsigned long long") {
        return "unsigned long long";
    }
    if (lowered == "float32" || lowered == "float") {
        return "float";
    }
    if (lowered == "float64" || lowered == "double") {
        return "double";
    }
    if (lowered == "string" || lowered == "std::string") {
        return "string";
    }
    if (lowered == "wstring" || lowered == "std::wstring") {
        return "wstring";
    }
    return sanitizeIdentifier(source.empty() ? "long" : source);
}

std::string IdlGenerator::sanitizeIdentifier(const std::string& value) {
    static const std::set<std::string> reserved = {
        "module", "struct", "union", "enum", "typedef", "long", "short", "float", "double", "char", "boolean", "string"
    };

    std::string result;
    for (char c : value) {
        if (std::isalnum(static_cast<unsigned char>(c)) || c == '_') {
            result += c;
        } else if (!result.empty()) {
            result += '_';
        }
    }
    if (result.empty() || std::isdigit(static_cast<unsigned char>(result.front()))) {
        result.insert(result.begin(), '_');
    }
    if (reserved.count(result) != 0) {
        result += "_";
    }
    return result;
}

std::string IdlGenerator::indent(size_t level) {
    return std::string(level * 4, ' ');
}

}  // namespace generator
}  // namespace eatransform
