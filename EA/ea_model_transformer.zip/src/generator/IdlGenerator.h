#pragma once

#include "db/SqliteConnection.h"

#include <iosfwd>
#include <string>

namespace eatransform {
namespace generator {

class IdlGenerator {
public:
    explicit IdlGenerator(db::Connection& input);

    void generate(int projectId, std::ostream& out);

private:
    static std::string idlType(const std::string& typeKind, const std::string& typeName);
    static std::string sanitizeIdentifier(const std::string& value);

    static std::string indent(size_t level);

    void emitEnum(int typeId, const std::string& name, size_t indentLevel, std::ostream& out);
    void emitStruct(int typeId, const std::string& name, size_t indentLevel, std::ostream& out);
    void emitTypedef(int typeId, const std::string& name, const std::string& baseType, size_t indentLevel, std::ostream& out);

    db::Connection& input_;
};

}  // namespace generator
}  // namespace eatransform
