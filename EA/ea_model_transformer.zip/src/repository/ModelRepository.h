#pragma once

#include "db/SqliteConnection.h"
#include "model/project/ProjectModel.h"

namespace eatransform {
namespace repository {

class ModelRepository {
public:
    explicit ModelRepository(db::Connection& input) : input_(input) {}

    model::ProjectModel loadProject(int projectId);
    model::TypeLibrary loadTypeLibrary(int projectId);
    model::DomainLibrary loadDomainLibrary(int projectId);
    model::DomainParticipantLibrary loadDomainParticipantLibrary(int projectId);
    model::QosLibrary loadQosLibrary(int projectId);
    model::ApplicationLibrary loadApplicationLibrary(int projectId);

private:
    db::Connection& input_;
};

}  // namespace repository
}  // namespace eatransform
