#include "db/SqliteDynamic.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

#include <stdexcept>
#include <string>

namespace {

class SqliteDll {
public:
    SqliteDll() : module_(NULL) {
        const char* candidates[] = {
            "deps\\sqlite\\bin\\x64\\sqlite3.dll",
            "deps\\sqlite\\sqlite3.dll",
            "sqlite3.dll",
            "C:\\Program Files\\DB Browser for SQLite\\sqlite3.dll",
            "C:\\Program Files (x86)\\NetFile\\sqlite3.dll",
            "C:\\Program Files (x86)\\ipTIME\\ipTIME NAS\\Utility\\sqlite3.dll"
        };

        for (size_t i = 0; i < sizeof(candidates) / sizeof(candidates[0]); ++i) {
            module_ = LoadLibraryA(candidates[i]);
            if (module_ != NULL) {
                break;
            }
        }

        if (module_ == NULL) {
            throw std::runtime_error("sqlite3.dll was not found. Place sqlite3.dll in deps\\sqlite\\bin\\x64 or next to the executable.");
        }
    }

    ~SqliteDll() {
    }

    FARPROC proc(const char* name) {
        FARPROC value = GetProcAddress(module_, name);
        if (value == NULL) {
            throw std::runtime_error(std::string("sqlite3.dll is missing export: ") + name);
        }
        return value;
    }

private:
    HMODULE module_;
};

SqliteDll& dll() {
    static SqliteDll instance;
    return instance;
}

template <typename T>
T load(const char* name) {
    return reinterpret_cast<T>(dll().proc(name));
}

}  // namespace

int sqlite3_open_v2(const char* filename, sqlite3** ppDb, int flags, const char* zVfs) {
    typedef int (*Fn)(const char*, sqlite3**, int, const char*);
    static Fn fn = load<Fn>("sqlite3_open_v2");
    return fn(filename, ppDb, flags, zVfs);
}

int sqlite3_close(sqlite3* db) {
    typedef int (*Fn)(sqlite3*);
    static Fn fn = load<Fn>("sqlite3_close");
    return fn(db);
}

int sqlite3_exec(sqlite3* db, const char* sql, int (*callback)(void*, int, char**, char**), void* arg, char** errmsg) {
    typedef int (*Fn)(sqlite3*, const char*, int (*)(void*, int, char**, char**), void*, char**);
    static Fn fn = load<Fn>("sqlite3_exec");
    return fn(db, sql, callback, arg, errmsg);
}

void sqlite3_free(void* value) {
    typedef void (*Fn)(void*);
    static Fn fn = load<Fn>("sqlite3_free");
    fn(value);
}

const char* sqlite3_errmsg(sqlite3* db) {
    typedef const char* (*Fn)(sqlite3*);
    static Fn fn = load<Fn>("sqlite3_errmsg");
    return fn(db);
}

int sqlite3_prepare_v2(sqlite3* db, const char* sql, int nByte, sqlite3_stmt** ppStmt, const char** pzTail) {
    typedef int (*Fn)(sqlite3*, const char*, int, sqlite3_stmt**, const char**);
    static Fn fn = load<Fn>("sqlite3_prepare_v2");
    return fn(db, sql, nByte, ppStmt, pzTail);
}

int sqlite3_finalize(sqlite3_stmt* stmt) {
    typedef int (*Fn)(sqlite3_stmt*);
    static Fn fn = load<Fn>("sqlite3_finalize");
    return fn(stmt);
}

int sqlite3_bind_int(sqlite3_stmt* stmt, int index, int value) {
    typedef int (*Fn)(sqlite3_stmt*, int, int);
    static Fn fn = load<Fn>("sqlite3_bind_int");
    return fn(stmt, index, value);
}

int sqlite3_bind_int64(sqlite3_stmt* stmt, int index, sqlite3_int64 value) {
    typedef int (*Fn)(sqlite3_stmt*, int, sqlite3_int64);
    static Fn fn = load<Fn>("sqlite3_bind_int64");
    return fn(stmt, index, value);
}

int sqlite3_bind_text(sqlite3_stmt* stmt, int index, const char* value, int n, sqlite3_destructor_type destructor) {
    typedef int (*Fn)(sqlite3_stmt*, int, const char*, int, sqlite3_destructor_type);
    static Fn fn = load<Fn>("sqlite3_bind_text");
    return fn(stmt, index, value, n, destructor);
}

int sqlite3_bind_null(sqlite3_stmt* stmt, int index) {
    typedef int (*Fn)(sqlite3_stmt*, int);
    static Fn fn = load<Fn>("sqlite3_bind_null");
    return fn(stmt, index);
}

int sqlite3_step(sqlite3_stmt* stmt) {
    typedef int (*Fn)(sqlite3_stmt*);
    static Fn fn = load<Fn>("sqlite3_step");
    return fn(stmt);
}

int sqlite3_reset(sqlite3_stmt* stmt) {
    typedef int (*Fn)(sqlite3_stmt*);
    static Fn fn = load<Fn>("sqlite3_reset");
    return fn(stmt);
}

int sqlite3_clear_bindings(sqlite3_stmt* stmt) {
    typedef int (*Fn)(sqlite3_stmt*);
    static Fn fn = load<Fn>("sqlite3_clear_bindings");
    return fn(stmt);
}

int sqlite3_column_int(sqlite3_stmt* stmt, int index) {
    typedef int (*Fn)(sqlite3_stmt*, int);
    static Fn fn = load<Fn>("sqlite3_column_int");
    return fn(stmt, index);
}

sqlite3_int64 sqlite3_column_int64(sqlite3_stmt* stmt, int index) {
    typedef sqlite3_int64 (*Fn)(sqlite3_stmt*, int);
    static Fn fn = load<Fn>("sqlite3_column_int64");
    return fn(stmt, index);
}

const unsigned char* sqlite3_column_text(sqlite3_stmt* stmt, int index) {
    typedef const unsigned char* (*Fn)(sqlite3_stmt*, int);
    static Fn fn = load<Fn>("sqlite3_column_text");
    return fn(stmt, index);
}

int sqlite3_column_type(sqlite3_stmt* stmt, int index) {
    typedef int (*Fn)(sqlite3_stmt*, int);
    static Fn fn = load<Fn>("sqlite3_column_type");
    return fn(stmt, index);
}

sqlite3* sqlite3_db_handle(sqlite3_stmt* stmt) {
    typedef sqlite3* (*Fn)(sqlite3_stmt*);
    static Fn fn = load<Fn>("sqlite3_db_handle");
    return fn(stmt);
}

sqlite3_int64 sqlite3_last_insert_rowid(sqlite3* db) {
    typedef sqlite3_int64 (*Fn)(sqlite3*);
    static Fn fn = load<Fn>("sqlite3_last_insert_rowid");
    return fn(db);
}
