#pragma once

#include "db/SqliteConnection.h"

const int SQLITE_OK = 0;
const int SQLITE_ROW = 100;
const int SQLITE_DONE = 101;
const int SQLITE_NULL = 5;
const int SQLITE_OPEN_READONLY = 0x00000001;
const int SQLITE_OPEN_READWRITE = 0x00000002;
const int SQLITE_OPEN_CREATE = 0x00000004;

extern "C" {
typedef void (*sqlite3_destructor_type)(void*);
}

#define SQLITE_TRANSIENT ((sqlite3_destructor_type)-1)

int sqlite3_open_v2(const char* filename, sqlite3** ppDb, int flags, const char* zVfs);
int sqlite3_close(sqlite3* db);
int sqlite3_exec(sqlite3* db, const char* sql, int (*callback)(void*, int, char**, char**), void* arg, char** errmsg);
void sqlite3_free(void* value);
const char* sqlite3_errmsg(sqlite3* db);
int sqlite3_prepare_v2(sqlite3* db, const char* sql, int nByte, sqlite3_stmt** ppStmt, const char** pzTail);
int sqlite3_finalize(sqlite3_stmt* stmt);
int sqlite3_bind_int(sqlite3_stmt* stmt, int index, int value);
int sqlite3_bind_int64(sqlite3_stmt* stmt, int index, sqlite3_int64 value);
int sqlite3_bind_text(sqlite3_stmt* stmt, int index, const char* value, int n, sqlite3_destructor_type destructor);
int sqlite3_bind_null(sqlite3_stmt* stmt, int index);
int sqlite3_step(sqlite3_stmt* stmt);
int sqlite3_reset(sqlite3_stmt* stmt);
int sqlite3_clear_bindings(sqlite3_stmt* stmt);
int sqlite3_column_int(sqlite3_stmt* stmt, int index);
sqlite3_int64 sqlite3_column_int64(sqlite3_stmt* stmt, int index);
const unsigned char* sqlite3_column_text(sqlite3_stmt* stmt, int index);
int sqlite3_column_type(sqlite3_stmt* stmt, int index);
sqlite3* sqlite3_db_handle(sqlite3_stmt* stmt);
sqlite3_int64 sqlite3_last_insert_rowid(sqlite3* db);
