#include "db/SqliteConnection.h"
#include "db/SqliteDynamic.h"

#include <sstream>

namespace eatransform {
namespace db {

namespace {

void throwSqlite(sqlite3* db, const std::string& prefix) {
    std::ostringstream message;
    message << prefix << ": " << sqlite3_errmsg(db);
    throw SqliteError(message.str());
}

}  // namespace

Connection Connection::openReadOnly(const std::string& path) {
    sqlite3* db = nullptr;
    if (sqlite3_open_v2(path.c_str(), &db, SQLITE_OPEN_READONLY, nullptr) != SQLITE_OK) {
        const std::string message = db ? sqlite3_errmsg(db) : "failed to allocate sqlite handle";
        if (db) {
            sqlite3_close(db);
        }
        throw SqliteError("open read-only failed for " + path + ": " + message);
    }
    return Connection(db);
}

Connection Connection::openReadWriteCreate(const std::string& path) {
    sqlite3* db = nullptr;
    if (sqlite3_open_v2(path.c_str(), &db, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE, nullptr) != SQLITE_OK) {
        const std::string message = db ? sqlite3_errmsg(db) : "failed to allocate sqlite handle";
        if (db) {
            sqlite3_close(db);
        }
        throw SqliteError("open output failed for " + path + ": " + message);
    }
    return Connection(db);
}

Connection::Connection(Connection&& other) noexcept : db_(other.db_) {
    other.db_ = nullptr;
}

Connection& Connection::operator=(Connection&& other) noexcept {
    if (this != &other) {
        if (db_) {
            sqlite3_close(db_);
        }
        db_ = other.db_;
        other.db_ = nullptr;
    }
    return *this;
}

Connection::~Connection() {
    if (db_) {
        sqlite3_close(db_);
    }
}

void Connection::exec(const std::string& sql) {
    char* error = nullptr;
    if (sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &error) != SQLITE_OK) {
        const std::string message = error ? error : sqlite3_errmsg(db_);
        sqlite3_free(error);
        throw SqliteError(message);
    }
}

Statement Connection::prepare(const std::string& sql) {
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        throwSqlite(db_, "prepare failed");
    }
    return Statement(stmt);
}

Statement::Statement(Statement&& other) noexcept : stmt_(other.stmt_) {
    other.stmt_ = nullptr;
}

Statement& Statement::operator=(Statement&& other) noexcept {
    if (this != &other) {
        if (stmt_) {
            sqlite3_finalize(stmt_);
        }
        stmt_ = other.stmt_;
        other.stmt_ = nullptr;
    }
    return *this;
}

Statement::~Statement() {
    if (stmt_) {
        sqlite3_finalize(stmt_);
    }
}

void Statement::bind(int index, int value) {
    if (sqlite3_bind_int(stmt_, index, value) != SQLITE_OK) {
        throwSqlite(sqlite3_db_handle(stmt_), "bind int failed");
    }
}

void Statement::bindInt64(int index, sqlite3_int64 value) {
    if (sqlite3_bind_int64(stmt_, index, value) != SQLITE_OK) {
        throwSqlite(sqlite3_db_handle(stmt_), "bind int64 failed");
    }
}

void Statement::bind(int index, const std::string& value) {
    if (sqlite3_bind_text(stmt_, index, value.c_str(), -1, SQLITE_TRANSIENT) != SQLITE_OK) {
        throwSqlite(sqlite3_db_handle(stmt_), "bind text failed");
    }
}

void Statement::bindNull(int index) {
    if (sqlite3_bind_null(stmt_, index) != SQLITE_OK) {
        throwSqlite(sqlite3_db_handle(stmt_), "bind null failed");
    }
}

bool Statement::step() {
    const int rc = sqlite3_step(stmt_);
    if (rc == SQLITE_ROW) {
        return true;
    }
    if (rc == SQLITE_DONE) {
        return false;
    }
    throwSqlite(sqlite3_db_handle(stmt_), "step failed");
    return false;
}

void Statement::execute() {
    if (step()) {
        throw SqliteError("statement returned rows where none were expected");
    }
}

void Statement::reset() {
    sqlite3_reset(stmt_);
    sqlite3_clear_bindings(stmt_);
}

int Statement::columnInt(int index) const {
    return sqlite3_column_int(stmt_, index);
}

sqlite3_int64 Statement::columnInt64(int index) const {
    return sqlite3_column_int64(stmt_, index);
}

std::string Statement::columnText(int index) const {
    const auto* text = sqlite3_column_text(stmt_, index);
    return text ? reinterpret_cast<const char*>(text) : "";
}

bool Statement::columnIsNull(int index) const {
    return sqlite3_column_type(stmt_, index) == SQLITE_NULL;
}

std::string quoteIdentifier(const std::string& value) {
    std::string quoted = "\"";
    for (char c : value) {
        if (c == '"') {
            quoted += "\"\"";
        } else {
            quoted += c;
        }
    }
    quoted += '"';
    return quoted;
}

}  // namespace db
}  // namespace eatransform
