#pragma once

#include <functional>
#include <stdexcept>
#include <string>
#include <vector>

struct sqlite3;
struct sqlite3_stmt;
typedef long long sqlite3_int64;

namespace eatransform {
namespace db {

class SqliteError : public std::runtime_error {
public:
    explicit SqliteError(const std::string& message) : std::runtime_error(message) {}
};

class Statement;

class Connection {
public:
    Connection() = default;
    Connection(const Connection&) = delete;
    Connection& operator=(const Connection&) = delete;
    Connection(Connection&& other) noexcept;
    Connection& operator=(Connection&& other) noexcept;
    ~Connection();

    static Connection openReadOnly(const std::string& path);
    static Connection openReadWriteCreate(const std::string& path);

    void exec(const std::string& sql);
    Statement prepare(const std::string& sql);
    sqlite3* handle() const { return db_; }

private:
    explicit Connection(sqlite3* db) : db_(db) {}
    sqlite3* db_ = nullptr;
};

class Statement {
public:
    Statement() = default;
    Statement(const Statement&) = delete;
    Statement& operator=(const Statement&) = delete;
    Statement(Statement&& other) noexcept;
    Statement& operator=(Statement&& other) noexcept;
    ~Statement();

    void bind(int index, int value);
    void bindInt64(int index, sqlite3_int64 value);
    void bind(int index, const std::string& value);
    void bindNull(int index);

    bool step();
    void execute();
    void reset();

    int columnInt(int index) const;
    sqlite3_int64 columnInt64(int index) const;
    std::string columnText(int index) const;
    bool columnIsNull(int index) const;

private:
    friend class Connection;
    explicit Statement(sqlite3_stmt* stmt) : stmt_(stmt) {}
    sqlite3_stmt* stmt_ = nullptr;
};

std::string quoteIdentifier(const std::string& value);

}  // namespace db
}  // namespace eatransform
