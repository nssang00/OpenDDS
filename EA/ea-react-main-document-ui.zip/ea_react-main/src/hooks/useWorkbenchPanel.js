import { useUiStore } from '../stores/useUiStore.js';

export function useWorkbenchPanel(panelId) {
  const activeExplorerViewId = useUiStore((state) => state.activeExplorerViewId);
  const activeWorkspaceViewId = useUiStore((state) => state.activeWorkspaceViewId);
  const setActiveExplorerView = useUiStore((state) => state.setActiveExplorerView);
  const setActiveWorkspaceView = useUiStore((state) => state.setActiveWorkspaceView);

  return {
    activeExplorerViewId,
    activeWorkspaceViewId,
    controlledActiveViewId: panelId === 'workspace' ? activeWorkspaceViewId : undefined,
    onActiveViewChange: panelId === 'explorer'
      ? setActiveExplorerView
      : panelId === 'workspace'
        ? setActiveWorkspaceView
        : undefined,
  };
}
