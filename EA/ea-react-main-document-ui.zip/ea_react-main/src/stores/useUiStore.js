import { create } from 'zustand';

export const useUiStore = create((set) => ({
  selectedElementId: null,
  activeExplorerViewId: 'types',
  activeWorkspaceViewId: 'diagram',

  selectElement: (id) => set({ selectedElementId: id }),
  setActiveExplorerView: (id) => set({ activeExplorerViewId: id }),
  setActiveWorkspaceView: (id) => set({ activeWorkspaceViewId: id }),
}));
