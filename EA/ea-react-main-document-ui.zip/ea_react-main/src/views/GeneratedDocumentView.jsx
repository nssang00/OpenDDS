import { useEffect, useRef } from 'react';
import { Button, Empty, Space, Typography } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import { useDocumentStore } from '../document/documentStore.js';
import { downloadDocx, previewDocx } from '../document/docxRenderer.js';

const { Text } = Typography;

export default function GeneratedDocumentView() {
  const previewRef = useRef(null);
  const { generatedBlob, generatedBuffer, templateName } = useDocumentStore();

  useEffect(() => {
    if (!generatedBuffer || !previewRef.current) return;
    previewDocx(generatedBuffer, previewRef.current);
  }, [generatedBuffer]);

  if (!generatedBuffer) {
    return <div className="generated-document-empty"><Empty description="Generate a document from the Document Template tab" /></div>;
  }

  return (
    <div className="generated-document-view">
      <div className="document-toolbar">
        <Text type="secondary">Generated from {templateName}</Text>
        <Button type="primary" icon={<DownloadOutlined />} onClick={() => downloadDocx(generatedBlob, generatedName(templateName))}>
          Download DOCX
        </Button>
      </div>
      <div className="document-preview-panel generated-document-preview-panel">
        <div ref={previewRef} className="document-docx-preview" />
      </div>
    </div>
  );
}

function generatedName(templateName) {
  if (!templateName) return 'generated-document.docx';
  return templateName.replace(/\.(docxtpl|docx)$/i, '-generated.docx');
}
