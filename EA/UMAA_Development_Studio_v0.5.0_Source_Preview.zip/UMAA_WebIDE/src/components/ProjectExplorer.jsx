import { Empty, Tree, Typography, Tag, Tooltip, Input } from 'antd';
import { ApartmentOutlined, ApiOutlined, FolderOpenOutlined, LinkOutlined, FileTextOutlined, DeploymentUnitOutlined, DatabaseOutlined, ControlOutlined } from '@ant-design/icons';
import { useMemo, useState } from 'react';
import { useEditorStore } from '../stores/useEditorStore.js';
const T = (color, label) => <Tag color={color} style={{ marginInlineStart: 5, marginInlineEnd: 0, fontSize: 10 }}>{label}</Tag>;
export function ProjectExplorer() {
  const snapshot = useEditorStore(s => s.snapshot);
  const select = useEditorStore(s => s.select);
  const selected = useEditorStore(s => s.selection);
  const [filter, setFilter] = useState('');
  const tree = useMemo(() => {
    if (!snapshot) return [];
    const hit = s => !filter || s.toLowerCase().includes(filter.toLowerCase());
    const ops = svc => snapshot.interfaces.filter(i => i.serviceId === svc.id).map(i => ({
      key: `interface:${i.id}`, title: <Tooltip title="Operation 탐색 그룹 · 공식 UML GUID는 미탑재">{i.name}</Tooltip>, icon: <LinkOutlined />,
      children: i.operationIds.map(opId => snapshot.operations.find(o => o.id === opId)).filter(Boolean).map(op => {
        const t = snapshot.topics.find(x => x.id === op.topicId);
        const m = snapshot.messages.find(x => x.id === t?.messageTypeId);
        return { key: `operation:${op.id}`, title: `${op.name} · ${op.action}`, icon: <FileTextOutlined />,
          children: t ? [{ key: `topic:${t.id}`, title: `Topic: ${t.name}`, icon: <DatabaseOutlined />,
            children: m ? [{ key: `message:${m.id}`, title: `IDL: ${m.name}`, icon: <FileTextOutlined /> }] : [] }] : [] };
      })
    }));
    const svcNode = svc => ({ key: `service:${svc.id}`, title: <span>{svc.name}{svc.source === 'custom' ? T('purple', 'EXT') : null}</span>, icon: <ApiOutlined />, children: ops(svc) });
    const standardAreas = snapshot.functionalAreas.filter(a => a.source !== 'custom');
    const extensionAreas = snapshot.functionalAreas.filter(a => a.source === 'custom');
    const areaNode = area => ({ key: `functionalArea:${area.id}`, title: <span>{area.id} · {area.name} {T('default',snapshot.services.filter(s => s.functionalArea === area.id && (area.source === 'custom' ? s.source === 'custom' : s.source === 'standard')).length)}</span>, icon: <DeploymentUnitOutlined />,
      children: snapshot.services.filter(s => s.functionalArea === area.id && (area.source === 'custom' ? s.source === 'custom' : s.source === 'standard') && hit(s.name)).map(svcNode) });
    const referenced = new Set(extensionAreas.map(a => a.id));
    const projectServices = snapshot.services.filter(s => s.source === 'custom' && !referenced.has(s.functionalArea));
    const groups = [
      { key: 'official-catalog', title: `UMAA 6.0 · Standard Catalog (read-only)`, icon: <FolderOpenOutlined />, children: standardAreas.map(areaNode) },
      { key: 'extensions', title: `Project Extensions (${projectServices.length + snapshot.services.filter(s => s.source === 'custom' && referenced.has(s.functionalArea)).length})`, icon: <FolderOpenOutlined />,
        children: [...extensionAreas.map(areaNode), ...projectServices.filter(s=>hit(s.name)).map(svcNode)] },
      { key: 'components-folder', title: `Components (${snapshot.components.length})`, icon: <ApartmentOutlined />,
        children: snapshot.components.filter(c => hit(c.name)).map(c => ({key: `component:${c.id}`, title: c.name, icon: <ApartmentOutlined />,
          children: snapshot.bindings.filter(b => b.componentId === c.id).map(b => ({key: `binding:${b.id}`, icon: <ApiOutlined />,
            title: <span>{snapshot.services.find(s => s.id === b.serviceId)?.name ?? 'Unknown'} {T(b.role === 'provider' ? 'blue' : 'orange',b.role === 'provider' ? 'P' : 'C')}</span>}))})) },
      { key: 'types-folder', title: `Types (${snapshot.messages.length + (snapshot.dataTypes?.length ?? 0)})`, icon: <DatabaseOutlined />,
        children: [
          {key:'msgtypes-folder',title:`Message Types (${snapshot.messages.length})`,icon:<FolderOpenOutlined />,children:snapshot.messages.filter(m=>hit(m.name)).map(m=>({key:`message:${m.id}`,title:<span>{m.name}{m.source==='custom'?T('purple','EXT'):null}</span>,icon:<FileTextOutlined />}))},
          {key:'datatypes-folder',title:`Custom Data Types (${snapshot.dataTypes?.length ?? 0})`,icon:<FolderOpenOutlined />,children:(snapshot.dataTypes??[]).filter(t=>hit(t.name)).map(t=>({key:`dataType:${t.id}`,title:`${t.name} · ${t.kind}`,icon:<DatabaseOutlined />}))},
        ]},
      { key: 'topics-folder', title: `DDS Topics (${snapshot.topics.length})`, icon: <DatabaseOutlined />,
        children: snapshot.topics.filter(t=>hit(t.name)).map(t=>({key:`topic:${t.id}`,title:t.name,icon:<DatabaseOutlined />})) },
      { key: 'qos-folder', title: `QoS Profiles (${snapshot.qosProfiles?.length ?? 0})`, icon: <ControlOutlined />,
        children: (snapshot.qosProfiles ?? []).filter(q=>hit(q.name)).map(q=>({key:`qos:${q.id}`,title:q.name,icon:<ControlOutlined />})) },
      { key: 'connections-folder', title: `Service Connections (${snapshot.connections.length})`, icon: <LinkOutlined />,
        children: snapshot.connections.map(c => ({ key: `connection:${c.id}`, title: snapshot.services.find(v => v.id === snapshot.bindings.find(b => b.id === c.providerBindingId)?.serviceId)?.name ?? 'Service', icon: <LinkOutlined /> })) },
    ];
    return [{ key:'project', title:<b>{snapshot.project.name}</b>,icon:<FolderOpenOutlined />,children:groups }];
  }, [snapshot, filter]);
  if (!snapshot) return <Empty description="프로젝트 로딩 중" />;
  const key = selected ? `${selected.kind}:${selected.id}` : '';
  return <div className="sidebar-section">
    <Typography.Text type="secondary" className="side-label">STANDARD / EXTENSIONS / ASSEMBLY</Typography.Text>
    <Input.Search size="small" placeholder="Service, Type, Component 검색" allowClear value={filter} onChange={e=>setFilter(e.target.value)} style={{margin:'9px 0'}} />
    <Tree showIcon showLine defaultExpandedKeys={['project','official-catalog','extensions','components-folder','functionalArea:MO','functionalArea:SA']} blockNode treeData={tree} selectedKeys={key?[key]:[]} onSelect={keys=>{
      const raw=String(keys[0]??''); const idx=raw.indexOf(':'); if(idx<0) return;
      const kind=raw.slice(0,idx);
      if(['functionalArea','component','service','interface','operation','topic','message','dataType','qos','binding','connection'].includes(kind)) select({kind,id:raw.slice(idx+1)});
    }}/>
    <Typography.Text type="secondary" className="small-hint">서비스는 영역에서 찾고, Components·Types·Topics·QoS는 독립적으로 참조합니다. 표준은 수정하지 않고 확장 항목을 추가합니다.</Typography.Text>
  </div>;
}
