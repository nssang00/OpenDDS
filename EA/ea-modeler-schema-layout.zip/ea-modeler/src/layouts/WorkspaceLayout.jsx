import { Splitter } from 'antd';
import { workspaceLayoutConfig } from '../layout/layoutConfig.js';
import PanelRenderer from '../layout/PanelRenderer.jsx';

export default function WorkspaceLayout() {
  return (
    <Splitter className="workspace-layout">
      {workspaceLayoutConfig.panels.map((panel) => (
        <Splitter.Panel
          key={panel.id}
          defaultSize={panel.defaultSize}
          min={panel.min}
          max={panel.max}
          className={panel.className}
        >
          <PanelRenderer panel={panel} />
        </Splitter.Panel>
      ))}
    </Splitter>
  );
}
