import ModelView from '../views/explorer/ModelView.jsx';
import SearchView from '../views/explorer/SearchView.jsx';
import DiagramView from '../views/workspace/DiagramView.jsx';
import IdlView from '../views/workspace/IdlView.jsx';
import QosXmlView from '../views/workspace/QosXmlView.jsx';
import ValidationView from '../views/workspace/ValidationView.jsx';
import MembersView from '../views/inspector/MembersView.jsx';
import PropertiesView from '../views/inspector/PropertiesView.jsx';
import QosView from '../views/inspector/QosView.jsx';

export const viewRegistry = {
  ModelView,
  SearchView,
  DiagramView,
  IdlView,
  QosXmlView,
  ValidationView,
  MembersView,
  PropertiesView,
  QosView,
};
