import { useMemo, useState } from 'react';
import { Alert, Empty, Segmented, Tree } from 'antd';
import { useModelStore } from '../stores/useModelStore.js';
import { useUiStore } from '../stores/useUiStore.js';
import { useDocumentStore } from '../document/documentStore.js';
import { createDocumentData } from '../document/documentMapper.js';
import TextEditor from '../components/TextEditor.jsx';

export default function DocumentBindingView() {
  const model = useModelStore((state) => state.model);
  const activeWorkspaceViewId = useUiStore((state) => state.activeWorkspaceViewId);
  const validationResult = useDocumentStore((state) => state.validationResult);
  const [mode, setMode] = useState('tree');

  const documentData = useMemo(() => createDocumentData(model), [model]);
  const treeData = useMemo(() => toTreeData(documentData), [documentData]);
  const jsonText = useMemo(() => JSON.stringify(documentData, null, 2), [documentData]);

  if (activeWorkspaceViewId !== 'document') {
    return (
      <div className="document-binding-view">
        <Empty description="Binding data is available in Document view" />
      </div>
    );
  }

  return (
    <div className="document-binding-view">
      <Segmented
        block
        size="small"
        value={mode}
        options={[
          { label: 'Tree', value: 'tree' },
          { label: 'JSON', value: 'json' },
        ]}
        onChange={setMode}
      />

      <div className="document-binding-content">
        {mode === 'tree' ? (
          <Tree
            className="document-data-tree"
            treeData={treeData}
            defaultExpandedKeys={['document', 'model']}
            blockNode
          />
        ) : (
          <div className="document-data-editor">
            <TextEditor value={jsonText} onChange={() => {}} />
          </div>
        )}
      </div>

      {validationResult && (
        <Alert
          className="document-binding-validation"
          type={validationResult.valid ? (validationResult.warnings.length ? 'warning' : 'success') : 'error'}
          showIcon
          message={validationResult.valid ? 'Template valid' : 'Template has errors'}
          description={`${validationResult.detectedTags.length} tags · ${validationResult.errors.length} errors · ${validationResult.warnings.length} warnings`}
        />
      )}
    </div>
  );
}

function toTreeData(data) {
  return Object.entries(data).map(([key, value]) => buildNode(key, value, key));
}

function buildNode(label, value, path) {
  if (Array.isArray(value)) {
    return {
      key: path,
      title: `${label} [${value.length}]`,
      children: value.map((item, index) => buildNode(`[${index}]`, item, `${path}.${index}`)),
    };
  }

  if (value && typeof value === 'object') {
    return {
      key: path,
      title: label,
      children: Object.entries(value).map(([key, child]) => buildNode(key, child, `${path}.${key}`)),
    };
  }

  return {
    key: path,
    title: `${label}: ${formatValue(value)}`,
    isLeaf: true,
  };
}

function formatValue(value) {
  if (value === '' || value == null) return '—';
  if (typeof value === 'boolean') return String(value);
  const text = String(value);
  return text.length > 50 ? `${text.slice(0, 50)}…` : text;
}
