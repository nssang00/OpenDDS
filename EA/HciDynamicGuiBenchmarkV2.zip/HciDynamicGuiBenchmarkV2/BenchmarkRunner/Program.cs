using System.Diagnostics;
using System.Globalization;
using System.Net;
using System.Text;

var o = Options.Parse(args);
Directory.CreateDirectory(o.OutputDir);
var manifest = ManifestReader.Read(o.ManifestPath);
var scales = o.Scales.Where(s => s > 0 && s <= manifest.Count).Distinct().OrderBy(s => s).ToArray();
if (scales.Length == 0) throw new ArgumentException("No valid scales.");

Console.WriteLine("============================================================");
Console.WriteLine(" HCI Dynamic GUI Benchmark V2");
Console.WriteLine("============================================================");
Console.WriteLine($"Views      : {manifest.Count}");
Console.WriteLine($"Scales     : {string.Join(", ", scales)}");
Console.WriteLine($"Runs       : {o.Runs}");
Console.WriteLine($"Warm-up    : {o.WarmupSeconds}s");
Console.WriteLine($"CPU sample : {o.SampleSeconds}s");
Console.WriteLine($"Window     : {o.Width}x{o.Height}");
Console.WriteLine();

var resourceRows = new List<ResourceRow>();
var timingRows = new List<TimingRow>();

for (var run = 1; run <= o.Runs; run++)
{
    var runDir = Path.Combine(o.OutputDir, $"run_{run:D2}");
    Directory.CreateDirectory(runDir);
    Console.WriteLine($"\n================ RUN {run}/{o.Runs} ================");

    foreach (var scale in scales)
    {
        Console.WriteLine($"\n[{run}/{o.Runs}] Scale {scale}: Legacy {scale} processes");
        var legacy = await RunLegacyAsync(o, manifest.Take(scale).ToArray(), runDir, run, scale);
        resourceRows.Add(legacy);
        Console.WriteLine($"  Ready {legacy.InitMs / 1000.0:F2}s | Private {legacy.PrivateMb:F1} MB | WS {legacy.WorkingSetMb:F1} MB | CPU {legacy.CpuPercent:F2}%");
        await Task.Delay(1500);

        Console.WriteLine($"[{run}/{o.Runs}] Scale {scale}: Dynamic 1 process / {scale} views");
        var dynamicRow = await RunDynamicResourceAsync(o, runDir, run, scale, "all", "DynamicRuntime");
        resourceRows.Add(dynamicRow);
        Console.WriteLine($"  Ready {dynamicRow.InitMs / 1000.0:F2}s | Private {dynamicRow.PrivateMb:F1} MB | WS {dynamicRow.WorkingSetMb:F1} MB | CPU {dynamicRow.CpuPercent:F2}%");
        await Task.Delay(1500);
    }

    var maxScale = scales.Max();
    Console.WriteLine($"\n[{run}/{o.Runs}] Lifecycle policy check at {maxScale} views");
    var policyRow = await RunDynamicResourceAsync(o, runDir, run, maxScale, "manifest", "DynamicLifecyclePolicy");
    resourceRows.Add(policyRow);
    Console.WriteLine($"  Private {policyRow.PrivateMb:F1} MB | Repository policy applied");

    Console.WriteLine($"[{run}/{o.Runs}] First-load / reuse timing benchmark");
    var timingPath = Path.Combine(runDir, "dynamic_view_times.csv");
    await RunTimingAsync(o, timingPath);
    var tr = ReadTimingRows(timingPath, run);
    timingRows.AddRange(tr);
    Console.WriteLine($"  Timing samples: {tr.Count}");
}

WriteRawResourceCsv(Path.Combine(o.OutputDir, "resource_raw.csv"), resourceRows);
WriteRawTimingCsv(Path.Combine(o.OutputDir, "timing_raw.csv"), timingRows);
var resourceSummary = AggregateResources(resourceRows);
var timingSummary = AggregateTimings(timingRows);
WriteResourceSummaryCsv(Path.Combine(o.OutputDir, "resource_summary.csv"), resourceSummary);
WriteTimingSummaryCsv(Path.Combine(o.OutputDir, "timing_summary.csv"), timingSummary);
WritePaperSummary(Path.Combine(o.OutputDir, "paper_summary.csv"), resourceSummary, timingSummary, scales.Max());
WriteMarkdown(Path.Combine(o.OutputDir, "report.md"), o, manifest, resourceSummary, timingSummary, scales.Max());
WriteHtml(Path.Combine(o.OutputDir, "report.html"), o, manifest, resourceSummary, timingSummary, scales.Max());

Console.WriteLine("\n============================================================");
Console.WriteLine(" COMPLETE");
Console.WriteLine("============================================================");
Console.WriteLine($"Results: {o.OutputDir}");
Console.WriteLine("Open report.html for an easy-to-read summary.");
return 0;

static async Task<ResourceRow> RunLegacyAsync(Options o, ViewMeta[] views, string runDir, int run, int scale)
{
    var readyDir = Path.Combine(runDir, $"legacy_{scale}_ready");
    ResetDir(readyDir);
    var processes = new List<Process>();
    var sw = Stopwatch.StartNew();
    try
    {
        foreach (var meta in views)
        {
            var ready = Path.Combine(readyDir, $"{meta.ViewId}.ready");
            processes.Add(Start(o.LegacyExe, new[]
            {
                "--xaml", meta.FullPath, "--view-id", meta.ViewId, "--ready-file", ready,
                "--width", o.Width.ToString(CultureInfo.InvariantCulture), "--height", o.Height.ToString(CultureInfo.InvariantCulture)
            }));
        }
        await WaitForReadyAsync(processes, readyDir, views.Length, o.ReadyTimeoutSeconds);
        sw.Stop();
        await Task.Delay(TimeSpan.FromSeconds(o.WarmupSeconds));
        var m = await MeasureProcessesAsync(processes, TimeSpan.FromSeconds(o.SampleSeconds));
        return new ResourceRow(run, scale, "LegacyMultiApp", processes.Count, m.WorkingSetMb, m.PrivateMb, m.CpuPercent, sw.Elapsed.TotalMilliseconds);
    }
    finally { StopAll(processes); }
}

static async Task<ResourceRow> RunDynamicResourceAsync(Options o, string runDir, int run, int scale, string policyMode, string mode)
{
    var ready = Path.Combine(runDir, $"dynamic_{policyMode}_{scale}.ready");
    var error = Path.Combine(runDir, $"dynamic_{policyMode}_{scale}.error.txt");
    if (File.Exists(ready)) File.Delete(ready);
    if (File.Exists(error)) File.Delete(error);
    Process? p = null;
    var sw = Stopwatch.StartNew();
    try
    {
        p = Start(o.DynamicExe, new[]
        {
            "--manifest", o.ManifestPath, "--load-count", scale.ToString(CultureInfo.InvariantCulture),
            "--policy-mode", policyMode, "--ready-file", ready, "--error-file", error,
            "--width", o.Width.ToString(CultureInfo.InvariantCulture), "--height", o.Height.ToString(CultureInfo.InvariantCulture)
        });
        await WaitForSingleReadyAsync(p, ready, error, o.ReadyTimeoutSeconds);
        sw.Stop();
        await Task.Delay(TimeSpan.FromSeconds(o.WarmupSeconds));
        var m = await MeasureProcessesAsync(new[] { p }, TimeSpan.FromSeconds(o.SampleSeconds));
        return new ResourceRow(run, scale, mode, 1, m.WorkingSetMb, m.PrivateMb, m.CpuPercent, sw.Elapsed.TotalMilliseconds);
    }
    finally { if (p is not null) StopAll(new[] { p }); }
}

static async Task RunTimingAsync(Options o, string outputPath)
{
    if (File.Exists(outputPath)) File.Delete(outputPath);
    var error = outputPath + ".error.txt";
    if (File.Exists(error)) File.Delete(error);
    using var p = Start(o.DynamicExe, new[]
    {
        "--manifest", o.ManifestPath, "--timing-out", outputPath, "--error-file", error,
        "--reuse-iterations", o.ReuseIterations.ToString(CultureInfo.InvariantCulture),
        "--samples-per-level", o.SamplesPerLevel.ToString(CultureInfo.InvariantCulture),
        "--width", o.Width.ToString(CultureInfo.InvariantCulture), "--height", o.Height.ToString(CultureInfo.InvariantCulture)
    });
    var deadline = DateTime.UtcNow.AddSeconds(o.ReadyTimeoutSeconds);
    while (!File.Exists(outputPath) && DateTime.UtcNow < deadline)
    {
        if (p.HasExited)
        {
            if (File.Exists(error)) throw new InvalidOperationException(File.ReadAllText(error));
            throw new InvalidOperationException($"Dynamic timing process exited early ({p.ExitCode}).");
        }
        await Task.Delay(100);
    }
    if (!File.Exists(outputPath))
    {
        try { p.Kill(true); } catch { }
        throw new TimeoutException("Timing benchmark timeout.");
    }
    if (!p.WaitForExit(15000)) { try { p.Kill(true); } catch { } }
}

static async Task WaitForReadyAsync(List<Process> processes, string readyDir, int expected, int timeoutSec)
{
    var deadline = DateTime.UtcNow.AddSeconds(timeoutSec);
    while (DateTime.UtcNow < deadline)
    {
        var ready = Directory.Exists(readyDir) ? Directory.GetFiles(readyDir, "*.ready").Length : 0;
        if (ready >= expected) return;
        var exited = processes.Count(p => p.HasExited);
        if (exited > 0) throw new InvalidOperationException($"{exited} legacy process(es) exited before ready.");
        await Task.Delay(100);
    }
    throw new TimeoutException($"Legacy ready timeout: {expected} processes.");
}

static async Task WaitForSingleReadyAsync(Process p, string ready, string error, int timeoutSec)
{
    var deadline = DateTime.UtcNow.AddSeconds(timeoutSec);
    while (DateTime.UtcNow < deadline)
    {
        if (File.Exists(ready)) return;
        if (p.HasExited)
        {
            if (File.Exists(error)) throw new InvalidOperationException(File.ReadAllText(error));
            throw new InvalidOperationException($"Dynamic process exited before ready ({p.ExitCode}).");
        }
        await Task.Delay(100);
    }
    throw new TimeoutException("Dynamic ready timeout.");
}

static Process Start(string exe, IEnumerable<string> arguments)
{
    var psi = new ProcessStartInfo(exe) { UseShellExecute = false, WorkingDirectory = Path.GetDirectoryName(exe)! };
    foreach (var arg in arguments) psi.ArgumentList.Add(arg);
    return Process.Start(psi) ?? throw new InvalidOperationException($"Could not start {exe}");
}

static async Task<(double WorkingSetMb, double PrivateMb, double CpuPercent)> MeasureProcessesAsync(IEnumerable<Process> source, TimeSpan duration)
{
    var ps = source.Where(p => !p.HasExited).ToArray();
    foreach (var p in ps) p.Refresh();
    var start = ps.ToDictionary(p => p.Id, p => p.TotalProcessorTime);
    var sw = Stopwatch.StartNew();
    await Task.Delay(duration);
    sw.Stop();
    double ws = 0, priv = 0, cpuMs = 0;
    foreach (var p in ps)
    {
        if (p.HasExited) continue;
        p.Refresh();
        ws += p.WorkingSet64 / 1024.0 / 1024.0;
        priv += p.PrivateMemorySize64 / 1024.0 / 1024.0;
        if (start.TryGetValue(p.Id, out var c0)) cpuMs += (p.TotalProcessorTime - c0).TotalMilliseconds;
    }
    var cpu = cpuMs / sw.Elapsed.TotalMilliseconds / Environment.ProcessorCount * 100.0;
    return (ws, priv, cpu);
}

static void StopAll(IEnumerable<Process> processes)
{
    foreach (var p in processes)
    {
        try
        {
            if (!p.HasExited)
            {
                p.CloseMainWindow();
                if (!p.WaitForExit(1000)) p.Kill(true);
            }
        }
        catch { }
        finally { p.Dispose(); }
    }
}

static void ResetDir(string path)
{
    if (Directory.Exists(path)) Directory.Delete(path, true);
    Directory.CreateDirectory(path);
}

static List<TimingRow> ReadTimingRows(string path, int run)
{
    var result = new List<TimingRow>();
    foreach (var line in File.ReadLines(path).Skip(1))
    {
        var c = line.Split(',');
        if (c.Length < 11) continue;
        result.Add(new TimingRow(run, c[0], c[1], c[2], c[3], int.Parse(c[4], CultureInfo.InvariantCulture), int.Parse(c[5], CultureInfo.InvariantCulture), int.Parse(c[6], CultureInfo.InvariantCulture), long.Parse(c[7], CultureInfo.InvariantCulture), c[8], int.Parse(c[9], CultureInfo.InvariantCulture), double.Parse(c[10], CultureInfo.InvariantCulture)));
    }
    return result;
}

static void WriteRawResourceCsv(string path, IEnumerable<ResourceRow> rows)
{
    var sb = new StringBuilder("Run,Scale,Mode,ProcessCount,WorkingSetMB,PrivateMemoryMB,CPUPercent,FullInitializationTimeMs\n");
    foreach (var r in rows) sb.AppendLine($"{r.Run},{r.Scale},{r.Mode},{r.ProcessCount},{F(r.WorkingSetMb)},{F(r.PrivateMb)},{F(r.CpuPercent)},{F(r.InitMs)}");
    File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
}

static void WriteRawTimingCsv(string path, IEnumerable<TimingRow> rows)
{
    var sb = new StringBuilder("Run,ViewId,Category,Complexity,Policy,ElementCount,BindingCount,TreeDepth,FileSizeBytes,Phase,Iteration,ElapsedMs\n");
    foreach (var r in rows) sb.AppendLine($"{r.Run},{r.ViewId},{r.Category},{r.Complexity},{r.Policy},{r.ElementCount},{r.BindingCount},{r.TreeDepth},{r.FileSizeBytes},{r.Phase},{r.Iteration},{F(r.ElapsedMs)}");
    File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
}

static List<ResourceSummary> AggregateResources(List<ResourceRow> rows) => rows
    .GroupBy(r => new { r.Scale, r.Mode })
    .Select(g => new ResourceSummary(g.Key.Scale, g.Key.Mode, g.Average(x => x.ProcessCount), g.Average(x => x.WorkingSetMb), Std(g.Select(x => x.WorkingSetMb)), g.Average(x => x.PrivateMb), Std(g.Select(x => x.PrivateMb)), g.Average(x => x.CpuPercent), Std(g.Select(x => x.CpuPercent)), g.Average(x => x.InitMs), Std(g.Select(x => x.InitMs))))
    .OrderBy(x => x.Scale).ThenBy(x => x.Mode).ToList();

static List<TimingSummary> AggregateTimings(List<TimingRow> rows) => rows
    .GroupBy(r => new { r.Complexity, r.Phase })
    .Select(g =>
    {
        var a = g.Select(x => x.ElapsedMs).OrderBy(x => x).ToArray();
        return new TimingSummary(g.Key.Complexity, g.Key.Phase, a.Length, a.Average(), Std(a), Percentile(a, .50), Percentile(a, .95));
    }).OrderBy(x => ComplexityOrder(x.Complexity)).ThenBy(x => x.Phase).ToList();

static void WriteResourceSummaryCsv(string path, IEnumerable<ResourceSummary> rows)
{
    var sb = new StringBuilder("Scale,Mode,ProcessCountMean,WorkingSetMBMean,WorkingSetMBStd,PrivateMemoryMBMean,PrivateMemoryMBStd,CPUPercentMean,CPUPercentStd,FullInitializationTimeMsMean,FullInitializationTimeMsStd\n");
    foreach (var r in rows) sb.AppendLine($"{r.Scale},{r.Mode},{F(r.ProcessCount)},{F(r.WorkingSetMean)},{F(r.WorkingSetStd)},{F(r.PrivateMean)},{F(r.PrivateStd)},{F(r.CpuMean)},{F(r.CpuStd)},{F(r.InitMean)},{F(r.InitStd)}");
    File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
}

static void WriteTimingSummaryCsv(string path, IEnumerable<TimingSummary> rows)
{
    var sb = new StringBuilder("Complexity,Phase,Samples,MeanMs,StdMs,MedianMs,P95Ms\n");
    foreach (var r in rows) sb.AppendLine($"{r.Complexity},{r.Phase},{r.Samples},{F(r.Mean)},{F(r.Std)},{F(r.Median)},{F(r.P95)}");
    File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
}

static void WritePaperSummary(string path, List<ResourceSummary> rs, List<TimingSummary> ts, int maxScale)
{
    var legacy = rs.First(r => r.Scale == maxScale && r.Mode == "LegacyMultiApp");
    var dyn = rs.First(r => r.Scale == maxScale && r.Mode == "DynamicRuntime");
    var first = ts.Where(t => t.Phase == "FirstLoad").Average(t => t.Mean);
    var reuse = ts.Where(t => t.Phase == "Reuse").Average(t => t.Mean);
    var sb = new StringBuilder("Metric,Legacy,Proposed,Unit\n");
    sb.AppendLine($"ProcessCount,{F(legacy.ProcessCount)},{F(dyn.ProcessCount)},count");
    sb.AppendLine($"PrivateMemory,{F(legacy.PrivateMean)},{F(dyn.PrivateMean)},MB");
    sb.AppendLine($"WorkingSet,{F(legacy.WorkingSetMean)},{F(dyn.WorkingSetMean)},MB");
    sb.AppendLine($"IdleCPU,{F(legacy.CpuMean)},{F(dyn.CpuMean)},percent");
    sb.AppendLine($"FullInitializationTime,{F(legacy.InitMean)},{F(dyn.InitMean)},ms");
    sb.AppendLine($"DynamicFirstLoad,-,{F(first)},ms");
    sb.AppendLine($"DynamicReuse,-,{F(reuse)},ms");
    File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
}

static void WriteMarkdown(string path, Options o, List<ViewMeta> manifest, List<ResourceSummary> rs, List<TimingSummary> ts, int maxScale)
{
    var sb = new StringBuilder();
    sb.AppendLine("# HCI Dynamic GUI Benchmark V2");
    sb.AppendLine();
    sb.AppendLine($"- Timestamp: {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
    sb.AppendLine($"- OS: {Environment.OSVersion}");
    sb.AppendLine($"- .NET: {Environment.Version}");
    sb.AppendLine($"- Logical processors: {Environment.ProcessorCount}");
    sb.AppendLine($"- Views: {manifest.Count}");
    sb.AppendLine($"- Runs: {o.Runs}");
    sb.AppendLine($"- Window: {o.Width} x {o.Height}");
    sb.AppendLine();
    sb.AppendLine("## Scalability result");
    sb.AppendLine("| Scale | Mode | Processes | Private MB | Working Set MB | CPU % | Full Init ms |");
    sb.AppendLine("|---:|---|---:|---:|---:|---:|---:|");
    foreach (var r in rs.Where(r => r.Mode != "DynamicLifecyclePolicy")) sb.AppendLine($"| {r.Scale} | {r.Mode} | {r.ProcessCount:F1} | {r.PrivateMean:F1} | {r.WorkingSetMean:F1} | {r.CpuMean:F2} | {r.InitMean:F1} |");
    sb.AppendLine();
    sb.AppendLine("## View timing by XAML complexity");
    sb.AppendLine("| Complexity | Phase | Samples | Mean ms | Std | Median | P95 |");
    sb.AppendLine("|---|---|---:|---:|---:|---:|---:|");
    foreach (var t in ts) sb.AppendLine($"| {t.Complexity} | {t.Phase} | {t.Samples} | {t.Mean:F4} | {t.Std:F4} | {t.Median:F4} | {t.P95:F4} |");
    sb.AppendLine();
    var policy = rs.FirstOrDefault(r => r.Scale == maxScale && r.Mode == "DynamicLifecyclePolicy");
    var all = rs.First(r => r.Scale == maxScale && r.Mode == "DynamicRuntime");
    if (policy is not null)
    {
        sb.AppendLine("## Lifecycle policy check");
        sb.AppendLine($"At {maxScale} views: retain-all private memory {all.PrivateMean:F1} MB, manifest-policy private memory {policy.PrivateMean:F1} MB.");
    }
    sb.AppendLine();
    sb.AppendLine("> Interpretation note: Working Set sums can double-count shared pages across processes. Use Private Memory as the primary process-memory comparison and Working Set as a supporting metric.");
    File.WriteAllText(path, sb.ToString(), new UTF8Encoding(false));
}

static void WriteHtml(string path, Options o, List<ViewMeta> manifest, List<ResourceSummary> rs, List<TimingSummary> ts, int maxScale)
{
    var legacy = rs.Where(r => r.Mode == "LegacyMultiApp").OrderBy(r => r.Scale).ToArray();
    var dyn = rs.Where(r => r.Mode == "DynamicRuntime").OrderBy(r => r.Scale).ToArray();
    var maxPrivate = Math.Max(legacy.Max(x => x.PrivateMean), dyn.Max(x => x.PrivateMean));
    var maxInit = Math.Max(legacy.Max(x => x.InitMean), dyn.Max(x => x.InitMean));
    var html = new StringBuilder();
    html.Append("<!doctype html><html><head><meta charset='utf-8'><title>HCI Benchmark</title><style>body{font-family:Segoe UI,Arial,sans-serif;margin:32px;max-width:1100px}table{border-collapse:collapse;width:100%;margin:12px 0 28px}th,td{border:1px solid #bbb;padding:6px 8px;text-align:right}th:first-child,td:first-child{text-align:left}h1,h2{margin-top:28px}.card{border:1px solid #ccc;padding:16px;margin:16px 0}.note{background:#f4f4f4;padding:12px}svg{width:100%;height:300px;border:1px solid #ddd}</style></head><body>");
    html.Append($"<h1>HCI Dynamic GUI Benchmark V2</h1><p>{WebUtility.HtmlEncode(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"))} · Views {manifest.Count} · Runs {o.Runs} · Window {o.Width}×{o.Height}</p>");
    html.Append("<h2>Scalability</h2><table><tr><th>Scale</th><th>Mode</th><th>Processes</th><th>Private MB</th><th>Working Set MB</th><th>CPU %</th><th>Full Init ms</th></tr>");
    foreach (var r in rs.Where(r => r.Mode != "DynamicLifecyclePolicy")) html.Append($"<tr><td>{r.Scale}</td><td>{r.Mode}</td><td>{r.ProcessCount:F1}</td><td>{r.PrivateMean:F1}</td><td>{r.WorkingSetMean:F1}</td><td>{r.CpuMean:F2}</td><td>{r.InitMean:F1}</td></tr>");
    html.Append("</table>");
    html.Append("<h2>Private memory trend</h2>");
    html.Append(SvgLineChart(legacy.Select(x => (x.Scale, x.PrivateMean)).ToArray(), dyn.Select(x => (x.Scale, x.PrivateMean)).ToArray(), maxPrivate, "MB"));
    html.Append("<h2>Full initialization time trend</h2>");
    html.Append(SvgLineChart(legacy.Select(x => (x.Scale, x.InitMean)).ToArray(), dyn.Select(x => (x.Scale, x.InitMean)).ToArray(), maxInit, "ms"));
    html.Append("<h2>XAML complexity timing</h2><table><tr><th>Complexity</th><th>Phase</th><th>Samples</th><th>Mean ms</th><th>Std</th><th>Median</th><th>P95</th></tr>");
    foreach (var t in ts) html.Append($"<tr><td>{t.Complexity}</td><td>{t.Phase}</td><td>{t.Samples}</td><td>{t.Mean:F4}</td><td>{t.Std:F4}</td><td>{t.Median:F4}</td><td>{t.P95:F4}</td></tr>");
    html.Append("</table>");
    var all = rs.First(r => r.Scale == maxScale && r.Mode == "DynamicRuntime");
    var policy = rs.FirstOrDefault(r => r.Scale == maxScale && r.Mode == "DynamicLifecyclePolicy");
    if (policy is not null) html.Append($"<div class='card'><h2>Lifecycle policy check ({maxScale} views)</h2><p>Retain all: <b>{all.PrivateMean:F1} MB</b> private memory<br>Manifest policy: <b>{policy.PrivateMean:F1} MB</b> private memory</p></div>");
    html.Append("<div class='note'><b>Measurement note.</b> Private Memory is the primary memory metric. Working Set is also recorded but summing it across processes can double-count shared pages. Dynamic First Load includes validation, file read, XAML parsing, object creation and layout; Reuse includes repository lookup, host reattachment and layout.</div>");
    html.Append("</body></html>");
    File.WriteAllText(path, html.ToString(), new UTF8Encoding(false));
}

static string SvgLineChart((int x, double y)[] legacy, (int x, double y)[] dyn, double maxY, string unit)
{
    const double W = 900, H = 280, L = 70, R = 25, T = 20, B = 45;
    var maxX = Math.Max(legacy.Max(p => p.x), dyn.Max(p => p.x));
    maxY = maxY <= 0 ? 1 : maxY * 1.10;
    double X(int x) => L + (W - L - R) * x / maxX;
    double Y(double y) => T + (H - T - B) * (1 - y / maxY);
    string Poly((int x, double y)[] pts) => string.Join(' ', pts.Select(p => $"{X(p.x):F1},{Y(p.y):F1}"));
    var s = new StringBuilder($"<svg viewBox='0 0 {W} {H}' role='img'>");
    s.Append($"<line x1='{L}' y1='{H-B}' x2='{W-R}' y2='{H-B}' stroke='#777'/><line x1='{L}' y1='{T}' x2='{L}' y2='{H-B}' stroke='#777'/>");
    foreach (var p in legacy.Concat(dyn).Select(p => p.x).Distinct().OrderBy(x => x)) s.Append($"<text x='{X(p):F1}' y='{H-18}' font-size='12' text-anchor='middle'>{p}</text>");
    s.Append($"<polyline fill='none' stroke='#333' stroke-width='2.5' points='{Poly(legacy)}'/><polyline fill='none' stroke='#888' stroke-width='2.5' stroke-dasharray='7 4' points='{Poly(dyn)}'/>");
    foreach (var p in legacy) s.Append($"<circle cx='{X(p.x):F1}' cy='{Y(p.y):F1}' r='4'/>");
    foreach (var p in dyn) s.Append($"<rect x='{X(p.x)-4:F1}' y='{Y(p.y)-4:F1}' width='8' height='8'/>");
    s.Append($"<text x='{L}' y='{T+12}' font-size='12'>max {maxY:F1} {unit}</text><text x='{W-250}' y='20' font-size='12'>● Legacy   ■ Dynamic</text></svg>");
    return s.ToString();
}

static double Std(IEnumerable<double> values)
{
    var a = values.ToArray();
    if (a.Length <= 1) return 0;
    var mean = a.Average();
    return Math.Sqrt(a.Sum(x => (x - mean) * (x - mean)) / (a.Length - 1));
}
static double Percentile(double[] a, double p)
{
    if (a.Length == 0) return double.NaN;
    var pos = (a.Length - 1) * p;
    var lo = (int)Math.Floor(pos); var hi = (int)Math.Ceiling(pos);
    return lo == hi ? a[lo] : a[lo] + (a[hi] - a[lo]) * (pos - lo);
}
static int ComplexityOrder(string c) => c switch { "Light" => 0, "Medium" => 1, "Heavy" => 2, "VeryHeavy" => 3, _ => 9 };
static string F(double x) => x.ToString("F6", CultureInfo.InvariantCulture);

record ResourceRow(int Run, int Scale, string Mode, int ProcessCount, double WorkingSetMb, double PrivateMb, double CpuPercent, double InitMs);
record TimingRow(int Run, string ViewId, string Category, string Complexity, string Policy, int ElementCount, int BindingCount, int TreeDepth, long FileSizeBytes, string Phase, int Iteration, double ElapsedMs);
record ResourceSummary(int Scale, string Mode, double ProcessCount, double WorkingSetMean, double WorkingSetStd, double PrivateMean, double PrivateStd, double CpuMean, double CpuStd, double InitMean, double InitStd);
record TimingSummary(string Complexity, string Phase, int Samples, double Mean, double Std, double Median, double P95);
record ViewMeta(int Index, string ViewId, string Category, string Complexity, string Policy, string FileName, int ElementCount, int BindingCount, int TreeDepth, long FileSizeBytes, string FullPath);

static class ManifestReader
{
    public static List<ViewMeta> Read(string path)
    {
        var dir = Path.GetDirectoryName(Path.GetFullPath(path))!;
        return File.ReadLines(path).Skip(1).Where(l => !string.IsNullOrWhiteSpace(l)).Select(line =>
        {
            var c = line.Split(',');
            return new ViewMeta(int.Parse(c[0], CultureInfo.InvariantCulture), c[1], c[2], c[3], c[4], c[5], int.Parse(c[6], CultureInfo.InvariantCulture), int.Parse(c[7], CultureInfo.InvariantCulture), int.Parse(c[8], CultureInfo.InvariantCulture), long.Parse(c[9], CultureInfo.InvariantCulture), Path.Combine(dir, c[5]));
        }).ToList();
    }
}

sealed class Options
{
    public string LegacyExe { get; init; } = "";
    public string DynamicExe { get; init; } = "";
    public string ManifestPath { get; init; } = "";
    public string OutputDir { get; init; } = "";
    public int[] Scales { get; init; } = new[] { 20, 50, 100, 150 };
    public int Runs { get; init; } = 5;
    public int WarmupSeconds { get; init; } = 10;
    public int SampleSeconds { get; init; } = 10;
    public int ReadyTimeoutSeconds { get; init; } = 240;
    public int ReuseIterations { get; init; } = 50;
    public int SamplesPerLevel { get; init; } = 5;
    public int Width { get; init; } = 1280;
    public int Height { get; init; } = 720;

    public static Options Parse(string[] args)
    {
        string? Get(string key)
        {
            for (var i = 0; i < args.Length - 1; i++) if (args[i].Equals(key, StringComparison.OrdinalIgnoreCase)) return args[i + 1];
            return null;
        }
        int GI(string k, int d) => int.TryParse(Get(k), out var x) ? x : d;
        var scales = (Get("--scales") ?? "20,50,100,150").Split(',', StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
        return new Options
        {
            LegacyExe = Path.GetFullPath(Get("--legacy") ?? throw new ArgumentException("--legacy required")),
            DynamicExe = Path.GetFullPath(Get("--dynamic") ?? throw new ArgumentException("--dynamic required")),
            ManifestPath = Path.GetFullPath(Get("--manifest") ?? throw new ArgumentException("--manifest required")),
            OutputDir = Path.GetFullPath(Get("--output") ?? "results"),
            Scales = scales,
            Runs = GI("--runs", 5), WarmupSeconds = GI("--warmup", 10), SampleSeconds = GI("--sample", 10), ReadyTimeoutSeconds = GI("--timeout", 240),
            ReuseIterations = GI("--reuse-iterations", 50), SamplesPerLevel = GI("--samples-per-level", 5), Width = GI("--width", 1280), Height = GI("--height", 720)
        };
    }
}
