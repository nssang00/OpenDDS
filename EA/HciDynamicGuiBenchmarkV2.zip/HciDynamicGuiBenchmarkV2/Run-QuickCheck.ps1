param([string]$Configuration = "Release")
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
& "$root\Run-Benchmark.ps1" -Runs 1 -Scales @(5,10,20) -MaxViews 20 -WarmupSeconds 2 -SampleSeconds 2 -ReuseIterations 10 -SamplesPerLevel 1 -Configuration $Configuration
