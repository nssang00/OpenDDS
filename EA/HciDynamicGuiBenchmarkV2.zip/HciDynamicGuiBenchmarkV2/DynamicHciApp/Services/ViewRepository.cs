using System.Windows;

namespace DynamicHciApp.Services;

public enum ViewLifetimePolicy { Persistent, Reusable, Transient }

public sealed class ViewRepository
{
    private readonly Dictionary<string, FrameworkElement> _views = new(StringComparer.OrdinalIgnoreCase);
    public bool TryGet(string viewId, out FrameworkElement? view) => _views.TryGetValue(viewId, out view);
    public void Register(string viewId, FrameworkElement view) => _views[viewId] = view;
    public void Release(string viewId) => _views.Remove(viewId);
    public void Clear() => _views.Clear();
    public int Count => _views.Count;
}
