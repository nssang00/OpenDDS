using System.IO;
using System.Windows;
using System.Windows.Markup;
using System.Xml;

namespace DynamicHciApp.Services;

public sealed class DynamicXamlLoader
{
    private readonly XamlValidationManager _validator;
    public DynamicXamlLoader(XamlValidationManager validator) => _validator = validator;

    public FrameworkElement Load(string path)
    {
        var text = File.ReadAllText(path);
        _validator.Validate(text);
        using var sr = new StringReader(text);
        using var xr = XmlReader.Create(sr, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null });
        return XamlReader.Load(xr) as FrameworkElement
            ?? throw new InvalidOperationException("XAML root is not FrameworkElement.");
    }
}
