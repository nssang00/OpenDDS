using System.Xml.Linq;

namespace DynamicHciApp.Services;

public sealed class XamlValidationManager
{
    private static readonly HashSet<string> AllowedElements = new(StringComparer.OrdinalIgnoreCase)
    {
        "UserControl", "Grid", "Grid.RowDefinitions", "Grid.ColumnDefinitions", "RowDefinition", "ColumnDefinition",
        "StackPanel", "UniformGrid", "WrapPanel", "Border", "Canvas", "ScrollViewer", "TextBlock", "TextBox", "Button",
        "CheckBox", "ComboBox", "ComboBoxItem", "ListBox", "ListBoxItem", "ProgressBar", "Ellipse", "Rectangle", "Line",
        "GroupBox", "Separator", "Slider"
    };

    private static readonly string[] ForbiddenNames =
    {
        "Class", "Click", "Loaded", "Unloaded", "MouseDown", "MouseUp", "MouseMove", "KeyDown", "KeyUp",
        "PreviewMouseDown", "PreviewMouseUp", "PreviewKeyDown", "PreviewKeyUp"
    };

    public void Validate(string xamlText)
    {
        var doc = XDocument.Parse(xamlText, LoadOptions.PreserveWhitespace);
        foreach (var element in doc.Root!.DescendantsAndSelf())
        {
            if (!AllowedElements.Contains(element.Name.LocalName))
                throw new InvalidOperationException($"Disallowed XAML element: {element.Name.LocalName}");

            foreach (var attr in element.Attributes())
            {
                var name = attr.Name.LocalName;
                if (ForbiddenNames.Any(f => name.Equals(f, StringComparison.OrdinalIgnoreCase)))
                    throw new InvalidOperationException($"Disallowed XAML attribute/event: {name}");
            }
        }
    }
}
