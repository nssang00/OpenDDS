using System.Windows;

namespace DynamicHciApp;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        var options = AppOptions.Parse(e.Args);
        var window = new MainWindow(options);
        window.Show();
    }
}
