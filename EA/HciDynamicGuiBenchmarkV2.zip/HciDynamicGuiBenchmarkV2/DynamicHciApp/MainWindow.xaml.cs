using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Threading;
using DynamicHciApp.Services;

namespace DynamicHciApp;

public partial class MainWindow : Window
{
    private readonly AppOptions _options;
    private readonly ViewRepository _repository = new();
    private readonly DynamicXamlLoader _loader = new(new XamlValidationManager());
    private List<ViewMeta> _manifest = new();

    public MainWindow(AppOptions options)
    {
        _options = options;
        InitializeComponent();
        Width = _options.Width;
        Height = _options.Height;
        Title = "Dynamic HCI Runtime";
        Loaded += OnLoaded;
    }

    private async void OnLoaded(object sender, RoutedEventArgs e)
    {
        try
        {
            _manifest = ManifestReader.Read(_options.ManifestPath);
            await Dispatcher.Yield(DispatcherPriority.ApplicationIdle);

            if (!string.IsNullOrWhiteSpace(_options.TimingOut))
            {
                await RunTimingBenchmarkAsync(_options.TimingOut!);
                Application.Current.Shutdown();
                return;
            }

            await RunResourceLoadAsync();
            SignalReady();
        }
        catch (Exception ex)
        {
            StatusText.Text = ex.ToString();
            if (!string.IsNullOrWhiteSpace(_options.ErrorFile))
            {
                Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(_options.ErrorFile!))!);
                File.WriteAllText(_options.ErrorFile!, ex.ToString());
            }
            Application.Current.Shutdown(2);
        }
    }

    private async Task RunResourceLoadAsync()
    {
        var views = _manifest.Take(Math.Min(_options.LoadCount, _manifest.Count)).ToArray();
        FrameworkElement? display = null;
        var loaded = 0;

        foreach (var meta in views)
        {
            var view = _loader.Load(meta.FullPath);
            ViewHost.Content = view;
            ViewHost.UpdateLayout();
            display = view;

            var retain = _options.PolicyMode.Equals("all", StringComparison.OrdinalIgnoreCase)
                || !meta.Policy.Equals("Transient", StringComparison.OrdinalIgnoreCase);
            if (retain) _repository.Register(meta.ViewId, view);
            loaded++;
            if (loaded % 10 == 0)
            {
                StatusText.Text = $"Loaded {loaded}/{views.Length} | repository {_repository.Count}";
                await Dispatcher.Yield(DispatcherPriority.Background);
            }
        }

        if (_options.PolicyMode.Equals("manifest", StringComparison.OrdinalIgnoreCase))
        {
            var firstRetained = views.FirstOrDefault(v => !v.Policy.Equals("Transient", StringComparison.OrdinalIgnoreCase));
            if (firstRetained is not null && _repository.TryGet(firstRetained.ViewId, out var retained) && retained is not null)
                ViewHost.Content = retained;
            else
                ViewHost.Content = display;
        }

        ViewHost.UpdateLayout();
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        StatusText.Text = $"READY | Views {views.Length} | Repository {_repository.Count} | Policy {_options.PolicyMode}";
    }

    private async Task RunTimingBenchmarkAsync(string outputPath)
    {
        var rows = new List<string>
        {
            "ViewId,Category,Complexity,Policy,ElementCount,BindingCount,TreeDepth,FileSizeBytes,Phase,Iteration,ElapsedMs"
        };

        var selected = _manifest
            .GroupBy(v => v.Complexity)
            .SelectMany(g => g.Take(_options.SamplesPerLevel))
            .ToArray();

        foreach (var meta in selected)
        {
            ViewHost.Content = null;
            _repository.Release(meta.ViewId);
            await Dispatcher.Yield(DispatcherPriority.ApplicationIdle);

            var sw = Stopwatch.StartNew();
            var view = _loader.Load(meta.FullPath);
            ViewHost.Content = view;
            ViewHost.UpdateLayout();
            sw.Stop();
            _repository.Register(meta.ViewId, view);
            rows.Add(ToTimingRow(meta, "FirstLoad", 1, sw.Elapsed.TotalMilliseconds));

            for (var i = 1; i <= _options.ReuseIterations; i++)
            {
                ViewHost.Content = null;
                ViewHost.UpdateLayout();
                var rsw = Stopwatch.StartNew();
                if (!_repository.TryGet(meta.ViewId, out var cached) || cached is null)
                    throw new InvalidOperationException($"View missing from repository: {meta.ViewId}");
                ViewHost.Content = cached;
                ViewHost.UpdateLayout();
                rsw.Stop();
                rows.Add(ToTimingRow(meta, "Reuse", i, rsw.Elapsed.TotalMilliseconds));
                if (i % 10 == 0) await Dispatcher.Yield(DispatcherPriority.Background);
            }
        }

        var full = Path.GetFullPath(outputPath);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        await File.WriteAllLinesAsync(full, rows, new UTF8Encoding(false));
        StatusText.Text = $"Timing benchmark complete: {selected.Length} views";
    }

    private static string ToTimingRow(ViewMeta m, string phase, int iteration, double ms) =>
        $"{m.ViewId},{m.Category},{m.Complexity},{m.Policy},{m.ElementCount},{m.BindingCount},{m.TreeDepth},{m.FileSizeBytes},{phase},{iteration},{ms.ToString("F6", CultureInfo.InvariantCulture)}";

    private void SignalReady()
    {
        if (string.IsNullOrWhiteSpace(_options.ReadyFile)) return;
        var full = Path.GetFullPath(_options.ReadyFile!);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        File.WriteAllText(full, $"READY,{Environment.ProcessId},{_options.LoadCount},{_repository.Count},{DateTime.UtcNow:O}");
    }
}

internal sealed class AppOptions
{
    public string ManifestPath { get; init; } = "";
    public int LoadCount { get; init; } = 20;
    public string PolicyMode { get; init; } = "all";
    public string? ReadyFile { get; init; }
    public string? TimingOut { get; init; }
    public string? ErrorFile { get; init; }
    public int ReuseIterations { get; init; } = 50;
    public int SamplesPerLevel { get; init; } = 5;
    public double Width { get; init; } = 1280;
    public double Height { get; init; } = 720;

    public static AppOptions Parse(string[] args)
    {
        string? Get(string key)
        {
            for (var i = 0; i < args.Length - 1; i++) if (args[i].Equals(key, StringComparison.OrdinalIgnoreCase)) return args[i + 1];
            return null;
        }
        int GetInt(string key, int fallback) => int.TryParse(Get(key), out var x) ? x : fallback;
        double GetDouble(string key, double fallback) => double.TryParse(Get(key), NumberStyles.Float, CultureInfo.InvariantCulture, out var x) ? x : fallback;
        return new AppOptions
        {
            ManifestPath = Path.GetFullPath(Get("--manifest") ?? throw new ArgumentException("--manifest is required")),
            LoadCount = GetInt("--load-count", 20),
            PolicyMode = Get("--policy-mode") ?? "all",
            ReadyFile = Get("--ready-file"),
            TimingOut = Get("--timing-out"),
            ErrorFile = Get("--error-file"),
            ReuseIterations = GetInt("--reuse-iterations", 50),
            SamplesPerLevel = GetInt("--samples-per-level", 5),
            Width = GetDouble("--width", 1280),
            Height = GetDouble("--height", 720)
        };
    }
}

internal sealed record ViewMeta(int Index, string ViewId, string Category, string Complexity, string Policy, string FileName, int ElementCount, int BindingCount, int TreeDepth, long FileSizeBytes, string FullPath);

internal static class ManifestReader
{
    public static List<ViewMeta> Read(string manifestPath)
    {
        if (!File.Exists(manifestPath)) throw new FileNotFoundException("Manifest not found", manifestPath);
        var dir = Path.GetDirectoryName(Path.GetFullPath(manifestPath))!;
        return File.ReadLines(manifestPath).Skip(1).Where(l => !string.IsNullOrWhiteSpace(l)).Select(line =>
        {
            var c = line.Split(',');
            if (c.Length < 10) throw new InvalidDataException($"Invalid manifest row: {line}");
            return new ViewMeta(
                int.Parse(c[0], CultureInfo.InvariantCulture), c[1], c[2], c[3], c[4], c[5],
                int.Parse(c[6], CultureInfo.InvariantCulture), int.Parse(c[7], CultureInfo.InvariantCulture),
                int.Parse(c[8], CultureInfo.InvariantCulture), long.Parse(c[9], CultureInfo.InvariantCulture), Path.Combine(dir, c[5]));
        }).ToList();
    }
}
