using System.Windows;

namespace LegacyHciApp;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        var options = Args.Parse(e.Args);
        var window = new MainWindow(options);
        window.Show();
    }
}

internal sealed class Args
{
    public string XamlPath { get; init; } = "";
    public string ViewId { get; init; } = "View";
    public string? ReadyFile { get; init; }
    public double Width { get; init; } = 1280;
    public double Height { get; init; } = 720;

    public static Args Parse(string[] args)
    {
        string? Get(string key)
        {
            for (var i = 0; i < args.Length - 1; i++)
                if (args[i].Equals(key, StringComparison.OrdinalIgnoreCase)) return args[i + 1];
            return null;
        }
        _ = double.TryParse(Get("--width"), out var w);
        _ = double.TryParse(Get("--height"), out var h);
        return new Args
        {
            XamlPath = Get("--xaml") ?? "",
            ViewId = Get("--view-id") ?? "View",
            ReadyFile = Get("--ready-file"),
            Width = w > 0 ? w : 1280,
            Height = h > 0 ? h : 720
        };
    }
}
