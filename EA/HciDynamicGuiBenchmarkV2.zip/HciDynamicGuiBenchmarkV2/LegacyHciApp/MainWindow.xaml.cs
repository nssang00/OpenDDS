using System.IO;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Threading;
using System.Xml;

namespace LegacyHciApp;

public partial class MainWindow : Window
{
    private readonly Args _options;

    public MainWindow(Args options)
    {
        _options = options;
        InitializeComponent();
        Title = $"Legacy HCI - {_options.ViewId}";
        Width = _options.Width;
        Height = _options.Height;

        if (!File.Exists(_options.XamlPath))
            throw new FileNotFoundException("XAML view not found", _options.XamlPath);

        ViewHost.Content = LoadXaml(_options.XamlPath);
        Loaded += async (_, _) =>
        {
            await Dispatcher.Yield(DispatcherPriority.ApplicationIdle);
            ViewHost.UpdateLayout();
            SignalReady();
        };
    }

    private static FrameworkElement LoadXaml(string path)
    {
        using var fs = File.OpenRead(path);
        using var xr = XmlReader.Create(fs, new XmlReaderSettings { DtdProcessing = DtdProcessing.Prohibit, XmlResolver = null });
        return XamlReader.Load(xr) as FrameworkElement
            ?? throw new InvalidOperationException("XAML root is not FrameworkElement.");
    }

    private void SignalReady()
    {
        if (string.IsNullOrWhiteSpace(_options.ReadyFile)) return;
        var full = Path.GetFullPath(_options.ReadyFile);
        Directory.CreateDirectory(Path.GetDirectoryName(full)!);
        File.WriteAllText(full, $"{_options.ViewId},{Environment.ProcessId},{DateTime.UtcNow:O}");
    }
}
