@echo off
cd /d "%~dp0"
echo This will run the full 20/50/100/150 WPF benchmark, 5 repetitions.
echo It can open up to 150 WPF processes at once.
echo.
pause
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Run-Benchmark.ps1" -Runs 5 -Scales 20,50,100,150
pause
