param(
    [int]$Runs = 5,
    [int[]]$Scales = @(20,50,100,150),
    [int]$MaxViews = 150,
    [int]$WarmupSeconds = 10,
    [int]$SampleSeconds = 10,
    [int]$ReuseIterations = 50,
    [int]$SamplesPerLevel = 5,
    [int]$Width = 1280,
    [int]$Height = 720,
    [string]$Configuration = "Release",
    [switch]$NoOpenReport
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dataset = Join-Path $root "GeneratedViews"
$resultsRoot = Join-Path $root ("results\" + (Get-Date -Format 'yyyyMMdd_HHmmss'))

Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " HCI Dynamic GUI Benchmark V2" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host "This benchmark can start up to $($Scales | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum) WPF processes." -ForegroundColor Yellow
Write-Host "Close unnecessary applications and use the same Windows power/display settings for paper measurements." -ForegroundColor Yellow
Write-Host ""

Write-Host "[1/5] Building projects..." -ForegroundColor Green
dotnet build "$root\ViewDatasetGenerator\ViewDatasetGenerator.csproj" -c $Configuration
dotnet build "$root\LegacyHciApp\LegacyHciApp.csproj" -c $Configuration
dotnet build "$root\DynamicHciApp\DynamicHciApp.csproj" -c $Configuration
dotnet build "$root\BenchmarkRunner\BenchmarkRunner.csproj" -c $Configuration

Write-Host "[2/5] Generating $MaxViews unique XAML views..." -ForegroundColor Green
$generator = "$root\ViewDatasetGenerator\bin\$Configuration\net8.0\ViewDatasetGenerator.exe"
& $generator $dataset $MaxViews

$legacy = "$root\LegacyHciApp\bin\$Configuration\net8.0-windows\LegacyHciApp.exe"
$dynamic = "$root\DynamicHciApp\bin\$Configuration\net8.0-windows\DynamicHciApp.exe"
$runner = "$root\BenchmarkRunner\bin\$Configuration\net8.0\BenchmarkRunner.exe"
$manifest = Join-Path $dataset "manifest.csv"
New-Item -ItemType Directory -Force -Path $resultsRoot | Out-Null

Write-Host "[3/5] Saving environment information..." -ForegroundColor Green
$os = Get-CimInstance Win32_OperatingSystem
$cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
$computer = Get-CimInstance Win32_ComputerSystem
$dotnetInfo = (& dotnet --info) -join "`r`n"
@"
Timestamp: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Computer: $env:COMPUTERNAME
OS: $($os.Caption) $($os.Version) Build $($os.BuildNumber)
CPU: $($cpu.Name)
Logical processors: $($computer.NumberOfLogicalProcessors)
RAM GB: $([math]::Round($computer.TotalPhysicalMemory / 1GB, 2))
Display test size: ${Width}x${Height}
Windows scaling/DPI: record manually if not 100%
Power plan: record manually

DOTNET INFO
$dotnetInfo
"@ | Set-Content -Path (Join-Path $resultsRoot "environment.txt") -Encoding UTF8

Write-Host "[4/5] Running benchmark..." -ForegroundColor Green
$scaleText = ($Scales -join ',')
& $runner `
    --legacy $legacy `
    --dynamic $dynamic `
    --manifest $manifest `
    --output $resultsRoot `
    --scales $scaleText `
    --runs $Runs `
    --warmup $WarmupSeconds `
    --sample $SampleSeconds `
    --reuse-iterations $ReuseIterations `
    --samples-per-level $SamplesPerLevel `
    --width $Width `
    --height $Height

Write-Host "[5/5] Complete." -ForegroundColor Green
Write-Host ""
Write-Host "Results folder : $resultsRoot" -ForegroundColor Cyan
Write-Host "Main report    : $(Join-Path $resultsRoot 'report.html')" -ForegroundColor Cyan
Write-Host "Paper table    : $(Join-Path $resultsRoot 'paper_summary.csv')" -ForegroundColor Cyan
Write-Host "Scale results  : $(Join-Path $resultsRoot 'resource_summary.csv')" -ForegroundColor Cyan
Write-Host "Timing results : $(Join-Path $resultsRoot 'timing_summary.csv')" -ForegroundColor Cyan

if (-not $NoOpenReport) {
    Start-Process (Join-Path $resultsRoot "report.html")
}
