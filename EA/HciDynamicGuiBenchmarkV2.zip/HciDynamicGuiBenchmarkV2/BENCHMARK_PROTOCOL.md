# 논문용 시험 프로토콜

## 시험 규모

20 / 50 / 100 / 150 App·View, 기본 5회 반복.

## UI 데이터셋

동일한 150개의 고유 XAML을 양 방식이 공유한다. 8개 화면 유형과 4단계 복잡도로 생성되며 manifest에 ElementCount, BindingCount, TreeDepth, FileSize를 기록한다.

## A. 실행구조 및 자원 비교

### Legacy
- N개의 독립 `LegacyHciApp.exe` 프로세스 실행
- 각 프로세스는 서로 다른 ViewNNN.xaml 1개를 로딩
- 각 Window의 Loaded + Layout 완료 후 ready 신호 기록
- 모든 N개 ready까지 `Full Initialization Time` 측정
- 이후 10초 안정화, 10초 CPU 측정
- N개 프로세스의 Private Memory와 Working Set 합산

### Dynamic
- `DynamicHciApp.exe` 1개 실행
- 동일한 N개의 ViewNNN.xaml을 Validation + XamlReader로 생성
- Resource 비교에서는 N개 View를 모두 Repository에 유지하여 동일 UI 객체 수를 보유
- 모든 N개 생성/Layout 완료 후 ready 신호 기록
- 이후 동일하게 안정화/CPU/Memory 측정

## B. XAML 동적 생성 및 재사용

복잡도별 대표 5개 View를 선택한다.

- First Load: Validation + File Read + XAML Parse + FrameworkElement 생성 + Host 연결 + Layout
- Reuse: ViewRepository Lookup + 기존 FrameworkElement Host 재연결 + Layout
- Reuse는 대표 View별 50회
- 평균, 표준편차, 중앙값, P95 기록

## C. Lifecycle 보조 시험

최대 규모에서 다음 두 조건의 Dynamic Private Memory를 비교한다.

1. `all`: 생성한 모든 View를 Repository에 유지
2. `manifest`: Persistent/Reusable만 유지하고 Transient는 생성 후 해제 가능 상태로 전환

이 시험은 Legacy와의 직접 비교가 아니라 View 수명주기 정책의 메모리 관리 효과를 확인하는 보조 시험이다.

## D. 논문 결과 권장 제시

### Figure
X축: App/View 수 (20, 50, 100, 150)
Y축: Private Memory 또는 Full Initialization Time
Legacy / Proposed 두 곡선 비교

### Table
최대 규모(150) 기준 Process Count, Private Memory, CPU, Full Init Time + Dynamic First Load/Reuse 요약.
