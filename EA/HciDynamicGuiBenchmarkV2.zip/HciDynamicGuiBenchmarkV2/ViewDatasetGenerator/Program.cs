using System.Text;
using System.Xml.Linq;

var outputDir = args.Length > 0 ? Path.GetFullPath(args[0]) : Path.GetFullPath("GeneratedViews");
var count = args.Length > 1 && int.TryParse(args[1], out var n) ? n : 150;
if (count < 1) throw new ArgumentOutOfRangeException(nameof(count));

Directory.CreateDirectory(outputDir);
foreach (var old in Directory.GetFiles(outputDir, "View*.xaml")) File.Delete(old);

var categories = new[] { "Tactical", "Sensor", "Weapon", "Equipment", "Alarm", "Control", "Monitoring", "Configuration" };
var levels = new[] { "Light", "Medium", "Heavy", "VeryHeavy" };
var manifest = new List<ViewMeta>();

for (var i = 1; i <= count; i++)
{
    var viewId = $"View{i:D3}";
    var category = categories[(i - 1) % categories.Length];
    var complexity = levels[(i - 1) % levels.Length];
    var policy = i % 10 == 0 ? "Persistent" : i % 10 <= 3 ? "Reusable" : "Transient";
    var seed = 1000 + i * 7919;
    var xaml = BuildXaml(viewId, category, complexity, seed);
    var fileName = $"{viewId}.xaml";
    var path = Path.Combine(outputDir, fileName);
    File.WriteAllText(path, xaml, new UTF8Encoding(false));

    var doc = XDocument.Parse(xaml);
    var elements = doc.Root!.DescendantsAndSelf().ToList();
    var elementCount = elements.Count(e => !e.Name.LocalName.Contains('.'));
    var bindingCount = elements.SelectMany(e => e.Attributes()).Count(a => a.Value.Contains("{Binding", StringComparison.Ordinal));
    var treeDepth = MaxDepth(doc.Root!, 1);
    var fileBytes = new FileInfo(path).Length;
    manifest.Add(new ViewMeta(i, viewId, category, complexity, policy, fileName, elementCount, bindingCount, treeDepth, fileBytes));
}

var manifestPath = Path.Combine(outputDir, "manifest.csv");
var csv = new StringBuilder();
csv.AppendLine("Index,ViewId,Category,Complexity,Policy,FileName,ElementCount,BindingCount,TreeDepth,FileSizeBytes");
foreach (var m in manifest)
    csv.AppendLine($"{m.Index},{m.ViewId},{m.Category},{m.Complexity},{m.Policy},{m.FileName},{m.ElementCount},{m.BindingCount},{m.TreeDepth},{m.FileSizeBytes}");
File.WriteAllText(manifestPath, csv.ToString(), new UTF8Encoding(false));

Console.WriteLine($"Generated {count} unique XAML views: {outputDir}");
foreach (var g in manifest.GroupBy(m => m.Complexity))
{
    Console.WriteLine($"  {g.Key,-10}: {g.Count(),3} views | elements avg {g.Average(x => x.ElementCount):F1}, bindings avg {g.Average(x => x.BindingCount):F1}, file avg {g.Average(x => x.FileSizeBytes) / 1024.0:F1} KB");
}
Console.WriteLine($"Manifest: {manifestPath}");

static int MaxDepth(XElement e, int depth)
{
    var children = e.Elements().ToArray();
    return children.Length == 0 ? depth : children.Max(c => MaxDepth(c, depth + 1));
}

static string BuildXaml(string viewId, string category, string complexity, int seed)
{
    var rnd = new Random(seed);
    var cardRange = complexity switch
    {
        "Light" => (5, 8),
        "Medium" => (14, 20),
        "Heavy" => (28, 38),
        _ => (48, 64)
    };
    var cardCount = rnd.Next(cardRange.Item1, cardRange.Item2 + 1);
    var columns = complexity switch
    {
        "Light" => 2,
        "Medium" => 3,
        "Heavy" => 4,
        _ => 5
    };

    var sb = new StringBuilder();
    sb.AppendLine("<UserControl xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\"");
    sb.AppendLine("             xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"");
    sb.AppendLine("             HorizontalAlignment=\"Stretch\" VerticalAlignment=\"Stretch\">");
    sb.AppendLine("  <Grid Margin=\"10\">");
    sb.AppendLine("    <Grid.RowDefinitions><RowDefinition Height=\"Auto\"/><RowDefinition Height=\"*\"/><RowDefinition Height=\"Auto\"/></Grid.RowDefinitions>");
    sb.AppendLine($"    <Border Grid.Row=\"0\" Padding=\"8\" BorderThickness=\"1\" CornerRadius=\"3\">");
    sb.AppendLine("      <Grid><Grid.ColumnDefinitions><ColumnDefinition Width=\"*\"/><ColumnDefinition Width=\"Auto\"/></Grid.ColumnDefinitions>");
    sb.AppendLine($"        <StackPanel><TextBlock FontSize=\"20\" FontWeight=\"Bold\" Text=\"{category} / {viewId}\"/><TextBlock Text=\"Complexity: {complexity} | Mission profile {seed % 97:D2}\"/></StackPanel>");
    sb.AppendLine($"        <TextBlock Grid.Column=\"1\" VerticalAlignment=\"Center\" Text=\"{{Binding RuntimeStatus{seed % 13}}}\"/>");
    sb.AppendLine("      </Grid>");
    sb.AppendLine("    </Border>");
    sb.AppendLine($"    <ScrollViewer Grid.Row=\"1\" VerticalScrollBarVisibility=\"Auto\"><UniformGrid Columns=\"{columns}\" Margin=\"0,8,0,8\">");

    for (var c = 0; c < cardCount; c++)
        AppendCard(sb, category, c, rnd, seed);

    sb.AppendLine("    </UniformGrid></ScrollViewer>");
    sb.AppendLine("    <Grid Grid.Row=\"2\"><Grid.ColumnDefinitions><ColumnDefinition Width=\"*\"/><ColumnDefinition Width=\"Auto\"/></Grid.ColumnDefinitions>");
    sb.AppendLine($"      <TextBlock Text=\"{viewId} / {category} / dynamic test view\"/>");
    sb.AppendLine($"      <ProgressBar Grid.Column=\"1\" Width=\"180\" Height=\"12\" Minimum=\"0\" Maximum=\"100\" Value=\"{rnd.Next(5, 96)}\"/>");
    sb.AppendLine("    </Grid>");
    sb.AppendLine("  </Grid>");
    sb.AppendLine("</UserControl>");
    return sb.ToString();
}

static void AppendCard(StringBuilder sb, string category, int index, Random rnd, int seed)
{
    var label = $"{category}-{index + 1:D2}";
    var v = rnd.Next(0, 101);
    sb.AppendLine("      <Border Margin=\"3\" Padding=\"6\" BorderThickness=\"1\" CornerRadius=\"2\">");
    sb.AppendLine("        <StackPanel>");
    sb.AppendLine($"          <TextBlock FontWeight=\"Bold\" Text=\"{label}\"/>");

    switch (category)
    {
        case "Tactical":
            sb.AppendLine($"          <Grid Height=\"42\"><Canvas><Ellipse Width=\"12\" Height=\"12\" Canvas.Left=\"{rnd.Next(2, 80)}\" Canvas.Top=\"{rnd.Next(2, 24)}\"/><Ellipse Width=\"8\" Height=\"8\" Canvas.Left=\"{rnd.Next(80, 150)}\" Canvas.Top=\"{rnd.Next(2, 24)}\"/></Canvas></Grid>");
            sb.AppendLine($"          <TextBlock Text=\"{{Binding Track{(seed + index) % 31}}}\"/>");
            sb.AppendLine($"          <ProgressBar Height=\"8\" Maximum=\"100\" Value=\"{v}\"/>");
            break;
        case "Sensor":
            sb.AppendLine($"          <TextBlock Text=\"Sensor channel {(seed + index) % 64:D2}\"/>");
            sb.AppendLine($"          <ProgressBar Height=\"10\" Maximum=\"100\" Value=\"{v}\"/>");
            sb.AppendLine($"          <CheckBox IsChecked=\"{(index % 2 == 0).ToString().ToLowerInvariant()}\" Content=\"Tracking enabled\"/>");
            sb.AppendLine($"          <TextBlock Text=\"{{Binding SensorState{index % 17}}}\"/>");
            break;
        case "Weapon":
            sb.AppendLine($"          <TextBlock Text=\"Launcher {index % 12 + 1} / Channel {index % 4 + 1}\"/>");
            sb.AppendLine("          <StackPanel Orientation=\"Horizontal\"><Button Width=\"60\" Margin=\"0,2,4,2\" Content=\"ARM\"/><Button Width=\"60\" Margin=\"0,2\" Content=\"SAFE\"/></StackPanel>");
            sb.AppendLine($"          <TextBlock Text=\"{{Binding WeaponState{index % 19}}}\"/>");
            break;
        case "Equipment":
            sb.AppendLine($"          <TextBlock Text=\"Equipment ID EQ-{(seed + index) % 999:D3}\"/>");
            sb.AppendLine($"          <ProgressBar Height=\"8\" Maximum=\"100\" Value=\"{v}\"/>");
            sb.AppendLine($"          <TextBlock Text=\"{{Binding EquipmentHealth{index % 23}}}\"/>");
            sb.AppendLine($"          <CheckBox Content=\"Power\" IsChecked=\"{(index % 3 != 0).ToString().ToLowerInvariant()}\"/>");
            break;
        case "Alarm":
            sb.AppendLine($"          <TextBlock Text=\"Alarm code A-{(seed + index) % 250:D3}\"/>");
            sb.AppendLine($"          <TextBlock Text=\"{{Binding AlarmText{index % 29}}}\"/>");
            sb.AppendLine("          <Button HorizontalAlignment=\"Left\" Width=\"90\" Content=\"Acknowledge\"/>");
            break;
        case "Control":
            sb.AppendLine($"          <TextBox Text=\"{{Binding ControlValue{index % 31}}}\"/>");
            sb.AppendLine("          <ComboBox SelectedIndex=\"0\"><ComboBoxItem Content=\"AUTO\"/><ComboBoxItem Content=\"MANUAL\"/></ComboBox>");
            sb.AppendLine("          <Button HorizontalAlignment=\"Left\" Width=\"80\" Content=\"Apply\"/>");
            break;
        case "Monitoring":
            sb.AppendLine($"          <TextBlock Text=\"Value {v}\"/>");
            sb.AppendLine($"          <ProgressBar Height=\"8\" Maximum=\"100\" Value=\"{v}\"/>");
            sb.AppendLine($"          <TextBlock Text=\"{{Binding MonitorValue{index % 37}}}\"/>");
            sb.AppendLine($"          <TextBlock Text=\"Rate {rnd.Next(1, 60)} Hz\"/>");
            break;
        default:
            sb.AppendLine($"          <TextBlock Text=\"Parameter P-{index + 1:D2}\"/>");
            sb.AppendLine($"          <TextBox Text=\"{{Binding ConfigValue{index % 41}}}\"/>");
            sb.AppendLine("          <CheckBox Content=\"Enabled\"/>");
            sb.AppendLine("          <Button HorizontalAlignment=\"Left\" Width=\"70\" Content=\"Set\"/>");
            break;
    }

    if (index % 3 == 0)
        sb.AppendLine($"          <TextBlock FontSize=\"10\" Text=\"Status sample {seed % 1000:D3}-{index:D2}\"/>");
    sb.AppendLine("        </StackPanel>");
    sb.AppendLine("      </Border>");
}

record ViewMeta(int Index, string ViewId, string Category, string Complexity, string Policy, string FileName, int ElementCount, int BindingCount, int TreeDepth, long FileSizeBytes);
