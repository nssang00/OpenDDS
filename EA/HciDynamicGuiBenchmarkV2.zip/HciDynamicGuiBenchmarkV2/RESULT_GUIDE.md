# 결과 확인 순서

시험 완료 후 `results\날짜_시간\` 폴더에서 다음 순서로 확인하면 됩니다.

1. **report.html** — 표와 추세 그래프가 자동 생성된 최종 요약
2. **paper_summary.csv** — 150개 기준 논문 표에 옮기기 쉬운 핵심 수치
3. **resource_summary.csv** — 20/50/100/150의 Process / Memory / CPU / Full Init 평균 및 표준편차
4. **timing_summary.csv** — Light/Medium/Heavy/VeryHeavy의 First Load / Reuse 통계
5. **environment.txt** — 시험 PC 정보
6. `*_raw.csv` — 원시값 확인용

## 논문 작성 시 우선순위

- 메모리: `PrivateMemoryMBMean`을 주 지표로 사용
- CPU: `CPUPercentMean`
- 기동: `FullInitializationTimeMsMean`
- 동적 UI: `FirstLoad`와 `Reuse` 비교
- Working Set은 보조 지표로 사용

## 첫 실행 권장

먼저 `Run-QuickCheck.bat`을 실행해 정상 동작을 확인한 뒤 `Run-PaperBenchmark.bat`을 실행하세요.
