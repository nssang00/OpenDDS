# HCI Dynamic GUI Benchmark V2

전투체계 HCI의 **다중 WPF 응용프로그램 구조**와 **단일 GUI Runtime + 동적 XAML + View Repository 구조**를 비교하기 위한 논문용 시험 프로그램입니다.

## 핵심 시험

1. **규모 확장 시험**: 20 / 50 / 100 / 150개의 서로 다른 UI를 대상으로 Legacy N개 프로세스와 Dynamic 1개 프로세스를 비교
2. **자원 시험**: Process Count, Private Memory, Working Set, Idle CPU
3. **전체 초기화 시간**: 시험 시작부터 모든 대상 UI가 Loaded/Layout 완료되어 Ready가 될 때까지 측정
4. **XAML 복잡도 시험**: Light / Medium / Heavy / VeryHeavy
5. **Dynamic First Load / Reuse 시험**: 최초 Validation+Parse+생성과 View Repository 재사용 비교
6. **Lifecycle 정책 보조 시험**: 150개 View를 전부 유지하는 경우와 manifest 정책(Persistent/Reusable/Transient)을 적용하는 경우 비교

## 중요한 공정성 원칙

`GeneratedViews`의 **동일한 XAML 파일**을 Legacy와 Dynamic이 함께 사용합니다.

- Legacy: View001.xaml → Process 1, View002.xaml → Process 2, ...
- Dynamic: 동일 View001.xaml ~ ViewNNN.xaml → 하나의 Runtime 내부에서 로딩

따라서 자원 비교에서는 UI 데이터셋은 동일하고 실행 아키텍처가 주된 차이가 되도록 구성했습니다.

> Legacy도 loose XAML을 1회 로딩합니다. 따라서 Resource Scaling 시험은 '정적 XAML 컴파일 성능'이 아니라 **다중 프로세스 vs 단일 Runtime 실행구조** 비교입니다. 동적 XAML 자체의 오버헤드는 별도의 First Load / Reuse 시험에서 측정합니다.

## 요구 환경

- Windows 10/11 64-bit
- .NET 8 SDK
- PowerShell 5.1 또는 7+
- 권장: RAM 16 GB 이상 (150 WPF 프로세스 시험은 PC 사양에 따라 부담이 큼)

## 1. 먼저 빠른 동작 확인

PowerShell에서 압축을 푼 폴더로 이동:

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\Run-QuickCheck.ps1
```

5 / 10 / 20개 규모, 1회 시험으로 프로그램이 정상 동작하는지 확인합니다.

## 2. 논문용 본 시험

```powershell
.\Run-Benchmark.ps1 -Runs 5 -Scales 20,50,100,150
```

기본값:

- 150개의 서로 다른 XAML 생성
- 화면 시험 크기 1280×720
- 안정화 10초
- CPU 측정 10초
- 5회 반복
- Reuse: 대표 View당 50회
- 복잡도별 대표 View: 5개

PC가 충분하면 200개까지 생성하여 추가할 수 있습니다.

```powershell
.\Run-Benchmark.ps1 -Runs 5 -Scales 20,50,100,150,200 -MaxViews 200
```

## 생성되는 XAML

8가지 화면 유형을 순환 생성합니다.

- Tactical
- Sensor
- Weapon
- Equipment
- Alarm
- Control
- Monitoring
- Configuration

각 파일은 View ID, 컨트롤 개수/배치, 값, Binding 대상이 달라 **서로 다른 XAML**입니다.

복잡도는 4단계로 분류됩니다.

- Light
- Medium
- Heavy
- VeryHeavy

`GeneratedViews/manifest.csv`에 다음 메타데이터가 기록됩니다.

- ViewId / Category / Complexity / Policy
- ElementCount / BindingCount / TreeDepth / FileSizeBytes

## 결과 파일

실행이 끝나면 `results/yyyyMMdd_HHmmss/`에 생성됩니다.

- `report.html` : **가장 먼저 볼 파일**. 표와 추세 그래프 포함
- `report.md` : Markdown 요약
- `paper_summary.csv` : 논문 표에 옮기기 쉬운 최대 규모 요약
- `resource_summary.csv` : 20/50/100/150 규모별 평균·표준편차
- `timing_summary.csv` : 복잡도별 First Load / Reuse 평균·표준편차·중앙값·P95
- `resource_raw.csv` / `timing_raw.csv` : 전체 원시값
- `environment.txt` : PC/OS/.NET 환경
- `run_XX/` : 회차별 중간 결과

`Run-Benchmark.ps1`은 종료 후 `report.html`을 자동으로 엽니다.

## 논문에 우선 사용할 지표

- **Private Memory**: 주 메모리 비교 지표
- Working Set: 보조 지표 (프로세스 합산 시 공유 페이지 중복 계산 가능)
- Idle CPU
- Full Initialization Time
- Dynamic First Load
- Dynamic Reuse

## 시험 전에 권장하는 조건

- 불필요한 프로그램 종료
- Windows 전원 설정 고정
- 동일 해상도 / 동일 화면 배율 유지
- 가능하면 100% DPI 사용
- 본 시험 전 재부팅 후 QuickCheck 1회 수행
- 각 시험 사이 Windows가 안정화될 시간을 확보

## 해석 주의

150개의 Legacy Window와 Dynamic의 150 View는 같은 XAML 데이터셋을 사용하지만, Legacy는 N개의 독립 Top-level Window/프로세스를 유지하고 Dynamic은 하나의 Window에서 View 인스턴스를 Repository에 보관합니다. 이는 본 논문에서 비교하려는 실행 아키텍처 차이 자체입니다.
