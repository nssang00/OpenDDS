import { Empty, Input, Space, Tag, Tree, Typography } from 'antd';
import {
  ApartmentOutlined,
  ApiOutlined,
  DatabaseOutlined,
  NodeIndexOutlined,
  SearchOutlined,
  SettingOutlined,
} from '@ant-design/icons';
import { useMemo, useState } from 'react';
import { useDesignerStore } from '../../stores/useDesignerStore.js';

const { DirectoryTree } = Tree;
const { Text } = Typography;

function getElementIcon(type) {
  if (type === 'Package') return <ApartmentOutlined />;
  if (type === 'DomainParticipant') return <ApiOutlined />;
  if (type === 'Struct') return <DatabaseOutlined />;
  if (type === 'QosProfile') return <SettingOutlined />;
  return <NodeIndexOutlined />;
}

function getElementColor(type) {
  if (type === 'Package') return 'blue';
  if (type === 'DomainParticipant') return 'purple';
  if (type === 'Topic') return 'green';
  if (type === 'Struct') return 'cyan';
  if (type === 'QosProfile') return 'orange';
  return 'default';
}

function sortElements(elements) {
  return [...elements].sort((a, b) => {
    const typeCompare = a.type.localeCompare(b.type);
    if (typeCompare !== 0) return typeCompare;
    return a.name.localeCompare(b.name);
  });
}

function matchesKeyword(element, keyword) {
  const loweredKeyword = keyword.trim().toLowerCase();
  if (!loweredKeyword) return true;

  const name = element.name?.toLowerCase() ?? '';
  const type = element.type?.toLowerCase() ?? '';

  return name.includes(loweredKeyword) || type.includes(loweredKeyword);
}

function collectVisibleElementIds(elementsById, keyword) {
  const visibleIds = new Set();
  const elements = Object.values(elementsById);

  if (!keyword.trim()) {
    elements.forEach((element) => visibleIds.add(element.id));
    return visibleIds;
  }

  elements.forEach((element) => {
    if (!matchesKeyword(element, keyword)) return;

    let current = element;
    while (current) {
      visibleIds.add(current.id);
      current = current.parentId ? elementsById[current.parentId] : null;
    }
  });

  return visibleIds;
}

function renderNodeTitle(element) {
  return (
    <Space size={6} className="model-tree-node-title">
      <Text className="model-tree-node-title__name">{element.name}</Text>
      <Tag color={getElementColor(element.type)} className="model-tree-node-title__type">
        {element.type}
      </Tag>
    </Space>
  );
}

function buildTreeData(elementsById, visibleIds) {
  const childrenMap = new Map();
  const elements = Object.values(elementsById).filter((element) => visibleIds.has(element.id));

  elements.forEach((element) => {
    const parentId = element.parentId && visibleIds.has(element.parentId)
      ? element.parentId
      : '__root__';

    if (!childrenMap.has(parentId)) {
      childrenMap.set(parentId, []);
    }

    childrenMap.get(parentId).push(element);
  });

  function buildNode(element) {
    const children = childrenMap.get(element.id) ?? [];

    return {
      key: element.id,
      title: renderNodeTitle(element),
      icon: getElementIcon(element.type),
      children: sortElements(children).map(buildNode),
    };
  }

  const roots = childrenMap.get('__root__') ?? [];
  return sortElements(roots).map(buildNode);
}

export default function ModelView() {
  const [keyword, setKeyword] = useState('');

  const model = useDesignerStore((state) => state.model);
  const selectedElementId = useDesignerStore((state) => state.selectedElementId);
  const selectElement = useDesignerStore((state) => state.selectElement);

  const elementsById = model?.elementsById ?? {};
  const elements = useMemo(() => Object.values(elementsById), [elementsById]);

  const visibleElementIds = useMemo(
    () => collectVisibleElementIds(elementsById, keyword),
    [elementsById, keyword],
  );

  const treeData = useMemo(
    () => buildTreeData(elementsById, visibleElementIds),
    [elementsById, visibleElementIds],
  );

  const selectedElement = selectedElementId ? elementsById[selectedElementId] : null;
  const visibleElementCount = visibleElementIds.size;

  if (!model) {
    return (
      <div className="panel-body model-view">
        <Empty description="No model loaded" />
      </div>
    );
  }

  return (
    <div className="panel-body model-view">
      <Space direction="vertical" size={8} className="model-view__content">
        <Input
          allowClear
          size="small"
          prefix={<SearchOutlined />}
          placeholder="Search model"
          value={keyword}
          onChange={(event) => setKeyword(event.target.value)}
        />

        <div className="model-view__summary">
          <Text type="secondary">
            {visibleElementCount} / {elements.length} elements
          </Text>

          {selectedElement && (
            <Text type="secondary" ellipsis>
              Selected: {selectedElement.name}
            </Text>
          )}
        </div>

        {treeData.length === 0 ? (
          <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="No matching elements" />
        ) : (
          <DirectoryTree
            showIcon
            blockNode
            defaultExpandAll
            selectedKeys={selectedElementId ? [selectedElementId] : []}
            treeData={treeData}
            onSelect={(keys) => {
              if (keys[0]) selectElement(keys[0]);
            }}
          />
        )}
      </Space>
    </div>
  );
}
