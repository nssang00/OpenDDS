# UI Studio v0.23 — Free Geometry & Responsive Anchors Handoff

Source: `UI-Studio-Free-Toolbox-v022-20261109.zip`. Added Free Frame multi-drag, snap guides, alignment controls, opt-in fluid frame and right/bottom anchors, preview viewport chooser, and native TSX output support.

## Entry points

- `source/FREE-GEOMETRY-V023.md`: complete scope, behavior, constraints and reproduction
- `source/src/framework/UnifiedStudio.jsx`: editor UI / Free Frame pointer interactions
- `source/packages/core/free-placement.js`: pure group/snap logic
- `source/packages/core/layout.js`: cross-Renderer CSS semantics
- `source/tests/free-geometry-v023.test.js`: new automated tests
- `source/e2e/free-geometry-v023.spec.js`: browser test cases **not executed**
- `source/examples/free-anchors-v023.json`: canonical v6 example
- `source/exports/AnchoredPanel-shadcn-native-v023.zip`: generated Native TSX example
- `source/verification/v023/`: verification logs

## Verification status

Core 244/244 PASS; Runtime mock PASS; syntax PASS; strict generated TSX PASS **with offline type shims**. Vite build/Playwright E2E/real Base UI consumer **NOT VERIFIED** because npm registry DNS lookup failed. Chromium standalone geometry smoke test timed out. This is **still a PoC**; don't replace the v0.19 official verified baseline without browser/consumer validation.

## Next recommended work

Install deps in an online environment; run Vite and Playwright tests, fix any real DOM drag/selection issues, validate generated AnchoredPanel in an actual shadcn Base UI project, and add responsive overflow/constraints UX only after real viewport checks.

Run: `cd source && npm install && npm test && node tools/verify-syntax.mjs && npm run verify:runtime && npm run verify:native-tsx && npm run build && npm run test:e2e`.
