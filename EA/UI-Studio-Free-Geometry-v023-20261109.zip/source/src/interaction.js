/** Pure geometry and drop validation for pointer-first Design interaction. */
export const DRAG_THRESHOLD = 6;
export const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
export const pointMoved = (a, b, threshold = DRAG_THRESHOLD) => Math.hypot(a.x-b.x, a.y-b.y) >= threshold;
export const insideRect = (p, r) => !!r && p.x >= r.left && p.x <= r.right && p.y >= r.top && p.y <= r.bottom;

/** Sort by layout order, not DOM paint order. The input rects follow the IR children order. */
export function insertionIndex(rects, point, mode='column', wrap=false) {
  if (!rects.length) return 0;
  if (mode === 'column') return rects.findIndex(r => point.y < (r.top+r.bottom)/2) < 0 ? rects.length : rects.findIndex(r => point.y < (r.top+r.bottom)/2);
  if (mode === 'row' && !wrap) return rects.findIndex(r => point.x < (r.left+r.right)/2) < 0 ? rects.length : rects.findIndex(r => point.x < (r.left+r.right)/2);
  // Visual rows (wrapped Flex/Grid): prefer a matching row, then an X midpoint.
  const rows = [];
  rects.forEach((r,i)=>{
    const center=(r.top+r.bottom)/2;
    const row=rows.find(row=>Math.abs(row.center-center)<Math.max(14,(r.bottom-r.top)/2));
    if (row) {row.items.push({r,i});row.center=(row.center*(row.items.length-1)+center)/row.items.length;}
    else rows.push({center,items:[{r,i}]});
  });
  rows.sort((a,b)=>a.center-b.center);
  let row=rows.find(row=>point.y<row.center+Math.max(12,(row.items[0].r.bottom-row.items[0].r.top)/2));
  if(!row)row=rows[rows.length-1];
  for(const item of row.items){if(point.x<(item.r.left+item.r.right)/2)return item.i;}
  return row.items[row.items.length-1].i+1;
}
export function mayDrop(root, drag, parentId, find) {
  const destination=find(root,parentId);
  if(!destination || destination.node.kind!=='frame')return false;
  if(drag?.kind !== 'move')return true;
  const src=find(root,drag.id);
  if(!src||!src.parent)return false;
  return drag.id!==parentId && !destination.ancestors.includes(drag.id);
}
export function dropGuide(rects,index,mode,frameRect,gridMode=false){
  if (!frameRect) return null;
  if(gridMode){
    const next=rects[Math.min(index,rects.length-1)];
    return next ? {kind:'cell',left:next.left,top:next.top,width:next.right-next.left,height:next.bottom-next.top}:
      {kind:'cell',left:frameRect.left+10,top:frameRect.top+22,width:Math.max(45,frameRect.right-frameRect.left-20),height:45};
  }
  if(mode==='row'){
    const x=index<rects.length?rects[index].left-3:rects.length?rects[rects.length-1].right+3:frameRect.left+16;
    return {kind:'line',left:x,top:frameRect.top+12,width:3,height:Math.max(22,Math.min(110,frameRect.bottom-frameRect.top-24))};
  }
  const y=index<rects.length?rects[index].top-3:rects.length?rects[rects.length-1].bottom+3:frameRect.top+24;
  return {kind:'line',left:frameRect.left+11,top:y,width:Math.max(36,frameRect.right-frameRect.left-22),height:3};
}
export function nextFixedWidth(startWidth, startX, pointerX, zoom=1) {
  return Math.round(clamp(startWidth+(pointerX-startX)/zoom,72,1800));
}
export function nextFrameHeight(startHeight,startY,pointerY,zoom=1){
  return Math.round(clamp(startHeight+(pointerY-startY)/zoom,40,1800));
}
/** CSS Grid uses ordered auto-placement. Map pointer to a future flow cell, not an absolute position. */
export function gridInsertion(rects, frameRect, point, columns=2, gap=0, padding=0, scale=1) {
  const cols=Math.max(1,columns);
  const pad=padding*scale,g=gap*scale;
  const cellWidth=Math.max(20,(frameRect.right-frameRect.left-pad*2-g*(cols-1))/cols);
  const startLeft=frameRect.left+pad,startTop=frameRect.top+pad;
  const firstRow=rects.slice(0,cols);
  const cellHeight=Math.max(40*scale,...firstRow.map(r=>r.bottom-r.top));
  const col=clamp(Math.floor((point.x-startLeft)/(cellWidth+g)),0,cols-1);
  const row=Math.max(0,Math.floor((point.y-startTop)/(cellHeight+g)));
  const index=clamp(row*cols+col,0,rects.length);
  const slotRow=Math.floor(index/cols),slotCol=index%cols;
  const slotRect={left:startLeft+slotCol*(cellWidth+g),top:startTop+slotRow*(cellHeight+g),width:cellWidth,height:cellHeight};
  return {index,guide:{kind:'cell',...slotRect}};
}
