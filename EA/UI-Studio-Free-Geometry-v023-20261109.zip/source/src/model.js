/** Portable project schema, immutable tree operations. No editor library dependencies. */
export const deepCopy = value => JSON.parse(JSON.stringify(value));
let counter=0;
export const makeId = (prefix='n') => `${prefix}_${Date.now().toString(36)}_${(++counter).toString(36)}`;
export const LAYOUT_MODES=['column','row','grid','overlay'];
// Insert and DSL are user-facing; all layout choices are one canonical Frame IR.
export const LAYOUT_PRESETS={Frame:{mode:'column',wrap:false},Column:{mode:'column',wrap:false},Row:{mode:'row',wrap:false},Grid:{mode:'grid',wrap:false},Wrap:{mode:'row',wrap:true},Overlay:{mode:'overlay',wrap:false}};
export const layoutLabel=node=>node.layout==='overlay'?'Overlay':node.layout==='row'&&node.wrap?'Wrap':node.layout==='row'?'Row':node.layout==='grid'?'Grid':'Column';
export const COMPONENT_TYPES=['Text','Button','Input','Select','Checkbox','Table','Card','Divider','Tag'];
export const KINDS=['frame','component','instance'];
export const BIND_RE=/^\{\{\s*((?:state|sources)(?:\.[a-zA-Z_$][\w$]*){1,8})\s*\}\}$/;
export const isBinding = v => typeof v === 'string' && BIND_RE.test(v);
export const bindingPath = v => isBinding(v)?v.match(BIND_RE)[1]:null;
export function resolveBinding(input,ctx){
  const path=bindingPath(input);
  if(!path) return input;
  let obj=ctx;
  for(const part of path.split('.')){
    if(['__proto__','prototype','constructor'].includes(part)) return undefined;
    if(obj===null||typeof obj!=='object'||!Object.prototype.hasOwnProperty.call(obj,part))return undefined;
    obj=obj[part];
  }
  return obj;
}
export const isFrame=n=>n?.kind==='frame';
export const labelOf=n=>n.name || (n.kind==='instance'?'Module':n.component||'Frame');
export function createNode(type){
  const id=makeId(type.toLowerCase());
  if(Object.prototype.hasOwnProperty.call(LAYOUT_PRESETS,type)){
    const preset=LAYOUT_PRESETS[type];
    return {id,kind:'frame',name:type==='Frame'?'새 Frame':type,layout:preset.mode,gap:12,padding:18,columns:2,align:'stretch',wrap:preset.wrap,background:'#ffffff',width:'fill',widthPx:420,minHeight:110,children:[]};
  }
  if(!COMPONENT_TYPES.includes(type)) throw Error(`지원하지 않는 요소: ${type}`);
  const props={
    Text:{text:'새 텍스트',weight:'normal'},Button:{text:'버튼',variant:'primary',action:{type:'message',message:'버튼을 클릭했습니다.'}},
    Input:{label:'검색어',placeholder:'입력하세요',valueBinding:'{{state.keyword}}'},
    Select:{label:'선택',options:'전체,활성,대기'},Checkbox:{text:'확인'},
    Table:{title:'고객 목록',rowsBinding:'{{sources.customers}}',filterBinding:'{{state.keyword}}',columns:'id,name,email,status'},
    Card:{title:'요약 카드',description:'카드 내용을 입력하세요.'},Divider:{},Tag:{text:'활성',color:'blue'}
  }[type];
  return {id,kind:'component',component:type,name:type,width:['Table','Card','Divider'].includes(type)?'fill':'hug',widthPx:220,props:deepCopy(props)};
}
export function createProject(){
  return {
    format:'ui-studio-canvas',schemaVersion:5,title:'고객 관리 UI',
    root:{id:'page-root',kind:'frame',name:'CustomerPage',layout:'column',gap:20,padding:30,columns:2,align:'stretch',wrap:false,background:'#ffffff',width:'fill',widthPx:900,minHeight:620,children:[
      {id:'title-row',kind:'frame',name:'Page header',layout:'row',gap:12,padding:0,columns:2,align:'center',wrap:false,background:'transparent',width:'fill',widthPx:800,minHeight:55,children:[
        {id:'heading-1',kind:'component',component:'Text',name:'Page title',width:'fill',widthPx:350,props:{text:'고객 관리',weight:'heading'}},
        {id:'badge-1',kind:'component',component:'Tag',name:'Status',width:'hug',widthPx:80,props:{text:'DEMO',color:'blue'}}
      ]},
      {id:'search-row',kind:'frame',name:'Search bar',layout:'row',gap:10,padding:18,columns:2,align:'end',wrap:true,background:'#f7f9fc',width:'fill',widthPx:800,minHeight:100,children:[
        {id:'search-input',kind:'component',component:'Input',name:'고객명 검색',width:'fixed',widthPx:290,props:{label:'고객명 / 이메일',placeholder:'고객명 또는 이메일',valueBinding:'{{state.keyword}}'}},
        {id:'reset-button',kind:'component',component:'Button',name:'초기화 버튼',width:'hug',widthPx:100,props:{text:'초기화',variant:'default',action:{type:'clear',target:'keyword'}}}
      ]},
      {id:'table-panel',kind:'frame',name:'Results panel',layout:'column',gap:16,padding:22,columns:2,align:'stretch',wrap:false,background:'#ffffff',width:'fill',widthPx:800,minHeight:300,children:[
        {id:'table-1',kind:'component',component:'Table',name:'Customers',width:'fill',widthPx:720,props:{title:'고객 목록',rowsBinding:'{{sources.customers}}',filterBinding:'{{state.keyword}}',columns:'id,name,email,status'}}
      ]},
      {id:'summary-grid',kind:'frame',name:'Summary grid',layout:'grid',gap:12,padding:0,columns:2,align:'stretch',wrap:false,background:'transparent',width:'fill',widthPx:800,minHeight:110,children:[
        {id:'info-card-1',kind:'component',component:'Card',name:'Reusable hint',width:'fill',widthPx:250,props:{title:'Frame 기반 설계',description:'왼쪽 레이어에서 Frame을 선택하여 Row / Column / Grid로 변경해보세요.'}},
        {id:'info-card-2',kind:'component',component:'Card',name:'Binding hint',width:'fill',widthPx:250,props:{title:'실제 Ant Design',description:'미리보기에서는 검색 입력과 초기화 버튼을 직접 실행할 수 있습니다.'}}
      ]}
    ]},
    modules:{},
    data:{state:{keyword:''},sources:{customers:[
      {id:'C001',name:'김민수',email:'minsu@example.com',status:'활성'},
      {id:'C002',name:'이지은',email:'jieun@example.com',status:'활성'},
      {id:'C003',name:'박서준',email:'seojun@example.com',status:'대기'},
      {id:'C004',name:'최유진',email:'yujin@example.com',status:'활성'}
    ]}}
  };
}
export function findLocation(root,id){
  if(root.id===id)return {node:root,parent:null,index:-1,ancestors:[]};
  function walk(node,ancestors){
    for(let i=0;i<(node.children||[]).length;i++){
      const child=node.children[i];
      if(child.id===id)return {node:child,parent:node,index:i,ancestors:[...ancestors,node.id]};
      const nested=walk(child,[...ancestors,node.id]);if(nested)return nested;
    }
    return null;
  }
  return walk(root,[]);
}
export function mapTree(root,visitor){visitor(root); for(const c of root.children||[])mapTree(c,visitor);}
export function changeNode(root,id,mutate){
  const result=deepCopy(root),loc=findLocation(result,id);
  if(!loc)throw Error(`요소를 찾을 수 없습니다: ${id}`);
  mutate(loc.node);return result;
}
export function addChild(root,parentId,node,index){
  const result=deepCopy(root),p=findLocation(result,parentId)?.node;
  if(!isFrame(p)) throw Error('Frame에만 추가할 수 있습니다.');
  if(findLocation(result,node.id))throw Error('중복 요소 ID');
  p.children.splice(index===undefined?p.children.length:Math.max(0,Math.min(index,p.children.length)),0,deepCopy(node));
  return result;
}
export function removeChild(root,id){
  if(root.id===id)throw Error('루트 Frame은 삭제할 수 없습니다.');
  const result=deepCopy(root),loc=findLocation(result,id);
  if(!loc)return result;
  loc.parent.children.splice(loc.index,1);return result;
}
export function moveChild(root,id,targetParentId,index){
  if(root.id===id)throw Error('루트는 이동할 수 없습니다.');
  const loc=findLocation(root,id),target=findLocation(root,targetParentId);
  if(!loc||!target||!isFrame(target.node))throw Error('유효하지 않은 이동');
  if(id===targetParentId||target.ancestors.includes(id))throw Error('자기 자신 또는 하위 Frame에는 놓을 수 없습니다.');
  const result=deepCopy(root),start=findLocation(result,id),[node]=start.parent.children.splice(start.index,1),dest=findLocation(result,targetParentId).node;
  let to=index===undefined?dest.children.length:Math.max(0,Math.min(index,dest.children.length+(start.parent.id===targetParentId?1:0)));
  if(start.parent.id===targetParentId&&to>start.index)to--;
  dest.children.splice(Math.min(to,dest.children.length),0,node);return result;
}
export function duplicateChild(root,id){
  const loc=findLocation(root,id);
  if(!loc?.parent)throw Error('루트는 복제할 수 없습니다.');
  const copied=deepCopy(loc.node);mapTree(copied,n=>{n.id=makeId('copy');});
  return {root:addChild(root,loc.parent.id,copied,loc.index+1),id:copied.id};
}
export function switchLayout(root,id,layout){
  const preset=LAYOUT_PRESETS[layout]||null;
  if(!LAYOUT_MODES.includes(layout)&&!preset)throw Error('지원하지 않는 레이아웃');
  return changeNode(root,id,n=>{
    if(!isFrame(n))throw Error('Frame만 레이아웃을 변경할 수 있습니다.');
    n.layout=preset?preset.mode:layout;
    n.wrap=preset?preset.wrap:false;
  });
}
export function createComponentModule(project,target,id,name){
  const out=deepCopy(project),root=getTargetRoot(out,target),loc=findLocation(root,id);
  if(!loc?.parent||!isFrame(loc.node))throw Error('하위 Frame을 선택해야 합니다.');
  const moduleId=makeId('module');
  out.modules[moduleId]={id:moduleId,name:name?.trim()||loc.node.name,version:1,revision:0,root:deepCopy(loc.node)};
  loc.parent.children[loc.index]={id:makeId('instance'),kind:'instance',name:name?.trim()||loc.node.name,moduleId,width:'fill',widthPx:280};
  return {project:out,moduleId,instanceId:loc.parent.children[loc.index].id};
}
export function getTargetRoot(project,target){return target==='page'?project.root:project.modules[target]?.root;}
export function setTargetRoot(project,target,root){const next=deepCopy(project);if(target==='page')next.root=root;else {if(!next.modules[target])throw Error('모듈을 찾을 수 없습니다.');next.modules[target].root=root;next.modules[target].revision=(next.modules[target].revision||0)+1;}return next;}
const allowedKeys=new Set(['id','kind','name','layout','gap','padding','columns','align','wrap','background','width','widthPx','minHeight','children','component','props','moduleId']);
export function validateProject(project){
  if(!project||project.format!=='ui-studio-canvas'||project.schemaVersion!==5||!project.root||!project.modules||!project.data||!project.data.state||!project.data.sources)return false;
  let total=0;
  function validNode(node,depth=0,ids=new Set()){
    if(!node||typeof node!=='object'||depth>22||!KINDS.includes(node.kind)||typeof node.id!=='string'||!/^[-a-zA-Z0-9_]{1,100}$/.test(node.id)||ids.has(node.id)||++total>900)return false;
    ids.add(node.id);
    if(Object.keys(node).some(k=>!allowedKeys.has(k))||typeof node.name!=='string'||!['hug','fill','fixed'].includes(node.width))return false;
    if(node.kind==='frame')return LAYOUT_MODES.includes(node.layout)&&Array.isArray(node.children)&&node.children.every(c=>validNode(c,depth+1,ids));
    if(node.kind==='component')return COMPONENT_TYPES.includes(node.component)&&node.props&&typeof node.props==='object'&&!Array.isArray(node.props)&&!node.children;
    return typeof node.moduleId==='string'&&!!project.modules[node.moduleId]&&!node.children;
  }
  if(!validNode(project.root))return false;
  for(const m of Object.values(project.modules))if(!m||!validNode(m.root,0,new Set()))return false;
  const seen=new Set(),active=new Set();
  function visit(mid){if(active.has(mid))return false;if(seen.has(mid))return true;
    if(!project.modules[mid])return false;
    seen.add(mid);active.add(mid);let ok=true;
    mapTree(project.modules[mid].root,n=>{if(n.kind==='instance'&&!visit(n.moduleId))ok=false;});
    active.delete(mid);return ok;}
  if(!Object.keys(project.modules).every(visit))return false;
  return Object.keys(project.data.state).length<50&&Object.keys(project.data.sources).length<30;
}
export function parseProjectJson(text){let parsed;try{parsed=JSON.parse(text);}catch{throw Error('JSON 문법을 확인하세요.');}if(!validateProject(parsed))throw Error('UI Studio v0.5 프로젝트 형식이 아니거나 유효하지 않습니다.');return parsed;}
