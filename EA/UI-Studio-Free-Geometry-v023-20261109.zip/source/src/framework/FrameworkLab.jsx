import React, {useEffect,useState,useSyncExternalStore} from 'react';
import {Button,Input,Select,Tag,Alert,Typography,Divider} from 'antd';
import {createSearchBoxDocument,literal,binding,serializeDocument,parseDocument,migrateV5ToV6,walkNodes,findNode} from '../../packages/schema/index.js';
import {createDefaultRegistry,RuntimeSession,patchDefinitionProperty,patchInstanceBinding,patchInstanceOverride,patchInstanceProp} from '../../packages/core/index.js';
import {RuntimeView} from '../../packages/runtime-react/Runtime.jsx';
import {createAntdRenderer} from '../../packages/renderer-antd/index.jsx';
const registry=createDefaultRegistry();
const renderer=createAntdRenderer();
const download=(text,name)=>{const url=URL.createObjectURL(new Blob([text],{type:'application/json'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);};
function StateValue({session,path}){
  const subscribe=React.useCallback(fn=>session.state.subscribe(path,fn),[session,path.join('.')]);
  const snapshot=React.useCallback(()=>session.state.get(path),[session,path.join('.')]);
  const value=useSyncExternalStore(subscribe,snapshot,snapshot);
  return <code>{JSON.stringify(value??'')}</code>;
}
function TreeRows({node,depth=0,selected,onSelect,definitions}){
  const nested=node.kind==='instance'?definitions[node.definitionId]?.root:null;
  const title=node.kind==='component'?(registry.get(node.typeId)?.displayName||node.typeId):node.kind==='instance'?`◇ ${node.definitionId}`:`▦ ${node.layout.type}`;
  return <>
    <button type="button" className={'core-tree-item '+(selected===node.id?'selected':'')} style={{paddingLeft:12+depth*14}} onClick={()=>onSelect(node.id)} title={node.id}><span>{title}</span><small>{node.name||node.id}</small></button>
    {node.kind==='frame'&&node.children.map(c=><TreeRows key={c.id} node={c} depth={depth+1} selected={selected} onSelect={onSelect} definitions={definitions}/>)}
    {nested&&<div className="core-tree-nested"><TreeRows node={nested} depth={depth+1} selected={selected} onSelect={onSelect} definitions={definitions}/></div>}
  </>;
}
function MetaEditor({definition,node,onChange,onError}){
  const metas=registry.get(node.typeId)?.properties||{};
  return <div className="core-inspector-section"><h4>Registry Properties · {node.typeId}</h4>
    {Object.entries(metas).map(([key,meta])=>{
      const value=node.props?.[key];
      const actual=value?.kind==='literal'?value.value:undefined;
      return <div className="core-field" key={key}><label>{key} <small>{meta.type} {meta.bindable?'· bindable':''}</small></label>
        {value?.kind==='binding'?<div className="core-field-binding">{value.source}.{value.path.join('.')} ({value.mode})</div>
          :meta.type==='boolean'?<input type="checkbox" checked={!!actual} onChange={e=>onChange(node.id,key,literal(e.target.checked))}/>
          :meta.type==='enum'?<Select size="small" value={actual??meta.defaultValue} options={meta.options.map(v=>({label:v,value:v}))} onChange={v=>onChange(node.id,key,literal(v))}/>
          :<Input size="small" value={actual??meta.defaultValue??''} onChange={e=>onChange(node.id,key,literal(e.target.value))}/>}
      </div>;
    })}
  </div>;
}
function InstanceEditor({node,definition,onBinding,onOverride,onProp}){
  const valueBinding=node.bindings?.value;
  const path=valueBinding?.path?.join('.')||'';
  const override=node.overrides?.searchButton?.color?.value;
  return <div className="core-inspector-section">
    <h4>{node.name||node.id}</h4><p className="core-hint">Definition: {node.definitionId} · revision {definition?.revision}</p>
    {!!definition.publicProps?.value&&<div className="core-field"><label>value · Data Binding</label>
      <Select style={{width:'100%'}} size="small" value={path} options={[{value:'customer.keyword',label:'state.customer.keyword'},{value:'product.keyword',label:'state.product.keyword'}]} onChange={p=>onBinding(node.id,'value',binding('state',p.split('.'),'TwoWay'))}/>
      <small>TwoWay · 다른 필드를 선택하면 이 인스턴스만 연결이 변경됩니다.</small>
    </div>}
    {Object.entries(definition.publicProps||{}).filter(([key])=>key!=='value').map(([key,meta])=><div className="core-field" key={key}><label>{key} · Public Property</label><Input size="small" value={node.props?.[key]?.value??meta.defaultValue??''} onChange={e=>onProp(node.id,key,literal(e.target.value))}/></div>)}
    {!!definition.overridePolicy?.searchButton?.includes('color')&&<div className="core-field"><label>Override · searchButton.color</label>
      <div className="core-color-field"><input type="color" value={/^#[0-9a-fA-F]{6}$/.test(override||'')?override:'#3764df'} onChange={e=>onOverride(node.id,'searchButton','color',literal(e.target.value))}/><code>{override||'원본 값'}</code><Button size="small" onClick={()=>onOverride(node.id,'searchButton','color',null)}>Reset</Button></div>
    </div>}
    <p className="core-hint">색상 Override는 다른 인스턴스에 영향을 주지 않습니다. Definition의 텍스트 변경도 보존됩니다.</p>
  </div>;
}
export function FrameworkLab({legacyProject}){
  const [doc,setDoc]=useState(createSearchBoxDocument);
  const [session,setSession]=useState(()=>new RuntimeSession(createSearchBoxDocument()));
  const [selected,setSelected]=useState('customerSearch');
  const [source,setSource]=useState('demo');
  const [json,setJson]=useState(()=>serializeDocument(createSearchBoxDocument(),registry));
  const [error,setError]=useState('');
  const [log,setLog]=useState([]);
  const [jsonOpen,setJsonOpen]=useState(false);
  session.document=doc;
  useEffect(()=>setJson(serializeDocument(doc,registry)),[doc]);
  const root=doc.pages.main?.root||Object.values(doc.pages)[0]?.root;
  const instance=(()=>{let result;walkNodes(root,n=>{if(n.id===selected)result=n;});return result;})();
  const definition=instance?.kind==='instance'?doc.definitions[instance.definitionId]:doc.definitions.SearchBox;
  const definitionNode=definition?.root&&findNode(definition.root,selected);
  const [buttonText,setButtonText]=useState('검색');
  useEffect(()=>{
    const button=definition?.root&&findNode(definition.root,'searchButton');
    setButtonText(button?.props?.text?.value??'검색');
  },[doc]);
  const update=(fn)=>{try{const next=fn(doc);setDoc(next);setError('');}catch(e){setError(e.message);}};
  const patchDef=(nodeId,key,value)=>update(d=>patchDefinitionProperty(d,definition.id,nodeId,key,value,registry));
  const patchBinding=(instanceId,key,value)=>update(d=>patchInstanceBinding(d,instanceId,key,value,registry));
  const patchOverride=(instanceId,nodeId,key,value)=>update(d=>patchInstanceOverride(d,instanceId,nodeId,key,value,registry));
  const patchProp=(instanceId,key,value)=>update(d=>patchInstanceProp(d,instanceId,key,value,registry));
  const reset=()=>{const next=createSearchBoxDocument();setDoc(next);setSession(new RuntimeSession(next));setSelected('customerSearch');setSource('demo');setLog([]);setError('');};
  const importLegacy=()=>{
    try{const next=migrateV5ToV6(legacyProject);parseDocument(JSON.stringify(next),registry);setDoc(next);setSession(new RuntimeSession(next));setSelected(next.pages.main.root.id);setSource('migrated');setLog([]);setError('');}
    catch(e){setError(`v5 변환 실패: ${e.message}`);}
  };
  const applyJson=()=>{try{const next=parseDocument(json,registry);setDoc(next);setSession(new RuntimeSession(next));setSelected(next.pages.main?.root?.id||Object.values(next.pages)[0].root.id);setSource('json');setLog([]);setError('');}
    catch(e){setError(`JSON 검증 실패: ${e.message}`);}};
  return <div className="framework-lab">
    <div className="core-header"><div><strong>Framework Core v0.8</strong><span>Headless Core · Canonical JSON v6 · React/AntD Adapter</span></div>
      <div className="core-header-actions"><Tag color="geekblue">{source==='demo'?'SearchBox Vertical Slice':source==='migrated'?'v5 Migrated Project':'JSON Loaded'}</Tag><Button size="small" onClick={reset}>데모 초기화</Button><Button size="small" onClick={importLegacy}>현재 v0.7.1 → v6</Button><Button size="small" onClick={()=>setJsonOpen(v=>!v)}>{jsonOpen?'JSON 닫기':'JSON 편집'}</Button><Button size="small" type="primary" onClick={()=>download(serializeDocument(doc,registry),'ui-studio-v6.json')}>JSON 저장</Button></div>
    </div>
    {error&&<Alert className="core-error" showIcon type="error" message={error} closable onClose={()=>setError('')}/>}
    {jsonOpen?<section className="core-json-pane"><div className="core-json-info"><strong>Canonical JSON Schema v6</strong><span>유효한 JSON만 적용됩니다. 편집 후 적용 시 런타임 데이터 상태는 초기화됩니다.</span><Button type="primary" onClick={applyJson}>JSON 검증 및 적용</Button></div><textarea aria-label="Canonical JSON 편집" spellCheck={false} value={json} onChange={e=>setJson(e.target.value)}/></section>:
    <div className="core-columns">
      <aside className="core-tree"><div className="core-pane-heading">Component Tree</div><TreeRows node={root} selected={selected} onSelect={setSelected} definitions={doc.definitions}/><Divider style={{margin:'12px 0'}}/><div className="core-pane-heading">Registered Controls</div>{registry.list().slice(0,4).map(d=><div key={d.typeId} className="core-registry-row"><span>{d.displayName}</span><small>{Object.keys(d.properties).length} props</small></div>)}<p className="core-hint">새 컨트롤은 Registry와 Renderer Adapter에 각각 등록합니다.</p></aside>
      <div className="core-stage"><div className="core-pane-heading">Runtime Preview <small>같은 Core 규칙을 사용하는 실제 AntD 입력</small></div><div className="core-preview"><RuntimeView document={doc} session={session} registry={registry} renderer={renderer} onPublicEvent={(instanceId,event,payload)=>setLog(items=>[{instanceId,event,value:payload.value},...items].slice(0,5))}/></div>
        {source==='demo'&&<div className="core-state"><div className="core-pane-heading">Reactive State · TwoWay</div><div><span>customer.keyword</span><StateValue session={session} path={['customer','keyword']}/></div><div><span>product.keyword</span><StateValue session={session} path={['product','keyword']}/></div></div>}
        <div className="core-log"><strong>공개 이벤트</strong>{log.length===0?<span className="core-hint">SearchBox의 검색 버튼을 누르면 이벤트가 표시됩니다.</span>:log.map((x,i)=><span key={i}>{x.instanceId}.on{x.event}({JSON.stringify(x.value)})</span>)}</div>
      </div>
      <aside className="core-inspector"><div className="core-pane-heading">Properties <small>Metadata-driven</small></div>
        {instance?.kind==='instance'&&definition?<InstanceEditor node={instance} definition={definition} onBinding={patchBinding} onOverride={patchOverride} onProp={patchProp}/>:null}
        {definitionNode?.kind==='component'?<MetaEditor definition={definition} node={definitionNode} onChange={patchDef}/>:null}
        {instance?.kind==='frame'&&<p className="core-hint">선택됨: {instance.name||instance.id} · {instance.layout.type}</p>}
        {source==='demo'&&<div className="core-inspector-section"><h4>Definition 변경 전파</h4><div className="core-field"><label>SearchBox.searchButton.text</label><Input size="small" value={buttonText} onChange={e=>setButtonText(e.target.value)}/></div><Button block size="small" onClick={()=>patchDef('searchButton','text',literal(buttonText))}>원본에 적용 · 두 인스턴스 갱신</Button><p className="core-hint">SearchBox Definition은 하나만 저장됩니다. Instance B의 색상 Override는 유지됩니다.</p></div>}
        <div className="core-inspector-section"><h4>공통 속성 시스템</h4><p className="core-hint">Literal / Binding / Resource가 동일한 Property Resolver를 통과합니다. 입력 상태와 문서 구조는 분리되어 저장됩니다.</p></div>
      </aside>
    </div>}
    <div className="core-footer">Schema v6 · Registry &amp; Property Metadata · Reactive Store · DataContext · TwoWay · Composite Instance · Override Preview <strong>· v5 Designer는 별도 탭에서 보존</strong></div>
  </div>;
}
