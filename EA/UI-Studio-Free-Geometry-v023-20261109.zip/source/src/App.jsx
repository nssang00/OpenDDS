import React from 'react';
import {ConfigProvider} from 'antd';
import {UnifiedStudio} from './framework/UnifiedStudio.jsx';
import './framework/unified.css';

/** One entrypoint, one canonical v6 document. Older v5 JSON is imported inside Studio. */
export default function App(){
  return <ConfigProvider theme={{token:{colorPrimary:'#3764df',borderRadius:7,fontFamily:'Inter, Pretendard, system-ui, sans-serif'}}}>
    <div className="one-studio-root"><UnifiedStudio/></div>
  </ConfigProvider>;
}
