# UI Studio v0.22 — Toolbox & Free Frame PoC

2026-11-09 · **실험 빌드입니다. 정식 검증 기준선이 아닙니다.**

## 설계 의도

v0.21의 Visual ↔ JSX-형 DSL ↔ canonical JSON v6 ↔ shadcn Native TSX 경로를 유지하면서, WPF Toolbox 같은 요소 추가 및 자유 좌표 배치를 작은 범위에서 검증합니다. 캔버스에 임의의 HTML/CSS를 넣는 기능은 아닙니다.

## 작업 흐름

1. 새 컴포넌트 → **빈 컴포넌트** 선택.
2. 왼쪽에 상시 표시되는 **Toolbox**에서 `자유 배치`를 클릭/드래그해 Frame 삽입. 레이아웃은 `Free`이며 기본 크기는 640×360px입니다.
3. `Heading`, `Input`, `Textarea`, `Switch`, `Button` 등을 Toolbox에서 **Free Frame 안으로 끌어다 놓기**. 드롭 좌표는 Frame 원점 기준 8px 격자에 스냅되고 canonical JSON의 `position: {x,y}`로 저장됩니다. 기존 요소의 재배치도 지원합니다.
4. Canvas의 요소 선택 → 오른쪽 Inspector에서 X/Y 수치 편집, 기존 모서리 드래그로 크기 조절. 레이어와 요소 트리는 이전 버전과 동일합니다.
5. 상단 **분할 · DSL**에서 `<Free>`와 `position={{"x":...,"y":...}}`를 편집하면 Canonical 모델로 검증 및 반영됩니다.
6. 미리보기에서 React Runtime의 상대/절대 배치를 확인하고, 컴포넌트 Definition의 Native shadcn TSX를 생성합니다.

## 구현 범위

- `packages/core/layout.js` — Free Frame style, Free child absolute coordinates.
- `packages/core/editor.js` — atomic `placeEditorNode`, `snapFreePosition`, `changeFrameLayout` (Free↔Auto 전환 시 좌표 자동 설정/해제).
- `packages/schema/index.js` — schemaVersion은 6 그대로; `free` 레이아웃과 `position`의 제한된 검증 추가. **기존 v6 문서 하위 호환**.
- `packages/format-dsl/index.js` — `<Free>` 텍스트와 position 속성 roundtrip.
- `packages/runtime-react/Runtime.jsx` 및 `src/framework/UnifiedStudio.jsx` — Canvas, Runtime, 인스펙터, pointer drop 좌표, 8px 스냅, 3모드 (디자인/분할 DSL/미리보기).
- `packages/exporter-react/native-shadcn.js` — Free Frame의 부모 relative/자식 absolute 스타일, 5종 컨트롤 신규 Export.
- `packages/core/registry.js` 및 `packages/renderer-antd/index.jsx` — 기존 9개 + Heading, Label, Textarea, Switch, Progress = **14종**. `Select/Table`은 구형 Runtime에서는 작동하지만 Native Export는 계속 실패 처리합니다.
- `src/framework/unified.css` — 상시 표시 Toolbox, 검색, 카테고리, 스냅 격자.
- `examples/free-panel-v022.json`, `exports/FreePanel-shadcn-native.zip` — 재현 가능한 샘플.

## 기술적 제약

- **전체 컴포넌트 배치 시스템을 Figma처럼 구현한 단계가 아닙니다.** Free Frame 안에서만 좌표 기반 배치가 가능하고, 자동 배치 Row/Column/Grid는 종전처럼 순서/셀 삽입입니다.
- 현재 단일 요소 마우스 배치와 8px 스냅을 구현했습니다. 정렬선, 다중 요소 좌표 이동, 회전, 반응형 Constraints, 겹친 요소 레이어 제어, 다중 breakpoint는 미구현입니다.
- Free Frame은 640px 고정 폭의 실험적 모델입니다. 좁은 모바일 화면에서 자동 재배치를 보장하지 않습니다.
- `position`은 Free Frame의 직계 자식에만 허용합니다. 다른 Frame으로 이동하면 좌표 메타데이터를 제거합니다.
- Visual↔텍스트 **DSL**은 양방향이지만 생성한 임의 React TSX를 다시 Visual로 가져오지는 못합니다.
- Studio와 Runtime의 화면은 아직 AntD로 렌더링하며, Native Export는 shadcn/ui(Base UI) 소스 코드만 생성합니다. 두 렌더러의 픽셀/접근성 완전 일치는 검증되지 않았습니다.
- 신규 Textarea/Switch의 변경 이벤트는 Runtime에서 발생하지만, Native Export의 공개 `change` Event 콜백 연결은 아직 미지원이며 명시적으로 Export 차단합니다.
- 실제 Vite 빌드, Playwright Chromium DOM E2E 및 shadcn/Base UI **진짜 소비자 프로젝트 빌드 미실행** (Vite/Playwright npm 의존성이 이 환경에 설치되지 않음). 오프라인 TypeScript 스텁 검사는 대체 검증이 아닙니다.

## 검증 재현

```bash
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run verify:native-tsx
npm run build        # 실제 환경에서 npm install 후
npm run test:e2e    # 실제 Vite/Chromium이 준비된 환경에서
```

`playwright.config.js`의 v0.22 시나리오는 준비돼 있지만 이 인계 환경에서는 실행하지 못했습니다. 코드 및 아카이브에는 별도의 SHA-256 목록이 있습니다.
