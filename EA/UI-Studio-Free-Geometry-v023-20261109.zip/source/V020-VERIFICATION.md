# UI Studio v0.20 One Studio UX — verification record

## Implementation
- Single v6 Studio mounted from `src/App.jsx`, removing v5 design/code/preview tab selection.
- 5 header actions: undo, redo, preview, export, project overflow menu.
- Contextual quick add, opt-in layer tree and palette, opt-in inspector detailed properties, action/data disclosure.
- Historical v5 JSON documents are migrated on file import via `migrateV5ToV6`.
- Code editor and JSON editing remain accessible from the project menu; React export uses the same schema v6.

## Verified locally (Node 22)
- `npm test`: 210 tests, 210 pass, 0 fail.
- `node tools/verify-syntax.mjs`: 56 source files plus 3 generated TSX, 0 syntax errors.
- `npm run verify:runtime`: successful Runtime/slot/TwoWay/event/dynamic composition checks.
- Reproducer `verification/v020-reproduce.py` applied to clean v0.19 baseline and compared 9 output files byte-for-byte.

## Scope limits
- At this packaging stage, full browser E2E and independently installed React Consumer were not executed in the local runtime (npm registry is unavailable). The repository includes `e2e/one-studio-v020.spec.js` (6 planned browser scenarios) but its results must not be treated as a pass without an actual run.
- This version changes the UI enough to make historical tests asserting v5/Advanced-mode affordances obsolete. They are retained for audit; Playwright default testMatch uses the v0.20 suite. Prior successful v0.19 CI is evidence for v0.19, not automatically v0.20.
- No formal user usability study was performed. Fewer visible controls is a measured simplification, not proof of subjective ease of use.
