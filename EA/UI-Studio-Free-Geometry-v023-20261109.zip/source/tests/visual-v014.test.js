import test from 'node:test';
import assert from 'node:assert/strict';
import {
  createDefaultRegistry,inspectorSchema,visualDataChoices,compatibleChoices,providerForChoice,
  configureStateField,configureVisibility,configureRepeat,setControlAction,stateAction,
  runControlAction,RuntimeSession,createBlankComponentWorkspace,createComponentDefinition,
  createEditorNode,insertEditorNode,createComponentExportDocument
} from '../packages/core/index.js';
import {binding,literal,parseDocument,serializeDocument,validateDocument} from '../packages/schema/index.js';
import {repeatEntries} from '../packages/core/dynamic.js';
import {createPortablePackageFiles} from '../packages/exporter-react/component-package.js';
import {readFileSync} from 'node:fs';
const registry=createDefaultRegistry();
const blank=()=>createBlankComponentWorkspace('CustomerBrowser',registry);
const nodeIn=(doc,kind,id,parentId='previewWorkspaceRoot')=>insertEditorNode(doc,parentId,999,{id,kind:'component',typeId:kind,props:{}},registry);

test('v0.14 schema-driven Inspector exposes types/defaults/enum/bindability without React',()=>{
 const r=inspectorSchema(registry,'core/Button');
 assert.equal(r.schema.type,'object');
 assert.equal(r.schema.properties.text.default,'버튼');
 assert.deepEqual(r.schema.properties.variant.enum,['primary','default']);
 assert.equal(r.ui.text.bindable,true);
 assert.equal(r.ui.text.widget,'text');
 assert.equal(r.ui.color.widget,'color');
 assert.throws(()=>inspectorSchema(registry,'unknown'));
});
test('v0.14 visual data creation adds valid canonical state and survives JSON save/reload',()=>{
 let d=configureStateField(blank(),'keyword','',registry);
 d=configureStateField(d,'visible',true,registry);
 d=configureStateField(d,'customers',[{id:1,name:'Alice'},{id:2,name:'Bob'}],registry);
 const parsed=parseDocument(serializeDocument(d,registry),registry);
 assert.equal(parsed.data.state.visible,true);
 assert.equal(parsed.data.state.customers[1].name,'Bob');
 assert.throws(()=>configureStateField(d,'__proto__','x',registry));
 assert.throws(()=>configureStateField(d,'visible','',registry));
});
test('v0.14 visual data picker suggests typed state, source, component props and repeated context items',()=>{
 let d=configureStateField(blank(),'customers',[{id:1,name:'Alice'}],registry);
 d=configureStateField(d,'visible',true,registry);
 const choices=visualDataChoices(d,'CustomerBrowser');
 assert.ok(choices.some(x=>x.label==='state.customers'&&x.type==='array'));
 assert.ok(choices.some(x=>x.label==='context.item.name'&&x.type==='string'));
 assert.ok(choices.some(x=>x.label==='state.visible'&&x.type==='boolean'));
 assert.deepEqual(compatibleChoices(choices,'boolean').map(x=>x.label),['state.visible']);
});
test('v0.14 TwoWay never binds read-only sources or repeated context',()=>{
 assert.throws(()=>providerForChoice({source:'sources',path:['items']},{twoWay:true}));
 assert.throws(()=>providerForChoice({source:'context',path:['item','name']},{twoWay:true}));
 assert.equal(providerForChoice({source:'state',path:['keyword']},{twoWay:true}).mode,'TwoWay');
});
test('v0.14 click-configured visibility uses canonical when and survives roundtrip',()=>{
 let d=configureStateField(blank(),'visible',true,registry);
 d=nodeIn(d,'core/Text','title');
 d=configureVisibility(d,'title',{source:'state',path:['visible'],type:'boolean'},registry);
 assert.deepEqual(d.pages.main.root.children[0].when,binding('state',['visible']));
 assert.equal(parseDocument(serializeDocument(d,registry),registry).pages.main.root.children[0].when.source,'state');
 d=configureVisibility(d,'title',null,registry);
 assert.equal(d.pages.main.root.children[0].when,undefined);
});
test('v0.14 visual Repeat with item key renders two entries in stable order',()=>{
 let d=configureStateField(blank(),'customers',[{id:'a',name:'Alice'},{id:'b',name:'Bob'}],registry);
 d=nodeIn(d,'core/Text','name');
 d=configureRepeat(d,'name',{source:'state',path:['customers'],type:'array'},['id'],registry);
 const node=d.pages.main.root.children[0];
 assert.deepEqual(node.repeat.items,binding('state',['customers']));
 assert.deepEqual(node.repeat.keyPath,['id']);
 assert.equal(repeatEntries(d.data.state.customers,node.repeat.keyPath).length,2);
 assert.throws(()=>configureRepeat(d,'name',{source:'state',path:['customers'],type:'string'},[],registry));
});
test('v0.14 visual button action mutates only selected state in Preview session',()=>{
 let d=configureStateField(blank(),'keyword','initial',registry);
 d=configureStateField(d,'lastSearch','',registry);
 d=nodeIn(d,'core/Button','submit');
 const action=stateAction({source:'state',path:['lastSearch']},binding('state',['keyword']));
 d=setControlAction(d,'submit','click',action,registry);
 const event=d.pages.main.root.children[0].events.click;
 const session=new RuntimeSession(d);
 session.state.set(['keyword'],'Alice');
 assert.equal(runControlAction(event,session.rootScope()),true);
 assert.equal(session.state.get(['lastSearch']),'Alice');
 assert.equal(d.data.state.lastSearch,'');
 assert.equal(parseDocument(serializeDocument(d,registry),registry).pages.main.root.children[0].events.click.kind,'set');
});
test('v0.14 declarative action rejects prototype injection, write-only source and executable payload',()=>{
 assert.throws(()=>stateAction({source:'state',path:['__proto__']},literal(1)));
 assert.throws(()=>stateAction({source:'sources',path:['name']},literal('x')));
 assert.throws(()=>stateAction({source:'state',path:['name']},binding('state',['name'],'TwoWay')));
 const d=nodeIn(blank(),'core/Button','button');
 assert.throws(()=>setControlAction(d,'button','click',{kind:'eval',code:'alert(1)'},registry));
});
test('v0.14 declarative action is not allowed to leak host State through independent React Export',()=>{
 let d=blank();const def=d.definitions.CustomerBrowser;
 d=insertEditorNode(d,def.root.id,0,createEditorNode(d,'core/Button',registry),registry,'definition:CustomerBrowser');
 const nodeId=d.definitions.CustomerBrowser.root.children[0].id;
 d=setControlAction(d,nodeId,'click',stateAction({source:'state',path:['keyword']},literal('oops')),registry,'definition:CustomerBrowser');
 assert.throws(()=>createComponentExportDocument(d,'CustomerBrowser',registry),/외부 상태 변경/);
});
test('v0.14 local state actions remain package-safe within reusable definitions',()=>{
 let d=blank();d=insertEditorNode(d,d.definitions.CustomerBrowser.root.id,0,createEditorNode(d,'core/Button',registry),registry,'definition:CustomerBrowser');
 const nodeId=d.definitions.CustomerBrowser.root.children[0].id;
 d=setControlAction(d,nodeId,'click',stateAction({source:'local',path:['clicked']},literal('yes')),registry,'definition:CustomerBrowser');
 assert.equal(createComponentExportDocument(d,'CustomerBrowser',registry).definitions.CustomerBrowser.root.children[0].events.click.kind,'set');
 const files=createPortablePackageFiles(d,registry,'CustomerBrowser',Object.fromEntries([
  'schema/index.js','runtime-react/Runtime.jsx','renderer-antd/index.jsx',
  ...['index','binding','components','document','editor','events','layout','properties','registry','session','store','workspace','slots','dynamic','visual'].map(x=>'core/'+x+'.js')
 ].map(file=>['packages/'+file,readFileSync('packages/'+file,'utf8')])));
 assert.equal(files['src/runtime/core/visual.js'].includes('runControlAction'),true);
 assert.equal(files['src/CustomerBrowser.tsx'].includes('RuntimeView'),true);
});
test('v0.14 schema registry rejects undefined control properties before runtime',()=>{
 const d=nodeIn(blank(),'core/Text','label');
 const copy=structuredClone(d);copy.pages.main.root.children[0].props={madeUp:literal(true)};
 assert.throws(()=>validateDocument(copy,registry),/미등록 Property/);
});
test('v0.14 static JSX component export and dynamic canonical JSON use a single definition',()=>{
 const d=blank();
 const json=parseDocument(serializeDocument(d,registry),registry);
 const files=createPortablePackageFiles(json,registry,'CustomerBrowser',Object.fromEntries([
  'schema/index.js','runtime-react/Runtime.jsx','renderer-antd/index.jsx',
  ...['index','binding','components','document','editor','events','layout','properties','registry','session','store','workspace','slots','dynamic','visual'].map(x=>'core/'+x+'.js')
 ].map(file=>['packages/'+file,readFileSync('packages/'+file,'utf8')])));
 assert.match(files['src/CustomerBrowser.tsx'],/const document = /);
 assert.match(files['src/CustomerBrowser.tsx'],/RuntimeView/);
 assert.match(files['src/runtime/runtime-react/Runtime.jsx'],/runControlAction/);
});
