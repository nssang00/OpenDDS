import test from 'node:test';
import assert from 'node:assert/strict';
import {createSearchBoxDocument,serializeDocument,parseDocument} from '../packages/schema/index.js';
import {createDefaultRegistry,createEditorNode,insertEditorNode,moveEditorNode,moveEditorGroup,editorDropCandidate,editorAutoScrollDelta,geometryInsertion} from '../packages/core/index.js';
const registry=createDefaultRegistry(),initial=()=>createSearchBoxDocument();
const ids=doc=>doc.pages.main.root.children.map(n=>n.id);
const check=(doc,input)=>editorDropCandidate(doc.pages.main.root,input);

test('v0.18 same-parent drop indexes always refer to the original child array',()=>{
 const d=initial(),[a,b,c]=ids(d);
 assert.deepEqual(check(d,{parentId:'pageRoot',index:3,sourceIds:[a]}),{valid:true,parentId:'pageRoot',index:3});
 let moved=moveEditorNode(d,a,'pageRoot',3,registry);
 assert.deepEqual(ids(moved),[b,c,a]);
 assert.equal(check(d,{parentId:'pageRoot',index:1,sourceIds:[a]}).valid,false);
 assert.equal(check(d,{parentId:'pageRoot',index:0,sourceIds:[a]}).valid,false);
 assert.equal(check(d,{parentId:'pageRoot',index:3,sourceIds:[c]}).valid,false);
 assert.deepEqual(ids(d),[a,b,c]);
 assert.deepEqual(parseDocument(serializeDocument(moved,registry),registry),moved);
});
test('v0.18 contiguous group no-op feedback and legal cross-frame moves',()=>{
 let d=initial();const [a,b,c]=ids(d);
 assert.equal(check(d,{parentId:'pageRoot',index:2,sourceIds:[a,b]}).valid,false);
 assert.equal(check(d,{parentId:'pageRoot',index:3,sourceIds:[a,b]}).valid,true);
 d=moveEditorGroup(d,[a,b],'pageRoot',3,registry);
 assert.deepEqual(ids(d),[c,a,b]);
 const frame=createEditorNode(d,'layout/column',registry);
 d=insertEditorNode(d,'pageRoot',3,frame,registry);
 assert.equal(check(d,{parentId:frame.id,index:0,sourceIds:[a,b]}).valid,true);
 d=moveEditorGroup(d,[a,b],frame.id,0,registry);
 assert.deepEqual(ids(d),[c,frame.id]);
 assert.deepEqual(d.pages.main.root.children[1].children.map(n=>n.id),[a,b]);
});
test('v0.18 cycle prevention rejects dropping a parent into its descendant',()=>{
 let d=initial();const outer=createEditorNode(d,'layout/row',registry);
 d=insertEditorNode(d,'pageRoot',3,outer,registry);
 const inner=createEditorNode(d,'layout/column',registry);
 d=insertEditorNode(d,outer.id,0,inner,registry);
 assert.match(check(d,{parentId:inner.id,index:0,sourceIds:[outer.id]}).reason,/자손/);
 assert.equal(check(d,{parentId:outer.id,index:1,sourceIds:[outer.id]}).valid,false);
 assert.equal(check(d,{parentId:'pageRoot',index:999,sourceIds:[outer.id]}).valid,false);
 assert.equal(check(d,{parentId:'unknown',index:0,sourceIds:[outer.id]}).valid,false);
 assert.equal(check(d,{parentId:inner.id,index:0,sourceIds:[],kind:'new'}).valid,true);
});
test('v0.18 non-sibling group and missing source cannot be dropped',()=>{
 let d=initial(),frame=createEditorNode(d,'layout/column',registry);
 d=insertEditorNode(d,'pageRoot',3,frame,registry);
 const [a,b]=ids(d);
 d=moveEditorNode(d,a,frame.id,0,registry);
 assert.equal(check(d,{parentId:'pageRoot',index:0,sourceIds:[a,b]}).valid,false);
 assert.equal(check(d,{parentId:'pageRoot',index:0,sourceIds:['missing']}).valid,false);
 assert.equal(check(d,{parentId:'pageRoot',index:0,sourceIds:[a],kind:'invalid'}).valid,false);
});
test('v0.18 geometry on original elements preserves correct before/after index',()=>{
 const r=[{left:10,top:10,right:110,bottom:40,width:100,height:30},{left:10,top:50,right:110,bottom:80,width:100,height:30},{left:10,top:90,right:110,bottom:120,width:100,height:30}];
 assert.deepEqual(geometryInsertion(r,{x:30,y:10},'column'),{index:0,edge:'before'});
 assert.deepEqual(geometryInsertion(r,{x:30,y:75},'column'),{index:2,edge:'before'});
 assert.deepEqual(geometryInsertion(r,{x:30,y:125},'column'),{index:3,edge:'after'});
 assert.deepEqual(geometryInsertion([], {x:0,y:0},'row'),{index:0,edge:'empty'});
});
test('v0.18 auto-scroll only near in-bounds vertical pane edges',()=>{
 const rect={left:10,right:110,top:20,bottom:220};
 assert.ok(editorAutoScrollDelta(rect,{x:30,y:22})<0);
 assert.ok(editorAutoScrollDelta(rect,{x:30,y:218})>0);
 assert.equal(editorAutoScrollDelta(rect,{x:30,y:120}),0);
 assert.equal(editorAutoScrollDelta(rect,{x:1,y:22}),0);
 assert.equal(editorAutoScrollDelta(rect,{x:30,y:900}),0);
});
