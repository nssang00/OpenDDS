import test from 'node:test';
import assert from 'node:assert/strict';
import {createDefaultRegistry,createEditorNode,insertEditorNode,editorSiblingSelection,chooseEditorSelection,editorGroupMoveOptions,moveEditorGroupRelative,moveEditorGroup,removeEditorGroup,alignEditorGroup,locateNode} from '../packages/core/index.js';
import {createSearchBoxDocument,serializeDocument,parseDocument} from '../packages/schema/index.js';
import {frameStyle} from '../packages/core/layout.js';
const registry=createDefaultRegistry();
const original=()=>createSearchBoxDocument();
const kids=(d,scope='main')=>scope==='main'?d.pages.main.root.children:d.definitions[scope].root.children;
const ids=d=>kids(d).map(n=>n.id);

test('v0.17 Ctrl/Cmd toggles within siblings, never root or cross-parent',()=>{
 const doc=original(),root=doc.pages.main.root,[a,b,c]=ids(doc);
 assert.deepEqual(chooseEditorSelection(root,[a],b,{toggle:true}),[a,b]);
 assert.deepEqual(chooseEditorSelection(root,[a,b],a,{toggle:true}),[b]);
 assert.deepEqual(chooseEditorSelection(root,[a],c,{range:true,anchor:a}),[a,b,c]);
 assert.deepEqual(chooseEditorSelection(root,[a],root.id,{toggle:true}),[root.id]);
 assert.deepEqual(chooseEditorSelection(root,[a],'missing',{toggle:true}),[]);
});
test('v0.17 noncontiguous group moves down/up preserving order and IDs',()=>{
 const before=original(),[a,b,c]=ids(before),sel=[a,c];
 assert.deepEqual(editorGroupMoveOptions(before.pages.main.root,sel),{up:true,down:true});
 let doc=moveEditorGroupRelative(before,sel,'down',registry);
 assert.deepEqual(ids(doc),[b,a,c]);
 doc=moveEditorGroupRelative(doc,sel,'up',registry);
 assert.deepEqual(ids(doc),[a,c,b]);
 assert.deepEqual(ids(before),[a,b,c]);
 assert.deepEqual(parseDocument(serializeDocument(doc,registry),registry),doc);
});
test('v0.17 contiguous group down and undo via immutable prior snapshot',()=>{
 const old=original(),[a,b,c]=ids(old);
 const moved=moveEditorGroupRelative(old,[a,b],'down',registry);
 assert.deepEqual(ids(moved),[c,a,b]);
 assert.deepEqual(ids(old),[a,b,c]);
 assert.deepEqual(editorGroupMoveOptions(moved.pages.main.root,[a,b]),{up:true,down:false});
 assert.throws(()=>moveEditorGroupRelative(moved,[a,b],'down',registry),/더 이동/);
});
test('v0.17 bulk drag respects insertion index before removal',()=>{
 let doc=original();const [a,b,c]=ids(doc);
 doc=moveEditorGroup(doc,[a,b],'pageRoot',3,registry);
 assert.deepEqual(ids(doc),[c,a,b]);
 doc=moveEditorGroup(doc,[a,b],'pageRoot',0,registry);
 assert.deepEqual(ids(doc),[a,b,c]);
});
test('v0.17 group drag into another Frame preserves descendants and data',()=>{
 let doc=original();const [a,b]=ids(doc),frame=createEditorNode(doc,'layout/row',registry);
 doc=insertEditorNode(doc,'pageRoot',3,frame,registry);
 const moved=moveEditorGroup(doc,[a,b],frame.id,0,registry);
 assert.deepEqual(ids(moved),[ids(doc)[2],frame.id]);
 assert.deepEqual(locateNode(moved.pages.main.root,frame.id).node.children.map(n=>n.id),[a,b]);
 assert.deepEqual(ids(doc),[a,b,ids(doc)[2],frame.id]);
 assert.deepEqual(parseDocument(serializeDocument(moved,registry),registry),moved);
});
test('v0.17 group drag rejects root, missing, duplicate and mixed parents',()=>{
 let doc=original(),[a,b]=ids(doc),frame=createEditorNode(doc,'layout/row',registry);
 doc=insertEditorNode(doc,'pageRoot',3,frame,registry);
 const child=createEditorNode(doc,'core/Text',registry);doc=insertEditorNode(doc,frame.id,0,child,registry);
 const root=doc.pages.main.root;
 for(const bad of [[a,a],[a,'missing'],[a,'pageRoot'],[a,child.id]]){
  assert.throws(()=>editorSiblingSelection(root,bad),/선택|형제|루트/);
 }
 assert.throws(()=>moveEditorGroup(doc,[frame.id],frame.id,0,registry),/자기 자신/);
 assert.throws(()=>moveEditorGroup(doc,[a],child.id,0,registry),/Frame/);
 assert.throws(()=>moveEditorGroup(doc,[a],frame.id,-1,registry),/삽입 위치/);
});
test('v0.17 bulk delete is atomic and refuses root',()=>{
 const doc=original(),[a,b,c]=ids(doc);
 const removed=removeEditorGroup(doc,[a,c],registry);
 assert.deepEqual(ids(removed),[b]);
 assert.deepEqual(ids(doc),[a,b,c]);
 assert.throws(()=>removeEditorGroup(doc,[a,'pageRoot'],registry),/루트/);
});
test('v0.17 parent alignment and gap use canonical v6 layout and runtime CSS',()=>{
 const before=original(),[a,b]=ids(before);
 const aligned=alignEditorGroup(before,[a,b],{align:'center',gap:16},registry);
 assert.equal(aligned.pages.main.root.layout.align,'center');
 assert.equal(frameStyle(aligned.pages.main.root.layout).alignItems,'center');
 assert.equal(frameStyle(aligned.pages.main.root.layout).gap,16);
 assert.deepEqual(parseDocument(serializeDocument(aligned,registry),registry),aligned);
 assert.notDeepEqual(before,aligned);
 assert.throws(()=>alignEditorGroup(before,[a,b],{align:'top'},registry),/정렬/);
 assert.throws(()=>alignEditorGroup(before,[a,b],{gap:-3},registry),/간격/);
});
test('v0.17 scoped Definition group operations increment revision',()=>{
 const d=original(),root=d.definitions.SearchBox.root,[a,b]=root.children.map(n=>n.id);
 const next=alignEditorGroup(d,[a,b],{gap:24},registry,'definition:SearchBox');
 assert.equal(next.definitions.SearchBox.revision,(d.definitions.SearchBox.revision||0)+1);
 assert.equal(next.definitions.SearchBox.root.layout.gap,24);
 assert.deepEqual(next.pages,d.pages);
});
