import test from 'node:test';
import assert from 'node:assert/strict';
import {createSearchBoxDocument,literal,binding,validateDocument} from '../packages/schema/index.js';
import {createDefaultRegistry} from '../packages/core/registry.js';
import {createSlotExampleDocument} from '../packages/core/workspace.js';
import {createNativeShadcnFiles,generateNativeShadcnTsx} from '../packages/exporter-react/native-shadcn.js';

const registry=createDefaultRegistry();
const example=()=>structuredClone(createSearchBoxDocument());

test('native shadcn export: existing SearchBox becomes editable React TSX without bundled Studio runtime',()=>{
  const files=createNativeShadcnFiles(example(),registry,'SearchBox');
  const code=files['src/components/SearchBox.tsx'];
  assert.match(code,/export default function SearchBox\(props: SearchBoxProps\)/);
  assert.match(code,/import \{ Input \} from '@\/components\/ui\/input'/);
  assert.match(code,/import \{ Button \} from '@\/components\/ui\/button'/);
  assert.match(code,/onChange=\{\(event\) => updateValue\(event\.currentTarget\.value\)\}/);
  assert.match(code,/onSearch\?\.\(\{value: currentValue\}\)/);
  assert.match(code,/className="flex flex-row min-w-0"/);
  assert.match(code,/props.value !== undefined \? props.value : localValue/);
  assert.doesNotMatch(code,/RuntimeSession|createAntdRenderer|@\/components\/ui\/label/);
  assert.match(files['README.md'],/npx shadcn@latest add button input/);
  assert.match(files['README.md'],/미지원/);
});

test('native shadcn export: emits Card / Checkbox / Badge / Separator and public TwoWay boolean API',()=>{
  const d=example(),def=d.definitions.SearchBox;
  def.root.children=[];
  def.publicProps={checked:{type:'boolean',defaultValue:false,bindable:true,twoWay:true,target:{nodeId:'agree',property:'checked'}}};
  def.publicEvents={};
  def.overridePolicy={};
  d.pages.main.root.children=d.pages.main.root.children.slice(0,1);
  def.root.children.push(
    {id:'agree',kind:'component',typeId:'core/Checkbox',props:{checked:binding('props',['checked'],'TwoWay'),text:literal('동의')}},
    {id:'card',kind:'component',typeId:'core/Card',props:{title:literal('제목'),description:literal('내용')}},
    {id:'rule',kind:'component',typeId:'core/Divider',props:{}},
    {id:'badge',kind:'component',typeId:'core/Tag',props:{text:literal('상태'),color:literal('#333333')}}
  );
  validateDocument(d,registry);
  const code=generateNativeShadcnTsx(d,registry,'SearchBox');
  assert.match(code,/onCheckedChange/);
  assert.match(code,/onCheckedChange=\{\(value\) => updateChecked\(value === true\)\}/);
  assert.match(code,/onCheckedChange\?: \(value: boolean\) => void/);
  assert.match(code,/CardTitle/);assert.match(code,/CardDescription/);
  assert.match(code,/Separator/);assert.match(code,/Badge/);
});

test('native shadcn export: unsupported runtime features fail explicitly rather than disappearing',()=>{
  const cases=[
    ['dynamic visibility',d=>{d.definitions.SearchBox.root.children[0].when=literal(true);},/When\/Repeat/],
    ['unsupported select',d=>{d.definitions.SearchBox.root.children.push({id:'sel',kind:'component',typeId:'core/Select',props:{}});},/core\/Select/],
    ['external state binding',d=>{d.definitions.SearchBox.root.children[0].props.value=binding('state',['customer','keyword'],'OneWay');},/Binding\(state\)/],
    ['unsupported blur',d=>{d.definitions.SearchBox.root.children[0].props.value.updateOn='blur';},/blur 기반 입력/],
    ['set action',d=>{d.definitions.SearchBox.root.children[1].events={click:{kind:'set',target:{source:'state',path:['customer','keyword']},value:literal('changed')}};d.definitions.SearchBox.publicEvents={};},/동작 set/]
  ];
  for(const [name,mutate,pattern] of cases){
    const d=example();mutate(d);
    assert.throws(()=>generateNativeShadcnTsx(d,registry,'SearchBox'),pattern,name);
  }
});

test('native shadcn export: serializes JSX hostile literal safely rather than interpolating it as source',()=>{
  const d=example(),payload='"} ; alert("bad") ; {/* JSX */}';
  d.definitions.SearchBox.root.children[1].props.text=literal(payload);
  const code=generateNativeShadcnTsx(d,registry,'SearchBox');
  assert.ok(code.includes(JSON.stringify(payload)));
  assert.ok(!code.includes(`toText(${payload})`));
});

test('native shadcn export: rejects missing or invalid target Definition',()=>{
  assert.throws(()=>generateNativeShadcnTsx(example(),registry,'Nope'),/유효한 Component Definition/);
  assert.throws(()=>generateNativeShadcnTsx(example(),registry,'../../x'),/유효한 Component Definition/);
});

test('native shadcn export: blank component emits valid minimal code without unused helper or parameter',async()=>{
  const {createBlankComponentWorkspace}=await import('../packages/core/workspace.js');
  const doc=createBlankComponentWorkspace('EmptyCard',registry);
  const code=generateNativeShadcnTsx(doc,registry,'EmptyCard');
  assert.match(code,/function EmptyCard\(_props: EmptyCardProps\)/);
  assert.doesNotMatch(code,/const toText/);
  assert.match(code,/className="flex flex-col min-w-0"/);
});


test('native shadcn export: nested component and Slot are independently editable source files',()=>{
  const doc=createSlotExampleDocument(registry);
  const files=createNativeShadcnFiles(doc,registry,'SearchCard');
  assert.deepEqual(Object.keys(files).sort(),['README.md','src/components/SearchBox.tsx','src/components/SearchCard.tsx','src/components/SlotPanel.tsx']);
  const parent=files['src/components/SearchCard.tsx'];
  const child=files['src/components/SearchBox.tsx'];
  const panel=files['src/components/SlotPanel.tsx'];
  assert.match(parent,/import SearchBox from '\.\/SearchBox'/);
  assert.match(parent,/import SlotPanel from '\.\/SlotPanel'/);
  assert.match(parent,/<SlotPanel>/);
  assert.match(parent,/onValueChange=\{\(nextValue\) => updateValue\(nextValue\)\}/);
  assert.match(parent,/onSearch=\{\(payload\) => props.onSearch\?\.\(payload\)\}/);
  assert.match(panel,/children\?: React.ReactNode;/);
  assert.match(panel,/props.children \?\? \(\<React.Fragment\>/);
  assert.match(child,/const updateValue/);
  assert.match(files['README.md'],/src\/components\/\*\.tsx/);
  assert.doesNotMatch(parent,/import .*antd|RuntimeSession|createAntdRenderer/);
});

test('native shadcn export: empty explicit slot fill overrides fallback content',()=>{
  const doc=createSlotExampleDocument(registry);
  doc.definitions.EmptyFillHost={id:'EmptyFillHost',name:'EmptyFillHost',version:'1.0.0',revision:1,
    root:{id:'emptyFillRoot',kind:'frame',layout:{type:'column'},children:[
      {id:'emptySlotInstance',kind:'instance',definitionId:'SlotPanel',props:{},bindings:{},overrides:{},slots:{content:[]}}
    ]},publicProps:{},publicEvents:{},overridePolicy:{}};
  validateDocument(doc,registry);
  const out=generateNativeShadcnTsx(doc,registry,'EmptyFillHost');
  assert.match(out,/children=\{\<React.Fragment \/>\}/);
  assert.doesNotMatch(out,/<SearchBox/);
});

test('native shadcn export: nested override and non-public binding still fail closed',()=>{
  const d=createSlotExampleDocument(registry);
  const nested=d.definitions.SearchCard.root.children[0].slots.content[0];
  nested.overrides={searchButton:{text:literal('Find')}};
  validateDocument(d,registry);
  assert.throws(()=>createNativeShadcnFiles(d,registry,'SearchCard'),/Override/);
  const d2=example();
  d2.definitions.UnsafeHost={id:'UnsafeHost',name:'UnsafeHost',version:'1.0.0',revision:1,
    root:{id:'unsafeRoot',kind:'frame',layout:{type:'column'},children:[
      {id:'unsafeNested',kind:'instance',definitionId:'SearchBox',props:{},bindings:{placeholder:binding('state',['customer','keyword'],'OneWay')},overrides:{}}
    ]},publicProps:{},publicEvents:{},overridePolicy:{}};
  validateDocument(d2,registry);
  assert.throws(()=>createNativeShadcnFiles(d2,registry,'UnsafeHost'),/Binding\(state\)/);
});

test('native shadcn export: no duplicate dependencies when child used twice',()=>{
  const d=createSlotExampleDocument(registry);
  const panel=d.definitions.SearchCard.root.children[0];
  const second=structuredClone(panel.slots.content[0]);
  second.id='extraSearch';
  panel.slots.content.push(second);
  validateDocument(d,registry);
  const files=createNativeShadcnFiles(d,registry,'SearchCard');
  assert.equal(Object.keys(files).filter(x=>x==='src/components/SearchBox.tsx').length,1);
  assert.equal((files['src/components/SearchCard.tsx'].match(/<SearchBox /g)||[]).length,2);
});
