import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import {CustomerBrowser} from 'ui-studio-customer-browser';
function App(){
 const [first,setFirst]=useState('');const [second,setSecond]=useState('');
 const [events,setEvents]=useState(0);
 return <main>
  <h1>Independent React Consumer</h1>
  <section data-testid="consumer-A"><CustomerBrowser value={first} onValueChange={setFirst} placeholder="첫째 검색" onSearch={()=>setEvents(n=>n+1)}/></section>
  <section data-testid="consumer-B"><CustomerBrowser value={second} onValueChange={setSecond} placeholder="둘째 검색" onSearch={()=>setEvents(n=>n+1)}/></section>
  <output data-testid="first-value">{first}</output><output data-testid="second-value">{second}</output>
  <output data-testid="search-events">{events}</output>
 </main>;
}
createRoot(document.getElementById('root')).render(<App/>);
