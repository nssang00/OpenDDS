import test from 'node:test';
import assert from 'node:assert/strict';
import {createSearchBoxDocument,validateDocument} from '../packages/schema/index.js';
import {createDefaultRegistry,createEditorNode,insertEditorNode} from '../packages/core/index.js';
import {createGuidedComponent,guidedConnectionSuggestions,applyGuidedConnection,guidedComponentSummary} from '../packages/core/guided.js';
import {generateNativeShadcnTsx} from '../packages/exporter-react/native-shadcn.js';

const registry=createDefaultRegistry();
const seed=()=>createSearchBoxDocument();

test('guided blank component is a normal canonical v6 definition and preserves existing project',()=>{
  const base=seed();const next=createGuidedComponent(base,'BlankCard',registry);
  assert.ok(next.definitions.SearchBox);assert.equal(next.definitions.BlankCard.root.children.length,0);
  assert.deepEqual(Object.keys(next.definitions.BlankCard.publicProps),[]);
  assert.equal(base.definitions.BlankCard,undefined);
  assert.equal(validateDocument(next,registry),next);
});

test('search template builds editable composition and public value, placeholder and search API',()=>{
  const doc=createGuidedComponent(seed(),'ProductSearch',registry,{template:'search'});
  const def=doc.definitions.ProductSearch;
  assert.equal(def.root.children[0].kind,'frame');
  const [input,button]=def.root.children[0].children;
  assert.equal(input.typeId,'core/Input');assert.equal(button.typeId,'core/Button');
  assert.deepEqual(Object.keys(def.publicProps),['value','placeholder']);
  assert.deepEqual(Object.keys(def.publicEvents),['search']);
  assert.deepEqual(button.events.click,{kind:'emit',event:'search'});
  assert.equal(def.publicProps.value.twoWay,true);
  assert.equal(doc.definitions.SearchBox.root.id,'searchRoot');
  const tsx=generateNativeShadcnTsx(doc,registry,'ProductSearch');
  assert.match(tsx,/export default function ProductSearch/);
  assert.match(tsx,/onValueChange/);
  assert.match(tsx,/onSearch/);
});

test('fresh search workspace has only requested component and empty preview harness',()=>{
  const doc=createGuidedComponent(seed(),'FreshSearch',registry,{template:'search',fresh:true});
  assert.deepEqual(Object.keys(doc.definitions),['FreshSearch']);
  assert.equal(doc.pages.main.root.children.length,0);
  assert.equal(validateDocument(doc,registry),doc);
});

test('guided suggestions safely expose once and preserve unrelated public API',()=>{
  let doc=createGuidedComponent(seed(),'CustomForm',registry);
  const root=doc.definitions.CustomForm.root.id;
  const input=createEditorNode(doc,'core/Input',registry);
  doc=insertEditorNode(doc,root,0,input,registry,'definition:CustomForm');
  let suggestions=guidedConnectionSuggestions(doc,'CustomForm',input.id,registry);
  assert.ok(suggestions.some(x=>x.type==='prop'&&x.publicName==='value'));
  assert.ok(!suggestions.some(x=>x.type==='event')); // TwoWay value already produces onValueChange
  const prop=suggestions.find(x=>x.type==='prop'&&x.publicName==='value');
  doc=applyGuidedConnection(doc,'CustomForm',input.id,prop,registry);
  assert.equal(doc.definitions.CustomForm.publicProps.value.twoWay,true);
  suggestions=guidedConnectionSuggestions(doc,'CustomForm',input.id,registry);
  assert.ok(!suggestions.some(x=>x.publicName==='value'));
  assert.throws(()=>applyGuidedConnection(doc,'CustomForm',input.id,prop,registry),/이미 연결/);
  const button=createEditorNode(doc,'core/Button',registry);
  doc=insertEditorNode(doc,root,1,button,registry,'definition:CustomForm');
  const event=guidedConnectionSuggestions(doc,'CustomForm',button.id,registry).find(x=>x.type==='event');
  doc=applyGuidedConnection(doc,'CustomForm',button.id,event,registry);
  assert.equal(doc.definitions.CustomForm.publicEvents.click.event,'click');
  assert.deepEqual(doc.definitions.CustomForm.root.children[1].events.click,{kind:'emit',event:'click'});
});

test('guided connection names are unique across multiple nodes and not based on global counters',()=>{
  let doc=createGuidedComponent(seed(),'FormWithTwoInputs',registry);
  const root=doc.definitions.FormWithTwoInputs.root.id;
  const first=createEditorNode(doc,'core/Input',registry);
  doc=insertEditorNode(doc,root,0,first,registry,'definition:FormWithTwoInputs');
  const firstValue=guidedConnectionSuggestions(doc,'FormWithTwoInputs',first.id,registry).find(x=>x.publicName==='value');
  doc=applyGuidedConnection(doc,'FormWithTwoInputs',first.id,firstValue,registry);
  const second=createEditorNode(doc,'core/Input',registry);
  doc=insertEditorNode(doc,root,1,second,registry,'definition:FormWithTwoInputs');
  const suggested=guidedConnectionSuggestions(doc,'FormWithTwoInputs',second.id,registry).find(x=>x.sourceKey==='value');
  assert.equal(suggested.publicName,'value2');
  doc=applyGuidedConnection(doc,'FormWithTwoInputs',second.id,suggested,registry);
  assert.equal(doc.definitions.FormWithTwoInputs.publicProps.value2.target.nodeId,second.id);
});

test('summary and input validation reflect current document, not separate workspace state',()=>{
  const doc=createGuidedComponent(seed(),'SearchWidget',registry,{template:'search'});
  assert.deepEqual(guidedComponentSummary(doc,'SearchWidget'),{
    name:'SearchWidget',controls:2,layouts:2,instances:0,props:['value','placeholder'],events:['search'],slots:[]
  });
  assert.equal(guidedComponentSummary(doc,'missing'),null);
  assert.deepEqual(guidedConnectionSuggestions(doc,'missing','anything',registry),[]);
  assert.throws(()=>createGuidedComponent(seed(),'Nope',registry,{template:'unsupported'}),/지원하지 않는/);
});
