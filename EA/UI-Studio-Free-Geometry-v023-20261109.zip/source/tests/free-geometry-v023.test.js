import test from 'node:test';
import assert from 'node:assert/strict';
import {createDefaultRegistry,createEditorNode,insertEditorNode,placeEditorNode,changeFrameLayout,locateNode,moveEditorNode} from '../packages/core/index.js';
import {moveFreeGroup,freeGroupIds,alignFreeGroup,snapFreeAlignment} from '../packages/core/free-placement.js';
import {createBlankComponentWorkspace} from '../packages/core/workspace.js';
import {validateDocument} from '../packages/schema/index.js';
import {freeFrameSizeStyle,freeChildStyle} from '../packages/core/layout.js';
import {printV6Dsl,parseV6Dsl} from '../packages/format-dsl/index.js';
import {createNativeShadcnFiles} from '../packages/exporter-react/native-shadcn.js';
const reg=createDefaultRegistry(),scope='definition:SnapDemo';
function fixture(count=3){
 let doc=createBlankComponentWorkspace('SnapDemo',reg);
 const frame=createEditorNode(doc,'layout/free',reg);
 doc=insertEditorNode(doc,doc.definitions.SnapDemo.root.id,0,frame,reg,scope);
 const ids=[];
 for(let i=0;i<count;i++){
   const n=createEditorNode(doc,'core/Button',reg);ids.push(n.id);
   n.size={width:80,height:32};
   doc=placeEditorNode(doc,{kind:'new',node:n,parentId:frame.id,index:i,position:{x:24+i*120,y:32+i*56}},reg,scope);
 }
 return {doc,frameId:frame.id,ids};
}
const get=(doc,id)=>locateNode(doc.definitions.SnapDemo.root,id).node;

test('v0.23 sibling snap aligns nearest edge/centre and honors selection exclusions',()=>{
 const siblings=[{id:'other',x:150,y:80,width:100,height:40},{id:'selected',x:200,y:90,width:80,height:36}];
 const snapped=snapFreeAlignment({x:147,y:79},{width:100,height:40},siblings,{excludeIds:['selected']});
 assert.deepEqual(snapped.position,{x:150,y:80});
 assert.deepEqual(snapped.guides.map(g=>g.axis),['x','y']);
 assert.equal(snapFreeAlignment({x:20,y:10},{width:40,height:30},siblings,{threshold:5}).guides.length,0);
 assert.equal(snapFreeAlignment({x:147,y:79},{width:100,height:40},siblings,{excludeIds:['selected','other']}).guides.length,0);
 assert.throws(()=>snapFreeAlignment({x:NaN,y:2},{},[]),/정렬 위치/);
});

test('v0.23 group move shifts free siblings atomically; unchanged others and order',()=>{
 const {doc,ids,frameId}=fixture();
 assert.equal(freeGroupIds(doc.definitions.SnapDemo.root,ids.slice(0,2)).parent.id,frameId);
 const original=structuredClone(doc);
 const next=moveFreeGroup(doc,ids.slice(0,2),ids[0],{x:64,y:80},reg,scope);
 assert.deepEqual(get(next,ids[0]).position,{x:64,y:80});
 assert.deepEqual(get(next,ids[1]).position,{x:184,y:136});
 assert.deepEqual(get(next,ids[2]).position,{x:264,y:144});
 assert.deepEqual(get(doc,ids[0]).position,get(original,ids[0]).position);
 assert.deepEqual(get(next,frameId).children.map(n=>n.id),ids);
 assert.equal(next.definitions.SnapDemo.revision,doc.definitions.SnapDemo.revision+1);
});

test('v0.23 group move rejects non-siblings and invalid coordinates without changing source',()=>{
 const {doc,ids}=fixture();
 assert.throws(()=>moveFreeGroup(doc,ids.slice(0,2),ids[0],{x:-2,y:80},reg,scope),/좌표 범위/);
 assert.throws(()=>moveFreeGroup(doc,ids.slice(0,2),ids[2],{x:100,y:100},reg,scope),/선택/);
 assert.throws(()=>moveFreeGroup(doc,ids.slice(0,2),ids[0],{x:NaN,y:12},reg,scope),/위치 오류/);
 const other=createEditorNode(doc,'layout/column',reg);
 const altered=insertEditorNode(doc,doc.definitions.SnapDemo.root.id,1,other,reg,scope);
 assert.equal(freeGroupIds(altered.definitions.SnapDemo.root,[ids[0],other.id]),null);
});

test('v0.23 group alignment supports four edges, retaining authored coordinates and registry validity',()=>{
 const {doc,ids}=fixture();
 let aligned=alignFreeGroup(doc,ids.slice(0,2),'left',reg,scope);
 assert.equal(get(aligned,ids[0]).position.x,get(aligned,ids[1]).position.x);
 aligned=alignFreeGroup(doc,ids.slice(0,2),'top',reg,scope);
 assert.equal(get(aligned,ids[0]).position.y,get(aligned,ids[1]).position.y);
 aligned=alignFreeGroup(doc,ids.slice(0,2),'right',reg,scope);
 assert.equal(get(aligned,ids[0]).position.x+80,get(aligned,ids[1]).position.x+80);
 aligned=alignFreeGroup(doc,ids.slice(0,2),'bottom',reg,scope);
 assert.equal(get(aligned,ids[0]).position.y+32,get(aligned,ids[1]).position.y+32);
 assert.throws(()=>alignFreeGroup(doc,ids,'centre',reg,scope),/정렬/);
});

test('v0.23 fluid Free Frame and right/bottom anchors roundtrip across v6 DSL and Native TSX',()=>{
 const {doc,frameId,ids}=fixture(1);
 const next=structuredClone(doc);const frame=get(next,frameId),child=get(next,ids[0]);
 frame.layout.fluid=true;child.anchors={horizontal:'right',vertical:'bottom'};
 assert.equal(validateDocument(next,reg),next);
 assert.deepEqual(freeFrameSizeStyle(frame),{width:'100%',height:360,maxWidth:640,minWidth:0});
 assert.deepEqual(freeChildStyle(child,frame),{position:'absolute',right:536,bottom:296});
 const dsl=printV6Dsl(next.definitions.SnapDemo.root).text;
 assert.match(dsl,/fluid=\{true\}/);
 assert.match(dsl,/anchors=\{\{"horizontal":"right","vertical":"bottom"\}\}/);
 const updated=dsl.replace('"x":24','"x":64');
 const parsed=parseV6Dsl(updated,next,reg,'main','SnapDemo').document;
 assert.equal(get(parsed,ids[0]).position.x,64);
 assert.equal(get(parsed,ids[0]).anchors.horizontal,'right');
 const generated=createNativeShadcnFiles(parsed,reg,'SnapDemo')['src/components/SnapDemo.tsx'];
 assert.match(generated,/"maxWidth":640/);
 assert.match(generated,/"right":496/);
 assert.match(generated,/"bottom":296/);
 assert.doesNotMatch(generated,/RuntimeSession|createAntdRenderer/);
});

test('v0.23 schema enforces Free-only anchors, dimensions, and fluid boolean',()=>{
 const {doc,frameId,ids}=fixture(1);
 const altered=structuredClone(doc);get(altered,ids[0]).anchors={horizontal:'right'};
 assert.equal(validateDocument(altered,reg),altered);
 delete get(altered,ids[0]).size.width;
 assert.throws(()=>validateDocument(altered,reg),/너비가 필요/);
 get(altered,ids[0]).size.width=80;
 get(altered,frameId).layout.fluid='true';
 assert.throws(()=>validateDocument(altered,reg),/반응형 Frame 설정 오류/);
 get(altered,frameId).layout.fluid=true;
 get(altered,ids[0]).anchors.horizontal='stretch';
 assert.throws(()=>validateDocument(altered,reg),/반응형 기준점 오류/);
 get(altered,ids[0]).anchors.horizontal='right';
 const root=altered.definitions.SnapDemo.root;
 root.children.push(root.children[0].children.pop());
 delete root.children.at(-1).position;
 assert.throws(()=>validateDocument(altered,reg),/자동 배치 Frame에서 반응형 기준점/);
});

test('v0.23 changing out of Free layout or moving to another Free Frame removes invalid anchors',()=>{
 const {doc,frameId,ids}=fixture(1);
 const changed=structuredClone(doc);get(changed,ids[0]).anchors={horizontal:'right'};
 const converted=changeFrameLayout(get(changed,frameId),'row');
 assert.equal(converted.children[0].anchors,undefined);
 assert.equal(converted.children[0].position,undefined);
 const second=createEditorNode(changed,'layout/free',reg);
 const added=insertEditorNode(changed,changed.definitions.SnapDemo.root.id,1,second,reg,scope);
 const moved=moveEditorNode(added,ids[0],second.id,0,reg,scope);
 assert.equal(get(moved,ids[0]).anchors,undefined);
});

test('v0.23 Studio exposes group free drag, alignment guide, responsive anchors and anchor Inspector',async()=>{
 const {readFileSync}=await import('node:fs');
 const source=readFileSync(new URL('../src/framework/UnifiedStudio.jsx',import.meta.url),'utf8');
 for(const marker of ['data-testid="free-alignment-guide"','data-testid="free-align-controls"','data-testid="free-fluid-frame"','data-testid="free-anchor-inspector"','moveFreeGroup(doc,selectedIds'])
   assert.ok(source.includes(marker),marker);
});
