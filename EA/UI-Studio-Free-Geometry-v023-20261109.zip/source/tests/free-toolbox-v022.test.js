import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createDefaultRegistry,FRAME_TYPES,createEditorNode,insertEditorNode,moveEditorNode,placeEditorNode,snapFreePosition,changeFrameLayout,locateNode} from '../packages/core/index.js';
import {createBlankComponentWorkspace} from '../packages/core/workspace.js';
import {validateDocument,literal} from '../packages/schema/index.js';
import {printV6Dsl,parseV6Dsl} from '../packages/format-dsl/index.js';
import {frameStyle,freeChildStyle} from '../packages/core/layout.js';
import {createNativeShadcnFiles} from '../packages/exporter-react/native-shadcn.js';

const reg=createDefaultRegistry();
const initial=()=>createBlankComponentWorkspace('FreeExample',reg);
const scope='definition:FreeExample';
const rootId=d=>d.definitions.FreeExample.root.id;
const root=d=>d.definitions.FreeExample.root;
function withFree(){
 let d=initial();const free=createEditorNode(d,'layout/free',reg);
 d=insertEditorNode(d,rootId(d),0,free,reg,scope);
 return {d,freeId:free.id};
}

test('free layout and expanded toolbox controls are registered, without changing legacy controls',()=>{
 assert.ok(FRAME_TYPES.includes('free'));
 for(const id of ['Text','Button','Input','Select','Checkbox','Table','Card','Divider','Tag','Heading','Label','Textarea','Switch','Progress'])
   assert.ok(reg.get('core/'+id),id);
 assert.equal(reg.list().length,14);
 const free=createEditorNode(initial(),'layout/free',reg);
 assert.deepEqual(free.layout,{type:'free',gap:0,padding:0});
 assert.deepEqual(free.size,{width:640,height:360});
 assert.equal(frameStyle(free.layout).position,'relative');
});

test('free insertion is validated, snapped placement persists on native IR',()=>{
 let {d,freeId}=withFree();
 const button=createEditorNode(d,'core/Button',reg);
 d=placeEditorNode(d,{kind:'new',node:button,parentId:freeId,index:0,position:{x:117,y:67}},reg,scope);
 assert.deepEqual(locateNode(root(d),button.id).node.position,{x:120,y:64});
 assert.deepEqual(freeChildStyle(locateNode(root(d),button.id).node),{position:'absolute',left:120,top:64});
 assert.equal(validateDocument(d,reg),d);
});

test('free position is valid only beneath a free parent, and is bounded',()=>{
 const d=initial(),button=createEditorNode(d,'core/Button',reg);
 const invalid=structuredClone(d);root(invalid).children=[{...button,position:{x:40,y:30}}];
 assert.throws(()=>validateDocument(invalid,reg),/자유 배치 Frame 외부/);
 const {d:negative,freeId}=withFree();
 const bad=createEditorNode(negative,'core/Button',reg);bad.position={x:-2,y:0};
 root(negative).children[0].children.push(bad);
 assert.throws(()=>validateDocument(negative,reg),/위치 오류/);
 assert.throws(()=>snapFreePosition({x:NaN,y:4}),/유한한/);
});

test('visual position survives DSL text editing and roundtrip on the same canonical document',()=>{
 let {d,freeId}=withFree();
 const heading=createEditorNode(d,'core/Heading',reg);
 d=placeEditorNode(d,{kind:'new',node:heading,parentId:freeId,index:0,position:{x:104,y:56}},reg,scope);
 const dsl=printV6Dsl(root(d)).text;
 assert.match(dsl,/<Free /);
 assert.match(dsl,/position=\{\{"x":104,"y":56\}\}/);
 const updated=dsl.replace('"x":104','"x":224');
 const parsed=parseV6Dsl(updated,d,reg,'main','FreeExample').document;
 assert.equal(locateNode(root(parsed),heading.id).node.position.x,224);
 assert.equal(printV6Dsl(root(parsed)).text,updated);
});

test('moving within a free frame only changes coordinates and preserves ID',()=>{
 let {d,freeId}=withFree();
 const input=createEditorNode(d,'core/Input',reg);
 d=placeEditorNode(d,{kind:'new',node:input,parentId:freeId,index:0,position:{x:16,y:24}},reg,scope);
 d=placeEditorNode(d,{kind:'move',id:input.id,parentId:freeId,index:1,position:{x:205,y:91}},reg,scope);
 assert.deepEqual(locateNode(root(d),input.id).node.position,{x:208,y:88});
 assert.equal(root(d).children[0].children.length,1);
});

test('moving from Free to Auto clears position without mutating source',()=>{
 let {d,freeId}=withFree();
 const label=createEditorNode(d,'core/Label',reg);
 d=placeEditorNode(d,{kind:'new',node:label,parentId:freeId,index:0,position:{x:8,y:8}},reg,scope);
 const original=structuredClone(d);
 d=placeEditorNode(d,{kind:'move',id:label.id,parentId:rootId(d),index:1},reg,scope);
 assert.equal(locateNode(root(d),label.id).node.position,undefined);
 assert.deepEqual(locateNode(root(original),label.id).node.position,{x:8,y:8});
});

test('switching frame layout assigns or clears child positions without discarding children',()=>{
 const rootFrame=root(initial());
 const button={id:'b',kind:'component',typeId:'core/Button',props:{text:literal('run')}};
 const old={...rootFrame,children:[button]};
 const free=changeFrameLayout(old,'free');
 assert.equal(free.children[0].id,'b');assert.deepEqual(free.children[0].position,{x:24,y:24});
 const normal=changeFrameLayout(free,'row');
 assert.equal(normal.children[0].position,undefined);
 assert.deepEqual(old.children[0],button);
});

test('native shadcn generates absolute wrappers at exact positions with supported added controls',()=>{
 let {d,freeId}=withFree();
 for(const [i,type] of ['Heading','Textarea','Switch','Progress','Label'].entries()){
   const item=createEditorNode(d,`core/${type}`,reg);
   d=placeEditorNode(d,{kind:'new',node:item,parentId:freeId,index:i,position:{x:24+i*32,y:24+i*48}},reg,scope);
 }
 const files=createNativeShadcnFiles(d,reg,'FreeExample');
 const code=files['src/components/FreeExample.tsx'];
 assert.match(code,/relative block/);
 assert.match(code,/data-free-child-id/);
 assert.match(code,/"left":56,"top":72/);
 for(const name of ['Textarea','Switch','Progress','Label'])assert.match(code,new RegExp('<'+name+'(?: |>)'),name);
 assert.match(code,/<h2 /);
 assert.doesNotMatch(code,/RuntimeSession|createAntdRenderer/);
 assert.match(files['README.md'],/textarea/);
});

test('unsupported controls still fail closed during export',()=>{
 let {d,freeId}=withFree();const select=createEditorNode(d,'core/Select',reg);
 d=insertEditorNode(d,freeId,0,select,reg,scope);
 assert.throws(()=>createNativeShadcnFiles(d,reg,'FreeExample'),/core\/Select/);
});

test('Studio exposes searchable persistent Toolbox and accessible DSL mode',()=>{
 const source=readFileSync(new URL('../src/framework/UnifiedStudio.jsx',import.meta.url),'utf8');
 assert.match(source,/data-testid="component-toolbox"/);
 assert.match(source,/aria-label="Toolbox 검색"/);
 assert.match(source,/분할 · DSL/);
 assert.match(source,/data-testid="free-position-inspector"/);
});
