import test from 'node:test';
import assert from 'node:assert/strict';
import {createDefaultRegistry,createEditorNode,insertEditorNode,editorMoveOptions,moveEditorRelative} from '../packages/core/index.js';
import {editorShortcut} from '../packages/core/shortcuts.js';
import {createSearchBoxDocument,serializeDocument,parseDocument,findNode} from '../packages/schema/index.js';
import {frameStyle} from '../packages/core/layout.js';
const registry=createDefaultRegistry();
const initial=()=>createSearchBoxDocument();
const children=(doc,scope='main')=>scope==='main'?doc.pages.main.root.children:doc.definitions[scope].root.children;
const names=doc=>children(doc).map(n=>n.id);

test('v0.16 move up/down preserves IDs, source and canonical roundtrip',()=>{
 const original=initial();const first=names(original);
 assert.deepEqual(editorMoveOptions(original.pages.main.root,first[0]),{up:false,down:true,indent:false,outdent:false});
 let doc=moveEditorRelative(original,first[0],'down',registry);
 assert.deepEqual(names(doc),[first[1],first[0],first[2]]);
 doc=moveEditorRelative(doc,first[0],'up',registry);
 assert.deepEqual(names(doc),first);
 assert.deepEqual(names(original),first);
 assert.deepEqual(parseDocument(serializeDocument(doc,registry),registry),doc);
});
test('v0.16 move guards boundaries, unknown directions, missing nodes and root',()=>{
 const doc=initial(),first=names(doc);
 assert.throws(()=>moveEditorRelative(doc,first[0],'up',registry),/이 방향/);
 assert.throws(()=>moveEditorRelative(doc,first.at(-1),'down',registry),/이 방향/);
 assert.throws(()=>moveEditorRelative(doc,'pageRoot','up',registry),/이 방향/);
 assert.throws(()=>moveEditorRelative(doc,'missing','up',registry),/이 방향/);
 assert.throws(()=>moveEditorRelative(doc,first[0],'sideways',registry),/알 수 없는/);
 assert.deepEqual(editorMoveOptions(doc.pages.main.root,'missing'),{up:false,down:false,indent:false,outdent:false});
});
test('v0.16 indent only into previous Frame and outdent exactly after parent',()=>{
 let doc=initial(),frame=createEditorNode(doc,'layout/row',registry);
 doc=insertEditorNode(doc,'pageRoot',0,frame,registry);
 const child='demoTitle';
 assert.equal(editorMoveOptions(doc.pages.main.root,child).indent,true);
 doc=moveEditorRelative(doc,child,'indent',registry);
 assert.equal(children(doc)[0].id,frame.id);
 assert.equal(children(doc)[0].children[0].id,child);
 assert.equal(editorMoveOptions(doc.pages.main.root,child).outdent,true);
 doc=moveEditorRelative(doc,child,'outdent',registry);
 assert.deepEqual(children(doc).slice(0,2).map(x=>x.id),[frame.id,child]);
 assert.equal(editorMoveOptions(doc.pages.main.root,'customerSearch').indent,false);
 assert.throws(()=>moveEditorRelative(doc,'customerSearch','indent',registry),/이 방향/);
});
test('v0.16 nested Frame outdent never escapes the editable root',()=>{
 let doc=initial(),outer=createEditorNode(doc,'layout/column',registry);
 doc=insertEditorNode(doc,'pageRoot',3,outer,registry);
 const inner=createEditorNode(doc,'layout/row',registry);
 doc=insertEditorNode(doc,outer.id,0,inner,registry);
 const child=createEditorNode(doc,'core/Button',registry);
 doc=insertEditorNode(doc,inner.id,0,child,registry);
 assert.equal(editorMoveOptions(doc.pages.main.root,child.id).outdent,true);
 doc=moveEditorRelative(doc,child.id,'outdent',registry);
 assert.equal(findNode(doc.pages.main.root,outer.id).children[1].id,child.id);
 assert.equal(editorMoveOptions(doc.pages.main.root,child.id).outdent,true);
 doc=moveEditorRelative(doc,child.id,'outdent',registry);
 assert.equal(children(doc).at(-1).id,child.id);
 assert.equal(editorMoveOptions(doc.pages.main.root,child.id).outdent,false);
});
test('v0.16 moving in a Definition increments revision but does not touch page',()=>{
 const original=initial(),root=original.definitions.SearchBox.root;
 const first=root.children.map(n=>n.id);
 let doc=moveEditorRelative(original,first[0],'down',registry,'definition:SearchBox');
 assert.deepEqual(doc.definitions.SearchBox.root.children.map(n=>n.id),[first[1],first[0]]);
 assert.equal(doc.definitions.SearchBox.revision,(original.definitions.SearchBox.revision||0)+1);
 assert.deepEqual(doc.pages,original.pages);
});
test('v0.16 frame gap and alignment compile to runtime CSS without changing schema',()=>{
 const doc=initial();const root=doc.pages.main.root;
 root.layout={...root.layout,gap:16,align:'center',padding:8};
 assert.deepEqual(parseDocument(serializeDocument(doc,registry),registry),doc);
 const style=frameStyle(root.layout);
 assert.equal(style.gap,16);assert.equal(style.alignItems,'center');assert.equal(style.padding,8);
});
test('v0.16 keyboard reordering respects inputs, modal and design preview mode',()=>{
 const ev=(key,extra={})=>({key,...extra});
 assert.equal(editorShortcut(ev('ArrowUp',{altKey:true})),'move-up');
 assert.equal(editorShortcut(ev('ArrowDown',{altKey:true})),'move-down');
 assert.equal(editorShortcut(ev('ArrowDown',{altKey:true}),{design:false}),null);
 assert.equal(editorShortcut(ev('ArrowUp',{altKey:true}),{editable:true}),null);
 assert.equal(editorShortcut(ev('ArrowUp',{altKey:true}),{modalOpen:true}),null);
 assert.equal(editorShortcut(ev('ArrowUp',{altKey:true,ctrlKey:true})),null);
 assert.equal(editorShortcut(ev('ArrowUp',{altKey:true,repeat:true})),null);
 assert.equal(editorShortcut(ev('ArrowRight',{altKey:true})),null);
 assert.equal(editorShortcut(ev('d',{ctrlKey:true})),'duplicate');
 assert.equal(editorShortcut(ev('z',{ctrlKey:true})),'undo');
});
