import test from 'node:test';
import assert from 'node:assert/strict';
import { createNode,createProject,addChild,changeNode,findLocation,layoutLabel,switchLayout,validateProject } from '../src/model.js';
import { printDsl,parseDsl,applyDsl,nodeAtOffset } from '../src/dsl.js';
import { layoutStyle,generateTsx } from '../src/generator.js';

const modes={Column:['column',false],Row:['row',false],Grid:['grid',false],Wrap:['row',true],Overlay:['overlay',false]};
test('five Insert layouts are Frame nodes with canonical IR shape',()=>{
 for(const [type,[mode,wrap]] of Object.entries(modes)){
   const n=createNode(type);
   assert.equal(n.kind,'frame');assert.equal(n.layout,mode);assert.equal(n.wrap,wrap);
   assert.equal(n.name,type);assert.equal(layoutLabel(n),type);
   assert.deepEqual(n.children,[]);
   const p=createProject();p.root=addChild(p.root,p.root.id,n);
   assert.ok(validateProject(p),type);
 }
});
test('each layout has an independent readable DSL tag, no redundant layout prop',()=>{
 for(const [type] of Object.entries(modes)){
  const n=createNode(type);
  const {text,ranges}=printDsl(n);
  assert.match(text,new RegExp('^<'+type+'\\s'));
  assert.doesNotMatch(text,/\slayout=/);
  assert.deepEqual(parseDsl(text).root,n);
  assert.equal(nodeAtOffset(ranges,text.indexOf('nodeId')),n.id);
 }
});
test('changing Row to Grid retains node identity, existing children, and source selections',()=>{
 const p=createProject();const id='search-row';const old=findLocation(p.root,id).node;
 p.root=switchLayout(p.root,id,'Grid');
 const changed=findLocation(p.root,id).node;
 assert.equal(changed.layout,'grid');assert.equal(changed.id,id);
 assert.deepEqual(changed.children,old.children);
 const {text,ranges}=printDsl(p.root);
 assert.match(text,/<Grid nodeId="search-row"/);
 assert.equal(nodeAtOffset(ranges,text.indexOf('nodeId="search-row"')),id);
 assert.deepEqual(applyDsl(p,'page',text).project.root,p.root);
});
test('changing Wrap to Row clears wrap without changing children',()=>{
 const p=createProject();let root=switchLayout(p.root,'search-row','Wrap');
 assert.equal(findLocation(root,'search-row').node.wrap,true);
 root=switchLayout(root,'search-row','Row');
 assert.equal(findLocation(root,'search-row').node.wrap,false);
 assert.match(printDsl(root).text,/<Row nodeId="search-row"/);
});
test('old Frame DSL remains accepted and prints canonical layout aliases',()=>{
 const n=parseDsl('<Frame nodeId="x" name="Panel" layout="grid" gap={8}><Button nodeId="b" text="확인" /></Frame>').root;
 assert.equal(n.kind,'frame');assert.equal(n.layout,'grid');
 assert.match(printDsl(n).text,/^<Grid /);
});
test('conflicting mode attributes are rejected rather than silently ignored',()=>{
 assert.throws(()=>parseDsl('<Row layout="grid" />'),/충돌/);
 assert.throws(()=>parseDsl('<Wrap wrap={false} />'),/wrap/);
 assert.throws(()=>parseDsl('<Overlay wrap={true} />'),/wrap/);
});
test('Wrap uses flex-wrap, Overlay uses stacked grid cells in preview and TSX',()=>{
 const wrap=createNode('Wrap'),overlay=createNode('Overlay');
 assert.equal(layoutStyle(wrap).display,'flex');
 assert.equal(layoutStyle(wrap).flexWrap,'wrap');
 assert.equal(layoutStyle(overlay).display,'grid');
 const p=createProject();p.root=addChild(p.root,p.root.id,overlay);p.root=addChild(p.root,overlay.id,createNode('Button'));
 assert.match(generateTsx(p),/gridArea: "1 \/ 1"/);
});
