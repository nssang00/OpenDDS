import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import test from 'node:test';
const app=readFileSync(new URL('../src/App.jsx',import.meta.url),'utf8');
const studio=readFileSync(new URL('../src/framework/UnifiedStudio.jsx',import.meta.url),'utf8');
const css=readFileSync(new URL('../src/framework/unified.css',import.meta.url),'utf8');

test('One Studio: only the canonical v6 editor is mounted',()=>{
  assert.match(app,/<UnifiedStudio\s*\/>/);
  assert.doesNotMatch(app,/activeTab|setActiveTab|Legacy Design|Legacy Preview|v5 React TSX/);
  assert.match(studio,/export function UnifiedStudio\(\)/);
});
test('One Studio: the component tree is opt-in, not a persistent sidebar',()=>{
  assert.match(studio,/structureOpen&&<div className="v19-structure-panel"/);
  assert.match(studio,/aria-label="구조 열기"/);
  assert.match(studio,/aria-label="레이어 닫기"/);
  assert.match(studio,/onClick=\{\(\)=>\{setStructureOpen\(true\);setInsertOpen\(true\);\}\}/);
});
test('One Studio: contextual tools and properties do not switch the editor mode',()=>{
  assert.doesNotMatch(studio,/const \[advanced,setAdvanced\]|setAdvanced\(/);
  assert.match(studio,/aria-label="프로젝트 메뉴"/);
  assert.match(studio,/data-testid="extra-properties"/);
  assert.match(studio,/aria-expanded=\{showDetails\}/);
  assert.match(studio,/migrateV5ToV6\(raw\)/);
  assert.match(css,/\.v20-project-menu/);
});
