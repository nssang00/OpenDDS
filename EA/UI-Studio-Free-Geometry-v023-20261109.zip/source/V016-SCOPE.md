# v0.16 Canvas hierarchy and layout scope

The v0.16 deliverable adds deterministic element reordering and hierarchy movement (up, down, indent into preceding Frame, outdent from Frame) and a fast Inspector workflow for Frame gap and alignment. It uses the existing canonical v6 IR, undo history, and exporter; no new document schema version or dynamic JS execution path was introduced.

**Explicitly outside scope:** multi-select move, auto-alignment between unrelated components, timeline-based editing, graphical drag accuracy across arbitrary nested grids. These are potential later increments and not claimed as completed.
