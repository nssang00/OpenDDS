# Native shadcn/ui TSX Export · Composition PoC (2026-11-08)

**Status: experimental change, not the verified baseline.** This is a source-code exporter from canonical JSON v6, not a shadcn-compatible visual renderer. AntD Runtime export is unchanged, remains available, and is the safer existing path until a real consumer acceptance test passes.

## Product contract

UI Studio aims to produce human-editable native React TSX without shipping UI Studio Runtime or Ant Design. UI editing continues in One Studio against canonical JSON v6. The target host is an **existing React + shadcn/ui (Base UI variant) + Tailwind** project; the output is not a standalone npm package. Export is one-way: changes to TSX are not imported back into Studio.

## What this iteration changes

- `packages/exporter-react/native-shadcn.js` now emits each transitive Definition dependency as a **separate TSX file**, including Definitions referenced in Slot fills. It retains one copy per Definition rather than flattening instances.
- Nested Instances forward public properties, two-way changes, and re-exposed public events to child components. Undeclared, global, or unsupported bindings fail rather than being silently dropped.
- Slots expose ReactNode props (`content` → `children`; other names unchanged). Missing Slot fill falls back to the Definition's original children; explicitly empty fill suppresses fallback.
- Generated public TwoWay values are **controlled if provided**, or backed by component-local `useState` if omitted. Change callbacks still fire when registered.
- Existing simple Controls are preserved: Button, Input, Text, Checkbox, Card, Divider, Tag. Existing frame layouts are preserved structurally: row, column, wrap, grid, overlay.
- Studio menu and CLI continue to use the same `createNativeShadcnFiles` API. The CLI can export the included `examples/native-shadcn/SearchCard-v6.json` as a multi-file example.
- New `npm run verify:native-tsx` compiles the generated simple and composed sources with `tsc --strict` using **temporary compile-only React/shadcn stubs**. This checks syntactic/type consistency only; it is NOT a real consumer or API proof.

## Reproduce locally

```bash
npm test
npm run verify:runtime
node tools/verify-syntax.mjs
npm run verify:native-tsx
npm run export:shadcn
npm run export:shadcn -- examples/native-shadcn/SearchCard-v6.json SearchCard exports/SearchCard-shadcn-native.zip
```

The generated ZIP contains `src/components/*.tsx` and `README.md`. Install all TSX files into an **already initialized** Vite React shadcn/Base UI project. The ZIP README enumerates necessary UI modules for `npx shadcn@latest add …`. A production consumer also needs a valid `@/` alias and Tailwind styles.

## Supported vs deliberately rejected

| Area | Native Export behavior |
|---|---|
| Public Props | Literal/resource/binding to a one-step public Prop; nested public mapping |
| TwoWay | Input `value` / Checkbox `checked`; mapped nested TwoWay Prop with callbacks |
| Events | Button `click` public emit; nested re-exposed public events |
| Slots | ReactNode named slots with fallback and explicit empty fill |
| Composition | Transitive child components emitted as separate files |
| Control/Frame model | Seven core controls, five layouts; no full CSS/style editor |
| Rejected | Nested Instance overrides, external DataContext, `when`/`repeat`, `Select`/`Table`, `set` actions, blur TwoWay updates, global `state`/`sources`/`local`/`context` bindings, dynamic control-model expansion |
| Unverified | Actual shadcn/Base UI component API & package versions, Chrome behavior, accessibility, visual equivalence, Vite consumer build |

Some otherwise-valid v6 Definitions intentionally fail Native Export rather than creating a misleading, incomplete component. In particular a fixed literal passed into a nested TwoWay Prop is rejected: use a parent public TwoWay Prop instead, or leave the child value unassigned so its own local state manages it. Events must be exposed explicitly.

## Local evidence for this iteration

- `npm test` — **220/220 PASS** (previous PoC 216).
- `npm run verify:runtime` — **PASS**, this covers the existing React Runtime with mock renderer, not Native export rendering.
- `node tools/verify-syntax.mjs` — **PASS**, 58 source files + 6 generated TSX.
- `npm run verify:native-tsx` — **PASS with compile-only stubs** for `SearchBox` and `SearchCard`/`SlotPanel`/`SearchBox` composition.
- `npm ping` — **FAIL EAI_AGAIN** resolving `registry.npmjs.org`. Consequently `npm install`, actual Vite build, shadcn CLI initialization, browser/Playwright, and independent consumer acceptance were **not run**.
- CI/Git commit hash — not available; no official baseline promotion.

## Next actions

1. In a network-enabled environment, initialize an independent **Vite + shadcn/ui Base UI** consumer per <https://ui.shadcn.com/docs/installation/vite>, install generated UI modules, build with actual types and test `SearchBox` / `SearchCard` input, change callback, click event, slot fill, keyboard/ARIA with Playwright.
2. Run v0.20 Studio Vite build, six v0.20 Chrome scenarios, earlier v0.19 regression scenarios, and independent AntD consumer regression. Keep native experimental until these pass.
3. Create a real shadcn Canvas renderer and compare DOM structure, behavior and style with native TSX for a bounded set of Controls; specify a reusable component schema for compound controls.
4. Only after consumer + editor parity are verified, consider Native as the primary Export; continue retaining explicit legacy AntD Export.

## Official API reference

- Base UI default: <https://ui.shadcn.com/docs/changelog/2026-07-base-ui-default>
- Vite installation: <https://ui.shadcn.com/docs/installation/vite>
- Base UI Checkbox `checked`/`onCheckedChange`: <https://ui.shadcn.com/docs/components/base/checkbox>
