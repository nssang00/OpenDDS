# v0.18 Scope — Precision Canvas Drag & Drop

Target user flow: Drag palette/tree/canvas item → inspect insertion cue → drop only at valid sibling/frame location → undo or save canonical v6 JSON.

**Included**: original-array indexes, tree and canvas guides, drop no-op rejection, ancestor/descendant validation, group constraints, scroll-edge assistance, Escape cancel, regression tests.

**Not included**: freeform coordinates, touch-centric gestures, cross-document node moves, alignment snapping, automatic multi-container drag scrolling, changes to the public JSON schema.
