import { ItemList } from 'ui-studio-item-list';

export default function Demo(){
  return <ItemList
    showTitle={true}
    items={[
      {id:'one',label:'첫 번째 부품',visible:true},
      {id:'hidden',label:'이 항목은 보이지 않음',visible:false},
      {id:'two',label:'두 번째 부품',visible:true}
    ]}
  />;
}
