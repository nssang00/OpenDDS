/** Small canonical Free Frame showcase; never mutates input or uses browser APIs. */
import {createBlankComponentWorkspace} from '../packages/core/workspace.js';
import {createEditorNode,insertEditorNode,placeEditorNode} from '../packages/core/editor.js';
import {literal,validateDocument} from '../packages/schema/index.js';
export function createFreePanelExample(registry){
  let doc=createBlankComponentWorkspace('FreePanel',registry);
  const scope='definition:FreePanel',rootId=doc.definitions.FreePanel.root.id;
  const frame=createEditorNode(doc,'layout/free',registry);
  frame.name='Free canvas';
  doc=insertEditorNode(doc,rootId,0,frame,registry,scope);
  for(const [type,x,y,props,width] of [
    ['Heading',24,24,{text:'고객 정보',level:'h2'},undefined],
    ['Label',24,96,{text:'고객 이름'},undefined],
    ['Input',24,124,{placeholder:'이름 입력'},280],
    ['Textarea',24,178,{placeholder:'고객 메모'},280],
    ['Switch',350,120,{text:'활성화'},undefined],
    ['Progress',350,180,{label:'진행 상태',value:60},200],
    ['Button',466,292,{text:'저장',variant:'primary'},110]
  ]){
    const control=createEditorNode(doc,`core/${type}`,registry);
    control.props=Object.fromEntries(Object.entries(props).map(([key,val])=>[key,literal(val)]));
    if(width)control.size={width};
    doc=placeEditorNode(doc,{kind:'new',node:control,parentId:frame.id,index:99,position:{x,y}},registry,scope);
  }
  return validateDocument(doc,registry);
}
