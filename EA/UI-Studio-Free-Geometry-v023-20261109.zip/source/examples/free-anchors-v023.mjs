/** Reproducible Free Frame anchors fixture: one fixed-size control anchored near right/bottom. */
import {createDefaultRegistry} from '../packages/core/registry.js';
import {createEditorNode,insertEditorNode,placeEditorNode,locateNode} from '../packages/core/editor.js';
import {createBlankComponentWorkspace} from '../packages/core/workspace.js';
import {literal,validateDocument} from '../packages/schema/index.js';
export function createFreeAnchorsExample(registry=createDefaultRegistry()){
 let doc=createBlankComponentWorkspace('AnchoredPanel',registry);
 const scope='definition:AnchoredPanel',rootId=doc.definitions.AnchoredPanel.root.id;
 const free=createEditorNode(doc,'layout/free',registry);
 free.layout.fluid=true;
 doc=insertEditorNode(doc,rootId,0,free,registry,scope);
 const title=createEditorNode(doc,'core/Heading',registry);
 title.props={text:literal('Responsive anchor preview')};title.size={width:330,height:48};
 doc=placeEditorNode(doc,{kind:'new',node:title,parentId:free.id,index:0,position:{x:24,y:24}},registry,scope);
 const button=createEditorNode(doc,'core/Button',registry);
 button.props={text:literal('Save')};button.size={width:100,height:44};
 button.anchors={horizontal:'right',vertical:'bottom'};
 doc=placeEditorNode(doc,{kind:'new',node:button,parentId:free.id,index:1,position:{x:520,y:280}},registry,scope);
 const hint=createEditorNode(doc,'core/Label',registry);
 hint.props={text:literal('Resize the preview and inspect the corner anchor.')};hint.size={width:280,height:32};
 doc=placeEditorNode(doc,{kind:'new',node:hint,parentId:free.id,index:2,position:{x:24,y:120}},registry,scope);
 return validateDocument(doc,registry);
}
