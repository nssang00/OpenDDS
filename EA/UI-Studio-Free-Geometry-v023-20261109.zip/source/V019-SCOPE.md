# UI Studio v0.19 — Simple First UX

## Product goal

Keep all v0.18 component authoring features; expose only essential controls by default. Expert users switch to the unchanged advanced editing workflow at any time.

## Basic surface

- Five primary header actions: Undo, Redo, Preview/Edit, Export, Advanced tools.
- Left quick-add rail: Text, Button, Input, Layout, on-demand Structure tree and Other elements.
- Center Canvas/Preview; breadcrumb selection; compact editing menu.
- Responsive Inspector remains accessible below the canvas on narrow screens.
- Right contextual Inspector: Name, up to three relevant component properties, Frame direction and gap; opt-in data/actions panel.
- A named Advanced mode (button or `?mode=advanced`) for complete pre-existing v0.18 tools: DSL, raw JSON, Data, component library, property/event/binding editors, selection/move/resize, and import/export operations.

## Non-goals

No canonical v6 schema or Runtime/React Export changes. No new data expression language, coordinate-based canvas, or breaking migration.

## Acceptance

1. Default first view has exactly five header action buttons, quick insert actions, no open Component Tree, and contextual inspector.
2. Add Text and edit its content on canvas; undo and preview observe the same canonical source of truth.
3. Open and close Structure on demand and expand Data/Actions only when requested.
4. Advanced mode exposes v0.18 functionality with all prior Studio E2E and isolated Consumer E2E passing.
