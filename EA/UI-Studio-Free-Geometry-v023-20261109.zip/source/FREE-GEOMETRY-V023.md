# UI Studio v0.23 — Free Geometry, Snap Guides, Anchors (PoC)

2026-11-09 · Derived from `UI-Studio-Free-Toolbox-v022-20261109.zip`. **Not a production / CI-approved baseline.**

## What was added

1. **Multiple Free-Frame children move as a unit.** Ctrl/Cmd-click or Shift-range-select sibling nodes, then drag one selection. All selected children keep their relative offsets, order, IDs, and anchors. A single atomic undo history entry is made. Group relocation across different Free Frames remains unsupported and is rejected with feedback.
2. **Sibling alignment guides.** Drag proximity (6px) to other immediate Free-Frame children's left/right/centre and top/bottom/middle edges can override the 8px grid. A thin magenta guide marks the matched axis. Excludes every member of a moving group. Empty areas use the existing 8px grid. A one-step `snapStep=1` is used only on matched alignments to avoid losing exact edge matching when persisted.
3. **Quick align actions.** When two or more siblings of a Free Frame are selected, a visible quick row offers left/top alignment. The existing `···` menu also offers right/bottom alignment. All coordinates remain in canonical JSON v6 and roundtrip through the DSL.
4. **Opt-in fluid Free Frame width.** Frame inspector exposes a checkbox to use `width:100%; max-width:<authored width>`. Authored reference width/height stay in JSON. Default Free Frames remain 640×360 fixed-size for backwards compatibility.
5. **Optional right/bottom anchors** on a Free Frame's immediate children. They retain right/bottom spacing when the Free Frame shrinks. X/Y in canonical JSON remain **authored top-left coordinates at the frame's reference size**. Anchoring requires a fixed child width/height on the corresponding axis; Studio measures the child when an anchor is enabled. Example at 640px reference: x=520, width=100 → right=20px; when the frame shrinks to 360px the child moves to x=240.
6. **Preview width chooser** for fit, 640px, 480px and 360px. This changes the preview container only and does not convert desktop absolute layouts to responsive web layouts. Preview is still AntD, not actual shadcn/Base UI.
7. **Native TSX output** emits `width: '100%'`, `maxWidth`, and right/bottom absolute styles; JSON v6, DSL, Studio Canvas, Runtime Preview and Native TSX use the same authored anchors.

## Main files

- `packages/core/free-placement.js` — pure group movement, four-edge align, sibling snap
- `packages/core/editor.js` — atomic Free moves, anchor cleanup on re-parenting, alignment precision
- `packages/core/layout.js` — anchor mapping and fluid-width Frame mapping
- `packages/schema/index.js` and `packages/schema/types.d.ts` — additive optional `layout.fluid` and `node.anchors`
- `packages/format-dsl/index.js` — visual↔text roundtrip of `fluid` and `anchors`
- `packages/runtime-react/Runtime.jsx` — responsive anchoring in preview / existing portable Runtime
- `packages/exporter-react/native-shadcn.js` — native React/TSX conversion
- `src/framework/UnifiedStudio.jsx`, `src/framework/unified.css` — selection bar, drag guides, inspectors, preview widths
- `tests/free-geometry-v023.test.js` — 8 core tests
- `e2e/free-geometry-v023.spec.js` — 2 browser scenarios, authored but not run
- `examples/free-anchors-v023.json`, `examples/free-anchors-v023.mjs`, `exports/AnchoredPanel-shadcn-native-v023.zip` — reproducible fixture and exported code

## Known limitations

- Right/bottom anchoring is for preserving an **edge offset** of individually fixed-size children. It does not adapt or rearrange text/cards to mobile. Unanchored absolute children can overlap or clip on narrow displays; the preview warns about this.
- Free group position is kept only within the same parent, not across frames. Layer z-index editing, smart spacing/equal-distribution, rotation, marquee selection, auto-layout conversion and native-TSX-to-Visual reverse import are not implemented.
- Guides use current browser-measured child rectangles. They are not yet verified in a built Vite/AntD Studio.
- Canvas/Runtime still uses AntD; generated Native TSX uses shadcn/ui Base UI components. Pixel/accessibility equivalence has not been verified.
- Actual shadcn consumer TypeScript/build, Chrome Playwright E2E, screen reader and responsive accessibility testing remain outstanding.

## Verification (this environment)

- Node Core: 244/244 pass, including eight new geometry tests
- Runtime mock (React JSX transpilation): pass
- Syntax check: pass
- Generated TSX strict type-check: pass **using offline shims, not real shadcn/Base UI types**
- Vite: unavailable (npm registry DNS EAI_AGAIN, no installed Vite dependencies)
- Chromium: local standalone smoke run timed out; **not a passing browser test**
- Playwright: scenarios checked in, **not run**

## Reproduce in a connected environment

```bash
cd source
npm install
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run verify:native-tsx
npm run build
npm run test:e2e
```

Open the new component dialogue → create a blank component, add Free Frame from Toolbox, then add children. Select Free Frame to enable `좁은 화면에 맞춰 Frame 폭 줄이기` and adjust reference size. Click children to configure anchor. Use Ctrl/Cmd-click to select two sibling elements and move/align them. Use `분할 · DSL` to inspect position/anchor data, then switch to Preview and choose `모바일 360px`.

**Release rule:** Don't promote v0.23 to default/official baseline or turn Native shadcn Export on by default before real consumer build and browser regression testing.
