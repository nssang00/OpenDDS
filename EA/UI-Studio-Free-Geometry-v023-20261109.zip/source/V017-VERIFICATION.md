# UI Studio v0.17 — Verified Baseline (2026-10-25)

## Verdict

**PASS** for the explicitly defined v0.17 scope: sibling multi-selection, atomic group reorder/drag/delete, shared-parent Frame alignment and gap, canonical JSON v6 and undo, and no regressions in React export and independent consumer.

### Independent GitHub Actions evidence

- Repository: `nssang00/chatgpt-write-test`
- Branch: `ci/ui-studio-v017-multiselect-20261025` (`main` was not modified)
- Verified commit: `c530af161dd68e795979d62d27fcf76cddf70cb6`
- Full CI run: https://github.com/nssang00/chatgpt-write-test/actions/runs/40161208899
- Run ID `40161208899`, attempt 1, conclusion **completed/success**.
- Browser proof artifact: https://github.com/nssang00/chatgpt-write-test/actions/runs/40161208899/artifacts/12586143480
- Artifact expiry: 2026-11-08 04:16:44 UTC (14-day retention)
- GitHub environment: Node 22, Google Chrome 155.0.8059.39.

### Actual verification stages

| Check | Result |
|---|---|
| Deterministic v0.13 → verified v0.14 → v0.15 → v0.16 reconstruction | PASS |
| v0.17 compressed patch + decoded patch SHA-256 | PASS |
| Pinned SHA-256 checks on changed/new source and test files | PASS |
| Core `npm test` | **204 passed / 0 failed** (195 prior + 9 new) |
| JS/TSX source syntax | **55 source files + 3 generated TSX, 0 errors** |
| `npm run verify:runtime` | PASS |
| Vite production build | PASS |
| Portable React component + separately installed consumer builds | PASS |
| Actual Chrome Studio E2E | **17 passed / 0 failed** (15 prior + 2 new) |
| Actual Chrome independent React consumer E2E | **1 passed / 0 failed** |
| Browser evidence artifact upload | PASS |

### New v0.17 scenarios, confirmed in Chrome logs

- Ctrl selects siblings and applies reorder, parent alignment, gap, undo, canonical v6 JSON verification.
- Shift selects sibling ranges, atomic bulk delete and undo.

### Behavior and deliberate constraints

- Ctrl/Cmd+click to toggle siblings; Shift+click selects a sibling range in Component Tree or Design Canvas.
- Selected siblings may be reordered atomically and moved as a group to a Frame, preserving their IDs and relative order.
- Bulk delete is a single undoable document change; current selection is constrained to a single sibling array, including instance slot arrays.
- The group alignment and gap controls modify the selected elements' **shared parent Frame**. This changes layout for every child of the parent Frame, not just selected nodes. The UI labels this distinction explicitly.
- Mixed-parent and ancestor/descendant selections are not supported. Arbitrary freeform geometric alignment / general multi-canvas lasso are not in v0.17 scope.

### Reproduce from the complete source ZIP

```bash
npm install --no-audit --no-fund
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run build
npm run export:v014
mkdir -p tests/component-v014
unzip -q -o examples/CustomerBrowser-react-component-v0.13.zip -d tests/component-v014
(cd tests/component-v014 && npm install --no-audit --no-fund && npm run build && npm pack --pack-destination ../consumer-v013)
(cd tests/consumer-v013 && npm install --no-audit --no-fund && npm run build)
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npm run test:e2e
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npx playwright test --config=e2e/consumer-v013.config.js
```

### Limitations

The above is proof for defined Core, Studio and Consumer cases, not exhaustive testing of all documents/browsers. Local environment has no npm registry/network access: local Core, syntax, Runtime, export and structural checks passed, while full browser proof is from GitHub Actions.
