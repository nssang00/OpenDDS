# UI Studio v0.18 — Verified Baseline

## Decision
**PASS — v0.18 precision drag-and-drop target is verified.** The GitHub Actions job returned `completed / success`.
This baseline is a reproducible, verified development artifact. It was not merged into `main`.

## Scope implemented
- Drop locations use the original (pre-removal) target child array to avoid same-parent off-by-one reordering.
- One pure `editorDropCandidate` governs both tree and canvas placement: frame-only destinations, cycle rejection, sibling-group validation, index bounds, and no-op detection.
- Tree insertion lines, canvas guides, and invalid-destination text feedback.
- Pointer dragging supports bounded vertical scroll assistance in the editor panes and Escape cancellation.
- Unchanged canonical v6 IR remains the source of truth. Source node IDs and data bindings remain stable through moves.

## Measured evidence
- **Core 210/210**, **Studio system Chrome 20/20**, **independent React Consumer Chrome 1/1**.
- Source JS syntax: 56 files and 3 generated TSX, errors 0.
- React Runtime integration: PASS; Vite production build: PASS; isolated React component build: PASS.
- Export structure: 25 files, 46 relative imports resolved, ZIP CRC PASS (also repeated locally).
- Six changed files independently reconstructed from v0.17 baseline patch: byte-identical (6/6).
- SHA-256 of the delta text patch: `32aa19c9b3bb6c035ad94b6814f18bc36309d4326df1d4e350d5b46526c875e1`.
- Encoded transport SHA-256: `eb6d752851e657389525e9166a5c3fab09a106437c3e7f9476d1d51fa777a77d`.

## GitHub run
- Repository: `nssang00/chatgpt-write-test`
- Branch: `ci/ui-studio-v018-drag-drop-20261025`
- Commit: `2acc1f8a952cb7b7f7412a3eacd7c42daeaee808`
- Run: https://github.com/nssang00/chatgpt-write-test/actions/runs/40168783803
- Browser artifact (retained until 2026-11-08): https://github.com/nssang00/chatgpt-write-test/actions/runs/40168783803/artifacts/12589101569
- GitHub host: Node.js 22, Google Chrome 155.0.8059.39

## Reproduce
From this extracted project's root with Node.js 22, npm install and an available Chrome:

```bash
npm install --no-audit --no-fund
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run build
npm run export:v014
python tools/check-export-structure.py examples/CustomerBrowser-react-component-v0.13.zip
UI_STUDIO_USE_SYSTEM_CHROME=1 CI=true npm run test:e2e
UI_STUDIO_USE_SYSTEM_CHROME=1 CI=true npx playwright test --config=e2e/consumer-v013.config.js
```

For the exact remotely executed reconstruction, see `.github/workflows/ui-studio-v018-full.yml` in the indicated GitHub commit. The original local verified ZIP is archived with a `SHA256SUMS.txt` inventory.

## Bounds of verification
- Drag behavior is model-index / tree / existing frame-layout placement; arbitrary absolute positioning, snap-to-grid, freeform box select, and touch-only gesture coverage are not claimed.
- The Chrome evidence proves the included E2E scenarios, not universal behavior on all browsers or screen sizes.
- The independent React Consumer test checks backward compatibility of the export path, not a newly implemented drag editor in the consumer runtime.
