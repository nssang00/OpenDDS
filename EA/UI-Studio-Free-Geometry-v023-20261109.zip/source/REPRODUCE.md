# Quick start

Requirements: Node.js 22+, npm registry access, Google Chrome or Playwright Chromium.

```bash
npm install --no-audit --no-fund
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run build
npm run export:v014
npm run test:e2e
```

Run actual browser tests in a GitHub-hosted Ubuntu runner using the bundled `.github/workflows/visual-first-e2e.yml`. The CI workflow uses `UI_STUDIO_USE_SYSTEM_CHROME=1` to avoid downloading Chromium. The same workflow installs/builds the CustomerBrowser ZIP in an isolated React project.

Open the app locally with `npm run dev`. Add a typed data field using **＋ 데이터 만들기**, select an element on the canvas, then choose a condition, repeat source, property value or button action in the Inspector. The implementation edits canonical v6 IR; no JSON scripting is necessary.

Verified local portions and limitations are documented in `VERIFICATION-STATUS.md`.
