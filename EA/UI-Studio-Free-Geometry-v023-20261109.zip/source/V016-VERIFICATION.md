# UI Studio v0.16 — Verified Baseline (2026-10-24)

## Verdict

**PASS** for the agreed v0.16 scoped contract: deterministic Canvas / Component Tree hierarchy editing, Frame alignment and gap presets, canonical v6 persistence, no regressions in React export and independent consumer.

### Independently inspectable GitHub evidence

- Repository: `nssang00/chatgpt-write-test`
- Validation branch: `ci/ui-studio-v016-canvas-20261024` (the `main` branch was not changed)
- Commit: `611d03dc5c82899e38c8b49b5d1ac002af3c0f5e`
- GitHub Actions run: https://github.com/nssang00/chatgpt-write-test/actions/runs/40095158555
- Run ID `40095158555`, attempt 1: **completed / success**
- Browser evidence artifact ID `12561000661`: https://github.com/nssang00/chatgpt-write-test/actions/runs/40095158555/artifacts/12561000661
- Evidence artifact retention expiry reported by GitHub: 2026-11-07 12:45:24 UTC
- Runner: Node.js 22, Google Chrome 155.0.8059.39

### Actual CI stage results

| Stage | Recorded result |
|---|---|
| Source reconstruction (v0.13 → verified v0.14 → verified v0.15 → v0.16) | PASS |
| Pinned SHA-256 of v0.16 patch, package, core, Studio, CSS and new tests | PASS |
| `npm test` | **195 passed**, 0 failed |
| `node tools/verify-syntax.mjs` | 54 source files + 3 generated TSX, **0 errors** |
| `npm run verify:runtime` | PASS (independent instances, TwoWay, events, slots, dynamic) |
| `npm run build` | PASS |
| Packaged React component and independent consumer Vite builds | PASS |
| Real Chrome Studio E2E | **15 passed**, 0 failed |
| Real Chrome independent React consumer E2E | **1 passed**, 0 failed |
| Browser proof upload | PASS |

## What's new in v0.16

- `editorMoveOptions` and `moveEditorRelative` offer validated, immutable sibling reorder/indent/outdent commands that preserve existing node IDs and source document immutability.
- Supports movement within page/Definition trees and sibling order within instance slot content; root/invalid moves are blocked.
- Selected element hierarchy toolbar exposes up/down/indent/outdent actions with disabled states.
- `Alt+ArrowUp` and `Alt+ArrowDown` reorder noneditable selections. Inputs and modal dialogs retain their own keyboard behavior.
- Frame Inspector provides gap presets (0, 8, 16, 24 pixels) and alignment options (stretch/start/center/end), persisted through the same canonical v6 document.
- Seven new Core tests and two real-browser Studio scenarios verify these operations, undo, serialization and layout persistence.

## Pinned v0.16 source hashes

```text
7decb58bd4792d34095018877d92fd8bdb030cfd291a434535173775605196d0  package.json
c685fcccc03e0778c214f2d70ff167abb6b4c3e7f4d5a89f0118dd995139da7a  packages/core/editor.js
d6582c2643fa40158114165d1ae3e4ace172d677f64676b5053a03b12a729365  packages/core/shortcuts.js
c869cc71c196754e7662f545a6b1fd399683efc9afded30b2907d6a84c8fee74  src/framework/UnifiedStudio.jsx
6c199a48e1a302b067f2b9a10047e13ab8844b26fa6fcca4866b41d9b8ab7c65  src/framework/unified.css
1ffe9c5dc8803cf9387c45e4bbc3d4e50673041c85297d05763d34029ec899ee  tests/canvas-v016.test.js
d52ecb556d4ca8354ec91ac8c43ab6c91cceffaef5cbef02bb1fa70e04919c06  e2e/canvas-v016.spec.js
```

## Reproduce from standalone ZIP

```bash
npm install --no-audit --no-fund
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run build
npm run export:v014
mkdir -p tests/component-v014
unzip -q -o examples/CustomerBrowser-react-component-v0.13.zip -d tests/component-v014
(cd tests/component-v014 && npm install --no-audit --no-fund && npm run build && npm pack --pack-destination ../consumer-v013)
(cd tests/consumer-v013 && npm install --no-audit --no-fund && npm run build)
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npm run test:e2e
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npx playwright test --config=e2e/consumer-v013.config.js
```

Chrome tests require dependencies and Google Chrome. The local sandbox lacks npm registry access; authoritative browser runs were conducted by GitHub Actions and their logs are linked above. Node-only Core, syntax and Runtime checks were also executed locally.

## Scope limitations

- This is proof for the defined 195 Core / 15 Studio / 1 Consumer cases, not every possible graph, OS, browser, security property or visual design workflow.
- v0.16 does **not** implement freeform multi-selection, arbitrary grid auto-layout, or general keyboard repositioning across any container; the controls deliberately implement constrained tree hierarchy moves.
- Any outstanding nonfunctional warnings in third-party libraries are separate from these functional assertions.
