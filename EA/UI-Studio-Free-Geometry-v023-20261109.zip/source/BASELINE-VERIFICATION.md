# UI Studio v0.14 - Baseline Verification (2026-10-24)

## Verdict: VERIFIED for the scoped v0.14 CI contract

- Verification branch: `ci/ui-studio-v014-visual-first-20261023` (not `main`)
- Commit: `1687fc5ba36d97d95f00524adb32f4477125017d`
- GitHub Actions run: https://github.com/nssang00/chatgpt-write-test/actions/runs/40063374176
- Run ID: `40063374176`, attempt 1; **completed / success**
- Workflow: `.github/workflows/ui-studio-v014-full.yml`
- Chrome used by CI: Google Chrome `155.0.8059.39` (Linux runner)

## Verified step results

1. CI source reconstruction from v0.13 plus v0.14 delta and corrections: PASS, including pinned SHA-256 checks.
2. `npm test`: 183 passed, 0 failed, 0 skipped.
3. `node tools/verify-syntax.mjs`: 51 sources and 3 generated TSX, no errors.
4. `npm run verify:runtime`: PASS (isolated instances, TwoWay state, public events, slots, nested controls, repeat).
5. `npm run build`: PASS.
6. `npm run export:v014`: PASS, generated 25 portable package source files.
7. Independently installed exported React component/package and consumer Vite builds: PASS.
8. Studio real Chrome E2E: 11 passed, 0 failed.
9. Independently installed React consumer real Chrome E2E: 1 passed, 0 failed.
10. Browser proof artifact: `ui-studio-v014-real-chrome-evidence`, artifact ID `12547959171`.
    https://github.com/nssang00/chatgpt-write-test/actions/runs/40063374176/artifacts/12547959171
    Artifact expires 2026-11-07 UTC unless retention changes.

## Pinned source SHA-256

- `src/framework/UnifiedStudio.jsx`: `22b33f0d5623fe56e7a2da33ee46a02c858826f50ac2d9169c614264c9f1e7cb`
- `e2e/visual-authoring-v014.spec.js`: `1f937cd46887ab87df39b1760ac0ae8e5484d7aaab8053599dc84830a1408526`

These are the post-patch paths verified by the GitHub Actions workflow. The GitHub branch reconstructs this application from the v0.13 source archive and the v0.14 delta, applying two deterministic Python correction scripts. This ZIP contains the resulting standalone project contents directly, avoiding that assembly step for local use.

## Changes from original handoff

- Corrected the Inspector's undefined `p.defaultValue` reference to the registry entry's default value.
- Made visual condition/repeat/action selects keyboard-searchable.
- Reworked v0.14 real-Chrome tests to select virtual AntD menus with keyboard search and Enter, validate canonical v6 bindings/actions, and verify exact state paths.

## Remaining non-blocking observations

- CI consumer log prints an AntD deprecation warning: indexed Table `rowKey` callback (future cleanup).
- Consumer dev server also logs an HTTP 404 for an unimportant resource; E2E functional assertions still passed.
- The scope proves the defined 11 Studio browser scenarios, 1 independent Consumer scenario, and existing Core regressions. It is not a proof of full product usability, all browsers, security review, or arbitrary customer documents.
- `npm install`/local browser E2E could not be run in this chat's container because the npm registry is not reachable (`EAI_AGAIN`). These checks were run successfully by the GitHub hosted runner. Node-only tests and runtime validations also passed in this local container.

## Reproduction (standalone ZIP)

```bash
npm install --no-audit --no-fund
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run build
npm run export:v014
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npm run test:e2e
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npx playwright test --config=e2e/consumer-v013.config.js
```

The final consumer test requires the standalone package to be unpacked and built first, as performed in the GitHub workflow:

```bash
mkdir -p tests/component-v014
unzip -q -o examples/CustomerBrowser-react-component-v0.13.zip -d tests/component-v014
(cd tests/component-v014 && npm install --no-audit --no-fund && npm run build && npm pack --pack-destination ../consumer-v013)
(cd tests/consumer-v013 && npm install --no-audit --no-fund && npm run build)
```
