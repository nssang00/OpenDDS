# UI Studio · Guided Component UX (v0.21 실험 구현)

2026-11-09 · 이전 v0.20 One Studio + Native TSX Composition PoC에서 이어서 구현했습니다. **공식 릴리스나 검증 기준선이 아닙니다.**

## 제품 목표

사용자가 기존 React 기본 컴포넌트를 배치하고, Props/Events/Slots을 공개하고, 실제 동작을 확인한 다음, 개발자가 수정할 수 있는 네이티브 React TSX로 내보내는 **Visual React Component Studio**. UI 제작 도구이지 백엔드·인증·라우팅까지 배포하는 전체 앱 빌더가 아닙니다.

## 이번 변경

1. **하나의 Studio에서 4단계 제작 흐름**: ① 구성 → ② 연결 → ③ 테스트 → ④ 코드 내보내기. 단계 버튼은 기존 패널과 Canvas, Preview, Export를 열 뿐 별도 문서를 생성하지 않습니다.
2. **시작 템플릿**: 빈 컴포넌트 또는 검색창 템플릿 선택. 검색창은 Input + Button을 만든 뒤 `value`(TwoWay), `placeholder`, `onSearch`를 자동 공개합니다. 트리/Props/Events는 그대로 편집·Undo/Redo 가능합니다.
3. **의도 중심 간편 연결**: 선택한 컨트롤에서 `입력값을 외부에서 제어`, `클릭 시 부모에게 알리기` 등의 원클릭 제안을 표시. 호출은 기존 `exposeDefinitionProperty()`/`exposeDefinitionEvent()`에 위임하며, 중복 공개는 숨깁니다.
4. **공개 API 요약**: 현재 Definition의 Props, Events, Slots을 선택 패널에 표시. 구체 타입이나 고급 설정은 기존 Inspector에서 계속 수정 가능합니다.
5. **Export 안내**: Native TSX Export 가능 여부를 **실제 생성 함수**로 사전 검사. 변환할 수 없는 기능이 있으면 다운로드 버튼 비활성화하고 이유를 보여 줍니다. 기존 Runtime 패키지 Export는 별도 버튼으로 보존합니다.
6. **브라우저 회귀 테스트 준비**: 기존 v0.20 E2E 6개 + 새 v0.21 워크플로 3개를 실행 목록에 포함했습니다. **실행 결과는 없음** (Vite/Playwright 의존성 미설치).

## 설계 원칙

- Puck의 팔레트·상황별 편집 UX, Plasmic의 컴포넌트 공개 API 경험, Storybook의 Preview 중심 검증 경험을 **참고**했습니다. Puck/Craft.js/Plasmic/Storybook을 의존성으로 설치하거나 소스를 복사하지 않았습니다.
- **한 개의 canonical JSON v6** 문서만 저장합니다. React 컴포넌트 코드와 Studio 실행 상태의 동기화는 현재 단방향 (`JSON v6 → Native TSX`)입니다.
- **조용한 기능 손실 금지**: Native 생성기에서 지원하지 않는 기능은 명시적으로 거부합니다. 현재 가이드는 Native Export가 이해하는 버튼 클릭 이벤트만 추천합니다. Input/Checkbox 값 변경은 TwoWay 공개 Prop의 `onValueChange`/`onCheckedChange` 스타일 콜백으로 처리합니다.
- **Studio 자체의 AntD → shadcn 전환은 별도**입니다. 이번 변경은 사용자 흐름과 기존 Native Export의 조합입니다. Canvas/Preview는 여전히 AntD Runtime입니다.
- Registry를 통한 팀 게시/버전 관리, npm 배포, 실제 Base UI 타입·브라우저/접근성 검증은 아직 구현하지 않았습니다.

## 변경된 소스

- `packages/core/guided.js` — 템플릿, 의도 기반 연결 제안/적용, API 요약
- `src/framework/UnifiedStudio.jsx` — 단계 바, 템플릿 생성, 연결 패널, Export 준비 검사 다이얼로그
- `src/framework/unified.css` — 안내 UI 스타일과 작은 화면 반응형
- `tests/guided-authoring.test.js` — 새 단위 테스트 6개
- `e2e/guided-v021.spec.js` — 실제 브라우저에서 돌릴 테스트 3개 (현재 미실행)
- `playwright.config.js` — 기존 v0.20 테스트와 새 테스트 모두 포함

## 로컬 검증

```bash
npm test
node tools/verify-syntax.mjs
node tools/verify-runtime.mjs
npm run verify:native-tsx
```

- Core: **226/226 PASS** (이전 220)
- JS/JSX/TS/TSX 구문 검사: **PASS, 60개 소스 파일 + 생성 TSX 6개, 오류 0**
- React Runtime 모의 렌더러 테스트: **PASS**
- Native TSX 다중 파일 + 신규 CustomerLookup 템플릿 엄격 TypeScript 검사: **PASS — 임시 React/shadcn 타입 스텁만 사용**
- 실제 Studio Vite 빌드/브라우저 E2E: **미실행**. npm 패키지가 설치돼 있지 않으며 네트워크 사용이 제한됨
- 실제 shadcn/Base UI 소비자 빌드, 시각적 동등성, 접근성: **미실행**

## 검증/제품화 우선순위

1. 네트워크가 되는 환경에서 `npm install`, `npm run build`, `npm run test:e2e`를 실행. v0.20 E2E 및 신규 3개 흐름 확인.
2. 실제 Vite + shadcn/ui(Base UI) 소비자에 생성 ZIP의 `src/components/*.tsx` 복사 후 타입/동작/키보드/접근성 검사.
3. Canvas용 실제 shadcn 렌더러와 제한된 컴포넌트 세트의 parity를 검증.
4. 검증 통과 후 게시용 shadcn Registry 포맷, 팀 라이브러리 배포, 버전 관리 UX를 설계.

## 재현 예시

오른쪽 연결 패널은 처음에는 SearchBox처럼 이미 공개된 속성이 있는 컴포넌트의 API를 보여 줍니다. `＋ 새 컴포넌트` → `검색창 템플릿` → 이름 `CustomerLookup` → 생성 → `④ 코드 내보내기`를 선택하면 Native 변환 준비 여부와 두 가지 Export 선택지를 볼 수 있습니다. `빈 컴포넌트` → `텍스트 추가` → `text 속성을 외부에서 변경`을 클릭하면 공개 Prop이 생성되며 Undo로 되돌릴 수 있습니다.
