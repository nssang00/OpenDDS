# UI Studio v0.13 — Component-first verification

## Scope

Create a component with Designer, publish typed props and events, compose that component inside another UserControl (multiple levels), create independent instances for preview, and export a standalone React package that runs within a separate React app.

## Commands

```sh
npm install
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run build
npm run export:v013
mkdir -p tests/component-v013
unzip -q examples/CustomerBrowser-react-component-v0.13.zip -d tests/component-v013
(cd tests/component-v013 && npm install && npm run build && npm pack --pack-destination ../consumer-v013)
(cd tests/consumer-v013 && npm install && npm run build)
UI_STUDIO_USE_SYSTEM_CHROME=1 CI=1 npm run test:e2e
UI_STUDIO_USE_SYSTEM_CHROME=1 CI=1 npx playwright test --config=e2e/consumer-v013.config.js
```

## v0.13 additions

- `createBlankComponentWorkspace`: no app-building assumptions; page is a preview/test harness.
- `addComponentToPreview`: references Definition with unique instance ID, default public props, not copied UI tree.
- `componentUsage`: reverse references across other Definitions and preview pages.
- UI Designer: named component creation modal, Component Library, navigate Instance → Definition, Preview Instance button.
- New Core regression, browser authoring + nested navigation E2E, independently installed React consumer E2E.

## Final CI evidence

**GitHub Actions full pipeline SUCCESS, 2026-10-23 (KST):**

- Repository: `nssang00/chatgpt-write-test`
- Branch: `ci/ui-studio-v013-component-first-20261023` (main unchanged)
- CI commit: `49b1e0374038fc0a3ec038872bc4ab7c2008349a`
- Run: https://github.com/nssang00/chatgpt-write-test/actions/runs/39877164077 — **success**
- Core: **171 passed, 0 failed**
- Studio real Chrome: **9 passed (22.3s)**. Includes manually creating nested `MiniSearch → FilterBar → CustomerBrowser` in Designer and two Preview instances.
- Independently installed exported React component real Chrome: **1 passed (3.0s)**, tests separately controlled inputs plus typed callbacks.
- Vite production app: success; exported component package: successful Vite build; separately installed consumer app: successful Vite build.
- Evidence artifact: https://github.com/nssang00/chatgpt-write-test/actions/runs/39877164077/artifacts/12467809447
- Artifact digest: `sha256:874fba395dfcf9acc099f75014598479cdf4d6e71ae8ce0529a95aad10a25006`

The isolated branch workflow extracted a source archive and applied six recorded CI patches while diagnosing failures. The downloadable v0.13 verified source integrates those exact fixes directly and includes `.github/workflows/component-first-e2e.yml` to reproduce the successful pipeline when the sources are checked in as a repository.

**Limits:** The passing checks cover these 10 E2E scenarios and 171 Core tests, not arbitrary user-authored controls or every browser/OS. CustomControl, advanced SVG/Canvas, and animations are future goals.
