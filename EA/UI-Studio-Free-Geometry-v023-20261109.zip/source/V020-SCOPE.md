# UI Studio v0.20 — One Studio UX

## Goal
- One canonical v6 editor as the only application entrypoint; no v5/v6 UI selection, no Simple/Advanced mode switch.
- Five primary header actions. The project menu reveals advanced tasks only on demand.
- Contextual quick add, layers panel, inspector basics; property details and data/action connections are opt-in.
- Keep JSON v6 editing, v5 JSON migration on import, code editing, React package exporting, component authoring, and declarative runtime working.

## Scope and limitations
- This release simplifies the editing entrypoint, not the underlying canonical document or runtime.
- Does not claim a formal usability study with new users. Chrome E2E demonstrates navigation and behavior, not subjective ease.
- Historical tests that assume separate Legacy and Advanced editors no longer match the product design; retained in the archive for reference. The v0.20 Chrome smoke suite exercises the new single-editor interaction model.
