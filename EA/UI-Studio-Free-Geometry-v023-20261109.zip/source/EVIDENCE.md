# UI Studio v0.12 — reproducible evidence (2026-10-22)

## Verified in this environment

| Command/check | Result |
|---|---|
| `npm test` (`node --test tests/*.test.js`) | **165 / 165 passed**, 0 failed |
| `npm run verify:runtime` | Runtime.jsx transpiled and executed in deterministic mock React renderer: independent Slot instances, TwoWay, events, external children, non-bindable Props, dynamic Repeat/when, nested ItemGallery → ItemList |
| `npm run export:dynamic` | **ItemList portable React source package generated** (24 files); contains `core/dynamic.js` and public `items` array / `showTitle` boolean typings |
| `npm run export:lego` / `npm run export:slots` | Existing exports rebuilt without errors (24 files each) |
| `node tools/verify-syntax.mjs` | 47 JS/TS/JSX/TSX sources + 3 generated TSX parsed; 0 parse errors |
| PostCSS parser | All 3 CSS files parse successfully |
| New `tests/dynamic.test.js` | Schema guards, safe key fallback, nested context, DSL/JSON roundtrip, pure Export dependencies, nested UserControl forwarding |

## Limitations that **remain unverified**

- ReactDOM with actual browser UI (mouse drag/resize/Inspector events) has not been tested in this environment.
- Actual Vite production build and build of the exported independent package cannot be run without fetching uncached dependencies; `npm install --offline` returns `ENOTCACHED` for `@vitejs/plugin-react`.
- Deterministic mock rendering exercises the **real JSX Runtime source and Core**, but is *not* a substitute for React DOM/browser integration.
- Dynamic Repeat supports array bindings and per-item keys, not virtualized rendering/huge lists or expression evaluation. CustomControl, SVG/Canvas, animation, full XML conversion remain future work.

## Repeatable commands

```bash
npm test
npm run verify:runtime
npm run export:dynamic
npm run export:lego
npm run export:slots
node tools/verify-syntax.mjs
```

---

## v0.11 historical evidence

# UI Studio v0.11 — 재현 가능한 검증 기록

## 확인한 결과

| 검사 | 명령 | 결과 |
|---|---|---|
| v0.10 기존 + Slot 신규 기능 테스트 | `npm test` | 155개 모두 통과 |
| React Runtime JSX 통합 (테스트 렌더러) | `npm run verify:runtime` | Nested TwoWay 상태 분리/중첩 이벤트 1회/외부 children Slot/일반 공개 Props 모두 통과 |
| 기존 LEGO 패키지 생성 | `npm run export:lego` | CustomerBrowser ZIP 생성 |
| Slot 컴포넌트 패키지 생성 | `npm run export:slots` | SearchCard / SlotPanel ZIP 생성 |
| 소스·생성된 TSX 구문 검사 | `node tools/verify-syntax.mjs` | 테스트 실행 시 결과 기록 |
| ZIP CRC / 파일 참조 검사 | 검증 스크립트 + Python zipfile | 패키징 이후 실행 |

### Runtime 통합 검사 설명

`verify:runtime`은 `packages/runtime-react/Runtime.jsx` **실제 파일**을 TypeScript로 JSX 변환한 뒤, 가짜 React/Control 렌더러에서 실행합니다. 실제 Runtime의 Definition/Instance 트리 탐색, Property 해석, RuntimeSession 상태, Event forwarding 경로는 통과하나, **브라우저·React DOM·Ant Design의 렌더링을 검증하지는 않습니다**. 설치된 TypeScript 라이브러리가 필요합니다(로컬 devDependency 또는 시스템 TypeScript).

## 검증하지 못한 내용

- npm 레지스트리 `EAI_AGAIN`으로 Studio 및 내보낸 패키지 Vite 프로덕션 빌드 불가.
- Chromium headless GPU 초기화 오류로 실제 브라우저 드래그/리사이즈/Slot Inspector 클릭 미검증.
- 외부 React 프로젝트 설치, 사용자 Code CustomControl, Canvas/SVG 도형 편집, Animation, XML, 임의 Data Adapter 미구현.
- ReactNode 외부 Slot의 실제 DOM 접근성/키보드 상호작용 미검증.

## 재현 명령

```bash
npm test
npm run verify:runtime
npm run export:lego
npm run export:slots
node tools/verify-syntax.mjs
```

React 전체 UI와 독립 패키지 빌드는 npm 접근 가능한 개발 머신에서 `npm install && npm run build`와 실제 브라우저 E2E 테스트를 따로 수행해야 합니다. 이 개발 빌드는 프로덕션 준비 완료를 의미하지 않습니다.
