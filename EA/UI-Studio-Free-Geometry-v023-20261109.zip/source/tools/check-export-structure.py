import zipfile, pathlib, re, sys
p=pathlib.Path(sys.argv[1])
with zipfile.ZipFile(p) as z:
    names={x.filename for x in z.infolist() if not x.is_dir()}
    assert z.testzip() is None
    assert any(x.endswith('src/runtime/core/editor.js') for x in names)
    assert 'src/runtime/core/index.js' in names
    assert 'src/CustomerBrowser.tsx' in names
    internal=0
    for name in names:
        if not name.startswith('src/') or not name.endswith(('.js','.jsx','.ts','.tsx')):
            continue
        data=z.read(name).decode()
        for match in re.finditer(r'''(?:from\s*|import\s*)["'](\.{1,2}/[^"']+)["']''', data):
            rel=match.group(1)
            target=(pathlib.PurePosixPath(name).parent / rel)
            parts=[]
            for segment in target.parts:
                if segment=='..':
                    if parts:parts.pop()
                elif segment!='.':parts.append(segment)
            resolved='/'.join(parts)
            assert resolved in names or any(resolved+ext in names for ext in ('.js','.jsx','.ts','.tsx')), (name,rel,resolved)
            internal+=1
    print(f'PASS: archive contains {len(names)} files; {internal} relative source imports resolved; ZIP CRC OK')
