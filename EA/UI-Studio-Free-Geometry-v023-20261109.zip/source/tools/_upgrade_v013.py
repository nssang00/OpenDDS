from pathlib import Path
p=Path('packages/core/workspace.js');s=p.read_text()
needle='/** Return referenced definitions in dependency-first order; never copy per instance. */'
addition='''/** Component-first document: an empty component is the project, and Page is only a preview harness. */
export function createBlankComponentWorkspace(name,registry){
  const seed=createSearchBoxDocument();
  const doc={...seed,title:`${name} · Component Workspace`,definitions:{},pages:{
    main:{id:'main',name:'Preview Harness',root:{id:'previewWorkspaceRoot',kind:'frame',name:'Preview Harness',layout:{type:'column',gap:12,padding:12},children:[]}}
  },data:{state:{},sources:{}},resources:{}};
  return createComponentDefinition(doc,name,registry);
}
/** Add a Definition by reference to a Page preview, without duplicating its tree. */
export function addComponentToPreview(doc,definitionId,registry){
  if(!doc.definitions[definitionId])throw Error(`없는 컴포넌트: ${definitionId}`);
  const next=structuredClone(doc);
  const def=next.definitions[definitionId];
  const instance={id:allocateNodeId(next,'preview'),kind:'instance',name:definitionId,definitionId,
    props:Object.fromEntries(Object.entries(def.publicProps||{}).map(([key,spec])=>[key,literal(structuredClone(spec.defaultValue??null))])),
    bindings:{},overrides:{}};
  next.pages.main.root.children.push(instance);
  return validateDocument(next,registry);
}
/** Reverse references are useful when navigating Lego components in the designer. */
export function componentUsage(doc,definitionId,registry){
  validateDocument(doc,registry);
  if(!doc.definitions[definitionId])throw Error('없는 사용자 컴포넌트');
  const usage=[];
  for(const [owner,def] of Object.entries(doc.definitions))walkNodes(def.root,node=>{
    if(node.kind==='instance'&&node.definitionId===definitionId)usage.push({owner:`definition:${owner}`,instanceId:node.id});
  });
  for(const [owner,page] of Object.entries(doc.pages))walkNodes(page.root,node=>{
    if(node.kind==='instance'&&node.definitionId===definitionId)usage.push({owner:`page:${owner}`,instanceId:node.id});
  });
  return usage;
}
'''
assert needle in s;s=s.replace(needle,addition+needle);p.write_text(s)
p=Path('src/framework/UnifiedStudio.jsx');s=p.read_text()
s=s.replace('Button,Input,InputNumber,Select,Segmented,Alert,Tag,Divider','Button,Input,InputNumber,Select,Segmented,Alert,Tag,Divider,Modal')
s=s.replace('createComponentDefinition,createDefinitionPreviewDocument,','createComponentDefinition,createBlankComponentWorkspace,addComponentToPreview,componentUsage,createDefinitionPreviewDocument,')
s=s.replace('onResetSlot,onAddPublicProp})','onResetSlot,onAddPublicProp,onOpenDefinition})')
old="    {def&&<><h4>Public Properties · {node.definitionId}</h4>"
new="    {def&&<><Button block type=\"primary\" size=\"small\" onClick={()=>onOpenDefinition(node.definitionId)}>↗ 원본 Definition 편집 · {node.definitionId}</Button><h4>Public Properties · {node.definitionId}</h4>"
assert old in s;s=s.replace(old,new)
s=s.replace("const [insertSearch,setInsertSearch]=useState('');","const [insertSearch,setInsertSearch]=useState('');\n  const [createOpen,setCreateOpen]=useState(false);\n  const [createName,setCreateName]=useState('MyComponent');")
old="  const createNew=()=>{const name=window.prompt('새 컴포넌트 이름 (예: MyControl)', 'MyControl');if(name===null)return;try{const next=createComponentDefinition(doc,name.trim(),registry);sync(next);setEditingDef(name.trim());setSelected(next.definitions[name.trim()].root.id);const printed=printV6Dsl(next.definitions[name.trim()].root);setCode(printed.text);codeRanges.current=printed.ranges;setView('design');}catch(e){setError(e.message);}};"
new="""  const createNew=(fresh=false)=>{const name=createName.trim();try{
    const next=fresh?createBlankComponentWorkspace(name,registry):createComponentDefinition(doc,name,registry);
    sync(next,{resetState:fresh,record:!fresh});setEditingDef(name);setSelected(next.definitions[name].root.id);
    const printed=printV6Dsl(next.definitions[name].root);setCode(printed.text);codeRanges.current=printed.ranges;
    setView('design');setCreateOpen(false);setInsertOpen(false);
  }catch(e){setError(e.message);}};
  const previewAdd=()=>{try{if(!editingDef)throw Error('컴포넌트를 선택하세요');sync(addComponentToPreview(doc,editingDef,registry));goPage();setView('design');}catch(e){setError(e.message);}};"""
assert old in s;s=s.replace(old,new)
# avoid goPage stale doc selected root same yes
s=s.replace('UI Studio v0.12 · Dynamic Component IDE','UI Studio v0.13 · Component-First IDE')
s=s.replace('<Button size="small" onClick={createNew}>＋ New Component</Button>','<Button size="small" type="primary" onClick={()=>{setCreateName(\'MyComponent\');setCreateOpen(true);}}>＋ New Component</Button><Button size="small" onClick={previewAdd} disabled={!editingDef}>＋ Preview Instance</Button>')
start='        <div className="v6-tree-actions"><Button size="small" type={!editingDef?\'primary\':\'default\'} onClick={goPage}>Preview Page</Button>{Object.keys(doc.definitions).map(id=><Button key={id} size="small" type={editingDef===id?\'primary\':\'default\'} onClick={()=>chooseDefinition(id)}>◇ {id}</Button>)}</div>'
end='''        <div className="v6-component-library">
          <div className="v6-library-head"><strong>Component Library</strong><small>사용자가 만든 재사용 부품</small></div>
          <div className="v6-tree-actions"><Button size="small" type={!editingDef?'primary':'default'} onClick={goPage}>Preview Harness</Button></div>
          <div className="v6-library-items" data-testid="component-library">{Object.keys(doc.definitions).map(id=><div className="v6-library-row" data-testid={`component-library-${id}`} key={id}>
            <Button size="small" type={editingDef===id?'primary':'default'} onClick={()=>chooseDefinition(id)}>◇ {id}</Button>
            <small>사용 {componentUsage(doc,id,registry).length}회</small>
          </div>)}</div>
        </div>'''
assert start in s;s=s.replace(start,end)
s=s.replace('onResetSlot={resetSlot} onAddPublicProp={addPublicProp}','onResetSlot={resetSlot} onAddPublicProp={addPublicProp} onOpenDefinition={chooseDefinition}')
old='    <div className="v6-footer">재사용 컴포넌트 Definition 편집 · 중첩·바인딩 · React Component ZIP Export · Core + IR 공유</div>'
new='''    <Modal title="새 재사용 컴포넌트" open={createOpen} onCancel={()=>setCreateOpen(false)} onOk={()=>createNew(false)} okText="컴포넌트 생성" destroyOnHidden>
      <label htmlFor="v13-component-name">Component name · PascalCase</label>
      <Input id="v13-component-name" aria-label="New component name" value={createName} onChange={e=>setCreateName(e.target.value)} onPressEnter={()=>createNew(false)} autoFocus/>
      <p>생성 즉시 라이브러리에 등록되며 다른 컴포넌트에 삽입할 수 있습니다.</p>
      <Button onClick={()=>createNew(true)}>새 컴포넌트 프로젝트로 시작 (Preview Harness만 유지)</Button>
    </Modal>
    <div className="v6-footer">Component-first Workspace · Definition / Instance 재사용 · Preview Harness · 독립 React 패키지 Export</div>'''
assert old in s;s=s.replace(old,new)
p.write_text(s)
p=Path('src/framework/unified.css');s=p.read_text();s+='''
/* v0.13 · reusable definitions are the central project library. */
.v6-component-library{border-bottom:1px solid #dce6ee;background:#f8fbff;flex:none}
.v6-library-head{display:flex;flex-direction:column;gap:4px;padding:11px 12px 5px}
.v6-library-head strong{font-size:12px;color:#16578f}
.v6-library-head small,.v6-library-row small{font-size:10px;color:#71859b}
.v6-library-items{max-height:190px;overflow:auto;padding:4px 8px 10px}
.v6-library-row{display:flex;gap:7px;align-items:center;justify-content:space-between;margin:3px 0}
.v6-library-row .ant-btn{max-width:170px;text-overflow:ellipsis;overflow:hidden}
''';p.write_text(s)
p=Path('package.json');s=p.read_text().replace('"version": "0.12.0"','"version": "0.13.0"').replace('Visual React Component IDE v0.12 — declarative conditional display, reactive repeat, reusable published props, and independent component packages','Visual React Component IDE v0.13 — component-first authoring and nested reusable React component packages');p.write_text(s)
print('Patched core component workspace, UI Studio, CSS, version')
