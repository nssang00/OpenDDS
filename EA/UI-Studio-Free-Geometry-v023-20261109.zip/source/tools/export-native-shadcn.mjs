/** Usage: npm run export:shadcn -- [canonical-v6.json] [DefinitionId] [output.zip]
 * Without arguments, exports the v6 sample SearchBox to exports/SearchBox-shadcn-native.zip.
 */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {createSearchBoxDocument,parseDocument} from '../packages/schema/index.js';
import {createDefaultRegistry} from '../packages/core/registry.js';
import {createNativeShadcnFiles} from '../packages/exporter-react/native-shadcn.js';
import {encodeZip} from '../packages/exporter-react/zip.js';

const registry=createDefaultRegistry();
const [input,definitionId='SearchBox',output=`exports/${definitionId}-shadcn-native.zip`]=process.argv.slice(2);
const doc=input?parseDocument(readFileSync(input,'utf8'),registry):createSearchBoxDocument();
const files=createNativeShadcnFiles(doc,registry,definitionId);
const target=resolve(output);
mkdirSync(dirname(target),{recursive:true});
writeFileSync(target,encodeZip(files));
console.log(`Native TSX PoC: ${target} (${Object.keys(files).join(', ')})`);
