/** Offline, reproducible reusable component export with conditional Repeat. */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createDefaultRegistry,createDynamicExampleDocument,componentDependencies} from '../packages/core/index.js';
import {serializeDocument} from '../packages/schema/index.js';
import {createPortablePackageFiles} from '../packages/exporter-react/component-package.js';
import {encodeZip} from '../packages/exporter-react/zip.js';
const needed=['schema/index.js','runtime-react/Runtime.jsx','renderer-antd/index.jsx',
  ...['index','binding','components','document','editor','events','layout','properties','registry','session','store','workspace','slots','dynamic'].map(n=>`core/${n}.js`)];
const sources=Object.fromEntries(needed.map(name=>[`packages/${name}`,readFileSync(`packages/${name}`,'utf8')]));
const registry=createDefaultRegistry(),doc=createDynamicExampleDocument(registry);
if(componentDependencies(doc,'ItemList',registry).join(',')!=='ItemList')throw Error('다른 Definition에 예기치 않게 의존합니다');
mkdirSync('examples',{recursive:true});
writeFileSync('examples/dynamic-composition-v0.12.json',serializeDocument(doc,registry)+'\n');
const files=createPortablePackageFiles(doc,registry,'ItemList',sources);
if(!files['src/runtime/core/dynamic.js']||!files['src/ItemList.tsx'].includes('items?: unknown[]'))throw Error('Dynamic Runtime 또는 Props 타입을 내보내지 않았습니다');
const zip=encodeZip(files);
writeFileSync('examples/ItemList-react-component-v0.12.zip',zip);
writeFileSync('examples/ItemList-usage.tsx',`import { ItemList } from 'ui-studio-item-list';

export default function Demo(){
  return <ItemList
    showTitle={true}
    items={[
      {id:'one',label:'첫 번째 부품',visible:true},
      {id:'hidden',label:'이 항목은 보이지 않음',visible:false},
      {id:'two',label:'두 번째 부품',visible:true}
    ]}
  />;
}
`);
console.log(`PASS independent ItemList source export: ${Object.keys(files).length} files, ${zip.length} bytes`);
