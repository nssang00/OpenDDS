/** v0.13 export: independently installable CustomerBrowser composing FilterBar and SearchBox. */
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {createDefaultRegistry,createLegoExampleDocument} from '../packages/core/index.js';
import {createPortablePackageFiles} from '../packages/exporter-react/component-package.js';
import {encodeZip} from '../packages/exporter-react/zip.js';
const names=['schema/index.js','runtime-react/Runtime.jsx','renderer-antd/index.jsx',
  ...['index','binding','components','document','editor','events','layout','properties','registry','session','store','workspace','slots','dynamic','visual'].map(x=>'core/'+x+'.js')];
const sources=Object.fromEntries(names.map(n=>['packages/'+n,readFileSync('packages/'+n,'utf8')]));
const registry=createDefaultRegistry(),doc=createLegoExampleDocument(registry);
const files=createPortablePackageFiles(doc,registry,'CustomerBrowser',sources);
mkdirSync('examples',{recursive:true});
writeFileSync('examples/CustomerBrowser-react-component-v0.13.zip',encodeZip(files));
console.log('v0.13 CustomerBrowser exported:',Object.keys(files).length,'files');
