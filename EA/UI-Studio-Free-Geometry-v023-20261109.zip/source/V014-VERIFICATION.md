# UI Studio v0.14 — Visual-First Component Builder verification

## Goal and UX contract
Create fields, change a control's props, bind data, select visibility/repetition rules,
configure a button action, save/load a canonical v6 Definition, reuse the component,
and export it as ordinary React without editing code or JSON. JSON Schema-style metadata
is derived from the existing Control Registry. RJSF is **not** embedded: the small,
framework-independent schema adapter avoids a second canonical document model.

## Supported in this increment
- `inspectorSchema()` derives JSON Schema property descriptors and editor hints from registry metadata.
- `visualDataChoices()` suggests typed state, sources, published props and repeated `context.item.*` fields.
- Native Studio Data Wizard adds string, number, boolean and array state values without editing raw JSON.
- Visual selectors set `when`, `repeat`, and Button `set`/`emit` actions in the existing v6 schema.
- Declarative state mutation is limited to validated `state` or instance `local`; no `eval`, no arbitrary URLs/code.
- The static component exporter and the SDUI-style JSON both consume the **same** canonical document.
- Independent React exports reject Definition actions that mutate host State, preventing hidden host coupling.

## Known boundary
- This is **not** runtime downloading of untrusted JS packages or DLL-equivalent hot module replacement.
- Complex expressions (e.g. comparison operators), first-class local state design UI, and remote schema-driven editing
  remain future work. Visual action editing currently supports Page-host state changes and component public events.
- Chrome E2E validates defined paths, not a human usability study.

## Repeatable checks
```
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run build
npm run export:v014
npm run test:e2e
```
The full GitHub Actions pipeline also builds an independently installed exported React package
and runs a separate consumer Playwright scenario. A CI green result is only claimed after
its run conclusion and logs are inspected.
