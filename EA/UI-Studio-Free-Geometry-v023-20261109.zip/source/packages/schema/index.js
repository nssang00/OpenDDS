/** UI Studio v6 canonical, UI-framework-neutral JSON schema. */
export const SCHEMA_VERSION = 6;
export const PROPERTY_KINDS = Object.freeze(['literal', 'binding', 'resource']);
export const LAYOUT_KINDS = Object.freeze(['row', 'column', 'grid', 'wrap', 'overlay', 'free']);
export const literal = value => ({kind: 'literal', value});
export const binding = (source, path, mode='OneWay', updateOn='change') => ({kind:'binding', source, path, mode, updateOn});
const VALID_ID = /^[a-zA-Z_][a-zA-Z0-9_:/.-]{0,127}$/;
const FORBIDDEN = new Set(['__proto__','prototype','constructor']);
export const safePath = path => Array.isArray(path) && path.length > 0 && path.length < 32 && path.every(k => (typeof k==='string' && k.length>0 && k.length<=128 && !FORBIDDEN.has(k)) || (Number.isInteger(k) && k>=0 && k<1000000));
export const isRecord = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const plain = value => isRecord(value) && (Object.getPrototypeOf(value)===Object.prototype || Object.getPrototypeOf(value)===null);

export function isPropertyValue(value){
  if(!plain(value))return false;
  if(value.kind==='literal')return Object.hasOwn(value,'value');
  if(value.kind==='resource')return typeof value.key==='string' && value.key.length>0 && !FORBIDDEN.has(value.key);
  if(value.kind==='binding')return ['state','sources','context','props','local'].includes(value.source) && safePath(value.path) && ['OneWay','TwoWay'].includes(value.mode) && (value.updateOn===undefined || ['change','blur'].includes(value.updateOn));
  return false;
}
export function walkNodes(root,callback){callback(root);for(const child of root.children||[])walkNodes(child,callback);for(const children of Object.values(root.slots||{}))for(const child of children)walkNodes(child,callback);}
export function findNode(root,id){let result;walkNodes(root,n=>{if(n.id===id)result=n;});return result;}
const ensure=(check,message)=>{if(!check)throw new Error(`Schema v6: ${message}`);};
export function validateDocument(doc,registry){
  ensure(plain(doc) && doc.format==='ui-studio' && doc.schemaVersion===SCHEMA_VERSION,'format/schemaVersion 오류');
  ensure(plain(doc.pages) && Object.keys(doc.pages).length>0 && Object.keys(doc.pages).length<=50,'pages 오류');
  ensure(plain(doc.definitions) && Object.keys(doc.definitions).length<=500,'definitions 오류');
  ensure(plain(doc.data) && plain(doc.data.state) && plain(doc.data.sources),'data 오류');
  const instances=[];let count=0;
  const inspectProperties=(props,where)=>{ensure(plain(props),`${where} 속성 객체가 필요합니다`);for(const [key,val] of Object.entries(props)){ensure(key.length>0 && !FORBIDDEN.has(key) && isPropertyValue(val),`${where}.${key}의 속성값이 유효하지 않습니다`);}};
  function nodeCheck(node,ids,depth=0){
    ensure(depth<=30 && ++count<=5000,'트리 깊이 또는 노드 수 초과');
    ensure(plain(node) && typeof node.id==='string' && VALID_ID.test(node.id) && !ids.has(node.id),`중복 또는 잘못된 노드 ID: ${node?.id}`);
    ids.add(node.id);
    // Dynamic behavior belongs to any existing node kind (frame, control, or instance).
    // The repeater is evaluated before the condition, so the condition may read
    // context.item inside each individual iteration.
    if(node.when!==undefined){
      ensure(isPropertyValue(node.when),`조건 속성 오류: ${node.id}`);
      ensure(node.when.kind!=='binding'||node.when.mode==='OneWay',`조건은 OneWay만 지원: ${node.id}`);
      ensure(node.when.kind!=='literal'||typeof node.when.value==='boolean',`조건은 boolean이 필요합니다: ${node.id}`);
    }
    if(node.repeat!==undefined){
      ensure(plain(node.repeat)&&isPropertyValue(node.repeat.items),`Repeat 속성 오류: ${node.id}`);
      const items=node.repeat.items;
      ensure(items.kind!=='binding'||items.mode==='OneWay',`Repeat는 OneWay만 지원: ${node.id}`);
      ensure(items.kind!=='literal'||Array.isArray(items.value),`Repeat에는 배열이 필요합니다: ${node.id}`);
      ensure(node.repeat.keyPath===undefined||(Array.isArray(node.repeat.keyPath)&&safePath(node.repeat.keyPath)),`Repeat keyPath 오류: ${node.id}`);
      ensure(Object.keys(node.repeat).every(k=>['items','keyPath'].includes(k)),`미등록 Repeat 속성: ${node.id}`);
    }
    if(node.position!==undefined){
      ensure(plain(node.position)&&Object.keys(node.position).sort().join(',')==='x,y' && ['x','y'].every(axis=>Number.isFinite(node.position[axis])&&node.position[axis]>=0&&node.position[axis]<=5000),`위치 오류: ${node.id}`);
    }
    if(node.anchors!==undefined){
      ensure(plain(node.anchors) && Object.keys(node.anchors).every(key=>['horizontal','vertical'].includes(key))
        && ['left','right'].includes(node.anchors.horizontal??'left')
        && ['top','bottom'].includes(node.anchors.vertical??'top')
        && node.position!==undefined,`반응형 기준점 오류: ${node.id}`);
      if(node.anchors.horizontal==='right')ensure(Number.isFinite(node.size?.width),`오른쪽 고정에는 요소 너비가 필요합니다: ${node.id}`);
      if(node.anchors.vertical==='bottom')ensure(Number.isFinite(node.size?.height),`아래쪽 고정에는 요소 높이가 필요합니다: ${node.id}`);
    }
    if(node.size!==undefined){
      ensure(plain(node.size),'크기 설정 오류: '+node.id);
      for(const [dimension,value] of Object.entries(node.size)){
        ensure(['width','height'].includes(dimension) && Number.isFinite(value) && value>=24 && value<=5000,`크기 오류: ${node.id}.${dimension}`);
      }
    }
    ensure(['frame','component','instance'].includes(node.kind),`잘못된 노드 종류: ${node.id}`);
    if(node.kind==='frame'){
      ensure(plain(node.layout)&&LAYOUT_KINDS.includes(node.layout.type),`레이아웃 오류: ${node.id}`);
      ensure(node.layout.gap===undefined || (Number.isFinite(node.layout.gap)&&node.layout.gap>=0),`gap 오류: ${node.id}`);
      ensure(node.layout.padding===undefined || (Number.isFinite(node.layout.padding)&&node.layout.padding>=0),`padding 오류: ${node.id}`);
      ensure(node.layout.columns===undefined || (Number.isInteger(node.layout.columns)&&node.layout.columns>=1&&node.layout.columns<=24),`columns 오류: ${node.id}`);
      ensure(node.layout.fluid===undefined || (node.layout.type==='free'&&typeof node.layout.fluid==='boolean'),`반응형 Frame 설정 오류: ${node.id}`);
      ensure(Array.isArray(node.children),`children 누락: ${node.id}`);
      for(const c of node.children){
        ensure(node.layout.type==='free'||c.position===undefined,`자유 배치 Frame 외부 위치 설정: ${c.id}`);
        ensure(node.layout.type==='free'||c.anchors===undefined,`자동 배치 Frame에서 반응형 기준점 사용 불가: ${c.id}`);
        if(c.anchors?.horizontal==='right')ensure(Number.isFinite(node.size?.width),`오른쪽 고정에는 Free Frame 기준 너비가 필요합니다: ${node.id}`);
        if(c.anchors?.vertical==='bottom')ensure(Number.isFinite(node.size?.height),`아래쪽 고정에는 Free Frame 기준 높이가 필요합니다: ${node.id}`);
        nodeCheck(c,ids,depth+1);
      }
    }else if(node.kind==='component'){
      ensure(typeof node.typeId==='string' && VALID_ID.test(node.typeId),`typeId 오류: ${node.id}`);
      ensure(!registry || registry.has(node.typeId),`미등록 컨트롤: ${node.typeId}`);
      inspectProperties(node.props||{},node.id);
      const control=registry?.get(node.typeId);
      if(control){
        for(const [key,value] of Object.entries(node.props||{})){
          const meta=control.properties[key];
          ensure(!!meta,`미등록 Property: ${node.typeId}.${key}`);
          if(value.kind==='binding'){
            ensure(meta.bindable,`Binding 미지원: ${node.typeId}.${key}`);
            ensure(value.mode!=='TwoWay'||meta.twoWay,`TwoWay 미지원: ${node.typeId}.${key}`);
          }
          if(value.kind==='literal' && value.value!==undefined && value.value!==null){
            const valid=meta.type==='enum'?meta.options?.includes(value.value):meta.type==='array'?Array.isArray(value.value):meta.type==='object'?plain(value.value):meta.type==='color'?typeof value.value==='string':typeof value.value===meta.type;
            ensure(valid,`Property 타입 오류: ${node.typeId}.${key}`);
          }
        }
      }
      if(node.events!==undefined){
        ensure(plain(node.events),`events 오류: ${node.id}`);
        for(const [key,event] of Object.entries(node.events)){
          ensure(plain(event)&&(
            (event.kind==='emit'&&typeof event.event==='string'&&VALID_ID.test(event.event)) ||
            (event.kind==='set'&&plain(event.target)&&['state','local'].includes(event.target.source)&&safePath(event.target.path)&&isPropertyValue(event.value)&&['literal','binding'].includes(event.value.kind)&&(event.value.kind!=='binding'||event.value.mode==='OneWay'))
          ),`이벤트 형식 오류: ${node.id}`);
          if(control)ensure(!!control.events[key],`미등록 이벤트: ${node.typeId}.${key}`);
        }
      }
    }else{
      ensure(typeof node.definitionId==='string' && !!doc.definitions[node.definitionId],`없는 Definition: ${node.definitionId}`);
      inspectProperties(node.props||{},node.id);
      inspectProperties(node.bindings||{},`${node.id}.bindings`);
      ensure(plain(node.overrides||{}),`overrides 오류: ${node.id}`);
      ensure(plain(node.slots||{}),`slots 형식 오류: ${node.id}`);
      const available=doc.definitions[node.definitionId].slots||{};
      for(const [name,children] of Object.entries(node.slots||{})){
        ensure(Object.hasOwn(available,name)&&Array.isArray(children),`없는 Slot 또는 잘못된 자식 목록: ${node.id}.${name}`);
        for(const child of children){ensure(child.position===undefined&&child.anchors===undefined,`Slot 자식은 위치를 직접 지정할 수 없습니다: ${child.id}`);nodeCheck(child,ids,depth+1);}
      }
      instances.push(node);
    }
  }
  for(const [id,page] of Object.entries(doc.pages)){
    ensure(VALID_ID.test(id) && plain(page) && page.root?.kind==='frame',`페이지 오류: ${id}`);
    nodeCheck(page.root,new Set());
  }
  for(const [id,def] of Object.entries(doc.definitions)){
    ensure(VALID_ID.test(id) && plain(def) && def.id===id && def.root?.kind==='frame',`Definition 오류: ${id}`);
    ensure(plain(def.publicProps||{}) && plain(def.publicEvents||{}) && plain(def.overridePolicy||{}) && plain(def.slots||{}),`Definition 메타데이터 오류: ${id}`);
    const ids=new Set();nodeCheck(def.root,ids);
    const slotTargets=new Set();
    for(const [name,spec] of Object.entries(def.slots||{})){
      ensure(VALID_ID.test(name)&&plain(spec)&&typeof spec.nodeId==='string',`Slot 선언 오류: ${id}.${name}`);
      const target=findNode(def.root,spec.nodeId);
      ensure(target?.kind==='frame'&&!slotTargets.has(spec.nodeId),`Slot 대상 Frame 오류 또는 중복: ${id}.${name}`);
      slotTargets.add(spec.nodeId);
    }
    for(const [k,p] of Object.entries(def.publicProps||{})){
      ensure(VALID_ID.test(k)&&plain(p)&&['string','number','boolean','enum','color','object','array'].includes(p.type),`공개 속성 메타데이터 오류: ${id}.${k}`);
      ensure(!p.twoWay||p.bindable,`TwoWay는 bindable 속성에서만 허용됩니다: ${id}.${k}`);
      if(p.defaultValue!==undefined && p.defaultValue!==null){
        const valid=p.type==='enum'||p.type==='color'?typeof p.defaultValue==='string':p.type==='array'?Array.isArray(p.defaultValue):p.type==='object'?plain(p.defaultValue):typeof p.defaultValue===p.type;
        ensure(valid,`공개 속성 기본값 타입 오류: ${id}.${k}`);
      }
      // Target-less public props act as the Definition's own state/behavior input,
      // e.g. props.items for Repeat or props.visible for conditional rendering.
      if(p.target!==undefined){
        ensure(plain(p.target) && ids.has(p.target.nodeId) && typeof p.target.property==='string',`공개 속성 매핑 오류: ${id}.${k}`);
        const target=findNode(def.root,p.target.nodeId);
        ensure(target?.kind==='component'||target?.kind==='instance',`공개 속성 대상이 Control/Instance가 아닙니다: ${id}.${k}`);
        const meta=target.kind==='component'?registry?.get(target.typeId)?.properties[p.target.property]:doc.definitions[target.definitionId]?.publicProps?.[p.target.property];
        if(registry)ensure(!!meta && p.type===meta.type && (!p.twoWay || meta.twoWay) && (!p.bindable || meta.bindable),`공개 속성의 대상 Property가 유효하지 않습니다: ${id}.${k}`);
      }
    }
    for(const [k,ev] of Object.entries(def.publicEvents||{})){
      ensure(plain(ev)&&ids.has(ev.nodeId)&&typeof ev.event==='string',`공개 이벤트 매핑 오류: ${id}.${k}`);
      const origin=findNode(def.root,ev.nodeId);
      if(origin.kind==='component' && registry){
        ensure(!!registry.get(origin.typeId)?.events[ev.event],`공개 이벤트 원본이 미등록되었습니다: ${id}.${k}`);
        ensure(origin.events?.[ev.event]?.kind==='emit'&&origin.events[ev.event].event===k,`공개 이벤트 연결이 없습니다: ${id}.${k}`);
      }
      if(origin.kind==='instance')ensure(!!doc.definitions[origin.definitionId]?.publicEvents?.[ev.event],`중첩 인스턴스 공개 이벤트가 없습니다: ${id}.${k}`);
    }
    for(const [nodeId,props] of Object.entries(def.overridePolicy||{}))ensure(ids.has(nodeId) && Array.isArray(props) && props.every(p=>typeof p==='string'),`Override 정책 오류: ${id}.${nodeId}`);
  }
  for(const instance of instances){
    const def=doc.definitions[instance.definitionId];
    for(const [key,value] of Object.entries(instance.props||{})){
      const spec=def.publicProps?.[key];
      ensure(!!spec,`공개되지 않은 속성: ${instance.id}.${key}`);
      ensure(value.kind!=='binding',`인스턴스 props의 Binding은 bindings에 저장해야 합니다: ${instance.id}.${key}`);
      if(value.kind==='literal' && value.value!==null && value.value!==undefined){
        const matches=spec.type==='enum'?typeof value.value==='string':spec.type==='array'?Array.isArray(value.value):spec.type==='object'?plain(value.value):spec.type==='color'?typeof value.value==='string':typeof value.value===spec.type;
        ensure(matches,`공개 Property 타입 오류: ${instance.id}.${key}`);
      }
    }
    for(const [key,value] of Object.entries(instance.bindings||{})){
      ensure(!!def.publicProps?.[key]?.bindable && value.kind==='binding',`바인딩 불가능한 공개 속성: ${instance.id}.${key}`);
      ensure(value.mode!=='TwoWay'||def.publicProps[key].twoWay,`TwoWay 미지원: ${instance.id}.${key}`);
      ensure(!Object.hasOwn(instance.props||{},key),`props/bindings 중복: ${instance.id}.${key}`);
    }
    for(const [nodeId,attrs] of Object.entries(instance.overrides||{})){
      ensure(plain(attrs) && Array.isArray(def.overridePolicy?.[nodeId]),`Override 대상 미허용: ${instance.id}.${nodeId}`);
      for(const [key,val] of Object.entries(attrs)){
        ensure(def.overridePolicy[nodeId].includes(key)&&isPropertyValue(val),`Override 미허용: ${instance.id}.${nodeId}.${key}`);
        const underlying=findNode(def.root,nodeId);
        const meta=underlying?.kind==='component'?registry?.get(underlying.typeId)?.properties[key]:null;
        if(meta && val.kind==='literal' && val.value!==null && val.value!==undefined){
          const matches=meta.type==='enum'?meta.options?.includes(val.value):meta.type==='array'?Array.isArray(val.value):meta.type==='object'?plain(val.value):meta.type==='color'?typeof val.value==='string':typeof val.value===meta.type;
          ensure(matches,`Override Property 타입 오류: ${instance.id}.${nodeId}.${key}`);
        }
        const original=findNode(def.root,nodeId);
        const publicTarget=Object.values(def.publicProps||{}).some(spec=>spec.target?.nodeId===nodeId&&spec.target?.property===key);
        ensure(!publicTarget && !(original?.props?.[key]?.kind==='binding'&&original.props[key].source==='props'),`공개 Property와 충돌: ${instance.id}.${nodeId}.${key}`);
      }
    }
  }
  const visiting=new Set(),visited=new Set();
  function checkCycles(id){ensure(!visiting.has(id),`Definition 순환 참조: ${id}`);if(visited.has(id))return;visiting.add(id);walkNodes(doc.definitions[id].root,node=>{if(node.kind==='instance')checkCycles(node.definitionId);});visiting.delete(id);visited.add(id);}
  for(const id of Object.keys(doc.definitions))checkCycles(id);
  return doc;
}
export const serializeDocument=(doc,registry)=>JSON.stringify(validateDocument(doc,registry),null,2);
export const parseDocument=(text,registry)=>validateDocument(JSON.parse(text),registry);

export function createSearchBoxDocument(){
  return {
    format:'ui-studio',schemaVersion:SCHEMA_VERSION,title:'Framework Core · SearchBox',
    pages:{main:{id:'main',name:'SearchBox Demo',root:{id:'pageRoot',kind:'frame',name:'Page',layout:{type:'column',gap:24,padding:24},children:[
      {id:'demoTitle',kind:'component',typeId:'core/Text',props:{text:literal('SearchBox · 재사용 / TwoWay 바인딩')}},
      {id:'customerSearch',kind:'instance',definitionId:'SearchBox',name:'고객 검색',props:{placeholder:literal('고객명 입력')},bindings:{value:binding('state',['customer','keyword'],'TwoWay')},overrides:{}},
      {id:'productSearch',kind:'instance',definitionId:'SearchBox',name:'상품 검색',props:{placeholder:literal('상품명 입력')},bindings:{value:binding('state',['product','keyword'],'TwoWay')},overrides:{searchButton:{color:literal('#16a34a')}}}
    ]}}},
    definitions:{SearchBox:{id:'SearchBox',name:'SearchBox',version:'1.0.0',revision:1,root:{id:'searchRoot',kind:'frame',name:'SearchBox',layout:{type:'row',gap:8,padding:0},children:[
      {id:'searchInput',kind:'component',typeId:'core/Input',props:{value:binding('props',['value'],'TwoWay'),placeholder:binding('props',['placeholder'],'OneWay')}},
      {id:'searchButton',kind:'component',typeId:'core/Button',props:{text:literal('검색'),variant:literal('primary'),color:literal('#3764df')},events:{click:{kind:'emit',event:'search'}}}
    ]},publicProps:{
      value:{type:'string',defaultValue:'',bindable:true,twoWay:true,target:{nodeId:'searchInput',property:'value'}},
      placeholder:{type:'string',defaultValue:'검색어 입력',bindable:true,twoWay:false,target:{nodeId:'searchInput',property:'placeholder'}}
    },publicEvents:{search:{nodeId:'searchButton',event:'click'}},overridePolicy:{searchButton:['color','text']}}},
    data:{state:{customer:{keyword:''},product:{keyword:''}},sources:{}},resources:{}
  };
}

/** One-directional migration: legacy Designer v5 remains unchanged and can be opened separately. */
export function migrateV5ToV6(old){
  ensure(old?.format==='ui-studio-canvas'&&old.schemaVersion===5,'v5 프로젝트가 아닙니다');
  function valueOf(k,v){
    if(typeof v==='string'&&/^\{\{\s*(state|sources)(?:\.[A-Za-z_$][\w$]*)+\s*\}\}$/.test(v)){
      const text=v.slice(2,-2).trim().split('.');return binding(text[0],text.slice(1),k==='value'?'TwoWay':'OneWay');
    }
    return literal(v);
  }
  function convert(n){
    if(n.kind==='frame')return {id:n.id,kind:'frame',name:n.name,layout:{type:n.layout==='row'&&n.wrap?'wrap':n.layout,gap:n.gap||0,padding:n.padding||0,columns:n.columns||2,align:n.align||'stretch',background:n.background||'transparent'},children:(n.children||[]).map(convert)};
    if(n.kind==='instance')return {id:n.id,kind:'instance',name:n.name,definitionId:n.moduleId,props:{},bindings:{},overrides:{}};
    const props={};for(const [k,v] of Object.entries(n.props||{})){
      const to=k==='valueBinding'?'value':k==='rowsBinding'?'dataSource':k==='filterBinding'?'filter':k;
      props[to]=valueOf(to,v);
    }
    return {id:n.id,kind:'component',name:n.name,typeId:`core/${n.component}`,props};
  }
  const defs=Object.fromEntries(Object.entries(old.modules||{}).map(([id,m])=>[id,{id,name:m.name,version:String(m.version||1)+'.0.0',revision:m.revision||0,root:convert(m.root),publicProps:{},publicEvents:{},overridePolicy:{}}]));
  return {format:'ui-studio',schemaVersion:6,title:old.title||'Imported',pages:{main:{id:'main',name:old.root.name||'Page',root:convert(old.root)}},definitions:defs,data:structuredClone(old.data),resources:{},migration:{from:5}};
}
