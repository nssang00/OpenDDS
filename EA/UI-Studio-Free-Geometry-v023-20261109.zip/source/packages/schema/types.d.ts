/** Stable public contract for the v6 JSON data model. */
export type Path = readonly (string | number)[];
export type DataSource = 'state' | 'sources' | 'context' | 'props' | 'local';
export type PropertyValue<T = unknown> =
  | {kind:'literal'; value:T}
  | {kind:'binding'; source:DataSource; path:Path; mode:'OneWay'|'TwoWay'; updateOn?:'change'|'blur'}
  | {kind:'resource'; key:string};
export interface Layout {type:'row'|'column'|'grid'|'wrap'|'overlay'|'free'; gap?:number; padding?:number; columns?:number; align?:'stretch'|'start'|'center'|'end'; background?:string;fluid?:boolean}
export interface Geometry {position?:{x:number;y:number};size?:{width?:number;height?:number};anchors?:{horizontal?:'left'|'right';vertical?:'top'|'bottom'}}
export interface FrameNode extends Geometry {id:string; kind:'frame'; name?:string; layout:Layout; children:UINode[]}
export interface ControlNode extends Geometry {id:string; kind:'component'; name?:string; typeId:string; props:Record<string,PropertyValue>; events?:Record<string,{kind:'emit';event:string}>}
export interface InstanceNode extends Geometry {id:string;kind:'instance';name?:string;definitionId:string;props?:Record<string,PropertyValue>;bindings?:Record<string,Extract<PropertyValue,{kind:'binding'}>>;overrides?:Record<string,Record<string,PropertyValue>>;dataContext?:{source:DataSource;path:Path}}
export type UINode=FrameNode|ControlNode|InstanceNode;
export interface PublicProperty {type:string;defaultValue?:unknown;bindable?:boolean;twoWay?:boolean;target:{nodeId:string;property:string}}
export interface ComponentDefinition {id:string;name:string;version:string;revision:number;root:FrameNode;publicProps:Record<string,PublicProperty>;publicEvents:Record<string,{nodeId:string;event:string}>;overridePolicy:Record<string,string[]>}
export interface UIDocument {format:'ui-studio';schemaVersion:6;title:string;pages:Record<string,{id:string;name:string;root:FrameNode}>;definitions:Record<string,ComponentDefinition>;data:{state:Record<string,unknown>;sources:Record<string,unknown>};resources:Record<string,unknown>}
