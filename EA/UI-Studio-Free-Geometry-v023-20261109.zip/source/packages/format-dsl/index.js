/** Safe JSX-shaped v6 DSL; never evaluates JavaScript. Operates on a single page tree. */
import {literal,binding,validateDocument} from '../schema/index.js';
const tags={Page:'column',Frame:'column',Column:'column',Row:'row',Grid:'grid',Wrap:'wrap',Overlay:'overlay',Free:'free'};
const ID=/^[A-Za-z_][\w:./-]{0,127}$/;
const attr=(key,val)=>` ${key}=${typeof val==='string'?JSON.stringify(val):`{${JSON.stringify(val)}}`}`;
const tagName=n=>n.kind==='frame'?({row:'Row',column:'Column',grid:'Grid',wrap:'Wrap',overlay:'Overlay',free:'Free'})[n.layout.type]:n.kind==='instance'?'Use':n.typeId.split('/').at(-1);
export function printV6Dsl(root){
  const ranges={};let text='';
  const walk=(node,depth,asPage=false)=>{
    const start=text.length,tag=asPage?'Page':tagName(node),pad='  '.repeat(depth);
    let line=pad+`<${tag}`;
    const attrs=[['id',node.id]];
    if(node.name)attrs.push(['name',node.name]);
    if(node.size&&Object.keys(node.size).length)attrs.push(['size',node.size]);
    if(node.position)attrs.push(['position',node.position]);
    if(node.anchors)attrs.push(['anchors',node.anchors]);
    if(node.when!==undefined)attrs.push(['when',node.when]);
    if(node.repeat!==undefined)attrs.push(['repeat',node.repeat]);
    if(node.kind==='frame'){
      if(asPage)attrs.push(['layout',node.layout.type]);
      for(const [key,value] of Object.entries(node.layout))if(key!=='type'&&value!==undefined)attrs.push([key,value]);
    }else if(node.kind==='component'){
      for(const [key,val] of Object.entries(node.props||{}))attrs.push([key,val.kind==='literal'?val.value:val]);
      if(node.events&&Object.keys(node.events).length)attrs.push(['events',node.events]);
    }else{
      attrs.push(['definitionId',node.definitionId]);
      for(const k of ['props','bindings','overrides','slots','dataContext'])if(node[k]&&Object.keys(node[k]).length)attrs.push([k,node[k]]);
    }
    for(const [key,value] of attrs)line+=attr(key,value);
    if(node.kind!=='frame'){text+=line+' />\n';ranges[node.id]={start,end:text.length};return;}
    text+=line+'>\n';
    for(const child of node.children)walk(child,depth+1);
    text+=pad+`</${tag}>\n`;ranges[node.id]={start,end:text.length};
  };
  walk(root,0,true);return {text,ranges};
}
export class V6DslError extends Error {constructor(message,pos,source){const line=source.slice(0,pos).split('\n').length;super(`${message} (${line}:${pos-source.lastIndexOf('\n',pos-1)})`);this.pos=pos;}}
class Reader{
  constructor(text,registry,definitions){this.s=text;this.i=0;this.ids=new Set();this.auto=0;this.registry=registry;this.definitions=definitions;this.ranges={};}
  fail(message){throw new V6DslError(message,this.i,this.s);}
  ws(){while(this.i<this.s.length){if(/\s/.test(this.s[this.i])){this.i++;continue;}if(this.s.startsWith('<!--',this.i)){const j=this.s.indexOf('-->',this.i+4);if(j<0)this.fail('주석을 닫아야 합니다');this.i=j+3;continue;}if(this.s.startsWith('{/*',this.i)){const j=this.s.indexOf('*/}',this.i+3);if(j<0)this.fail('주석을 닫아야 합니다');this.i=j+3;continue;}break;}}
  id(){const m=this.s.slice(this.i).match(/^[A-Za-z_][A-Za-z0-9_-]*/);if(!m)this.fail('태그 또는 속성 이름이 필요합니다');this.i+=m[0].length;return m[0];}
  string(){
    const quote=this.s[this.i++];let raw='';let escaped=false;
    while(this.i<this.s.length){const c=this.s[this.i++];
      if(escaped){raw+='\\'+c;escaped=false;continue;}
      if(c==='\\'){escaped=true;continue;}
      if(c===quote){
        try {return JSON.parse('"'+(quote==='"'?raw:raw.replace(/\\'/g,"'").replaceAll('"','\\"'))+'"');}
        catch {this.fail('문자열 값이 올바르지 않습니다');}
      }
      raw+=c;
    }
    this.fail('문자열이 닫히지 않았습니다');
  }
  object(){const begin=++this.i;let level=1,quote=null,escaped=false;while(this.i<this.s.length){const c=this.s[this.i++];if(quote){if(escaped){escaped=false;continue;}if(c==='\\'){escaped=true;continue;}if(c===quote)quote=null;continue;}if(c==='"'||c==="'"){quote=c;continue;}if(c==='{')level++;else if(c==='}'&&--level===0){try{return JSON.parse(this.s.slice(begin,this.i-1).trim());}catch{this.fail('속성 중괄호는 JSON 값만 허용합니다 (JavaScript 실행 금지)');}}}this.fail('닫는 중괄호가 없습니다');}
  node(depth=0){if(depth>28)this.fail('중첩 깊이 초과');this.ws();const start=this.i;if(this.s[this.i++]!=='<'||this.s[this.i]==='/')this.fail('열린 태그가 필요합니다');const tag=this.id();
    const isFrame=Object.hasOwn(tags,tag),isUse=tag==='Use',typeId=`core/${tag}`;
    if(!isFrame&&!isUse&&!this.registry.has(typeId))this.fail(`등록되지 않은 Control: ${tag}`);
    const attrs={};let self=false;
    while(true){this.ws();if(this.s.startsWith('/>',this.i)){this.i+=2;self=true;break;}if(this.s[this.i]==='>'){this.i++;break;}if(this.i>=this.s.length)this.fail('태그가 닫히지 않았습니다');const key=this.id();if(Object.hasOwn(attrs,key))this.fail('중복 속성: '+key);this.ws();if(this.s[this.i++]!=='=')this.fail('속성은 = 값으로 지정합니다');this.ws();const c=this.s[this.i];if(c==='"'||c==="'")attrs[key]=this.string();else if(c==='{')attrs[key]=this.object();else this.fail('속성은 문자열 또는 {JSON} 형식이어야 합니다');}
    const id=attrs.id??attrs.nodeId??`dsl_${++this.auto}`;if(typeof id!=='string'||!ID.test(id)||this.ids.has(id))this.fail('잘못되었거나 중복된 ID: '+id);this.ids.add(id);
    let node;
    if(isFrame){const layoutType=tag==='Page'||tag==='Frame'?attrs.layout??'column':tags[tag];const layout={type:layoutType};for(const key of ['gap','padding','columns','align','background','fluid'])if(attrs[key]!==undefined)layout[key]=attrs[key];node={id,kind:'frame',...(attrs.name!==undefined?{name:attrs.name}:{}),layout,children:[]};const valid=new Set(['id','nodeId','name','layout','gap','padding','columns','align','background','fluid','size','position','anchors','when','repeat']);for(const key of Object.keys(attrs))if(!valid.has(key))this.fail('레이아웃 속성 오류: '+key);}
    else if(isUse){const definitionId=attrs.definitionId??attrs.moduleId;if(typeof definitionId!=='string'||!this.definitions[definitionId])this.fail('없는 Definition: '+definitionId);node={id,kind:'instance',...(attrs.name!==undefined?{name:attrs.name}:{}),definitionId,props:attrs.props??{},bindings:attrs.bindings??{},overrides:attrs.overrides??{},...(attrs.slots?{slots:attrs.slots}:{})};if(attrs.dataContext)node.dataContext=attrs.dataContext;const valid=new Set(['id','nodeId','name','definitionId','moduleId','props','bindings','overrides','slots','dataContext','size','position','anchors','when','repeat']);for(const key of Object.keys(attrs))if(!valid.has(key))this.fail('인스턴스 속성 오류: '+key);}
    else {const def=this.registry.get(typeId),props={};for(const [key,val] of Object.entries(attrs)){
      if(['id','nodeId','name','events','size','position','anchors','when','repeat'].includes(key))continue;
      if(!def.properties[key])this.fail(`미등록 속성: ${tag}.${key}`);
      const matched=typeof val==='string'?val.match(/^\{\{\s*(state|sources|context|props|local)\.([\w.]+)\s*\}\}$/):null;
      if(matched){const mode=def.properties[key].twoWay?'TwoWay':'OneWay';props[key]=binding(matched[1],matched[2].split('.'),mode);}
      else props[key]=val&&typeof val==='object'&&['literal','binding','resource'].includes(val.kind)?val:literal(val);
    }node={id,kind:'component',...(attrs.name!==undefined?{name:attrs.name}:{}),typeId,props};if(attrs.events)node.events=attrs.events;}
    if(attrs.size!==undefined)node.size=attrs.size;
    if(attrs.position!==undefined)node.position=attrs.position;
    if(attrs.anchors!==undefined)node.anchors=attrs.anchors;
    if(attrs.when!==undefined)node.when=attrs.when;
    if(attrs.repeat!==undefined)node.repeat=attrs.repeat;
    if(isFrame){if(!self){while(true){this.ws();if(this.s.startsWith('</',this.i)){this.i+=2;const closing=this.id();this.ws();if(this.s[this.i++]!=='>')this.fail('닫는 태그 >가 필요합니다');if(closing!==tag)this.fail(`</${tag}>가 필요합니다`);break;}if(this.i>=this.s.length)this.fail(`</${tag}>가 필요합니다`);node.children.push(this.node(depth+1));}}}
    else if(!self){this.ws();if(!this.s.startsWith('</',this.i))this.fail('컨트롤은 />로 닫아야 합니다');this.i+=2;const closing=this.id();if(closing!==tag||this.s[this.i++]!=='>')this.fail('잘못된 닫는 태그');}
    this.ranges[id]={start,end:this.i};return node;
  }
}
export function parseV6Dsl(source,doc,registry,pageId='main',definitionId=null){
  if(typeof source!=='string'||source.length>250000)throw Error('DSL 최대 250KB');const reader=new Reader(source,registry,doc.definitions);const root=reader.node();reader.ws();if(reader.i!==source.length)reader.fail('루트 뒤에 불필요한 내용');if(root.kind!=='frame')reader.fail('Page 또는 레이아웃이 루트여야 합니다');
  const next=structuredClone(doc);
  if(definitionId){if(!next.definitions[definitionId])throw Error('없는 Definition');next.definitions[definitionId].root=root;next.definitions[definitionId].revision=(next.definitions[definitionId].revision||0)+1;}
  else {if(!next.pages[pageId])throw Error('없는 페이지');next.pages[pageId].root=root;}
  return {document:validateDocument(next,registry),ranges:reader.ranges};
}
