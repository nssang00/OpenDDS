import {createComponentExportDocument} from '../core/workspace.js';

const jsName=/^[A-Z][A-Za-z0-9_]*$/;
const typeFor=(type)=>({string:'string',color:'string',enum:'string',number:'number',boolean:'boolean',array:'unknown[]',object:'Record<string, unknown>'}[type]||'unknown');
const cap=s=>s[0].toUpperCase()+s.slice(1);

/** Generate a portable React component with typed public API. No Studio App or page export. */
export function generateComponentSource(document,registry,definitionId){
  if(!jsName.test(definitionId))throw Error('React export 이름은 영문 대문자로 시작해야 합니다');
  const portable=createComponentExportDocument(document,definitionId,registry);
  const def=portable.definitions[definitionId];
  const fields=Object.entries(def.publicProps||{}),events=Object.keys(def.publicEvents||{});
  const callbackNames=new Set(fields.filter(([,spec])=>spec.twoWay).map(([key])=>`on${cap(key)}Change`));
  for(const event of events){if(callbackNames.has(`on${cap(event)}`))throw Error(`React 콜백 명칭 충돌: ${event}`);}
  const slots=Object.keys(def.slots||{});
  const slotPropName=name=>name==='content'?'children':name;
  if(new Set([...fields.map(([key])=>key),...slots.map(slotPropName)]).size!==fields.length+slots.length)throw Error('Slot과 공개 Property 이름이 충돌합니다');
  const declarations=[...slots.map(name=>`  ${slotPropName(name)}?: React.ReactNode;`),...fields.map(([key,spec])=>`  ${key}?: ${typeFor(spec.type)};`),
    ...fields.filter(([,spec])=>spec.twoWay).map(([key,spec])=>`  on${cap(key)}Change?: (nextValue: ${typeFor(spec.type)}) => void;`),
    ...events.map(event=>`  on${cap(event)}?: (payload: Record<string, unknown>) => void;`)];
  const initial=JSON.stringify(portable);
  return `/** Generated from UI Studio. Edit the original Definition in the Studio.
 * Includes all referenced child Definitions; no dependence on the Studio app.
 */
import React, { useEffect, useRef, useState } from 'react';
import { RuntimeSession, createDefaultRegistry } from './runtime/core/index.js';
import { RuntimeView } from './runtime/runtime-react/Runtime.jsx';
import { createAntdRenderer } from './runtime/renderer-antd/index.jsx';

export interface ${definitionId}Props {
${declarations.join('\n')}
}

const document = ${initial};
const registry = createDefaultRegistry();
const renderer = createAntdRenderer();
const defaults: Record<string, unknown> = ${JSON.stringify(Object.fromEntries(fields.map(([key,spec])=>[key,spec.defaultValue??null])))};
const names: string[] = ${JSON.stringify(fields.filter(([,spec])=>spec.bindable).map(([key])=>key))};
const staticNames: string[] = ${JSON.stringify(fields.filter(([,spec])=>!spec.bindable).map(([key])=>key))};
const twoWayNames: string[] = ${JSON.stringify(fields.filter(([,spec])=>spec.twoWay).map(([key])=>key))};
const slotNames: Record<string, string> = ${JSON.stringify(Object.fromEntries(slots.map(n=>[n,slotPropName(n)])))};

export default function ${definitionId}(props: ${definitionId}Props) {
  const [session] = useState(() => new RuntimeSession(document));
  const propsRef = useRef(props);
  const applyingProps = useRef(false);
  propsRef.current = props;

  // Parent React props -> independent ReactiveStore. Never emit change callbacks
  // when a controlled value is supplied or changed by the React parent.
  useEffect(() => {
    applyingProps.current = true;
    try {
      for (const key of names) {
        const raw = (props as unknown as Record<string, unknown>)[key];
        if (raw === undefined) continue; // Uncontrolled: preserve this instance's local value.
        const next = raw;
        if (!Object.is(session.state.get(['__component', key]), next)) {
          session.state.set(['__component', key], next);
        }
      }
    } finally { applyingProps.current = false; }
  });
  useEffect(() => {
    const unsubs = twoWayNames.map(key => session.state.subscribe(['__component', key], () => {
      if (applyingProps.current) return;
      const callbackName = 'on' + key[0].toUpperCase() + key.slice(1) + 'Change';
      const callback = (propsRef.current as unknown as Record<string, unknown>)[callbackName];
      if (typeof callback === 'function') (callback as (value: unknown) => void)(session.state.get(['__component', key]));
    }));
    return () => unsubs.forEach(unsubscribe => unsubscribe());
  }, [session]);

  const externalSlots: Record<string, React.ReactNode> = {};
  for (const [name,propName] of Object.entries(slotNames)) {
    const content=(props as unknown as Record<string, React.ReactNode>)[propName];
    if(content!==undefined) externalSlots[name]=content;
  }
  const externalProps: Record<string, unknown> = {};
  for(const name of staticNames){
    const value=(props as unknown as Record<string, unknown>)[name];
    if(value!==undefined)externalProps[name]=value;
  }
  return <RuntimeView document={document} session={session} registry={registry} renderer={renderer} externalSlots={externalSlots} externalProps={externalProps}
    onPublicEvent={(_nodeId: string, event: string, payload: Record<string, unknown>) => {
      if (_nodeId !== 'exportInstance') return; // Only expose this component's public API, not child events.
      const callbackName = 'on' + event[0].toUpperCase() + event.slice(1);
      const callback = (propsRef.current as unknown as Record<string, unknown>)[callbackName];
      if (typeof callback === 'function') (callback as (value: Record<string, unknown>) => void)(payload);
    }} />;
}
`;
}

/** sources is a map of repository paths to source text injected by the caller.
 * All referenced source files are bundled, never resolved from the Studio's app directory.
 */
export function createPortablePackageFiles(document,registry,definitionId,sources){
  if(!jsName.test(definitionId))throw Error('유효하지 않은 React 컴포넌트 이름');
  const code=generateComponentSource(document,registry,definitionId);
  const def=document.definitions[definitionId];
  const slots=Object.keys(def.slots||{});
  const slotNames=slots.map(name=>name==='content'?'children':name);
  if(new Set([...Object.keys(def.publicProps||{}),...slotNames]).size!==Object.keys(def.publicProps||{}).length+slotNames.length)throw Error('Slot과 공개 Property 이름이 충돌합니다');
  const declarations=[...slotNames.map(name=>`  ${name}?: import('react').ReactNode;`),...Object.entries(def.publicProps||{}).map(([key,spec])=>`  ${key}?: ${typeFor(spec.type)};`),
    ...Object.entries(def.publicProps||{}).filter(([,spec])=>spec.twoWay).map(([key,spec])=>`  on${cap(key)}Change?: (nextValue: ${typeFor(spec.type)}) => void;`),
    ...Object.keys(def.publicEvents||{}).map(event=>`  on${cap(event)}?: (payload: Record<string, unknown>) => void;`)];
  const types=`export interface ${definitionId}Props {\n${declarations.join('\n')}\n}\nexport declare function ${definitionId}(props: ${definitionId}Props): import('react').ReactElement | null;\n`;
  const files={
    [`src/${definitionId}.tsx`]:code,
    'src/index.ts':`export { default as ${definitionId} } from './${definitionId}';\nexport type { ${definitionId}Props } from './${definitionId}';\n`,
    'src/index.d.ts':types,
    'package.json':JSON.stringify({name:`ui-studio-${definitionId.replace(/([a-z])([A-Z])/g,'$1-$2').toLowerCase()}`,version:'0.1.0',private:false,type:'module',
      main:'./dist/index.js',module:'./dist/index.js',types:'./src/index.d.ts',
      exports:{'.':{types:'./src/index.d.ts',import:'./dist/index.js'}},files:['dist','src'],scripts:{build:'vite build'},
      peerDependencies:{react:'^19.0.0', 'react-dom':'^19.0.0'},
      dependencies:{antd:'^6.6.5'},devDependencies:{vite:'^7.0.0','@vitejs/plugin-react':'^5.0.0',typescript:'^5.9.3'}},null,2)+'\n',
    'vite.config.js':`import { defineConfig } from 'vite';\nimport react from '@vitejs/plugin-react';\nexport default defineConfig({plugins:[react()],build:{lib:{entry:'src/index.ts',formats:['es'],fileName:'index'},rollupOptions:{external:['react','react-dom','react/jsx-runtime','antd']}}});\n`,
    'README.md':`# ${definitionId}\n\nReusable React component generated by UI Studio.\n\n\`\`\`bash\nnpm install\nnpm run build\n\`\`\`\n\nPublic Props and events are declared in \`src/${definitionId}.tsx\`.\n\nImport \`{ ${definitionId} }\` from this local package in a React project. Pass props as normal React values; TwoWay UI bindings call \`on<Value>Change\` callbacks instead of mutating parent props.\n\nThis first exporter uses the Ant Design renderer and includes the lightweight UI Studio Core internally. It is independent of the Studio application, but not dependency-free.\n`,
    'tsconfig.json':JSON.stringify({compilerOptions:{target:'ES2022',module:'ESNext',moduleResolution:'Bundler',jsx:'react-jsx',strict:true,esModuleInterop:true,skipLibCheck:true,allowJs:true,allowImportingTsExtensions:true,noEmit:true},include:['src']},null,2)+'\n'
  };
  const needed=['packages/schema/index.js','packages/runtime-react/Runtime.jsx','packages/renderer-antd/index.jsx',
    'packages/core/index.js','packages/core/binding.js','packages/core/components.js','packages/core/document.js','packages/core/editor.js','packages/core/events.js','packages/core/layout.js','packages/core/properties.js','packages/core/registry.js','packages/core/session.js','packages/core/store.js','packages/core/workspace.js','packages/core/slots.js','packages/core/dynamic.js','packages/core/visual.js'];
  for(const path of needed){
    if(typeof sources[path]!=='string')throw Error(`누락된 런타임 소스: ${path}`);
    files[`src/runtime/${path.slice('packages/'.length)}`]=sources[path];
  }
  return files;
}
