/** Small uncompressed ZIP writer (UTF-8 file names, CRC32). Browser/Node portable. */
const encoder=new TextEncoder();
const crc32=bytes=>{let c=0xffffffff;for(const b of bytes){c^=b;for(let i=0;i<8;i++)c=c&1?(c>>>1)^0xedb88320:c>>>1;}return (c^0xffffffff)>>>0;};
const u16=(a,n)=>{a.push(n&255,n>>>8&255);};
const u32=(a,n)=>{a.push(n&255,n>>>8&255,n>>>16&255,n>>>24&255);};
export function encodeZip(files){
  const local=[],central=[];let offset=0,n=0;
  for(const [name,content] of Object.entries(files)){
    if(name.startsWith('/')||name.includes('..')||name.includes('\\'))throw Error('ZIP 내부 경로가 안전하지 않습니다');
    const filename=encoder.encode(name),data=encoder.encode(content),sum=crc32(data);
    if(filename.length>65535||data.length>0xffffffff)throw Error('ZIP 파일 크기 초과');
    const header=[];u32(header,0x04034b50);u16(header,20);u16(header,0x0800);u16(header,0);u16(header,0);u16(header,0);u32(header,sum);u32(header,data.length);u32(header,data.length);u16(header,filename.length);u16(header,0);
    local.push(new Uint8Array(header),filename,data);
    const cd=[];u32(cd,0x02014b50);u16(cd,20);u16(cd,20);u16(cd,0x0800);u16(cd,0);u16(cd,0);u16(cd,0);u32(cd,sum);u32(cd,data.length);u32(cd,data.length);u16(cd,filename.length);u16(cd,0);u16(cd,0);u16(cd,0);u16(cd,0);u32(cd,0);u32(cd,offset);
    central.push(new Uint8Array(cd),filename);
    offset+=header.length+filename.length+data.length;n++;
  }
  if(n>65535)throw Error('ZIP 파일 수 초과');
  const centralOffset=offset,centralSize=central.reduce((a,x)=>a+x.length,0);
  const tail=[];u32(tail,0x06054b50);u16(tail,0);u16(tail,0);u16(tail,n);u16(tail,n);u32(tail,centralSize);u32(tail,centralOffset);u16(tail,0);
  const all=[...local,...central,new Uint8Array(tail)],total=all.reduce((a,x)=>a+x.length,0),result=new Uint8Array(total);let pos=0;
  for(const chunk of all){result.set(chunk,pos);pos+=chunk.length;}return result;
}
