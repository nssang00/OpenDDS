import {binding} from '../schema/index.js';
/** Definition's public property targets are projected into internal property providers.
 * An instance override must never target the same property as a public mapping.
 */
export function instancePropertyProviders(definition,instance){
  const providers={};
  for(const [key,property] of Object.entries(definition.publicProps||{})){
    if(!property.target)continue;
    const {nodeId,property:targetKey}=property.target;
    (providers[nodeId]||={})[targetKey]=binding('props',[key],property.twoWay?'TwoWay':'OneWay');
  }
  for(const [nodeId,fields] of Object.entries(instance.overrides||{})){
    Object.assign(providers[nodeId]||={},fields);
  }
  return providers;
}

/** Apply parent Definition's public-property projection to a nested component Instance.
 * The provider is evaluated in the parent's DataContext, and therefore TwoWay
 * writes propagate through any number of nested UserControls.
 */
export function projectNestedInstance(instance,overrides={}){
  const assigned=overrides?.[instance.id];
  if(!assigned)return instance;
  const props={...instance.props},bindings={...instance.bindings};
  for(const [key,provider] of Object.entries(assigned)){
    if(provider.kind==='binding'){bindings[key]=provider;delete props[key];}
    else {props[key]=provider;delete bindings[key];}
  }
  return {...instance,props,bindings};
}
