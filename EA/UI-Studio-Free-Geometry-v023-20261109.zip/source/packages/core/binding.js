import {safePath} from '../schema/index.js';
export class DataContext {
  constructor(stores={},parent=null){this.stores=stores;this.parent=parent;}
  resolve(source){return this.stores[source]||this.parent?.resolve(source);}
  child(stores){return new DataContext(stores,this);}
}
export function readBinding(binding,scope){
  if(!safePath(binding.path))throw Error('바인딩 경로 오류');
  return scope.resolve(binding.source)?.get(binding.path);
}
export function writeBinding(binding,scope,value,phase='change'){
  if(binding.mode!=='TwoWay')throw Error('OneWay 속성에는 쓸 수 없습니다');
  if(binding.updateOn==='blur'&&phase!=='blur')return false;
  const store=scope.resolve(binding.source);if(!store)throw Error(`데이터 소스 없음: ${binding.source}`);
  store.set(binding.path,value);return true;
}
export function readProperty(value,scope,resources={}){
  if(!value)return undefined;
  switch(value.kind){
    case 'literal':return value.value;
    case 'binding':return readBinding(value,scope);
    case 'resource':return resources[value.key];
    default:throw Error('속성 값 종류가 유효하지 않습니다');
  }
}
export function subscribeProperty(value,scope,fn){
  if(value?.kind!=='binding')return()=>{};
  return scope.resolve(value.source)?.subscribe(value.path,fn) || (()=>{});
}
