/** Keyboard decisions are pure, so shortcuts can be tested separately from React. */
export function editorShortcut({key='',ctrlKey=false,metaKey=false,altKey=false,shiftKey=false,repeat=false}={}, {design=true,modalOpen=false,editable=false,inside=true}={}){
  if(!inside||editable||modalOpen||repeat)return null;
  if(design&&altKey&&!ctrlKey&&!metaKey&&!shiftKey){
    if(key==='ArrowUp')return 'move-up';
    if(key==='ArrowDown')return 'move-down';
  }
  if(altKey)return null;
  const command=ctrlKey||metaKey,normal=String(key).toLowerCase();
  if(command&&normal==='z')return shiftKey?'redo':'undo';
  if(command&&normal==='y'&&!shiftKey)return 'redo';
  if(design&&command&&normal==='d'&&!shiftKey)return 'duplicate';
  if(design&&!command&&!shiftKey&&(normal==='delete'||normal==='backspace'))return 'delete';
  return null;
}
