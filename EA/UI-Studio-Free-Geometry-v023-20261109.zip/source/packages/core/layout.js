/** Semantic CSS mapping; the browser remains responsible for layout measurement. */
export function frameStyle(layout){
  const {type,gap=0,padding=0,columns=2,align='stretch',background='transparent'}=layout;
  const result={minWidth:0,gap,padding,background,alignItems:align};
  if(type==='free'){return {position:'relative',display:'block',minWidth:0,background,padding:0,overflow:'visible'};}
  if(type==='grid'){return {...result,display:'grid',gridTemplateColumns:`repeat(${columns}, minmax(0, 1fr))`};}
  if(type==='overlay'){return {...result,display:'grid',gridTemplateColumns:'minmax(0, 1fr)',gap:0};}
  return {...result,display:'flex',flexDirection:type==='column'?'column':'row',flexWrap:type==='wrap'?'wrap':'nowrap'};
}

/** Position only immediate children of a Free Frame; other nodes stay in normal flow. */
export function freeChildStyle(node, parentFrame=null){
  const {x=0,y=0}=node.position||{};
  const style={position:'absolute'};
  if(node.anchors?.horizontal==='right' && parentFrame?.size?.width !== undefined && node.size?.width !== undefined)
    style.right=parentFrame.size.width-x-node.size.width;
  else style.left=x;
  if(node.anchors?.vertical==='bottom' && parentFrame?.size?.height !== undefined && node.size?.height !== undefined)
    style.bottom=parentFrame.size.height-y-node.size.height;
  else style.top=y;
  return style;
}

/** The frame width scales down to its container, while authored size remains the anchor reference. */
export function freeFrameSizeStyle(node){
  if(node.kind!=='frame'||node.layout.type!=='free'||!node.layout.fluid)return node.size||{};
  return {...node.size,width:'100%',maxWidth:node.size?.width??640,minWidth:0};
}
