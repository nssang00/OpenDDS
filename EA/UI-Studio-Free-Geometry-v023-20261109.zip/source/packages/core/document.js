import {findNode,validateDocument} from '../schema/index.js';
/** Document edits are pure; runtime state belongs to RuntimeSession. */
export function patchDefinitionProperty(document,definitionId,nodeId,property,value,registry){
  const next=structuredClone(document),def=next.definitions[definitionId];
  if(!def)throw Error('정의가 존재하지 않습니다');
  const node=findNode(def.root,nodeId);
  if(!node||node.kind!=='component')throw Error('컴포넌트를 찾지 못했습니다');
  if(!registry.get(node.typeId)?.properties[property])throw Error('등록되지 않은 속성입니다');
  node.props={...node.props,[property]:value};def.revision=(def.revision||0)+1;
  return validateDocument(next,registry);
}
function findInstance(next,instanceId,scope='main'){
  const root=scope.startsWith('definition:')
    ?next.definitions[scope.slice('definition:'.length)]?.root
    :next.pages[scope]?.root;
  if(!root)throw Error(`없는 편집 범위: ${scope}`);
  const found=findNode(root,instanceId);
  if(found?.kind!=='instance')throw Error('현재 편집 범위에서 인스턴스를 찾을 수 없습니다');
  return found;
}
function touch(next,scope){if(scope.startsWith('definition:')){
  const def=next.definitions[scope.slice('definition:'.length)];def.revision=(def.revision||0)+1;
}}
export function patchInstanceBinding(document,instanceId,key,value,registry,scope='main'){
  const next=structuredClone(document);
  const node=findInstance(next,instanceId,scope);node.bindings={...node.bindings,[key]:value};if(node.props)delete node.props[key];
  touch(next,scope);return validateDocument(next,registry);
}
export function patchInstanceOverride(document,instanceId,nodeId,key,value,registry,scope='main'){
  const next=structuredClone(document);
  const instance=findInstance(next,instanceId,scope);
  const overrides={...instance.overrides};const attrs={...(overrides[nodeId]||{})};
  if(value===null)delete attrs[key];else attrs[key]=value;
  if(Object.keys(attrs).length)overrides[nodeId]=attrs;else delete overrides[nodeId];
  instance.overrides=overrides;touch(next,scope);return validateDocument(next,registry);
}

export function patchInstanceProp(document,instanceId,key,value,registry,scope='main'){
  const next=structuredClone(document);
  const instance=findInstance(next,instanceId,scope);
  instance.props={...instance.props,[key]:value};
  if(instance.bindings)delete instance.bindings[key];
  touch(next,scope);return validateDocument(next,registry);
}
