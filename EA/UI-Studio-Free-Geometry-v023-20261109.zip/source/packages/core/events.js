/** Public events are explicitly mapped; internal events never leak by name alone. */
export function matchesPublicEvent(definition,publicEvent,sourceNodeId,sourceEvent){
  const spec=definition.publicEvents?.[publicEvent];
  return !!spec && spec.nodeId===sourceNodeId && spec.event===sourceEvent;
}
