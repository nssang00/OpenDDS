import type {Path,PropertyValue,DataSource} from '../schema/types';
export interface PropertyMetadata {type:'string'|'number'|'boolean'|'enum'|'color'|'object'|'array';defaultValue?:unknown;bindable?:boolean;twoWay?:boolean;editor?:string;options?:string[]}
export interface ControlDefinition {typeId:string;displayName:string;category:string;properties:Record<string,PropertyMetadata>;events:Record<string,{payloadType?:string}>}
export interface ControlRegistryContract {register(control:ControlDefinition):ControlDefinition;get(id:string):ControlDefinition|undefined;has(id:string):boolean;list():ControlDefinition[]}
export interface ReactiveStoreContract {get(path:Path):unknown;set(path:Path,value:unknown):void;subscribe(path:Path,callback:()=>void):()=>void}
export interface DataContextContract {resolve(source:DataSource):ReactiveStoreContract|undefined}
export interface ReactRendererAdapter {register(typeId:string,component:unknown):void;get(typeId:string):unknown}
export type PropertyResolver=(property:PropertyValue,context:DataContextContract,resources?:Record<string,unknown>)=>unknown;
