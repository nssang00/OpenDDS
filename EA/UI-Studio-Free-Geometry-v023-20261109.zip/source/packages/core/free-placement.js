/** Pure geometry for WPF-like Free Frame editing. No DOM, React or registry dependency. */
import {pageRoot,locateNode} from './editor.js';
import {validateDocument} from '../schema/index.js';

export function freeGroupIds(root,ids){
  if(!Array.isArray(ids)||ids.length<2||new Set(ids).size!==ids.length) return null;
  const locations=ids.map(id=>locateNode(root,id));
  if(locations.some(loc=>!loc?.parent||loc.parent.kind!=='frame'||loc.parent.layout.type!=='free'))return null;
  const parent=locations[0].parent;
  return locations.every(loc=>loc.parent===parent&&loc.node.position)?{parent,locations}:null;
}

/** Translate selected direct siblings together by the primary node's snapped delta. */
export function moveFreeGroup(doc,ids,primaryId,primaryPosition,registry,scope='main'){
  const next=structuredClone(doc),root=pageRoot(next,scope),group=freeGroupIds(root,ids);
  if(!group||!ids.includes(primaryId))throw Error('같은 Free Frame의 형제 요소 두 개 이상을 선택하세요');
  if(!Number.isFinite(primaryPosition?.x)||!Number.isFinite(primaryPosition?.y))throw Error('그룹 위치 오류');
  const primary=group.locations.find(loc=>loc.node.id===primaryId).node;
  const dx=Math.round(primaryPosition.x)-primary.position.x,dy=Math.round(primaryPosition.y)-primary.position.y;
  for(const {node} of group.locations){
    const x=node.position.x+dx,y=node.position.y+dy;
    if(x<0||y<0||x>5000||y>5000)throw Error('선택 요소가 Free Frame의 좌표 범위를 벗어납니다');
    node.position={x,y};
  }
  if(scope.startsWith('definition:'))next.definitions[scope.slice(11)].revision++;
  return validateDocument(next,registry);
}

/** Align selected Free siblings without changing their stacking order or IDs. */
export function alignFreeGroup(doc,ids,axis,registry,scope='main'){
  const next=structuredClone(doc),group=freeGroupIds(pageRoot(next,scope),ids);
  if(!group||!['left','top','right','bottom'].includes(axis))throw Error('Free Frame 정렬: 동일 부모의 여러 요소를 선택하세요');
  const nodes=group.locations.map(loc=>loc.node);
  const dimension=(node,key)=>node.size?.[key]??(key==='width'?100:36);
  const target=axis==='left'?Math.min(...nodes.map(n=>n.position.x)):
    axis==='top'?Math.min(...nodes.map(n=>n.position.y)):
    axis==='right'?Math.max(...nodes.map(n=>n.position.x+dimension(n,'width'))):
    Math.max(...nodes.map(n=>n.position.y+dimension(n,'height')));
  for(const node of nodes){
    const pos={...node.position};
    if(axis==='left')pos.x=target;
    if(axis==='top')pos.y=target;
    if(axis==='right')pos.x=target-dimension(node,'width');
    if(axis==='bottom')pos.y=target-dimension(node,'height');
    node.position=pos;
  }
  if(scope.startsWith('definition:'))next.definitions[scope.slice(11)].revision++;
  return validateDocument(next,registry);
}

/** Nearest sibling edge/centre snap; grid snapping is the caller's fallback. */
export function snapFreeAlignment(point,subject,siblings,{threshold=6,excludeIds=[]}={}){
  if(!point||!Number.isFinite(point.x)||!Number.isFinite(point.y))throw Error('정렬 위치 오류');
  const ignored=new Set(excludeIds);
  const items=(siblings||[]).filter(s=>!ignored.has(s.id)&&s.width>=0&&s.height>=0&&Number.isFinite(s.x)&&Number.isFinite(s.y));
  const result={position:{...point},guides:[]};
  for(const [axis,measure] of [['x','width'],['y','height']]){
    const length=subject[measure]??0;
    let best=null;
    for(const item of items){
      const targets=[item[axis],item[axis]+item[measure]/2,item[axis]+item[measure]];
      const origins=[0,length/2,length];
      for(const target of targets)for(const offset of origins){
        const delta=target-(point[axis]+offset);
        if(Math.abs(delta)>threshold)continue;
        if(!best||Math.abs(delta)<Math.abs(best.delta))best={delta,coordinate:target,targetId:item.id};
      }
    }
    if(best){result.position[axis]=Math.max(0,Math.min(5000,Math.round(point[axis]+best.delta)));result.guides.push({axis,coordinate:best.coordinate,targetId:best.targetId});}
  }
  return result;
}
