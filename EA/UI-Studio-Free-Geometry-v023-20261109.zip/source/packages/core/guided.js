/** Guided component authoring built entirely on the canonical v6 commands.
 * This module is deliberately UI-framework agnostic. No parallel editor state.
 */
import {literal,validateDocument,walkNodes} from '../schema/index.js';
import {createComponentDefinition,createBlankComponentWorkspace} from './workspace.js';
import {createEditorNode,insertEditorNode,exposeDefinitionProperty,exposeDefinitionEvent} from './editor.js';

const CONNECTION_FIELDS={
  'core/Input':['value','placeholder'],
  'core/Checkbox':['checked','text'],
  'core/Button':['text','disabled'],
  'core/Text':['text'],
  'core/Card':['title','description'],
  'core/Tag':['text']
};
const IDENTIFIER=/^[A-Za-z_][A-Za-z0-9_]{0,63}$/;
const unique=(base,used)=>{
  let candidate=base,index=2;
  while(used.has(candidate))candidate=`${base}${index++}`;
  used.add(candidate);return candidate;
};

/** Creates a starter component in-place or in a fresh workspace.
 * The search recipe is normal v6 nodes + public API, not a locked template.
 */
export function createGuidedComponent(doc,name,registry,{template='blank',fresh=false}={}){
  if(!['blank','search'].includes(template))throw Error(`지원하지 않는 시작 템플릿: ${template}`);
  let next=fresh?createBlankComponentWorkspace(name,registry):createComponentDefinition(doc,name,registry);
  if(template==='blank')return next;
  const scope=`definition:${name}`,root=next.definitions[name].root.id;
  const row=createEditorNode(next,'layout/row',registry);
  row.name='검색창 레이아웃';row.layout={...row.layout,gap:8,align:'center'};
  next=insertEditorNode(next,root,0,row,registry,scope);
  const input=createEditorNode(next,'core/Input',registry);
  input.name='검색어 입력';input.props={...input.props,placeholder:literal('검색어 입력')};
  next=insertEditorNode(next,row.id,0,input,registry,scope);
  const button=createEditorNode(next,'core/Button',registry);
  button.name='검색 버튼';button.props={...button.props,text:literal('검색'),variant:literal('primary')};
  next=insertEditorNode(next,row.id,1,button,registry,scope);
  next=exposeDefinitionProperty(next,name,input.id,'value','value',registry);
  next=exposeDefinitionProperty(next,name,input.id,'placeholder','placeholder',registry);
  next=exposeDefinitionEvent(next,name,button.id,'click','search',registry);
  return validateDocument(next,registry);
}

/** Produces ready-to-apply intent-first suggestions for the selected node.
 * Existing public targets are excluded so clicking twice cannot create duplicates.
 */
export function guidedConnectionSuggestions(doc,definitionId,nodeId,registry){
  const def=doc.definitions?.[definitionId];if(!def)return [];
  let selected;
  walkNodes(def.root,node=>{if(node.id===nodeId)selected=node;});
  if(!selected||selected.kind!=='component')return [];
  const meta=registry.get(selected.typeId);if(!meta)return [];
  const exposedTargets=new Set(Object.values(def.publicProps||{}).filter(p=>p.target).map(p=>`${p.target.nodeId}:${p.target.property}`));
  const exposedEvents=new Set(Object.values(def.publicEvents||{}).map(p=>`${p.nodeId}:${p.event}`));
  const used=new Set([...Object.keys(def.publicProps||{}),...Object.keys(def.publicEvents||{})]);
  const results=[];
  for(const field of CONNECTION_FIELDS[selected.typeId]||[]){
    if(!meta.properties[field]||exposedTargets.has(`${nodeId}:${field}`))continue;
    const base=selected.typeId==='core/Button'&&field==='text'?'buttonText':field;
    const name=unique(base,used);
    const twoWay=!!meta.properties[field].twoWay;
    results.push({type:'prop',sourceKey:field,publicName:name,
      label:twoWay?`입력값 ${name}을 외부에서 제어`:`${field} 속성을 외부에서 변경`,
      detail:twoWay?`React Prop ${name} 및 on${name[0].toUpperCase()+name.slice(1)}Change 생성`:`React Prop ${name} 생성`});
  }
  for(const event of Object.keys(meta.events||{})){
    // Native exporter currently maps Input/Checkbox changes via two-way Props,
    // not an extra event emitter. Do not suggest actions that block Native TSX.
    if(selected.typeId!=='core/Button'||event!=='click')continue;
    if(exposedEvents.has(`${nodeId}:${event}`))continue;
    const buttonText=selected.props?.text?.kind==='literal'?String(selected.props.text.value):'';
    const base=event==='click'&&selected.typeId==='core/Button'&&/검색|search/i.test(buttonText)?'search':event;
    const name=unique(base,used);
    results.push({type:'event',sourceKey:event,publicName:name,
      label:`${event==='click'?'클릭':event==='change'?'값 변경':event} 시 부모에게 알리기`,
      detail:`React callback on${name[0].toUpperCase()+name.slice(1)} 생성`});
  }
  return results;
}

export function applyGuidedConnection(doc,definitionId,nodeId,suggestion,registry){
  const candidates=guidedConnectionSuggestions(doc,definitionId,nodeId,registry);
  const allowed=candidates.find(c=>c.type===suggestion?.type&&c.sourceKey===suggestion?.sourceKey&&c.publicName===suggestion?.publicName);
  if(!allowed||!IDENTIFIER.test(allowed.publicName))throw Error('이미 연결됐거나 사용할 수 없는 연결입니다. 추천 목록을 다시 확인하세요.');
  if(allowed.type==='prop')return exposeDefinitionProperty(doc,definitionId,nodeId,allowed.sourceKey,allowed.publicName,registry);
  return exposeDefinitionEvent(doc,definitionId,nodeId,allowed.sourceKey,allowed.publicName,registry);
}

export function guidedComponentSummary(doc,definitionId){
  const def=doc.definitions?.[definitionId];if(!def)return null;
  let controls=0,layouts=0,instances=0;
  walkNodes(def.root,node=>{if(node.kind==='component')controls++;else if(node.kind==='frame')layouts++;else if(node.kind==='instance')instances++;});
  return {name:definitionId,controls,layouts,instances,
    props:Object.keys(def.publicProps||{}),events:Object.keys(def.publicEvents||{}),slots:Object.keys(def.slots||{})};
}
