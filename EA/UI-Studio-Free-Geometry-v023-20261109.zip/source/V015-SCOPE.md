# UI Studio v0.15 — Editing UX

Derived from verified v0.14 baseline (GitHub Actions run 40063374176).

Scope:
- Selection breadcrumbs: page/definition root -> selected node, including nested frames and slot content.
- One-click duplicate next to selected node: recursively fresh IDs and preserved values, bindings, events and instance slots. Root duplication is forbidden.
- Editing shortcuts: Ctrl/Cmd+D duplicate in Design, Delete/Backspace remove, Ctrl/Cmd+Z Undo, Ctrl/Cmd+Shift+Z or Ctrl+Y Redo. Text inputs, contenteditable, Code/JSON and modals are protected.
- Buttons for duplicate and delete in selection toolbar; Undo/Redo disabled when no entries.
- No changes to canonical v6 representation, runtime bindings, React exporter semantics or untrusted code execution policy.

Verification contract: existing 183 Core tests + new editing Core tests; existing 11 Studio Chrome scenarios + two new v0.15 scenarios; independent Consumer Chrome test, standalone component build, syntax & runtime integration.

This is a bounded editing-UX milestone, not a comprehensive usability or security certification.
