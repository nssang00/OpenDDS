# UI Studio v0.15 — verified baseline (2026-10-24)

## Release status

**VERIFIED — all required gates passed** in GitHub Actions on 2026-10-24.
This supersedes the earlier v0.15 *candidate / browser E2E unverified* report.

- Repository: `nssang00/chatgpt-write-test`
- Branch: `ci/ui-studio-v015-editing-ux-20261024` (the repository's `main` branch was not modified)
- Verified commit: `7c56f9f870d47746e59254e04ab9e2ab69b3fd65`
- Workflow run: https://github.com/nssang00/chatgpt-write-test/actions/runs/40076981416
- Run status/conclusion: `completed` / `success`
- Chrome evidence: https://github.com/nssang00/chatgpt-write-test/actions/runs/40076981416/artifacts/12553771805
- Evidence artifact name: `ui-studio-v015-real-chrome-evidence` (expires 2026-11-07)
- CI environment: Node.js 22; Google Chrome 155.0.8059.39

## Verified results (GitHub Actions job 120822337994)

| Gate | Result |
|---|---|
| v0.14 base + v0.15 patch reconstruction and pinned SHA-256 validation | PASS |
| `npm test` | 188 passed / 0 failed |
| `node tools/verify-syntax.mjs` | 53 source files, 3 generated TSX, 0 errors |
| `npm run verify:runtime` | PASS |
| `npm run build` (Vite production) | PASS |
| `npm run export:v014`, standalone component build, consumer Vite build | PASS |
| `CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npm run test:e2e` | **13/13 passed** (real Chrome) |
| `CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npx playwright test --config=e2e/consumer-v013.config.js` | **1/1 passed** (real Chrome) |
| Overall GitHub Actions job | SUCCESS |

## Scope

- Breadcrumb navigation from selection to page/component ancestry
- Deep duplication with fresh descendant IDs across component, frame, and slot structures
- Design-mode shortcuts for duplicate, delete, undo and redo
- Protection against shortcuts while editing text or interacting with modals
- No schema migration or changes to exported runtime semantics

## Changes made during browser stabilization

The preceding candidate had three failed Chrome scenarios. The actual Chrome log showed that the original Lego scenario had an ambiguous `Preview Harness` button after the breadcrumb addition, and that two new test scenarios wrongly assumed an initially empty component tree. The regression tests now choose the preview-launch button unambiguously and calculate tree counts relative to the starting fixture. The final E2E code is included in this archive.

This is a scenario-based verification claim, not a guarantee of zero defects in untested user environments. JavaScript library deprecation/bundle size warnings do not invalidate the CI outcome.

## Reproduction

From the extracted project root, with Node.js 22 and system Chrome installed:

```sh
npm install --no-audit --no-fund
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
npm run build
npm run export:v014
python3 tools/check-export-structure.py examples/CustomerBrowser-react-component-v0.13.zip
mkdir -p tests/component-v014
unzip -q -o examples/CustomerBrowser-react-component-v0.13.zip -d tests/component-v014
(cd tests/component-v014 && npm install --no-audit --no-fund && npm run build && npm pack --pack-destination ../consumer-v013)
(cd tests/consumer-v013 && npm install --no-audit --no-fund && npm run build)
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npm run test:e2e
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npx playwright test --config=e2e/consumer-v013.config.js
```

The included `.github/workflows/v015-verification.yml` can verify this standalone root project. The monorepo reconstruction workflow used for the passing GitHub run is available at `.github/workflows/ui-studio-v015-full.yml` on the verified branch. The v0.14 source ancestry and v0.15 overlay were pinned by SHA-256 in that workflow.
