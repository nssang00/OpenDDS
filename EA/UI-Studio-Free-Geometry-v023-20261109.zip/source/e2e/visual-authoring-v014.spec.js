import {test,expect} from '@playwright/test';

const studio=page=>page.locator('.v6-studio');
const inspector=page=>studio(page).locator('.v6-right .v6-inspector-content');
async function addState(page,name,type,value){
  await studio(page).getByRole('button',{name:/데이터 만들기/}).click();
  await page.getByRole('textbox',{name:'데이터 이름'}).fill(name);
  if(type!=='string'){
    await page.getByRole('combobox',{name:'데이터 형식'}).click();
    await page.locator('.ant-select-dropdown:visible').getByText(({array:'목록',boolean:'참/거짓',number:'숫자'})[type],{exact:true}).click();
  }
  if(type!=='boolean')await page.getByRole('textbox',{name:'데이터 초기 값'}).fill(value);
  else {
    await page.getByRole('combobox',{name:'데이터 초기 값'}).click();
    await page.locator('.ant-select-dropdown:visible').getByText(value==='true'?'참':'거짓',{exact:true}).click();
  }
  await page.getByRole('button',{name:'데이터 추가',exact:true}).click();
  await expect(studio(page).locator('.v6-error')).toHaveCount(0);
}
async function insert(page,type){
  await studio(page).getByRole('button',{name:/Insert/}).first().click();
  const panel=studio(page).locator('.v6-insert');
  await panel.locator('.v6-insert-items button').filter({hasText:type}).first().click();
  await expect(panel).toBeHidden();
}
async function setSelect(page,scope,label){
  const fields=scope.getByRole('combobox');
  const control=label.startsWith('state.')&&(await fields.count())>1?fields.nth(1):fields.first();
  await control.click();
  if(label.startsWith('state.')){
    // Search and Enter are actual keyboard UX; AntD's virtual menu may be offscreen.
    await control.fill(label);
    await control.press('Enter');
  }else{
    await page.locator('.ant-select-dropdown:visible').getByText(label,{exact:true}).last().click();
  }
}

test('v0.14 visual rules: users create typed data and select condition/repeat without writing JSON',async({page})=>{
  await page.goto('/?mode=advanced');
  await studio(page).getByRole('button',{name:'Preview Harness',exact:true}).click();
  await addState(page,'showCustomers','boolean','true');
  await addState(page,'customers','array','[{"id":1,"name":"Alice"},{"id":2,"name":"Bob"}]');
  await insert(page,'Text');
  const panel=inspector(page);
  await expect(panel.getByTestId('visual-condition')).toBeVisible();
  await setSelect(page,panel.getByTestId('visual-condition'),'state.showCustomers');
  await setSelect(page,panel.getByTestId('visual-repeat'),'state.customers');
  // A single canonical Definition is edited by the visual controls.
  await studio(page).getByRole('button',{name:'JSON 편집'}).click();
  const data=JSON.parse(await studio(page).getByRole('textbox',{name:'v6 JSON 문서'}).inputValue());
  const n=data.pages.main.root.children.at(-1);
  expect(n.when).toMatchObject({kind:'binding',source:'state',path:['showCustomers']});
  expect(n.repeat).toMatchObject({items:{kind:'binding',source:'state',path:['customers']},keyPath:['id']});
  expect(data.data.state.customers).toHaveLength(2);
});

test('v0.14 visual action: click copies live input state to a display field',async({page})=>{
  await page.goto('/?mode=advanced');
  await studio(page).getByRole('button',{name:'Preview Harness',exact:true}).click();
  await addState(page,'keyword','string','');
  await addState(page,'lastSearch','string','');
  await insert(page,'Input');
  const value=inspector(page).locator('.v6-property-field').filter({has:page.locator('label:text-is("value")')});
  await setSelect(page,value,'Binding');
  await setSelect(page,value,'state.keyword');
  await insert(page,'Button');
  await setSelect(page,inspector(page).getByTestId('visual-action').locator('.ant-select').nth(1),'데이터 값 변경');
  await setSelect(page,inspector(page).getByTestId('visual-action').locator('.ant-select').nth(2),'state.lastSearch');
  await setSelect(page,inspector(page).getByTestId('visual-action').locator('.ant-select').nth(3),'state.keyword');
  await insert(page,'Text');
  const text=inspector(page).locator('.v6-property-field').filter({has:page.locator('label:text-is("text")')});
  await setSelect(page,text,'Binding');
  await setSelect(page,text,'state.lastSearch');
  // Verify authoring mutations before evaluating runtime interactions.
  await studio(page).getByRole('button',{name:'JSON 편집'}).click();
  const configured=JSON.parse(await studio(page).getByRole('textbox',{name:'v6 JSON 문서'}).inputValue());
  const added=configured.pages.main.root.children.filter(n=>n.kind==='component');
  const inputDoc=added.find(n=>n.typeId==='core/Input');
  const buttonDoc=added.find(n=>n.typeId==='core/Button');
  const textDoc=added.find(n=>n.typeId==='core/Text' && n.id!=='demoTitle');
  expect(inputDoc?.props.value).toMatchObject({kind:'binding',source:'state',path:['keyword'],mode:'TwoWay'});
  expect(buttonDoc?.events?.click).toMatchObject({kind:'set',target:{source:'state',path:['lastSearch']},value:{kind:'binding',source:'state',path:['keyword']}});
  expect(textDoc?.props.text).toMatchObject({kind:'binding',source:'state',path:['lastSearch']});
  await studio(page).getByRole('button',{name:'JSON 편집'}).click();
  await studio(page).locator('.v6-center-head .ant-segmented-item').filter({hasText:'Preview'}).click();
  const input=studio(page).locator('.v6-artboard').getByRole('textbox',{name:'Input'});
  await input.fill('Alice');
  await expect(studio(page).locator('.v6-state-line').filter({hasText:/^keyword/})).toContainText('Alice');
  const button=studio(page).locator('.v6-artboard').getByRole('button',{name:'버튼',exact:true});
  await button.click();
  await expect(studio(page).locator('.v6-artboard')).toContainText('Alice');
  await expect(studio(page).locator('.v6-state-line').filter({hasText:'lastSearch'})).toContainText('Alice');
});
