import {test,expect} from '@playwright/test';
const studio=p=>p.locator('.v6-studio');
const quick=p=>studio(p).getByTestId('quick-tools');
async function menu(page){await studio(page).getByRole('button',{name:'프로젝트 메뉴'}).click();return studio(page).getByTestId('project-menu');}
test.beforeEach(async({page})=>{await page.goto('/');await expect(studio(page)).toHaveCount(1);});

test('v0.20 opens only one editor: no legacy mode, five primary actions, contextual UI',async({page})=>{
  await expect(page.locator('.studio .view-tabs')).toHaveCount(0);
  await expect(studio(page).locator('.v6-header .v6-actions >button')).toHaveCount(5);
  await expect(quick(page)).toBeVisible();
  await expect(studio(page).getByTestId('simple-inspector')).toBeVisible();
  await expect(studio(page).locator('.v6-tree')).toHaveCount(0);
  await expect(studio(page).locator('.v6-inspector-content')).toHaveCount(0);
  await expect(page.getByText('Legacy Design')).toHaveCount(0);
  await expect(page.getByText('고급 모드')).toHaveCount(0);
  await expect(studio(page).getByTestId('project-menu')).toHaveCount(0);
});

test('v0.20 beginner creates and edits text, previews, and undoes through the same document',async({page})=>{
  await quick(page).getByRole('button',{name:'텍스트 추가'}).click();
  const input=studio(page).getByRole('textbox',{name:'간편 text'});
  await expect(input).toBeVisible();
  await input.fill('설명 없이 만들기');
  await expect(studio(page).locator('.v6-canvas-control-ui').last()).toContainText('설명 없이 만들기');
  await studio(page).getByRole('button',{name:'▶ 미리보기'}).click();
  await expect(studio(page).locator('.v6-artboard')).toContainText('설명 없이 만들기');
  await expect(studio(page).getByRole('button',{name:'실행 정보'})).toBeVisible();
  await studio(page).getByRole('button',{name:'편집으로'}).click();
  await studio(page).getByRole('button',{name:/Undo/}).click();
  await expect(studio(page).locator('.v6-canvas-control-ui').last()).not.toContainText('설명 없이 만들기');
});

test('v0.20 additional properties disclose only inside inspector without switching editor',async({page})=>{
  await quick(page).getByRole('button',{name:'버튼 추가'}).click();
  await expect(studio(page).getByTestId('visual-logic-panel')).toHaveCount(0);
  await studio(page).getByRole('button',{name:/데이터·동작 연결/}).click();
  await expect(studio(page).getByTestId('visual-logic-panel')).toBeVisible();
  await studio(page).getByRole('button',{name:'추가 설정',exact:true}).click();
  await expect(studio(page).getByTestId('extra-properties')).toBeVisible();
  await studio(page).getByRole('button',{name:'추가 설정 접기'}).click();
  await expect(studio(page).getByTestId('extra-properties')).toHaveCount(0);
  await expect(studio(page)).toHaveCount(1);
});

test('v0.20 reveals layer management and full insert palette only on demand',async({page})=>{
  await quick(page).getByRole('button',{name:'구조 열기'}).click();
  await expect(studio(page).locator('.v6-tree')).toBeVisible();
  await studio(page).getByRole('button',{name:'레이어 닫기'}).click();
  await expect(studio(page).locator('.v6-tree')).toHaveCount(0);
  await quick(page).getByRole('button',{name:'모든 요소'}).click();
  await expect(studio(page).locator('.v6-insert')).toBeVisible();
  await expect(studio(page).locator('.v6-tree')).toBeVisible();
});

test('v0.20 project menu preserves JSON/code/React export access without toolbar clutter',async({page})=>{
  let m=await menu(page);
  await expect(m.getByRole('button',{name:'JSON 저장'})).toBeVisible();
  await m.getByRole('button',{name:'JSON 편집'}).click();
  const text=studio(page).getByRole('textbox',{name:'v6 JSON 문서'});
  const json=JSON.parse(await text.inputValue());
  expect(json.schemaVersion).toBe(6);
  await studio(page).getByRole('button',{name:'프로젝트 메뉴'}).click();
  // Close JSON via its own toggle; keep file operations in the same editor.
  await studio(page).getByTestId('project-menu').getByRole('button',{name:'JSON 편집'}).click();
  m=await menu(page);
  await m.getByRole('button',{name:'코드 편집'}).click();
  await expect(studio(page).getByRole('textbox',{name:'v6 JSX DSL'})).toBeVisible();
  await studio(page).getByRole('button',{name:'코드 편집 닫기'}).click();
  await expect(studio(page).getByRole('textbox',{name:'v6 JSX DSL'})).toHaveCount(0);
});

test('v0.20 keeps the context inspector at tablet width',async({page})=>{
  await page.setViewportSize({width:800,height:720});
  await expect(quick(page)).toBeVisible();
  await expect(studio(page).getByTestId('simple-inspector')).toBeVisible();
  await quick(page).getByRole('button',{name:'입력 추가'}).click();
  await expect(studio(page).getByTestId('simple-inspector')).toBeVisible();
});
