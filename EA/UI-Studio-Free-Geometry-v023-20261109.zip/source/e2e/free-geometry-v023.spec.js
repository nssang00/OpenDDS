import {test,expect} from '@playwright/test';
const studio=p=>p.locator('.v6-studio');
async function blankFree(page){
 await page.goto('/');const app=studio(page),tools=app.getByTestId('component-toolbox');
 await app.getByRole('button',{name:'＋ 새 컴포넌트'}).click();
 const modal=page.getByRole('dialog',{name:'새 재사용 컴포넌트'});
 await modal.getByRole('radio',{name:'빈 컴포넌트'}).click();
 await modal.getByLabel('New component name').fill('FreeGeometry');
 await modal.getByRole('button',{name:'컴포넌트 생성'}).click();
 await tools.getByRole('button',{name:'자유 배치'}).click();
 const free=app.locator('.v6-artboard .v22-free-frame').first();
 await expect(free).toBeVisible();
 return {app,tools,free};
}
test('v0.23 selected Free siblings align and drag together',async({page})=>{
 const {app,tools,free}=await blankFree(page);
 await tools.getByRole('button',{name:'Button'}).click();
 await tools.getByRole('button',{name:'Button'}).click();
 const nodes=free.locator(':scope > .v6-canvas-control');
 await expect(nodes).toHaveCount(2);
 const before=await nodes.evaluateAll(items=>items.map(el=>({left:el.offsetLeft,top:el.offsetTop})));
 await nodes.nth(0).click();
 await nodes.nth(1).click({modifiers:['Control']});
 await expect(app.getByTestId('free-selection-quick')).toBeVisible();
 await app.getByRole('button',{name:'왼쪽 맞춤'}).click();
 const aligned=await nodes.evaluateAll(items=>items.map(el=>({left:el.offsetLeft,top:el.offsetTop})));
 expect(aligned[0].left).toBe(aligned[1].left);
 await nodes.nth(0).dragTo(free,{targetPosition:{x:240,y:190}});
 const moved=await nodes.evaluateAll(items=>items.map(el=>({left:el.offsetLeft,top:el.offsetTop})));
 expect(moved[0].left).toBe(moved[1].left);
 expect(moved[0].top-before[0].top).toBe(moved[1].top-before[1].top);
});
test('v0.23 Free Frame fluid layout and child anchor roundtrip to DSL and preview',async({page})=>{
 const {app,tools,free}=await blankFree(page);
 await free.click({position:{x:450,y:280}});
 await app.getByTestId('free-fluid-frame').getByRole('checkbox').check();
 await tools.getByRole('button',{name:'Button'}).click();
 const control=free.locator(':scope > .v6-canvas-control').first();
 await control.click();
 await app.getByLabel('가로 기준점').click();
 await page.getByRole('option',{name:'오른쪽 고정'}).click();
 await app.getByText('분할 · DSL',{exact:true}).click();
 await expect(app.getByRole('textbox',{name:'v6 JSX DSL'})).toHaveValue(/anchors=\{\{"horizontal":"right"\}\}/);
 await app.locator('.v6-center-head').getByText('미리보기',{exact:true}).click();
 await app.getByLabel('미리보기 화면 너비').click();
 await page.getByText('모바일 360px',{exact:true}).click();
 await expect(app.locator('.v6-artboard')).toHaveCSS('width','360px');
 await expect(app.locator('[data-free-child-id]').first()).toHaveCSS('position','absolute');
});
