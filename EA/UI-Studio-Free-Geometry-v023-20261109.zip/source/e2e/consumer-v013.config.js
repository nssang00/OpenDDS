import {defineConfig,devices} from '@playwright/test';
export default defineConfig({
 testDir:'./consumer-v013',timeout:60000,expect:{timeout:10000},workers:1,retries:0,
 reporter:[['list'],['html',{open:'never',outputFolder:'playwright-report-consumer'}]],
 use:{baseURL:'http://127.0.0.1:4273',trace:'retain-on-failure',screenshot:'only-on-failure',video:'off'},
 projects:[{name:'chrome',use:{...devices['Desktop Chrome'],channel:'chrome'}}],
 webServer:{command:'npm run dev --prefix tests/consumer-v013 -- --port 4273 --strictPort',url:'http://127.0.0.1:4273',cwd:process.cwd(),timeout:90000,reuseExistingServer:false}
});
