import {test,expect} from '@playwright/test';
const studio=page=>page.locator('.v6-studio');
const quick=page=>studio(page).getByTestId('quick-tools');
test.beforeEach(async({page})=>{await page.goto('/');await expect(quick(page)).toBeVisible();});
test('Simple First default keeps 5 main actions; Tree, developer controls and advanced inspector are absent',async({page})=>{
  await expect(studio(page).locator('.v6-header .v6-actions button')).toHaveCount(5);
  await expect(studio(page).getByRole('button',{name:'고급 도구 열기'})).toBeVisible();
  await expect(studio(page).getByTestId('simple-inspector')).toBeVisible();
  await expect(studio(page).locator('.v6-tree')).toHaveCount(0);
  await expect(studio(page).getByRole('button',{name:'JSON 편집'})).toHaveCount(0);
  await expect(studio(page).locator('.v6-right')).not.toContainText('Instance Overrides');
  await expect(quick(page).getByRole('button',{name:'구조 열기'})).toHaveAttribute('aria-expanded','false');
  await quick(page).getByRole('button',{name:'구조 열기'}).click();
  await expect(studio(page).locator('.v6-tree [data-v6-tree-id]').first()).toBeVisible();
  await quick(page).getByRole('button',{name:'구조 열기'}).click();
  await expect(studio(page).locator('.v6-tree')).toHaveCount(0);
});
test('Quick add, simple text editing, undo, preview and the advanced inspector share one document',async({page})=>{
  await quick(page).getByRole('button',{name:'텍스트 추가'}).click();
  const text=studio(page).getByRole('textbox',{name:'간편 text'});
  await expect(text).toBeVisible();
  await text.fill('단순한 화면');
  await expect(studio(page).locator('.v6-canvas-control-ui').last()).toContainText('단순한 화면');
  await studio(page).getByRole('button',{name:/Undo/}).click();
  await expect(studio(page).locator('.v6-canvas-control-ui').last()).not.toContainText('단순한 화면');
  await text.fill('사용자 친화적');
  await studio(page).getByRole('button',{name:'▶ 미리보기'}).click();
  await expect(studio(page).locator('.v6-artboard')).toContainText('사용자 친화적');
  await studio(page).getByRole('button',{name:'편집으로'}).click();
  await studio(page).getByRole('button',{name:'고급 도구 열기'}).click();
  await expect(studio(page).locator('.v6-tree [data-v6-tree-id]').last()).toBeVisible();
  await expect(studio(page).getByRole('button',{name:'JSON 편집'})).toBeVisible();
  await studio(page).getByRole('button',{name:'간단 모드'}).click();
  await expect(studio(page).getByTestId('simple-inspector')).toBeVisible();
  await expect(studio(page).locator('.v6-canvas-control-ui').last()).toContainText('사용자 친화적');
});
test('Data and action editing remains discoverable but closed until requested',async({page})=>{
  await quick(page).getByRole('button',{name:'버튼 추가'}).click();
  await expect(studio(page).getByTestId('visual-logic-panel')).toHaveCount(0);
  await studio(page).getByRole('button',{name:/데이터·동작 연결/}).click();
  await expect(studio(page).getByTestId('visual-logic-panel')).toBeVisible();
  await studio(page).getByRole('button',{name:/데이터·동작 연결/}).click();
  await expect(studio(page).getByTestId('visual-logic-panel')).toHaveCount(0);
  await studio(page).getByRole('button',{name:'더 많은 설정 보기'}).click();
  await expect(studio(page).locator('.v6-inspector-content')).toBeVisible();
});

test('Responsive Simple First keeps Inspector usable at tablet width',async({page})=>{
  await page.setViewportSize({width:800,height:800});
  await expect(quick(page)).toBeVisible();
  await expect(studio(page).locator('.v6-artboard')).toBeVisible();
  await expect(studio(page).getByTestId('simple-inspector')).toBeVisible();
  await quick(page).getByRole('button',{name:'버튼 추가'}).click();
  await expect(studio(page).getByTestId('simple-inspector')).toBeVisible();
  await expect(studio(page).getByRole('textbox',{name:'간편 text'})).toBeVisible();
});
