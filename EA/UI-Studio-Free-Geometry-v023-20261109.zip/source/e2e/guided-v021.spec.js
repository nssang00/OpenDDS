import {test,expect} from '@playwright/test';
const studio=p=>p.locator('.v6-studio');

test.beforeEach(async({page})=>{
  await page.goto('/');
  await expect(studio(page).getByTestId('studio-workflow')).toBeVisible();
});

test('guided authoring keeps the same One Studio document and exposes a discoverable insert palette',async({page})=>{
  const steps=studio(page).getByTestId('studio-workflow');
  await expect(steps.locator('button')).toHaveCount(5);
  await steps.getByRole('button',{name:'① 구성'}).click();
  await expect(studio(page).getByTestId('component-toolbox')).toBeVisible();
  await expect(studio(page).locator('.v6-insert')).toHaveCount(0);
  await steps.getByRole('button',{name:'③ 테스트'}).click();
  await expect(studio(page).locator('.v6-stage-title')).toContainText('Runtime Preview');
  await steps.getByRole('button',{name:'② 연결'}).click();
  await expect(studio(page).getByTestId('guided-connections')).toBeVisible();
  await expect(studio(page).locator('.v6-stage-title')).toContainText('Design Canvas');
});

test('search template composes Input, Button and public API without requiring manual binding setup',async({page})=>{
  await studio(page).getByRole('button',{name:'＋ 새 컴포넌트'}).click();
  const dialog=page.getByRole('dialog',{name:'새 재사용 컴포넌트'});
  await dialog.getByLabel('New component name').fill('CustomerLookup');
  await dialog.getByRole('button',{name:'컴포넌트 생성'}).click();
  await expect(dialog).toHaveCount(0);
  await expect(studio(page).getByTestId('guided-connections')).toContainText('CustomerLookup');
  // Shortcut starts with the search template, including a generated public API.
  await expect(studio(page).getByTestId('guided-connections')).toContainText('value');
  await expect(studio(page).getByTestId('guided-connections')).toContainText('onSearch');
  await studio(page).getByTestId('studio-workflow').getByRole('button',{name:'④ 코드 내보내기'}).click();
  const exportDialog=page.getByTestId('export-dialog');
  await expect(exportDialog.getByTestId('native-export-readiness')).toContainText('준비됨');
  const download=page.waitForEvent('download');
  await exportDialog.getByRole('button',{name:/shadcn Native TSX ZIP/}).click();
  expect((await download).suggestedFilename()).toBe('CustomerLookup-shadcn-native-experimental.zip');
});

test('one-click public Prop connection supports undo through canonical document history',async({page})=>{
  await studio(page).getByRole('button',{name:'＋ 새 컴포넌트'}).click();
  const dialog=page.getByRole('dialog',{name:'새 재사용 컴포넌트'});
  await dialog.getByRole('radio',{name:'빈 컴포넌트'}).click();
  await dialog.getByLabel('New component name').fill('LabelCard');
  await dialog.getByRole('button',{name:'컴포넌트 생성'}).click();
  await studio(page).getByTestId('quick-tools').getByRole('button',{name:'텍스트 추가'}).click();
  const guide=studio(page).getByTestId('guided-connections');
  const connect=guide.getByTestId('guide-connect-prop-text');
  await expect(connect).toBeVisible();
  await connect.click();
  await expect(connect).toHaveCount(0);
  await expect(guide).toContainText('Props');
  await studio(page).getByRole('button',{name:/Undo/}).click();
  await expect(guide.getByTestId('guide-connect-prop-text')).toBeVisible();
});
