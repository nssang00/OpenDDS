import {test,expect} from '@playwright/test';
const studio=page=>page.locator('.v6-studio');

test.beforeEach(async({page})=>{await page.goto('/');await expect(studio(page).getByTestId('component-toolbox')).toBeVisible();});

test('v0.22 persistent Toolbox exposes grouped controls and keyboard-click insertion',async({page})=>{
  const toolbox=studio(page).getByTestId('component-toolbox');
  await expect(toolbox.getByRole('region',{name:'입력'})).toBeVisible();
  await expect(toolbox.getByRole('region',{name:'레이아웃'})).toBeVisible();
  await toolbox.getByRole('textbox',{name:'Toolbox 검색'}).fill('textarea');
  await expect(toolbox.getByRole('button',{name:'Textarea'})).toHaveCount(1);
  await expect(toolbox.getByRole('button',{name:'자유 배치'})).toHaveCount(0);
  await toolbox.getByRole('textbox',{name:'Toolbox 검색'}).clear();
  await toolbox.getByRole('button',{name:'Heading'}).click();
  await expect(studio(page).locator('[data-v6-canvas-id]').last()).toContainText('Heading');
});

test('v0.22 WPF-like drop places Button in Free Frame and syncs DSL, Preview and JSON',async({page})=>{
  const app=studio(page),toolbox=app.getByTestId('component-toolbox');
  await app.getByRole('button',{name:'＋ 새 컴포넌트'}).click();
  const dialog=page.getByRole('dialog',{name:'새 재사용 컴포넌트'});
  await dialog.getByRole('radio',{name:'빈 컴포넌트'}).click();
  await dialog.getByLabel('New component name').fill('FreePanel');
  await dialog.getByRole('button',{name:'컴포넌트 생성'}).click();
  await toolbox.getByRole('button',{name:'자유 배치'}).click();
  const free=app.locator('.v6-artboard .v22-free-frame').first();
  await expect(free).toBeVisible();
  await toolbox.getByRole('button',{name:'Button'}).dragTo(free,{targetPosition:{x:152,y:112}});
  const child=free.locator('.v6-canvas-control').first();
  await expect(child).toBeVisible();
  await expect(child).toHaveCSS('position','absolute');
  await expect(child).toHaveCSS('left','152px');
  await expect(child).toHaveCSS('top','112px');
  await child.click();
  await expect(app.getByTestId('simple-free-position')).toContainText('X 좌표');
  await app.getByText('분할 · DSL',{exact:true}).click();
  await expect(app.getByRole('textbox',{name:'v6 JSX DSL'})).toHaveValue(/position=\{\{\"x\":152,\"y\":112\}\}/);
  await app.locator('.v6-center-head').getByText('미리보기',{exact:true}).click();
  await expect(app.locator('[data-free-child-id]').first()).toHaveCSS('left','152px');
});
