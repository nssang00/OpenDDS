import {test,expect} from '@playwright/test';
const studio=p=>p.locator('.v6-studio');
const tree=p=>studio(p).locator('.v6-tree');
const row=(p,id)=>tree(p).locator(`[data-v6-tree-id="${id}"]`);
async function openPage(page){await page.goto('/?mode=advanced');await studio(page).locator('.v6-tree-actions').getByRole('button',{name:'Preview Harness'}).click();}
const treeIds=p=>tree(p).locator('[data-v6-tree-id]').evaluateAll(nodes=>nodes.map(n=>n.dataset.v6TreeId));
async function readJson(page){await studio(page).getByRole('button',{name:'JSON 편집'}).click();return JSON.parse(await studio(page).getByRole('textbox',{name:'v6 JSON 문서'}).inputValue());}

test('v0.18 tree drag moves the first control to the end, preserving IDs and undo',async({page})=>{
 await openPage(page);
 const original=await treeIds(page),[root,first,second,third]=original;
 await row(page,first).dragTo(row(page,third),{targetPosition:{x:70,y:28}});
 await expect(row(page,first)).toBeVisible();
 expect(await treeIds(page)).toEqual([root,second,third,first]);
 let data=await readJson(page);
 expect(data.pages.main.root.children.map(n=>n.id)).toEqual([second,third,first]);
 await studio(page).getByRole('button',{name:'JSON 편집'}).click();
 await studio(page).getByRole('button',{name:/Undo/}).click();
 expect(await treeIds(page)).toEqual(original);
});

test('v0.18 invalid self drop has red feedback and no insertion guide or document mutation',async({page})=>{
 await openPage(page);
 const before=await treeIds(page);
 const root=await row(page,'pageRoot').boundingBox();
 const item=await row(page,before[1]).boundingBox();
 await page.mouse.move(item.x+30,item.y+item.height/2);
 await page.mouse.down();
 await page.mouse.move(item.x+40,item.y+item.height/2+12,{steps:5});
 // Same item cannot be dropped back in its existing position; invalid plan is visible.
 await expect(studio(page).getByTestId('drop-feedback')).toHaveAttribute('data-drop-valid','false');
 await expect(studio(page).getByTestId('drop-guide')).toHaveCount(0);
 await page.mouse.up();
 expect(await treeIds(page)).toEqual(before);
 await expect(studio(page).locator('.v6-error')).toHaveCount(0);
});

test('v0.18 palette pointer drop into an empty Frame shows insertion guide and creates exactly one node',async({page})=>{
 await openPage(page);
 const original=await treeIds(page);
 await studio(page).getByRole('button',{name:/Insert/}).first().click();
 const source=studio(page).locator('.v6-insert-items button').filter({hasText:'Button'}).first();
 const root=studio(page).locator('.v6-artboard [data-v6-frame-id="pageRoot"]');
 await source.dragTo(root,{targetPosition:{x:110,y:170}});
 await expect(tree(page).locator('[data-v6-tree-id]')).toHaveCount(original.length+1);
 const now=await treeIds(page);
 const created=now.find(id=>!original.includes(id));
 expect(created).toBeTruthy();
 await expect(studio(page).locator(`[data-v6-canvas-id="${created}"]`)).toContainText('Button');
});
