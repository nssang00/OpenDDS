import {test,expect} from '@playwright/test';
const studio=p=>p.locator('.v6-studio');
const tree=p=>studio(p).locator('.v6-tree');
const bar=p=>studio(p).getByTestId('selection-toolbar');
async function openPage(page){await page.goto('/?mode=advanced');await expect(studio(page)).toBeVisible();await studio(page).locator('.v6-tree-actions').getByRole('button',{name:'Preview Harness'}).click();}
async function json(page){await studio(page).getByRole('button',{name:'JSON 편집'}).click();return JSON.parse(await studio(page).getByRole('textbox',{name:'v6 JSON 문서'}).inputValue());}
const row=(page,id)=>tree(page).locator(`[data-v6-tree-id="${id}"]`);
test('v0.17 Ctrl selects sibling nodes and group reordering, alignment, gap, undo persist in canonical JSON',async({page})=>{
 await openPage(page);
 const initial=await tree(page).locator('[data-v6-tree-id]').evaluateAll(nodes=>nodes.map(n=>n.dataset.v6TreeId));
 const [root,a,b,c]=initial;
 await row(page,a).click();await row(page,b).click({modifiers:['Control']});
 await expect(bar(page).getByTestId('group-toolbar')).toContainText('2개 선택');
 await expect(row(page,a)).toHaveClass(/is-selected/);
 await expect(row(page,b)).toHaveClass(/is-selected/);
 await bar(page).getByRole('button',{name:'아래로 이동'}).click();
 let ordered=await tree(page).locator('[data-v6-tree-id]').evaluateAll(nodes=>nodes.map(n=>n.dataset.v6TreeId));
 expect(ordered).toEqual([root,c,a,b]);
 await bar(page).getByTestId('group-toolbar').getByRole('combobox',{name:'선택한 형제의 부모 정렬'}).click();
 await page.locator('.ant-select-dropdown:visible').getByText('가운데',{exact:true}).last().click();
 await bar(page).getByTestId('group-toolbar').getByRole('combobox',{name:'선택한 형제의 부모 간격'}).click();
 await page.locator('.ant-select-dropdown:visible').getByText('16px',{exact:true}).last().click();
 let document=await json(page);
 expect(document.pages.main.root.children.map(n=>n.id)).toEqual([c,a,b]);
 expect(document.pages.main.root.layout.align).toBe('center');
 expect(document.pages.main.root.layout.gap).toBe(16);
 await studio(page).getByRole('button',{name:'JSON 편집'}).click();
 await studio(page).getByRole('button',{name:/Undo/}).click();
 await studio(page).getByRole('button',{name:/Undo/}).click();
 await studio(page).getByRole('button',{name:/Undo/}).click();
 document=await json(page);
 expect(document.pages.main.root.children.map(n=>n.id)).toEqual([a,b,c]);
});
test('v0.17 Shift range selects siblings, batch delete is atomic and can undo',async({page})=>{
 await openPage(page);
 const original=await tree(page).locator('[data-v6-tree-id]').evaluateAll(nodes=>nodes.map(n=>n.dataset.v6TreeId));
 const [root,a,b,c]=original;
 await row(page,a).click();await row(page,b).click({modifiers:['Shift']});
 await expect(bar(page).getByTestId('group-toolbar')).toContainText('2개 선택');
 await bar(page).getByRole('button',{name:'삭제'}).click();
 await expect(tree(page).locator('[data-v6-tree-id]')).toHaveCount(2);
 await expect(row(page,c)).toBeVisible();
 await studio(page).getByRole('button',{name:/Undo/}).click();
 await expect(tree(page).locator('[data-v6-tree-id]')).toHaveCount(4);
 const doc=await json(page);
 expect(doc.pages.main.root.children.map(n=>n.id)).toEqual([a,b,c]);
});
