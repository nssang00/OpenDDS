import {test,expect} from '@playwright/test';
const studio=p=>p.locator('.v6-studio');
const tree=p=>studio(p).locator('.v6-tree');
const toolbar=p=>studio(p).getByTestId('selection-toolbar');
async function insert(page,type){
 await studio(page).getByRole('button',{name:/Insert/}).first().click();
 await studio(page).locator('.v6-insert-items button').filter({hasText:type}).first().click();
}
async function documentJson(page){
 await studio(page).getByRole('button',{name:'JSON 편집'}).click();
 return JSON.parse(await studio(page).getByRole('textbox',{name:'v6 JSON 문서'}).inputValue());
}
test.beforeEach(async({page})=>{
 await page.goto('/?mode=advanced');await expect(studio(page)).toBeVisible();
 await studio(page).getByRole('button',{name:'Preview Harness',exact:true}).first().click();
});
test('v0.16 reorder controls and Alt arrows change canonical root order and undo restores it',async({page})=>{
 const original=await tree(page).locator('[data-v6-tree-id]').evaluateAll(els=>els.map(el=>el.dataset.v6TreeId));
 const chosen=original[2];
 await tree(page).locator(`[data-v6-tree-id="${chosen}"]`).click();
 await expect(toolbar(page).getByRole('button',{name:'위로 이동'})).toBeEnabled();
 await toolbar(page).getByRole('button',{name:'위로 이동'}).click();
 let order=await tree(page).locator('[data-v6-tree-id]').evaluateAll(els=>els.map(el=>el.dataset.v6TreeId));
 expect(order).toEqual([original[0],original[2],original[1],...original.slice(3)]);
 await page.keyboard.press('Alt+ArrowDown');
 order=await tree(page).locator('[data-v6-tree-id]').evaluateAll(els=>els.map(el=>el.dataset.v6TreeId));
 expect(order).toEqual(original);
 await page.keyboard.press('Alt+ArrowUp');
 await studio(page).getByRole('button',{name:/Undo/}).click();
 const exported=await documentJson(page);
 expect(exported.pages.main.root.children.map(n=>n.id)).toEqual(original.slice(1));
});
test('v0.16 Frame outdent-indent and align/gap presets survive canonical JSON export',async({page})=>{
 await tree(page).locator('[data-v6-tree-id="pageRoot"]').click();
 await insert(page,'row');
 const frame=await tree(page).locator('[data-v6-tree-id]').last().getAttribute('data-v6-tree-id');
 await expect(toolbar(page).getByRole('button',{name:'상위 Frame으로'})).toBeDisabled();
 await insert(page,'Text');
 const textId=await tree(page).locator('[data-v6-tree-id]').last().getAttribute('data-v6-tree-id');
 await toolbar(page).getByRole('button',{name:'상위 Frame으로'}).click();
 await expect(toolbar(page).getByRole('button',{name:'하위 Frame으로'})).toBeEnabled();
 await toolbar(page).getByRole('button',{name:'하위 Frame으로'}).click();
 await tree(page).locator(`[data-v6-tree-id="${frame}"]`).click();
 await studio(page).getByTestId('layout-presets').getByRole('button',{name:'간격 16'}).click();
 await studio(page).getByRole('combobox',{name:'자식 정렬'}).click();
 await page.locator('.ant-select-dropdown:visible').getByText('가운데',{exact:true}).last().click();
 const json=await documentJson(page);
 const parent=json.pages.main.root.children.find(x=>x.id===frame);
 expect(parent?.children.map(n=>n.id)).toEqual([textId]);
 expect(parent.layout.gap).toBe(16);
 expect(parent.layout.align).toBe('center');
});
