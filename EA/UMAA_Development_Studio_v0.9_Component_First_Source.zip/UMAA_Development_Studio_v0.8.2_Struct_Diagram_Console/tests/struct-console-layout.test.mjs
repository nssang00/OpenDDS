import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const read=(path)=>readFileSync(new URL(path, import.meta.url),'utf8');
const workbench=read('../src/components/TypeWorkbench.jsx');
const prop=read('../src/components/TypeProperties.jsx');
const context=read('../src/components/ContextProperties.jsx');
const app=read('../src/App.jsx');
const workspace=read('../src/components/WorkspaceWorkbench.jsx');
const preview=read('../preview/UMAA_Types_Struct_Diagram_v0.8.2.html');
assert.match(workbench,/className="struct-diagram"/);
assert.match(workbench,/className="struct-members"/);
assert.match(workbench,/fieldName:field\.name/);
assert.match(workspace,/TypeWorkbench kind=\{kind\} id=\{id\}/);
assert.doesNotMatch(workspace,/Type Dependency Graph/);
assert.match(context,/return type\?<TypeProperties/);
for (const key of ['addMessageField','updateMessageField','addDataTypeField','updateDataTypeField']) assert.match(prop,new RegExp(key));
assert.match(app,/log-only-panel/);
assert.match(app,/\bOUTPUT\b/);
assert.match(app,/\bCONSOLE\b/);
for(const extraneous of ["label: <span><ApartmentOutlined /> Autopilot", "label: <span><ApiOutlined /> ICD", "label: <span><ShareAltOutlined /> Mock Flow Simulation", "label: <span><DatabaseOutlined /> DDS Endpoint Matrix"]){
  assert.ok(!app.includes(extraneous),'Bottom panel must not contain detailed views');
}
assert.match(preview,/class="struct" id="struct"/);
assert.match(preview,/data-field=/); // selectable struct rows
assert.match(preview,/function renderLogs\(/);
assert.match(preview,/32 Message Types \+ 17 Common Data Types/);
console.log('PASS compact Struct Diagram + right-side field Properties + Output/Console-only bottom panel');
