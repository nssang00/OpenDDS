import { Button, Collapse, Empty, Space, Tag, Typography } from 'antd';
import { PlusOutlined, LinkOutlined } from '@ant-design/icons';
import { useEditorStore } from '../stores/useEditorStore.js';
import { effectiveTypeFields } from '../model/mockIdlCatalog.js';
const { Text } = Typography;

// The source is a compact *preview*, not canonical IDL suitable for a DDS compiler.
export function renderIdlPreview(type) {
  const ns=(type.namespace??'ProjectCustom').split('::').filter(Boolean);
  const indent='  '.repeat(ns.length);
  const fields=(type.fields??[]).map(f=>`${indent}  ${f.key?'@key ':''}${f.optional?'@optional ':''}${f.type} ${f.name};`);
  const body=type.kind==='enum'
    ? [`${indent}enum ${type.name} {`,...(type.members??[]).map((m,i)=>`${indent}  ${m}${i<(type.members?.length??0)-1?',':''}`),`${indent}};`]
    : [`${indent}struct ${type.name}${type.baseType?' : '+type.baseType:''} {`,...fields,`${indent}};`];
  return [type.source==='custom'?'// PROJECT EXTENSION — IDL PREVIEW':'// ICD-DERIVED MOCK — NOT OFFICIAL UMAA IDL',
    ...(type.source==='custom'?[]:[`// Reference: ${type.reference??'UMAA 6.0 ICD'}`,'// Bounds, typedefs, annotations and DDS compatibility are unverified.']),
    ...ns.map((n,i)=>`${'  '.repeat(i)}module ${n} {`),...body,
    ...ns.slice().reverse().map((_,i)=>`${'  '.repeat(ns.length-1-i)}};`)].join('\n');
}

export function TypeWorkbench({ kind, id }) {
  const snapshot=useEditorStore(s=>s.snapshot);
  const selection=useEditorStore(s=>s.selection);
  const select=useEditorStore(s=>s.select);
  const type=kind==='message'?snapshot?.messages.find(m=>m.id===id):snapshot?.dataTypes.find(m=>m.id===id);
  if(!type)return <Empty description="Type을 선택하세요"/>;
  const custom=type.source==='custom';
  const enumType=type.kind==='enum';
  const fields=enumType?(type.members??[]).map(name=>({name,type:'enumerator'})):effectiveTypeFields(snapshot,type);
  const active=selection?.id===id?selection?.fieldName:null;
  const topics=(snapshot?.topics??[]).filter(x=>x.messageTypeId===id);
  return <div className="type-struct-workbench">
    <div className="struct-heading">
      <div><Text className="editor-eyebrow" type="secondary">IDL TYPE / STRUCT DIAGRAM</Text><h2>{type.name}</h2>
        <Space size={5} wrap><Tag color={custom?'purple':'blue'}>{custom?'PROJECT EXTENSION':'ICD MOCK · READ ONLY'}</Tag><Tag>{enumType?'enum':'struct'}</Tag><Text type="secondary">{fields.length} {enumType?'members':'fields'}</Text></Space>
      </div>
      {custom&&<Button icon={<PlusOutlined/>} size="small" onClick={()=>select({kind,id,fieldEditor:'create'})}>{enumType?'Member':'Field'} 추가</Button>}
    </div>
    <div className="struct-workspace">
      <section className="struct-diagram" aria-label={`${type.name} ${enumType?'enum':'struct'} diagram`}>
        <div className="struct-diagram-header">
          <span className="struct-stereotype">«{enumType?'enumeration':'struct'}»</span>
          <strong>{type.name}</strong>
          <span className="struct-namespace" title={type.namespace}>{type.namespace}</span>
        </div>
        {type.baseType&&<div className="struct-base"><span>extends</span><code>{type.baseType}</code></div>}
        <div className="struct-members" role="list" aria-label="Fields">
          {fields.length?fields.map((field,i)=><button type="button" role="listitem" key={`${field.declaredIn??type.name}-${field.name}-${i}`}
              className={`struct-member${active===field.name?' selected':''}${field.inherited?' inherited':''}`}
              onClick={()=>select({kind,id,fieldName:field.name})} aria-label={`${field.name} ${field.type} 상세 속성`}>
              <span className="struct-visibility">+</span>
              <span className="struct-field-name" title={field.name}>{field.name}</span>
              {!enumType&&<><span className="struct-colon">:</span><code title={field.type}>{field.type}</code></>}
              <span className="struct-member-annotations">{field.key&&<em>key</em>}{field.optional&&<em>optional</em>}{field.inherited&&<em>inherited</em>}</span>
            </button>):<div className="struct-empty">필드 없음 · {custom?'오른쪽 Properties에서 추가할 수 있습니다.':'ICD 목 데이터에 정의되지 않았습니다.'}</div>}
        </div>
        <div className="struct-diagram-footer">{type.fields?.length??0} declared{!enumType?` · ${fields.filter(f=>f.inherited).length} inherited`:''}</div>
      </section>
      <div className="struct-side-guide"><strong>필드를 선택하세요</strong><p>중앙은 구조 확인만 담당합니다. 필드의 타입, annotation, 참조 정보와 Custom 필드 편집은 <b>오른쪽 Properties</b>에서 진행합니다.</p>
        {!custom&&<p className="struct-mock-note">ICD 표 기반 Mock입니다. 공식 `.idl`이 아니며 DDS 타입 생성용으로 사용할 수 없습니다.</p>}
        {topics.length>0&&<><strong className="struct-subheading">Referenced by Topics</strong>{topics.map(t=><Button type="link" size="small" key={t.id} onClick={()=>select({kind:'topic',id:t.id})}><LinkOutlined/> {t.name}</Button>)}</>}
      </div>
    </div>
    <Collapse size="small" ghost className="struct-source-collapse" items={[{key:'idl',label:'Pseudo IDL 소스 미리보기 (필요할 때만 펼치기)',children:<pre className="idl-source-preview">{renderIdlPreview(type)}</pre>}]} />
  </div>;
}
