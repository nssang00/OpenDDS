import { useEffect } from 'react';
import { Button, Checkbox, Descriptions, Divider, Form, Input, Popconfirm, Select, Space, Tag, Typography, message } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { useEditorStore } from '../stores/useEditorStore.js';
import { effectiveTypeFields } from '../model/mockIdlCatalog.js';
const {Text}=Typography;
const identifier=/^[A-Za-z_][A-Za-z0-9_]*$/;
const primitive=['boolean','octet','short','unsigned short','long','unsigned long','long long','unsigned long long','float','double','string','char'];

export function TypeProperties({ snapshot, type, kind, selection }) {
  const select=useEditorStore(s=>s.select);
  const addMessage=useEditorStore(s=>s.addMessageField);
  const updateMessage=useEditorStore(s=>s.updateMessageField);
  const removeMessage=useEditorStore(s=>s.removeMessageField);
  const addData=useEditorStore(s=>s.addDataTypeField);
  const updateData=useEditorStore(s=>s.updateDataTypeField);
  const removeData=useEditorStore(s=>s.removeDataTypeField);
  const addEnum=useEditorStore(s=>s.addEnumMember);
  const updateEnum=useEditorStore(s=>s.updateEnumMember);
  const removeEnum=useEditorStore(s=>s.removeEnumMember);
  const [form]=Form.useForm();
  const custom=type.source==='custom';
  const isEnum=type.kind==='enum';
  const fields=isEnum?(type.members??[]).map(name=>({name,type:'enumerator'})):effectiveTypeFields(snapshot,type);
  const field=fields.find(f=>f.name===selection.fieldName);
  const creating=custom&&selection.fieldEditor==='create';
  const editing=custom&&(creating||field&&!field.inherited);
  const available=[...primitive,...(snapshot.dataTypes??[]),...(snapshot.messages??[])].filter(t=>typeof t==='string'||t.id!==type.id).map(t=>typeof t==='string'?t:`${t.namespace}::${t.name}`);
  useEffect(()=>{
    form.setFieldsValue({name:creating?'':field?.name??'',type:creating?'double':field?.type??'double',key:creating?false:!!field?.key,optional:creating?false:!!field?.optional});
  },[type.id,selection.fieldName,selection.fieldEditor,field?.name,field?.type,field?.key,field?.optional,creating,form]);
  async function saveField(){
    let v;try{v=await form.validateFields();}catch{return;}
    if(v.key&&v.optional){message.error('@key와 @optional은 동시에 지정할 수 없습니다.');return;}
    let ok;
    if(isEnum)ok=creating?addEnum(type.id,v.name):updateEnum(type.id,field.name,v.name);
    else {
      const patch={name:v.name,type:v.type,key:!!v.key,optional:!!v.optional};
      ok=kind==='message'?(creating?addMessage(type.id,v.name,v.type,patch):updateMessage(type.id,field.name,patch))
        :(creating?addData(type.id,v.name,v.type,patch):updateData(type.id,field.name,patch));
    }
    if(!ok){message.error('필드명 중복 또는 잘못된 정의입니다.');return;}
    select({kind,id:type.id,fieldName:v.name});message.success('Custom Type에 반영했습니다.');
  }
  function deleteField(){
    if(!field||!custom||field.inherited)return;
    if(isEnum){if(!removeEnum(type.id,field.name)){message.error('마지막 Enum Member는 삭제할 수 없습니다.');return;}}
    else (kind==='message'?removeMessage:removeData)(type.id,field.name);
    select({kind,id:type.id});
  }
  return <div className="inspector context-properties type-properties">
    <Text type="secondary" className="side-label">TYPE PROPERTIES</Text><h3>{type.name}</h3>
    <Space wrap size={4}><Tag color={custom?'purple':'blue'}>{custom?'Editable':'ICD MOCK · READ ONLY'}</Tag><Tag>{isEnum?'Enum':'Struct'}</Tag></Space>
    <Descriptions className="type-properties-meta" bordered column={1} size="small" style={{marginTop:12}}>
      <Descriptions.Item label="Namespace">{type.namespace}</Descriptions.Item>
      <Descriptions.Item label="Fields">{fields.length}</Descriptions.Item>
      {type.baseType&&<Descriptions.Item label="Base">{type.baseType}</Descriptions.Item>}
      {type.reference&&<Descriptions.Item label="Reference">{type.reference}</Descriptions.Item>}
    </Descriptions>
    <Divider style={{margin:'14px 0 10px'}}/>
    <div className="type-field-property-head"><Text strong>{creating?'새 필드':field?`Field · ${field.name}`:'Field Details'}</Text>
      {custom&&!creating&&<Button type="text" size="small" icon={<PlusOutlined/>} onClick={()=>select({kind,id:type.id,fieldEditor:'create'})}>추가</Button>}
    </div>
    {editing?<Form layout="vertical" form={form} className="type-field-edit-form">
      <Form.Item label={isEnum?'Enumerator':'Field Name'} name="name" rules={[{required:true,message:'이름을 입력하세요'},{pattern:identifier,message:'IDL 식별자 형식이어야 합니다'}]}><Input size="small"/></Form.Item>
      {!isEnum&&<><Form.Item label="IDL Type" name="type" rules={[{required:true}]}><Select showSearch size="small" options={available.map(v=>({value:v,label:v}))}/></Form.Item>
        <Space size={3} direction="vertical"><Form.Item name="key" valuePropName="checked" noStyle><Checkbox>@key</Checkbox></Form.Item><Form.Item name="optional" valuePropName="checked" noStyle><Checkbox>@optional</Checkbox></Form.Item></Space></>}
      <Space style={{marginTop:14}}><Button size="small" type="primary" onClick={saveField}>적용</Button><Button size="small" onClick={()=>select({kind,id:type.id})}>취소</Button>
        {field&&!creating&&<Popconfirm title="필드를 삭제하시겠습니까?" onConfirm={deleteField}><Button size="small" danger>삭제</Button></Popconfirm>}</Space>
    </Form>:field?<Descriptions size="small" column={1} bordered className="field-selected-properties">
      <Descriptions.Item label="Name"><Text code>{field.name}</Text></Descriptions.Item>
      {!isEnum&&<Descriptions.Item label="IDL Type"><Text code>{field.type}</Text></Descriptions.Item>}
      <Descriptions.Item label="@key">{field.key?'Yes':'No'}</Descriptions.Item>
      <Descriptions.Item label="@optional">{field.optional?'Yes':'No'}</Descriptions.Item>
      <Descriptions.Item label="Origin">{field.inherited?`Inherited · ${field.declaredIn??type.baseType}`:'Declared'}</Descriptions.Item>
    </Descriptions>:<p className="small-hint">중앙 Struct Diagram의 필드를 선택하면 해당 필드의 속성만 표시됩니다.{custom?' 또는 새 필드를 추가할 수 있습니다.':''}</p>}
    <p className="small-hint">{custom?'Custom Type의 변경 사항은 프로젝트 모델에 저장됩니다.':'ICD 속성표 기반 Mock 데이터입니다. 공식 IDL 원문과 다를 수 있습니다.'}</p>
  </div>;
}
