import { List, Tag, Typography } from 'antd';
import { useDesignerStore } from '../../stores/useDesignerStore.js';
import { useProjectStore } from '../../stores/useProjectStore.js';
import { generateModelSummary } from '../../utils/documentGenerator.js';

const { Text } = Typography;

export default function ConsoleView() {
  const model = useDesignerStore((state) => state.model);
  const dirty = useDesignerStore((state) => state.dirty);
  const currentProject = useProjectStore((state) => state.currentProject);
  const summary = generateModelSummary(model);

  const messages = [
    {
      level: 'info',
      message: currentProject
        ? `Project loaded: ${currentProject.name}`
        : 'Default model loaded',
    },
    {
      level: dirty ? 'warning' : 'success',
      message: dirty ? 'Model has unsaved changes' : 'Model state is clean',
    },
    {
      level: 'info',
      message: `Model summary: ${summary.topics} topics, ${summary.structs} struct types, ${summary.qosProfiles} QoS profiles`,
    },
  ];

  return (
    <div className="tab-panel console-view">
      <List
        size="small"
        dataSource={messages}
        renderItem={(item) => (
          <List.Item className="console-view__item">
            <Tag className="console-view__level" color={getLevelColor(item.level)}>
              {item.level}
            </Tag>
            <Text>{item.message}</Text>
          </List.Item>
        )}
      />
    </div>
  );
}

function getLevelColor(level) {
  if (level === 'success') return 'green';
  if (level === 'warning') return 'orange';
  return 'blue';
}
