export const studioLayoutConfig = {
  panels: [
    {
      id: 'explorer',
      region: 'left',
      defaultSize: 300,
      min: 240,
      max: 480,
      className: 'studio-layout__explorer',
      panelClassName: 'explorer-panel',
      tabClassName: 'panel-tabs',
      defaultActiveView: 'model',
      views: [
        {
          id: 'model',
          label: 'Model',
          component: 'ModelView',
        },
        {
          id: 'search',
          label: 'Search',
          component: 'SearchView',
        },
      ],
    },
    {
      id: 'workspace',
      region: 'center',
      min: 520,
      className: 'studio-layout__workspace',
      panelClassName: 'workspace-panel',
      tabClassName: 'workspace-tabs',
      defaultActiveView: 'diagram',
      views: [
        {
          id: 'diagram',
          label: 'Diagram',
          component: 'DiagramView',
        },
        {
          id: 'idl',
          label: 'IDL',
          component: 'IdlView',
        },
        {
          id: 'qosXml',
          label: 'QoS XML',
          component: 'QosXmlView',
        },
      ],
    },
    {
      id: 'inspector',
      region: 'right',
      defaultSize: 390,
      min: 320,
      max: 560,
      className: 'studio-layout__inspector',
      panelClassName: 'inspector-panel',
      tabClassName: 'panel-tabs',
      defaultActiveView: 'properties',
      views: [
        {
          id: 'properties',
          label: 'Properties',
          component: 'PropertiesView',
        },
        {
          id: 'members',
          label: 'Members',
          component: 'MembersView',
        },
        {
          id: 'qos',
          label: 'QoS',
          component: 'QosView',
        },
      ],
    },
  ],
  bottomPanel: {
    id: 'bottom',
    defaultSize: 260,
    min: 160,
    max: 420,
    className: 'studio-layout__bottom',
    panelClassName: 'bottom-panel',
    tabClassName: 'bottom-tabs',
    defaultActiveView: 'console',
    views: [
      {
        id: 'console',
        label: 'Console',
        component: 'ConsoleView',
      },
    ],
  },
};
