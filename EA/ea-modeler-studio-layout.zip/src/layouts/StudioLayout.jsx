import { useState } from 'react';
import { Button, Splitter } from 'antd';
import { DownOutlined, UpOutlined } from '@ant-design/icons';
import { studioLayoutConfig } from './studioLayout.config.js';
import StudioPanelRenderer from './StudioPanelRenderer.jsx';

export default function StudioLayout() {
  const [isBottomPanelOpen, setIsBottomPanelOpen] = useState(false);
  const [explorerPanel, workspacePanel, inspectorPanel] = studioLayoutConfig.panels;
  const bottomPanel = studioLayoutConfig.bottomPanel;

  return (
    <Splitter className="studio-layout">
      <Splitter.Panel
        defaultSize={explorerPanel.defaultSize}
        min={explorerPanel.min}
        max={explorerPanel.max}
        className={explorerPanel.className}
      >
        <StudioPanelRenderer panel={explorerPanel} />
      </Splitter.Panel>

      <Splitter.Panel min={workspacePanel.min + inspectorPanel.min}>
        <div className="studio-main-stack">
          <Splitter layout="vertical" className="studio-main-splitter">
            <Splitter.Panel min={360}>
              <Splitter className="studio-main-content">
                <Splitter.Panel
                  min={workspacePanel.min}
                  className={workspacePanel.className}
                >
                  <StudioPanelRenderer panel={workspacePanel} />
                </Splitter.Panel>

                <Splitter.Panel
                  defaultSize={inspectorPanel.defaultSize}
                  min={inspectorPanel.min}
                  max={inspectorPanel.max}
                  className={inspectorPanel.className}
                >
                  <StudioPanelRenderer panel={inspectorPanel} />
                </Splitter.Panel>
              </Splitter>
            </Splitter.Panel>

            {isBottomPanelOpen && (
              <Splitter.Panel
                defaultSize={bottomPanel.defaultSize}
                min={bottomPanel.min}
                max={bottomPanel.max}
                className={bottomPanel.className}
              >
                <StudioPanelRenderer
                  panel={bottomPanel}
                  tabBarExtraContent={
                    <Button
                      type="text"
                      size="small"
                      icon={<DownOutlined />}
                      aria-label="Close bottom panel"
                      onClick={() => setIsBottomPanelOpen(false)}
                    />
                  }
                />
              </Splitter.Panel>
            )}
          </Splitter>

          {!isBottomPanelOpen && (
            <div className="bottom-panel-dock">
              <Button
                size="small"
                icon={<UpOutlined />}
                onClick={() => setIsBottomPanelOpen(true)}
              >
                Console
              </Button>
            </div>
          )}
        </div>
      </Splitter.Panel>
    </Splitter>
  );
}
