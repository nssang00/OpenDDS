import ModelView from '../views/explorer/ModelView.jsx';
import SearchView from '../views/explorer/SearchView.jsx';
import DiagramView from '../views/workspace/DiagramView.jsx';
import IdlView from '../views/workspace/IdlView.jsx';
import QosXmlView from '../views/workspace/QosXmlView.jsx';
import ConsoleView from '../views/bottom/ConsoleView.jsx';
import MembersView from '../views/inspector/MembersView.jsx';
import PropertiesView from '../views/inspector/PropertiesView.jsx';
import QosView from '../views/inspector/QosView.jsx';

export const studioViewsRegistry = {
  ModelView,
  SearchView,
  DiagramView,
  IdlView,
  QosXmlView,
  ConsoleView,
  MembersView,
  PropertiesView,
  QosView,
};
