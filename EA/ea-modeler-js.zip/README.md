# EA Modeler JS MVP

Sparx EA/QEA 연동 전에 웹 기술스택의 연결 흐름을 익히기 위한 JavaScript 기반 MVP입니다.

## 포함된 기술

- React + Vite
- JavaScript, TypeScript 없음
- Ant Design Layout / Tree / Form / Table / TextArea
- Zustand 상태 관리
- React Flow diagram
- Mock model data

## 실행 방법

```bash
npm install
npm run dev
```

브라우저에서 Vite가 알려주는 주소를 열면 됩니다. 보통 다음 주소입니다.

```bash
http://localhost:5173
```

## 먼저 볼 파일

```text
src/model/mockModel.js              샘플 모델 데이터
src/store/modelStore.js             Zustand 상태 저장소
src/app/AppShell.jsx                전체 3분할 화면
src/features/explorer/ModelTree.jsx Tree
src/features/diagram/ModelDiagram.jsx React Flow diagram
src/features/properties/PropertyPanel.jsx 속성 패널
src/features/members/MemberTable.jsx 구조체 멤버 테이블
src/features/text-editor/TextEditor.jsx IDL/QoS TextArea
```

## 핵심 흐름

```text
ModelTree 클릭
  -> selectedElementId 변경
  -> PropertyPanel 내용 변경
  -> Diagram 선택 표시 변경

Diagram Node 클릭
  -> selectedElementId 변경
  -> Tree 선택 변경
  -> PropertyPanel 내용 변경

PropertyPanel 수정
  -> elementsById 변경
  -> Tree 이름/Diagram 이름 함께 변경
  -> dirty 상태 modified로 변경
```

## 다음 단계 추천

1. mockModel.js에 Topic, Struct, Participant를 더 추가해보기
2. PropertyPanel.jsx에 QoS 항목을 더 추가해보기
3. MemberTable.jsx에서 타입을 Input 대신 Select로 바꿔보기
4. TextEditor.jsx를 나중에 CodeMirror로 교체해보기
5. QEA SQLite read-only importer를 별도 파일로 추가하기
