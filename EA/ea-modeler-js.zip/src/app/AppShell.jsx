import { Layout, Tag } from 'antd';
import ModelTree from '../features/explorer/ModelTree.jsx';
import ModelDiagram from '../features/diagram/ModelDiagram.jsx';
import PropertyPanel from '../features/properties/PropertyPanel.jsx';
import { useModelStore } from '../store/modelStore.js';

const { Header, Sider, Content } = Layout;

export default function AppShell() {
  const dirty = useModelStore((state) => state.dirty);

  return (
    <Layout className="app-shell">
      <Header className="app-header">
        EA Modeler JS MVP
        <span style={{ marginLeft: 12 }}>
          {dirty ? <Tag color="orange">modified</Tag> : <Tag color="green">clean</Tag>}
        </span>
      </Header>

      <Layout className="app-content">
        <Sider width={280} theme="light" className="left-panel">
          <div className="panel-title">Model Explorer</div>
          <div className="panel-body">
            <ModelTree />
          </div>
        </Sider>

        <Content>
          <ModelDiagram />
        </Content>

        <Sider width={380} theme="light" className="right-panel">
          <div className="panel-title">Properties</div>
          <PropertyPanel />
        </Sider>
      </Layout>
    </Layout>
  );
}
