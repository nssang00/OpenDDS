import React from 'react';
import ReactDOM from 'react-dom/client';
import { ConfigProvider, App as AntdApp } from 'antd';
import 'antd/dist/reset.css';
import '@xyflow/react/dist/style.css';
import './styles.css';
import AppShell from './app/AppShell.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ConfigProvider>
      <AntdApp>
        <AppShell />
      </AntdApp>
    </ConfigProvider>
  </React.StrictMode>
);
