import { useEffect } from 'react';
import { Divider, Form, Input, InputNumber, Select, Typography } from 'antd';
import { useModelStore } from '../../store/modelStore.js';
import MemberTable from '../members/MemberTable.jsx';
import TextEditor from '../text-editor/TextEditor.jsx';

const { Text } = Typography;

function fieldInputFor(key, value) {
  if (key === 'reliability') {
    return (
      <Select
        options={[
          { label: 'RELIABLE', value: 'RELIABLE' },
          { label: 'BEST_EFFORT', value: 'BEST_EFFORT' },
        ]}
      />
    );
  }

  if (key === 'durability') {
    return (
      <Select
        options={[
          { label: 'VOLATILE', value: 'VOLATILE' },
          { label: 'TRANSIENT_LOCAL', value: 'TRANSIENT_LOCAL' },
          { label: 'TRANSIENT', value: 'TRANSIENT' },
          { label: 'PERSISTENT', value: 'PERSISTENT' },
        ]}
      />
    );
  }

  if (typeof value === 'number') {
    return <InputNumber style={{ width: '100%' }} />;
  }

  return <Input />;
}

export default function PropertyPanel() {
  const [form] = Form.useForm();
  const elementsById = useModelStore((state) => state.elementsById);
  const selectedElementId = useModelStore((state) => state.selectedElementId);
  const updateElement = useModelStore((state) => state.updateElement);
  const updateProperty = useModelStore((state) => state.updateProperty);

  const element = selectedElementId ? elementsById[selectedElementId] : null;

  useEffect(() => {
    if (!element) return;
    form.setFieldsValue({
      name: element.name,
      type: element.type,
      ...element.properties,
    });
  }, [element, form]);

  if (!element) {
    return <div className="empty-state">Select an element.</div>;
  }

  const normalProperties = Object.entries(element.properties || {}).filter(
    ([, value]) => !Array.isArray(value) && typeof value !== 'string'
  );

  const shortTextProperties = Object.entries(element.properties || {}).filter(
    ([key, value]) =>
      typeof value === 'string' && key !== 'idl' && key !== 'qosXml' && value.length < 80
  );

  const editorProperties = Object.entries(element.properties || {}).filter(
    ([key, value]) => typeof value === 'string' && (key === 'idl' || key === 'qosXml' || value.length >= 80)
  );

  return (
    <div className="panel-body">
      <Text type="secondary">Selected ID: {element.id}</Text>

      <Divider orientation="left">Basic</Divider>
      <Form
        form={form}
        layout="vertical"
        onValuesChange={(changed) => {
          const [key, value] = Object.entries(changed)[0];
          if (key === 'name') {
            updateElement(element.id, { name: value });
          } else if (key !== 'type') {
            updateProperty(element.id, key, value);
          }
        }}
      >
        <Form.Item label="name" name="name">
          <Input />
        </Form.Item>
        <Form.Item label="type" name="type">
          <Input disabled />
        </Form.Item>

        {[...shortTextProperties, ...normalProperties].map(([key, value]) => (
          <Form.Item key={key} label={key} name={key}>
            {fieldInputFor(key, value)}
          </Form.Item>
        ))}
      </Form>

      {Array.isArray(element.properties.members) && (
        <>
          <Divider orientation="left">Struct Members</Divider>
          <MemberTable elementId={element.id} members={element.properties.members} />
        </>
      )}

      {editorProperties.map(([key, value]) => (
        <div key={key}>
          <Divider orientation="left">{key}</Divider>
          <TextEditor
            value={value}
            onChange={(nextValue) => updateProperty(element.id, key, nextValue)}
          />
        </div>
      ))}
    </div>
  );
}
