import { useMemo } from 'react';
import { ReactFlow, Background, Controls, MiniMap } from '@xyflow/react';
import { useModelStore } from '../../store/modelStore.js';

function ModelNode({ data, selected }) {
  return (
    <div className={`model-node ${selected ? 'selected-node' : ''}`}>
      <strong>{data.label}</strong>
      <div className="model-node-type">{data.type}</div>
    </div>
  );
}

const nodeTypes = {
  modelNode: ModelNode,
};

export default function ModelDiagram() {
  const elementsById = useModelStore((state) => state.elementsById);
  const diagram = useModelStore((state) => state.diagram);
  const selectedElementId = useModelStore((state) => state.selectedElementId);
  const selectElement = useModelStore((state) => state.selectElement);

  const nodes = useMemo(() => {
    return diagram.nodes.map((node) => {
      const element = elementsById[node.id];
      return {
        id: node.id,
        type: 'modelNode',
        position: node.position,
        selected: node.id === selectedElementId,
        data: {
          label: element?.name ?? node.id,
          type: element?.type ?? 'Unknown',
        },
      };
    });
  }, [diagram.nodes, elementsById, selectedElementId]);

  const edges = useMemo(() => {
    return diagram.edges.map((edge) => ({
      ...edge,
      animated: edge.source === selectedElementId || edge.target === selectedElementId,
    }));
  }, [diagram.edges, selectedElementId]);

  return (
    <div className="diagram-wrapper">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        fitView
        onNodeClick={(_, node) => selectElement(node.id)}
      >
        <Background />
        <Controls />
        <MiniMap />
      </ReactFlow>
    </div>
  );
}
