import { Tree } from 'antd';
import { ApartmentOutlined, DatabaseOutlined, NodeIndexOutlined } from '@ant-design/icons';
import { useModelStore } from '../../store/modelStore.js';

function iconForType(type) {
  if (type === 'Package') return <ApartmentOutlined />;
  if (type === 'Struct') return <DatabaseOutlined />;
  return <NodeIndexOutlined />;
}

function buildTree(elementsById) {
  const elements = Object.values(elementsById);

  return elements
    .filter((element) => element.parentId === null)
    .map((root) => ({
      key: root.id,
      title: root.name,
      icon: iconForType(root.type),
      children: elements
        .filter((element) => element.parentId === root.id)
        .map((child) => ({
          key: child.id,
          title: child.name,
          icon: iconForType(child.type),
        })),
    }));
}

export default function ModelTree() {
  const elementsById = useModelStore((state) => state.elementsById);
  const selectedElementId = useModelStore((state) => state.selectedElementId);
  const selectElement = useModelStore((state) => state.selectElement);

  return (
    <Tree.DirectoryTree
      showIcon
      defaultExpandAll
      selectedKeys={selectedElementId ? [selectedElementId] : []}
      treeData={buildTree(elementsById)}
      onSelect={(keys) => {
        if (keys[0]) selectElement(keys[0]);
      }}
    />
  );
}
