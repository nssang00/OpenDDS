import { create } from 'zustand';
import { initialDiagram, initialElements } from '../model/mockModel.js';

export const useModelStore = create((set, get) => ({
  elementsById: initialElements,
  diagram: initialDiagram,
  selectedElementId: 'topic-vehicle-status',
  dirty: false,

  selectElement: (id) => set({ selectedElementId: id }),

  updateElement: (id, patch) => {
    const current = get().elementsById[id];
    if (!current) return;

    set({
      elementsById: {
        ...get().elementsById,
        [id]: {
          ...current,
          ...patch,
        },
      },
      dirty: true,
    });
  },

  updateProperty: (id, key, value) => {
    const current = get().elementsById[id];
    if (!current) return;

    set({
      elementsById: {
        ...get().elementsById,
        [id]: {
          ...current,
          properties: {
            ...current.properties,
            [key]: value,
          },
        },
      },
      dirty: true,
    });
  },

  updateMembers: (id, members) => {
    const current = get().elementsById[id];
    if (!current) return;

    set({
      elementsById: {
        ...get().elementsById,
        [id]: {
          ...current,
          properties: {
            ...current.properties,
            members,
          },
        },
      },
      dirty: true,
    });
  },
}));
