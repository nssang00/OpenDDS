export const initialElements = {
  'pkg-dds': {
    id: 'pkg-dds',
    name: 'DDS Model',
    type: 'Package',
    parentId: null,
    properties: {
      description: 'Sample DDS modeling package',
    },
  },
  'topic-vehicle-status': {
    id: 'topic-vehicle-status',
    name: 'VehicleStatus',
    type: 'Topic',
    parentId: 'pkg-dds',
    properties: {
      dataType: 'VehicleStatusType',
      reliability: 'RELIABLE',
      durability: 'TRANSIENT_LOCAL',
      qosXml: '<datawriter_qos>\n  <reliability>RELIABLE</reliability>\n</datawriter_qos>',
    },
  },
  'type-vehicle-status': {
    id: 'type-vehicle-status',
    name: 'VehicleStatusType',
    type: 'Struct',
    parentId: 'pkg-dds',
    properties: {
      idl: 'struct VehicleStatusType {\n  float speed;\n  long gear;\n};',
      members: [
        { id: 'm-speed', name: 'speed', type: 'float32', defaultValue: '0.0' },
        { id: 'm-gear', name: 'gear', type: 'int32', defaultValue: '0' },
      ],
    },
  },
  'participant-main': {
    id: 'participant-main',
    name: 'MainParticipant',
    type: 'DomainParticipant',
    parentId: 'pkg-dds',
    properties: {
      domainId: 0,
      qosXml: '<domain_participant_qos>\n</domain_participant_qos>',
    },
  },
};

export const initialDiagram = {
  nodes: [
    { id: 'participant-main', position: { x: 80, y: 80 } },
    { id: 'topic-vehicle-status', position: { x: 360, y: 80 } },
    { id: 'type-vehicle-status', position: { x: 360, y: 260 } },
  ],
  edges: [
    { id: 'e-participant-topic', source: 'participant-main', target: 'topic-vehicle-status', label: 'publishes/subscribes' },
    { id: 'e-topic-type', source: 'topic-vehicle-status', target: 'type-vehicle-status', label: 'dataType' },
  ],
};
