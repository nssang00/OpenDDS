import { Card, Descriptions, Tabs } from 'antd';
import MainLayout from '../layouts/MainLayout.jsx';
import ModelDiagram from '../components/ModelDiagram.jsx';
import TextEditor from '../components/TextEditor.jsx';
import { useDesignerStore } from '../stores/useDesignerStore.js';
import { generateIdl } from '../utils/idlGenerator.js';
import { generateModelSummary } from '../utils/documentGenerator.js';

export default function WorkspacePage() {
  const model = useDesignerStore((state) => state.model);
  const summary = generateModelSummary(model);

  const items = [
    {
      key: 'diagram',
      label: 'Diagram',
      children: <ModelDiagram />,
    },
    {
      key: 'idl',
      label: 'IDL Preview',
      children: (
        <div className="tab-panel">
          <TextEditor value={generateIdl(model)} onChange={() => {}} />
        </div>
      ),
    },
    {
      key: 'document',
      label: 'Document',
      children: (
        <div className="tab-panel">
          <Card title="Model Summary" size="small">
            <Descriptions bordered size="small" column={1}>
              <Descriptions.Item label="Topics">{summary.topics}</Descriptions.Item>
              <Descriptions.Item label="Struct Types">{summary.structs}</Descriptions.Item>
              <Descriptions.Item label="QoS Profiles">{summary.qosProfiles}</Descriptions.Item>
            </Descriptions>
          </Card>
        </div>
      ),
    },
  ];

  return (
    <MainLayout>
      <Tabs className="workspace-tabs" items={items} />
    </MainLayout>
  );
}
