import { useState } from 'react';
import { Button, Drawer, Layout, Space, Tag, Typography } from 'antd';
import { ExportOutlined, ProjectOutlined, TeamOutlined } from '@ant-design/icons';
import ModelTree from '../components/ModelTree.jsx';
import PropertyPanel from '../components/PropertyPanel.jsx';
import TextEditor from '../components/TextEditor.jsx';
import { useAuthStore } from '../stores/useAuthStore.js';
import { useProjectStore } from '../stores/useProjectStore.js';
import { useDesignerStore } from '../stores/useDesignerStore.js';
import { generateIdl } from '../utils/idlGenerator.js';

const { Header, Sider, Content } = Layout;
const { Text } = Typography;

export default function MainLayout({ children }) {
  const [exportOpen, setExportOpen] = useState(false);
  const user = useAuthStore((state) => state.user);
  const setPage = useAuthStore((state) => state.setPage);
  const logout = useAuthStore((state) => state.logout);
  const currentProject = useProjectStore((state) => state.currentProject);
  const dirty = useDesignerStore((state) => state.dirty);
  const model = useDesignerStore((state) => state.model);

  return (
    <Layout className="app-shell">
      <Header className="app-header">
        <div className="app-title">RTI System Designer MVP</div>
        <Tag color={dirty ? 'orange' : 'green'}>{dirty ? 'modified' : 'clean'}</Tag>
        <Text className="header-project">{currentProject?.name ?? 'No project'}</Text>
        <Space className="header-actions">
          <Button size="small" icon={<ProjectOutlined />} onClick={() => setPage('projects')}>
            Projects
          </Button>
          <Button size="small" icon={<TeamOutlined />} onClick={() => setPage('users')}>
            Users
          </Button>
          <Button size="small" icon={<ExportOutlined />} onClick={() => setExportOpen(true)}>
            Export
          </Button>
          <Text className="header-user">{user?.name}</Text>
          <Button size="small" onClick={logout}>Logout</Button>
        </Space>
      </Header>

      <Layout className="app-content">
        <Sider width={300} theme="light" className="left-panel">
          <div className="panel-title">Model Tree</div>
          <div className="panel-body">
            <ModelTree />
          </div>
        </Sider>

        <Content className="main-workspace">{children}</Content>

        <Sider width={390} theme="light" className="right-panel">
          <div className="panel-title">Properties</div>
          <PropertyPanel />
        </Sider>
      </Layout>

      <Drawer
        title="Export Preview"
        width={560}
        open={exportOpen}
        onClose={() => setExportOpen(false)}
        extra={<Button type="primary">Download IDL</Button>}
      >
        <Text type="secondary">MVP에서는 생성 결과를 미리보기만 합니다.</Text>
        <div style={{ marginTop: 12 }}>
          <TextEditor value={generateIdl(model)} onChange={() => {}} />
        </div>
      </Drawer>
    </Layout>
  );
}
