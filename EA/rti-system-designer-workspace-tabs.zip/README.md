# RTI System Designer MVP - esbuild Static Build

Sparx EA에서 변환된 JSON 모델을 웹에서 확인하고, Topic / Type / QoS 속성을 수정한 뒤 IDL 또는 문서 생성으로 확장하기 위한 MVP 예제입니다.

## 구조

```text
src/
├── main.jsx
├── App.jsx
├── layouts/
│   └── MainLayout.jsx
├── pages/
│   ├── LoginPage.jsx
│   ├── ProjectListPage.jsx
│   ├── DesignerPage.jsx
│   └── UserManagementPage.jsx
├── components/
│   ├── ModelTree.jsx
│   ├── ModelDiagram.jsx
│   ├── PropertyPanel.jsx
│   ├── MemberTable.jsx
│   └── TextEditor.jsx
├── stores/
│   ├── useAuthStore.js
│   ├── useProjectStore.js
│   └── useDesignerStore.js
├── api/
│   └── mockData.js
├── utils/
│   ├── idlGenerator.js
│   └── documentGenerator.js
└── assets/
```

## 의도

대규모 feature 기반 구조는 제거하고, MVP에서 이해하기 쉬운 기본 폴더 구조만 사용합니다.

- `main.jsx`: React 진입점
- `App.jsx`: 로그인 여부와 현재 화면에 따른 단순 화면 분기
- `MainLayout.jsx`: System Designer 스타일의 상단바 / 좌측 트리 / 중앙 다이어그램 / 우측 속성 패널
- `stores`: Zustand 상태 관리
- `api/mockData.js`: 백엔드 JSON 응답을 흉내 낸 임의 데이터
- `utils/idlGenerator.js`: Struct 정보 기반 IDL Preview 생성 예시

## 실행

```bash
npm install
npm run dev
```

브라우저에서 아래 주소를 엽니다.

```text
http://localhost:5173
```

## 빌드

```bash
npm run build
```

결과물은 `dist/`에 생성됩니다.

```text
dist/
├── index.html
├── app.js
└── app.css
```

## esbuild 방식 유지

`esbuild.config.mjs`는 기존 방식을 유지합니다.

```js
entryPoints: ['src/main.jsx']
format: 'iife'
outfile: 'dist/app.js'
jsx: 'automatic'
```
