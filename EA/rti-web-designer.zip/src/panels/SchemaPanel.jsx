import { useMemo } from 'react';
import { createForm } from '@formily/core';
import { createSchemaField, FormProvider } from '@formily/react';
import { Form, FormItem, Input, NumberPicker, Select, Switch } from '@formily/antd-v5';
import { useDesignerStore } from '../store/designerStore.js';

const SchemaField = createSchemaField({
  components: {
    FormItem,
    Input,
    NumberPicker,
    Select,
    Switch,
  },
});

export function SchemaPanel() {
  const config = useDesignerStore((state) => state.config);
  const form = useMemo(
    () =>
      createForm({
        initialValues: config.form.initialValues,
      }),
    [config.form.initialValues],
  );

  return (
    <div className="panel-pad schema-panel">
      <FormProvider form={form}>
        <Form layout="vertical" feedbackLayout="terse">
          <SchemaField schema={config.form.schema} />
        </Form>
      </FormProvider>
    </div>
  );
}
