import Editor from '@monaco-editor/react';
import { useDesignerStore } from '../store/designerStore.js';

export function JsonPanel() {
  const modelJson = useDesignerStore((state) => state.modelJson);
  const updateModelJson = useDesignerStore((state) => state.updateModelJson);

  return (
    <Editor
      height="100%"
      language="json"
      theme="vs-dark"
      value={modelJson}
      onChange={(value) => updateModelJson(value || '')}
      options={{
        minimap: { enabled: false },
        fontSize: 13,
        tabSize: 2,
        wordWrap: 'on',
        automaticLayout: true,
      }}
    />
  );
}
