import { AgGridReact } from 'ag-grid-react';
import { AllCommunityModule, ModuleRegistry } from 'ag-grid-community';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import { useDesignerStore } from '../store/designerStore.js';

ModuleRegistry.registerModules([AllCommunityModule]);

const columnDefs = [
  { field: 'category', rowGroup: true, hide: true },
  { field: 'label', headerName: 'Property', flex: 1 },
  { field: 'value', headerName: 'Value', flex: 1, editable: true },
];

export function PropertiesPanel() {
  const config = useDesignerStore((state) => state.config);

  return (
    <div className="ag-theme-quartz-dark properties-grid">
      <AgGridReact
        rowData={config.properties}
        columnDefs={columnDefs}
        groupDefaultExpanded={1}
        autoGroupColumnDef={{ headerName: 'Category', minWidth: 140 }}
        defaultColDef={{ resizable: true, sortable: true }}
      />
    </div>
  );
}
