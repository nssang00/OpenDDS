import { Tree } from 'antd';
import { useDesignerStore } from '../store/designerStore.js';

const { DirectoryTree } = Tree;

export function ExplorerPanel() {
  const config = useDesignerStore((state) => state.config);
  const selectedKey = useDesignerStore((state) => state.selectedKey);
  const selectTreeItem = useDesignerStore((state) => state.selectTreeItem);

  return (
    <div className="panel-pad">
      <DirectoryTree
        defaultExpandAll
        blockNode
        selectedKeys={[selectedKey]}
        treeData={config.tree}
        onSelect={(keys) => {
          if (keys[0]) selectTreeItem(keys[0]);
        }}
      />
    </div>
  );
}
