import { useCallback } from 'react';
import { Background, Controls, MiniMap, ReactFlow } from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { useDesignerStore } from '../store/designerStore.js';

export function DiagramPanel() {
  const config = useDesignerStore((state) => state.config);
  const selectedNodeId = useDesignerStore((state) => state.selectedNodeId);
  const selectGraphNode = useDesignerStore((state) => state.selectGraphNode);

  const onNodeClick = useCallback(
    (_, node) => {
      selectGraphNode(node.id);
    },
    [selectGraphNode],
  );

  const nodes = config.graph.nodes.map((node) => ({
    ...node,
    selected: node.id === selectedNodeId,
    className: node.id === selectedNodeId ? 'flow-node-selected' : '',
  }));

  return (
    <div className="diagram-panel">
      <ReactFlow nodes={nodes} edges={config.graph.edges} fitView onNodeClick={onNodeClick}>
        <Background color="#395168" gap={18} />
        <MiniMap pannable zoomable />
        <Controls />
      </ReactFlow>
    </div>
  );
}
