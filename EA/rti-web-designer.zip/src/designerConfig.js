export const designerConfig = {
  app: {
    title: 'RTI System Designer',
    subtitle: 'JSON-driven web modeling workspace',
    project: 'Smart Factory Cell',
  },
  toolbar: [
    { id: 'save', label: 'Save', type: 'primary' },
    { id: 'validate', label: 'Validate' },
    { id: 'export', label: 'Export JSON' },
  ],
  dock: [
    { id: 'explorer', title: 'Explorer', component: 'explorer', position: 'left' },
    { id: 'diagram', title: 'DDS Graph', component: 'diagram', position: 'center' },
    { id: 'properties', title: 'Properties', component: 'properties', position: 'right' },
    { id: 'schema', title: 'QoS Form', component: 'schema', position: 'bottom' },
    { id: 'json', title: 'Model JSON', component: 'json', position: 'bottom' },
  ],
  tree: [
    {
      title: 'Domain: Factory',
      key: 'domain.factory',
      children: [
        {
          title: 'Participants',
          key: 'participants',
          children: [
            { title: 'RobotController', key: 'participant.robot-controller', entityType: 'participant' },
            { title: 'VisionSystem', key: 'participant.vision-system', entityType: 'participant' },
          ],
        },
        {
          title: 'Topics',
          key: 'topics',
          children: [
            { title: 'RobotCommand', key: 'topic.robot-command', entityType: 'topic' },
            { title: 'VisionFrame', key: 'topic.vision-frame', entityType: 'topic' },
            { title: 'CellStatus', key: 'topic.cell-status', entityType: 'topic' },
          ],
        },
      ],
    },
  ],
  properties: [
    { id: 'name', label: 'Name', value: 'RobotCommand', category: 'Topic' },
    { id: 'type', label: 'Data Type', value: 'CommandMessage', category: 'Topic' },
    { id: 'reliability', label: 'Reliability', value: 'Reliable', category: 'QoS' },
    { id: 'durability', label: 'Durability', value: 'Transient Local', category: 'QoS' },
    { id: 'deadline', label: 'Deadline', value: '20 ms', category: 'QoS' },
  ],
  graph: {
    nodes: [
      {
        id: 'robot',
        type: 'default',
        position: { x: 80, y: 120 },
        data: { label: 'RobotController\nPublisher' },
      },
      {
        id: 'command',
        type: 'default',
        position: { x: 360, y: 90 },
        data: { label: 'RobotCommand\nTopic' },
      },
      {
        id: 'vision',
        type: 'default',
        position: { x: 360, y: 250 },
        data: { label: 'VisionFrame\nTopic' },
      },
      {
        id: 'dashboard',
        type: 'default',
        position: { x: 670, y: 170 },
        data: { label: 'OperationsUI\nSubscriber' },
      },
    ],
    edges: [
      { id: 'e-robot-command', source: 'robot', target: 'command', animated: true },
      { id: 'e-command-dashboard', source: 'command', target: 'dashboard' },
      { id: 'e-vision-dashboard', source: 'vision', target: 'dashboard' },
    ],
  },
  form: {
    initialValues: {
      topicName: 'RobotCommand',
      reliability: 'reliable',
      historyDepth: 8,
      transientLocal: true,
    },
    schema: {
      type: 'object',
      properties: {
        topicName: {
          type: 'string',
          title: 'Topic Name',
          'x-decorator': 'FormItem',
          'x-component': 'Input',
          'x-component-props': { placeholder: 'Topic name' },
        },
        reliability: {
          type: 'string',
          title: 'Reliability',
          enum: [
            { label: 'Reliable', value: 'reliable' },
            { label: 'Best Effort', value: 'best_effort' },
          ],
          'x-decorator': 'FormItem',
          'x-component': 'Select',
        },
        historyDepth: {
          type: 'number',
          title: 'History Depth',
          'x-decorator': 'FormItem',
          'x-component': 'NumberPicker',
          'x-component-props': { min: 1, max: 128 },
        },
        transientLocal: {
          type: 'boolean',
          title: 'Transient Local',
          'x-decorator': 'FormItem',
          'x-component': 'Switch',
        },
      },
    },
  },
};
