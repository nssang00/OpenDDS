import { create } from 'zustand';
import { designerConfig } from '../designerConfig.js';

export const useDesignerStore = create((set, get) => ({
  config: designerConfig,
  selectedKey: 'topic.robot-command',
  selectedNodeId: 'command',
  modelJson: JSON.stringify(designerConfig, null, 2),
  selectTreeItem: (selectedKey) => set({ selectedKey }),
  selectGraphNode: (selectedNodeId) => set({ selectedNodeId }),
  updateModelJson: (modelJson) => {
    set({ modelJson });
    try {
      const nextConfig = JSON.parse(modelJson);
      set({ config: nextConfig });
    } catch {
      set({ config: get().config });
    }
  },
}));
