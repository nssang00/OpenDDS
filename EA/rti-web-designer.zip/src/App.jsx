import { useCallback, useMemo } from 'react';
import { App as AntApp, Button, Layout, Space, Tag, Typography } from 'antd';
import { DockviewReact } from 'dockview';
import 'dockview/dist/styles/dockview.css';
import { useDesignerStore } from './store/designerStore.js';
import { DiagramPanel } from './panels/DiagramPanel.jsx';
import { ExplorerPanel } from './panels/ExplorerPanel.jsx';
import { JsonPanel } from './panels/JsonPanel.jsx';
import { PropertiesPanel } from './panels/PropertiesPanel.jsx';
import { SchemaPanel } from './panels/SchemaPanel.jsx';

const { Header, Content } = Layout;
const { Text, Title } = Typography;

const components = {
  explorer: ExplorerPanel,
  diagram: DiagramPanel,
  properties: PropertiesPanel,
  schema: SchemaPanel,
  json: JsonPanel,
};

function addDockPanels(api, panels) {
  const refs = {};

  panels.forEach((panel) => {
    if (panel.position === 'center') {
      refs[panel.id] = api.addPanel({
        id: panel.id,
        title: panel.title,
        component: panel.component,
      });
    }
  });

  panels.forEach((panel) => {
    if (panel.position === 'left') {
      refs[panel.id] = api.addPanel({
        id: panel.id,
        title: panel.title,
        component: panel.component,
        position: { referencePanel: 'diagram', direction: 'left' },
      });
    }

    if (panel.position === 'right') {
      refs[panel.id] = api.addPanel({
        id: panel.id,
        title: panel.title,
        component: panel.component,
        position: { referencePanel: 'diagram', direction: 'right' },
      });
    }
  });

  panels.forEach((panel) => {
    if (panel.position === 'bottom') {
      refs[panel.id] = api.addPanel({
        id: panel.id,
        title: panel.title,
        component: panel.component,
        position: { referencePanel: 'diagram', direction: 'below' },
      });
    }
  });
}

export default function App() {
  const config = useDesignerStore((state) => state.config);
  const selectedKey = useDesignerStore((state) => state.selectedKey);

  const onReady = useCallback(
    (event) => {
      addDockPanels(event.api, config.dock);
    },
    [config.dock],
  );

  const toolbar = useMemo(
    () =>
      config.toolbar.map((item) => (
        <Button key={item.id} size="small" type={item.type}>
          {item.label}
        </Button>
      )),
    [config.toolbar],
  );

  return (
    <AntApp>
      <Layout className="app-shell">
        <Header className="app-header">
          <div className="brand">
            <Title level={4}>{config.app.title}</Title>
            <Text type="secondary">{config.app.subtitle}</Text>
          </div>
          <Space size={8} className="status-strip">
            <Tag color="green">{config.app.project}</Tag>
            <Tag color="blue">{selectedKey}</Tag>
            {toolbar}
          </Space>
        </Header>
        <Content className="workspace">
          <DockviewReact className="dockview-theme-abyss designer-dock" components={components} onReady={onReady} />
        </Content>
      </Layout>
    </AntApp>
  );
}
