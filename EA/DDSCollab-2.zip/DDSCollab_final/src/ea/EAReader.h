#pragma once
#include <string>
#include <vector>
#include <set>
#include "EAModels.h"
#include "../../third_party/sqlite3/sqlite3.h"

namespace EA {

// EAReader
// Reads EA Model data from QEA file (SQLite)
class EAReader {
public:
    EAReader();
    ~EAReader();

    bool open(const std::string& qea_path);
    void close();
    bool isOpen() const;

    // Read t_package
    std::vector<EAPackage> readPackages();
    EAPackage              readPackage(int package_id);

    // Resolve root package ID by name
    int findPackageIdByName(const std::string& name);

    // Collect all package IDs under a root package (recursive)
    std::set<int> collectPackageIdsUnder(int root_package_id);

    // Read all extractable t_object within package scope
    // Includes Class/Interface/Enumeration/DataType + DDS-stereotyped Part/Component/Port
    std::vector<EAObject> readDDSObjects(const std::set<int>& package_ids);

    // Read t_attribute
    std::vector<EAAttribute> readAttributesByObjects(
        const std::set<int>& object_ids);

    // Read t_attributetag
    std::vector<EAAttributeTag> readAttributeTagsByElements(
        const std::set<int>& element_ids);

    // Read t_connector
    std::vector<EAConnector> readConnectors(
        const std::set<int>& object_ids);

    // Read t_objectproperties
    std::vector<EAObjectProperty> readObjectProperties(
        const std::set<int>& object_ids);

    // Read t_taggedvalue
    std::vector<EATaggedValue> readTaggedValues(
        const std::set<int>& object_ids);

    // Collect required parent package IDs from objects
    std::set<int> collectRequiredPackageIds(
        const std::vector<EAObject>& objects);

    std::string getLastError() const { return last_error_; }

private:
    sqlite3*    db_          = nullptr;
    std::string last_error_;

    std::string getString(sqlite3_stmt* stmt, int col);
    int         getInt   (sqlite3_stmt* stmt, int col);
};

} // namespace EA
