#include "EAConverter.h"
#include <algorithm>
#include <sstream>
#include <random>
#include <functional>

namespace Converter {

EAConverter::EAConverter(EA::EAReader& reader, Repo::IRepository& repo)
    : reader_(reader), repo_(repo) {}

// ------------------------------------------------------------
// UUID generation (C++11)
// ------------------------------------------------------------
std::string EAConverter::generateUUID() {
    static std::random_device rd;
    static std::mt19937 gen(rd());
    static std::uniform_int_distribution<> d(0, 15);
    static std::uniform_int_distribution<> d2(8, 11);
    std::stringstream ss;
    ss << std::hex;
    for (int i = 0; i < 8;  i++) ss << d(gen);  ss << "-";
    for (int i = 0; i < 4;  i++) ss << d(gen);  ss << "-4";
    for (int i = 0; i < 3;  i++) ss << d(gen);  ss << "-";
    ss << d2(gen);
    for (int i = 0; i < 3;  i++) ss << d(gen);  ss << "-";
    for (int i = 0; i < 12; i++) ss << d(gen);
    return ss.str();
}

// ------------------------------------------------------------
// Object_Type + Stereotype -> types.kind
// ------------------------------------------------------------
std::string EAConverter::resolveTypeKind(const std::string& object_type,
                                          const std::string& stereotype)
{
    if (object_type == "Enumeration") return "enum";
    if (object_type == "DataType")    return "typedef";
    if (object_type == "Interface")   return "struct";
    if (object_type == "Class") {
        if (stereotype == "struct" || stereotype == "idlStruct") return "struct";
        if (stereotype == "enumeration")                          return "enum";
        if (stereotype == "union")                                return "union";
        if (stereotype == "typedef" || stereotype == "alias")     return "typedef";
        return "struct"; // default
    }
    return "";
}

// ------------------------------------------------------------
// EA type string -> DDS primitive_type
// ------------------------------------------------------------
std::string EAConverter::resolvePrimitiveType(const std::string& ea_type) {
    std::string t = ea_type;
    std::transform(t.begin(), t.end(), t.begin(), ::tolower);
    t.erase(std::remove(t.begin(), t.end(), ' '), t.end());

    if (t == "boolean" || t == "bool")            return "boolean";
    if (t == "octet"   || t == "byte")            return "octet";
    if (t == "char"    || t == "char8")           return "char";
    if (t == "wchar"   || t == "char16")          return "wchar";
    if (t == "int8")                              return "int8";
    if (t == "uint8")                             return "uint8";
    if (t == "short"   || t == "int16")           return "int16";
    if (t == "unsignedshort" || t == "uint16")    return "uint16";
    if (t == "long"    || t == "int" || t == "int32") return "int32";
    if (t == "unsignedlong"  || t == "uint32")    return "uint32";
    if (t == "longlong"      || t == "int64")     return "int64";
    if (t == "unsignedlonglong" || t == "uint64") return "uint64";
    if (t == "float"   || t == "float32")         return "float32";
    if (t == "double"  || t == "float64")         return "float64";
    if (t == "longdouble" || t == "float128")     return "float128";
    if (t == "string"  || t == "char*")           return "string";
    if (t == "wstring")                           return "wstring";
    return ""; // complex type
}

// ------------------------------------------------------------
// LowerBound/UpperBound -> collection info
// ------------------------------------------------------------
void EAConverter::resolveCollection(const std::string& lower_bound,
                                     const std::string& upper_bound,
                                     Repo::TypeMember& member)
{
    member.lower_bound = lower_bound;
    member.upper_bound = upper_bound;

    if (upper_bound.empty() || upper_bound == "1") {
        if (lower_bound == "0" && upper_bound == "1")
            member.is_optional = 1;
        return;
    }
    if (upper_bound == "0" || upper_bound == "*") {
        member.is_sequence = 1; member.sequence_bound = -1; return;
    }
    try {
        int lower = lower_bound.empty() ? 1 : std::stoi(lower_bound);
        int upper = std::stoi(upper_bound);
        if (lower == upper && upper > 1) {
            member.is_array = 1;
            member.array_dimensions = "[" + std::to_string(upper) + "]";
        } else if (lower < upper) {
            member.is_sequence = 1; member.sequence_bound = upper;
        }
    } catch (...) {}
}

// ------------------------------------------------------------
// member_kind determination
// ------------------------------------------------------------
std::string EAConverter::resolveMemberKind(const std::string& type_kind,
                                            const std::string& ea_stereotype)
{
    if (type_kind == "enum")  return "literal";
    if (type_kind == "union") {
        if (ea_stereotype == "discriminator") return "discriminator";
        return "case";
    }
    return "field";
}

// ============================================================
// Main convert function
// ============================================================
ConvertResult EAConverter::convert(const std::string& project_id,
                                    const std::string& qea_path,
                                    const std::string& root_package_name)
{
    ConvertResult result;
    if (!reader_.isOpen()) {
        result.errors.push_back("QEA file is not open.");
        return result;
    }

    repo_.beginTransaction();
    try {
        // Step 1. Determine target package scope
        std::set<int> target_pkg_ids;

        if (!root_package_name.empty()) {
            int root_id = reader_.findPackageIdByName(root_package_name);
            if (root_id <= 0) {
                result.errors.push_back(
                    "Root package not found: " + root_package_name);
                repo_.rollbackTransaction();
                return result;
            }
            target_pkg_ids = reader_.collectPackageIdsUnder(root_id);
        } else {
            // No filter: collect all packages
            auto all_pkgs = reader_.readPackages();
            for (const auto& p : all_pkgs) target_pkg_ids.insert(p.package_id);
        }

        // Step 2. Read all extractable objects within target packages
        auto all_objects = reader_.readDDSObjects(target_pkg_ids);

        std::set<int> obj_ids;
        for (const auto& obj : all_objects) obj_ids.insert(obj.object_id);

        // Step 3. Collect required package IDs (parent chain)
        auto required_pkg_ids = reader_.collectRequiredPackageIds(all_objects);
        // Intersect with target_pkg_ids to avoid going outside root
        if (!root_package_name.empty()) {
            std::set<int> filtered;
            for (int id : required_pkg_ids) {
                if (target_pkg_ids.find(id) != target_pkg_ids.end())
                    filtered.insert(id);
            }
            required_pkg_ids = filtered;
        }

        // Step 4. Convert packages
        auto all_packages = reader_.readPackages();
        convertPackages(project_id, required_pkg_ids, all_packages, result);

        // Step 5. Convert objects -> types / domains / topics / participants
        convertObjects(project_id, all_objects, result);

        // Step 6. Convert attributes -> type_members
        std::set<int> type_obj_ids;
        for (const auto& obj : all_objects) {
            if (obj.object_type == "Class"       ||
                obj.object_type == "Interface"   ||
                obj.object_type == "Enumeration" ||
                obj.object_type == "DataType")
                type_obj_ids.insert(obj.object_id);
        }

        auto attributes = reader_.readAttributesByObjects(type_obj_ids);
        std::set<int> attr_ids;
        for (const auto& attr : attributes) attr_ids.insert(attr.id);
        auto attr_tags = reader_.readAttributeTagsByElements(attr_ids);
        convertAttributes(project_id, attributes, attr_tags, result);

        // Step 7. Process object properties (topic->type, participant->domain)
        auto obj_props = reader_.readObjectProperties(obj_ids);
        processObjectProperties(obj_props, result);

        // Step 8. Process connectors (Generalization, Association)
        auto connectors = reader_.readConnectors(obj_ids);
        processConnectors(connectors, result);

        // Step 9. audit_log
        Repo::AuditLog log;
        log.id         = generateUUID();
        log.project_id = project_id;
        log.target_kind= "project";
        log.target_id  = project_id;
        log.action     = "ea_sync";
        log.changed_by = "ea_import";
        log.diff       = "{\"source\":\"" + qea_path + "\","
                         "\"root_package\":\"" + root_package_name + "\","
                         "\"types\":"        + std::to_string(result.types) +
                         ",\"type_members\":" + std::to_string(result.type_members) +
                         ",\"domains\":"     + std::to_string(result.domains) +
                         ",\"topics\":"      + std::to_string(result.topics) + "}";
        repo_.saveAuditLog(log);

        repo_.commitTransaction();
    } catch (const std::exception& e) {
        repo_.rollbackTransaction();
        result.errors.push_back(std::string("Conversion error: ") + e.what());
    }
    return result;
}

// ------------------------------------------------------------
// Convert packages
// ------------------------------------------------------------
void EAConverter::convertPackages(
    const std::string& project_id,
    const std::set<int>& required_pkg_ids,
    const std::vector<EA::EAPackage>& all_packages,
    ConvertResult& result)
{
    std::map<int, EA::EAPackage> pkg_map;
    for (const auto& pkg : all_packages) pkg_map[pkg.package_id] = pkg;

    std::vector<int> ordered;
    std::set<int> visited;

    std::function<void(int)> visit = [&](int pkg_id) {
        if (visited.count(pkg_id) || !required_pkg_ids.count(pkg_id)) return;
        auto it = pkg_map.find(pkg_id);
        if (it == pkg_map.end()) return;
        if (it->second.parent_id > 0) visit(it->second.parent_id);
        visited.insert(pkg_id);
        ordered.push_back(pkg_id);
    };

    for (int pkg_id : required_pkg_ids) visit(pkg_id);

    for (int pkg_id : ordered) {
        auto it = pkg_map.find(pkg_id);
        if (it == pkg_map.end()) continue;
        const EA::EAPackage& ea_pkg = it->second;

        std::string existing_id = repo_.findPackageByEaGuid(ea_pkg.ea_guid);

        Repo::Package repo_pkg;
        repo_pkg.id          = existing_id.empty() ? generateUUID() : existing_id;
        repo_pkg.project_id  = project_id;
        repo_pkg.name        = ea_pkg.name;
        repo_pkg.description = ea_pkg.notes;
        repo_pkg.ordinal     = ea_pkg.t_pos;
        repo_pkg.ea_guid     = ea_pkg.ea_guid;
        repo_pkg.source      = "ea";
        repo_pkg.kind        = "module";

        if (ea_pkg.parent_id > 0) {
            auto parent_it = pkg_map.find(ea_pkg.parent_id);
            if (parent_it != pkg_map.end()) {
                auto cached = pkg_guid_to_id_.find(parent_it->second.ea_guid);
                if (cached != pkg_guid_to_id_.end())
                    repo_pkg.parent_id = cached->second;
            }
        }

        if (repo_.savePackage(repo_pkg)) {
            pkg_guid_to_id_[ea_pkg.ea_guid]       = repo_pkg.id;
            pkg_id_to_repo_id_[ea_pkg.package_id] = repo_pkg.id;
            result.packages++;
        }
    }
}

// ------------------------------------------------------------
// Convert objects
// ------------------------------------------------------------
void EAConverter::convertObjects(const std::string& project_id,
                                  const std::vector<EA::EAObject>& objects,
                                  ConvertResult& result)
{
    for (const auto& obj : objects) {
        const std::string& ot = obj.object_type;
        const std::string& st = obj.stereotype;

        if (ot == "Class" || ot == "Interface" ||
            ot == "Enumeration" || ot == "DataType")
            convertToType(project_id, obj, result);
        else if (ot == "Part" && st == "domain")
            convertToDomain(project_id, obj, result);
        else if (ot == "Part" && st == "topic")
            convertToTopic(project_id, obj, result);
        else if (ot == "Component" && st == "domainParticipant")
            convertToParticipant(project_id, obj, result);
        else if (ot == "Part" && st == "publisher")
            convertToPublisher(project_id, obj, result);
        else if (ot == "Part" && st == "subscriber")
            convertToSubscriber(project_id, obj, result);
        else if (ot == "Port" && st == "dataWriter")
            convertToWriter(project_id, obj, result);
        else if (ot == "Port" && st == "dataReader")
            convertToReader(project_id, obj, result);
    }
}

void EAConverter::convertToType(const std::string& project_id,
                                 const EA::EAObject& obj,
                                 ConvertResult& result)
{
    std::string existing_id = repo_.findTypeByEaGuid(obj.ea_guid);
    Repo::Type t;
    t.id             = existing_id.empty() ? generateUUID() : existing_id;
    t.project_id     = project_id;
    t.name           = obj.name;
    t.description    = obj.note;
    t.ea_guid        = obj.ea_guid;
    t.ea_object_type = obj.object_type;
    t.ea_stereotype  = obj.stereotype;
    t.source         = "ea";
    t.kind           = resolveTypeKind(obj.object_type, obj.stereotype);
    // Class without DDS stereotype defaults to struct
    if (t.kind.empty() && obj.object_type == "Class") t.kind = "struct";
    t.extensibility  = "appendable";

    auto pkg_it = pkg_id_to_repo_id_.find(obj.package_id);
    if (pkg_it != pkg_id_to_repo_id_.end())
        t.package_id = pkg_it->second;

    if (repo_.saveType(t)) {
        type_guid_to_id_[obj.ea_guid]     = t.id;
        obj_id_to_type_id_[obj.object_id] = t.id;
        result.types++;
    }
}

void EAConverter::convertToDomain(const std::string& project_id,
                                   const EA::EAObject& obj,
                                   ConvertResult& result)
{
    std::string existing_id = repo_.findDomainByEaGuid(obj.ea_guid);
    Repo::Domain d;
    d.id            = existing_id.empty() ? generateUUID() : existing_id;
    d.project_id    = project_id;
    d.name          = obj.name;
    d.description   = obj.note;
    d.ea_guid       = obj.ea_guid;
    d.ea_stereotype = obj.stereotype;
    d.source        = "ea";
    auto pkg_it = pkg_id_to_repo_id_.find(obj.package_id);
    if (pkg_it != pkg_id_to_repo_id_.end()) d.package_id = pkg_it->second;

    if (repo_.saveDomain(d)) {
        domain_guid_to_id_[obj.ea_guid]     = d.id;
        obj_id_to_domain_id_[obj.object_id] = d.id;
        result.domains++;
    }
}

void EAConverter::convertToTopic(const std::string& project_id,
                                  const EA::EAObject& obj,
                                  ConvertResult& result)
{
    std::string existing_id = repo_.findTopicByEaGuid(obj.ea_guid);
    Repo::Topic t;
    t.id            = existing_id.empty() ? generateUUID() : existing_id;
    t.project_id    = project_id;
    t.name          = obj.name;
    t.description   = obj.note;
    t.ea_guid       = obj.ea_guid;
    t.ea_stereotype = obj.stereotype;
    t.source        = "ea";
    auto pkg_it = pkg_id_to_repo_id_.find(obj.package_id);
    if (pkg_it != pkg_id_to_repo_id_.end()) t.package_id = pkg_it->second;

    if (repo_.saveTopic(t)) {
        topic_guid_to_id_[obj.ea_guid]     = t.id;
        obj_id_to_topic_id_[obj.object_id] = t.id;
        result.topics++;
    }
}

void EAConverter::convertToParticipant(const std::string& project_id,
                                        const EA::EAObject& obj,
                                        ConvertResult& result)
{
    Repo::Participant p;
    p.id            = generateUUID();
    p.project_id    = project_id;
    p.name          = obj.name;
    p.description   = obj.note;
    p.ea_guid       = obj.ea_guid;
    p.ea_stereotype = obj.stereotype;
    p.source        = "ea";
    auto pkg_it = pkg_id_to_repo_id_.find(obj.package_id);
    if (pkg_it != pkg_id_to_repo_id_.end()) p.package_id = pkg_it->second;

    if (repo_.saveParticipant(p)) {
        obj_id_to_participant_id_[obj.object_id] = p.id;
        result.participants++;
    }
}

void EAConverter::convertToPublisher(const std::string& project_id,
                                      const EA::EAObject& obj,
                                      ConvertResult& result)
{
    Repo::Publisher p;
    p.id            = generateUUID();
    p.name          = obj.name;
    p.description   = obj.note;
    p.ea_guid       = obj.ea_guid;
    p.ea_stereotype = obj.stereotype;
    p.source        = "ea";
    if (repo_.savePublisher(p)) {
        obj_id_to_publisher_id_[obj.object_id] = p.id;
        result.publishers++;
    }
}

void EAConverter::convertToSubscriber(const std::string& project_id,
                                       const EA::EAObject& obj,
                                       ConvertResult& result)
{
    Repo::Subscriber s;
    s.id            = generateUUID();
    s.name          = obj.name;
    s.description   = obj.note;
    s.ea_guid       = obj.ea_guid;
    s.ea_stereotype = obj.stereotype;
    s.source        = "ea";
    if (repo_.saveSubscriber(s)) {
        obj_id_to_subscriber_id_[obj.object_id] = s.id;
        result.subscribers++;
    }
}

void EAConverter::convertToWriter(const std::string& project_id,
                                   const EA::EAObject& obj,
                                   ConvertResult& result)
{
    Repo::Writer w;
    w.id            = generateUUID();
    w.name          = obj.name;
    w.description   = obj.note;
    w.ea_guid       = obj.ea_guid;
    w.ea_stereotype = obj.stereotype;
    w.source        = "ea";
    if (repo_.saveWriter(w)) result.writers++;
}

void EAConverter::convertToReader(const std::string& project_id,
                                   const EA::EAObject& obj,
                                   ConvertResult& result)
{
    Repo::Reader r;
    r.id            = generateUUID();
    r.name          = obj.name;
    r.description   = obj.note;
    r.ea_guid       = obj.ea_guid;
    r.ea_stereotype = obj.stereotype;
    r.source        = "ea";
    if (repo_.saveReader(r)) result.readers++;
}

// ------------------------------------------------------------
// Convert attributes -> type_members
// ------------------------------------------------------------
void EAConverter::convertAttributes(
    const std::string& project_id,
    const std::vector<EA::EAAttribute>& attributes,
    const std::vector<EA::EAAttributeTag>& attr_tags,
    ConvertResult& result)
{
    std::map<int, std::vector<EA::EAAttributeTag>> tag_map;
    for (const auto& tag : attr_tags)
        tag_map[tag.element_id].push_back(tag);

    for (const auto& attr : attributes) {
        auto type_it = obj_id_to_type_id_.find(attr.object_id);
        if (type_it == obj_id_to_type_id_.end()) continue;
        const std::string& type_id = type_it->second;

        Repo::Type parent_type = repo_.loadType(type_id);

        Repo::TypeMember m;
        m.id            = generateUUID();
        m.type_id       = type_id;
        m.name          = attr.name;
        m.ordinal       = attr.pos;
        m.ea_guid       = attr.ea_guid;
        m.ea_stereotype = attr.stereotype;
        m.ea_type_name  = attr.type;
        m.source        = "ea";
        m.default_value = attr.default_val;
        m.description   = attr.notes;
        m.member_kind   = resolveMemberKind(parent_type.kind, attr.stereotype);

        if (attr.stereotype == "key" || attr.stereotype == "Key")
            m.is_key = 1;

        std::string prim = resolvePrimitiveType(attr.type);
        if (!prim.empty()) {
            m.primitive_type = prim;
        } else if (attr.classifier > 0) {
            auto ref_it = obj_id_to_type_id_.find(attr.classifier);
            if (ref_it != obj_id_to_type_id_.end())
                m.ref_type_id = ref_it->second;
            else
                m.ref_type_id = repo_.findTypeByName(project_id, attr.type);
        }

        if (attr.length > 0) m.string_bound = attr.length;
        resolveCollection(attr.lower_bound, attr.upper_bound, m);

        // Process attribute tags
        auto tag_it = tag_map.find(attr.id);
        if (tag_it != tag_map.end()) {
            std::string anno = "{";
            bool first = true;
            for (const auto& tag : tag_it->second) {
                if (tag.property == "isDCPSKey" || tag.property == "isKey" ||
                    tag.property == "Key") {
                    if (tag.value == "true" || tag.value == "True")
                        m.is_key = 1;
                } else if (tag.property == "isOptional" ||
                           tag.property == "Optional") {
                    if (tag.value == "true" || tag.value == "True")
                        m.is_optional = 1;
                } else {
                    if (!first) anno += ",";
                    anno += "\"" + tag.property + "\":\"" + tag.value + "\"";
                    first = false;
                }
            }
            anno += "}";
            if (anno != "{}") m.annotations = anno;
        }

        if (m.member_kind == "literal" && !attr.default_val.empty()) {
            try {
                m.enum_value = std::stoi(attr.default_val);
                m.has_enum_value = true;
            } catch (...) {}
        }

        if (repo_.saveMember(m)) result.type_members++;
    }
}

// ------------------------------------------------------------
// Process object properties
// ------------------------------------------------------------
void EAConverter::processObjectProperties(
    const std::vector<EA::EAObjectProperty>& props,
    ConvertResult& result)
{
    for (const auto& prop : props) {
        if (prop.property == "type") {
            auto topic_it = obj_id_to_topic_id_.find(prop.object_id);
            auto type_it  = type_guid_to_id_.find(prop.value);
            if (topic_it != obj_id_to_topic_id_.end() &&
                type_it  != type_guid_to_id_.end()) {
                // Find domain for this topic (via participant->domain)
                Repo::RegisterType rt;
                rt.id      = generateUUID();
                rt.type_id = type_it->second;
                // domain_id will be set when we know the topic's domain
                repo_.saveRegisterType(rt);
                result.register_types++;
            }
        } else if (prop.property == "domain") {
            // participant -> domain connection
            // handled via connector or direct lookup
        }
    }
}

// ------------------------------------------------------------
// Process connectors
// ------------------------------------------------------------
void EAConverter::processConnectors(
    const std::vector<EA::EAConnector>& connectors,
    ConvertResult& result)
{
    for (const auto& conn : connectors) {
        if (conn.connector_type == "Generalization") {
            // child extends parent
            auto child_it  = obj_id_to_type_id_.find(conn.start_object_id);
            auto parent_it = obj_id_to_type_id_.find(conn.end_object_id);
            if (child_it  != obj_id_to_type_id_.end() &&
                parent_it != obj_id_to_type_id_.end()) {
                // UPDATE types.base_type_id
                // (requires IRepository::updateTypeBaseId - future work)
            }
        } else if (conn.connector_type == "Dependency" &&
                   (conn.sub_type == "use" || conn.stereotype == "use")) {
            // type reference via members.ref_type_id
        }
    }
}

} // namespace Converter
