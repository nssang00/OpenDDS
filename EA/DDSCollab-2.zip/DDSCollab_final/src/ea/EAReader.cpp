#include "EAReader.h"
#include <sstream>

namespace EA {

EAReader::EAReader()  : db_(nullptr) {}
EAReader::~EAReader() { close(); }

bool EAReader::open(const std::string& qea_path) {
    int rc = sqlite3_open_v2(qea_path.c_str(), &db_,
                             SQLITE_OPEN_READONLY, nullptr);
    if (rc != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_);
        sqlite3_close(db_);
        db_ = nullptr;
        return false;
    }
    return true;
}

void EAReader::close() {
    if (db_) { sqlite3_close(db_); db_ = nullptr; }
}

bool EAReader::isOpen() const { return db_ != nullptr; }

std::string EAReader::getString(sqlite3_stmt* stmt, int col) {
    const char* v = (const char*)sqlite3_column_text(stmt, col);
    return v ? v : "";
}

int EAReader::getInt(sqlite3_stmt* stmt, int col) {
    return sqlite3_column_int(stmt, col);
}

// ------------------------------------------------------------
// t_package
// ------------------------------------------------------------
std::vector<EAPackage> EAReader::readPackages() {
    std::vector<EAPackage> result;
    if (!db_) return result;

    const char* sql =
        "SELECT Package_ID, Name, Parent_ID, Notes, ea_guid, TPos "
        "FROM t_package ORDER BY Parent_ID, TPos;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_); return result;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAPackage p;
        p.package_id = getInt(stmt, 0);
        p.name       = getString(stmt, 1);
        p.parent_id  = getInt(stmt, 2);
        p.notes      = getString(stmt, 3);
        p.ea_guid    = getString(stmt, 4);
        p.t_pos      = getInt(stmt, 5);
        result.push_back(p);
    }
    sqlite3_finalize(stmt);
    return result;
}

EAPackage EAReader::readPackage(int package_id) {
    EAPackage pkg;
    if (!db_) return pkg;
    std::string sql =
        "SELECT Package_ID, Name, Parent_ID, Notes, ea_guid, TPos "
        "FROM t_package WHERE Package_ID = " +
        std::to_string(package_id) + ";";
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK)
        return pkg;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        pkg.package_id = getInt(stmt, 0);
        pkg.name       = getString(stmt, 1);
        pkg.parent_id  = getInt(stmt, 2);
        pkg.notes      = getString(stmt, 3);
        pkg.ea_guid    = getString(stmt, 4);
        pkg.t_pos      = getInt(stmt, 5);
    }
    sqlite3_finalize(stmt);
    return pkg;
}

// ------------------------------------------------------------
// Find root package ID by name
// ------------------------------------------------------------
int EAReader::findPackageIdByName(const std::string& name) {
    if (!db_) return -1;
    std::string sql =
        "SELECT Package_ID FROM t_package WHERE Name = ? LIMIT 1;";
    sqlite3_stmt* stmt = nullptr;
    int result = -1;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, name.c_str(), -1, SQLITE_STATIC);
        if (sqlite3_step(stmt) == SQLITE_ROW)
            result = getInt(stmt, 0);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ------------------------------------------------------------
// Collect all package IDs under a root package (recursive)
// ------------------------------------------------------------
std::set<int> EAReader::collectPackageIdsUnder(int root_package_id) {
    std::set<int> result;
    if (!db_ || root_package_id <= 0) return result;

    result.insert(root_package_id);

    bool changed = true;
    while (changed) {
        changed = false;
        std::set<int> new_ids;

        for (int pid : result) {
            std::string sql =
                "SELECT Package_ID FROM t_package WHERE Parent_ID = " +
                std::to_string(pid) + ";";
            sqlite3_stmt* stmt = nullptr;
            if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr)
                == SQLITE_OK) {
                while (sqlite3_step(stmt) == SQLITE_ROW) {
                    int child_id = getInt(stmt, 0);
                    if (result.find(child_id) == result.end()) {
                        new_ids.insert(child_id);
                        changed = true;
                    }
                }
                sqlite3_finalize(stmt);
            }
        }
        for (int id : new_ids) result.insert(id);
    }
    return result;
}

// ------------------------------------------------------------
// Read extractable t_object filtered by package scope
// Extracts all Class/Interface/Enumeration/DataType regardless of stereotype
// DDS-specific stereotypes (topic, domain, participant etc.) also included
// ------------------------------------------------------------
std::vector<EAObject> EAReader::readDDSObjects(
    const std::set<int>& package_ids)
{
    std::vector<EAObject> result;
    if (!db_ || package_ids.empty()) return result;

    // Build IN clause for package IDs
    std::string pkg_in;
    for (auto it = package_ids.begin(); it != package_ids.end(); ++it) {
        if (it != package_ids.begin()) pkg_in += ",";
        pkg_in += std::to_string(*it);
    }

    // Extract all type-representable objects:
    //   Class / Interface   -> struct (default) or enum/union/typedef if stereotyped
    //   Enumeration         -> enum
    //   DataType            -> typedef
    //   Part/Component/Port with DDS stereotypes -> domain/topic/participant etc.
    std::string sql =
        "SELECT Object_ID, Name, Object_Type, Stereotype, "
        "       Package_ID, Note, ea_guid, Classifier_guid, "
        "       Classifier, ParentID "
        "FROM t_object "
        "WHERE Package_ID IN (" + pkg_in + ") "
        "AND ("
        "  Object_Type IN ('Class','Interface','Enumeration','DataType') "
        "  OR (Object_Type IN ('Part','Component','Port') "
        "      AND Stereotype IN ('topic','domain','domainParticipant',"
        "                         'publisher','subscriber',"
        "                         'dataWriter','dataReader','qosProperty'))"
        ") "
        "ORDER BY Package_ID, Object_ID;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_); return result;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAObject obj;
        obj.object_id       = getInt(stmt, 0);
        obj.name            = getString(stmt, 1);
        obj.object_type     = getString(stmt, 2);
        obj.stereotype      = getString(stmt, 3);
        obj.package_id      = getInt(stmt, 4);
        obj.note            = getString(stmt, 5);
        obj.ea_guid         = getString(stmt, 6);
        obj.classifier_guid = getString(stmt, 7);
        obj.classifier      = getInt(stmt, 8);
        obj.parent_id       = getInt(stmt, 9);
        result.push_back(obj);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ------------------------------------------------------------
// t_attribute
// ------------------------------------------------------------
std::vector<EAAttribute> EAReader::readAttributesByObjects(
    const std::set<int>& object_ids)
{
    std::vector<EAAttribute> result;
    if (!db_ || object_ids.empty()) return result;

    std::string in_clause;
    for (auto it = object_ids.begin(); it != object_ids.end(); ++it) {
        if (it != object_ids.begin()) in_clause += ",";
        in_clause += std::to_string(*it);
    }

    std::string sql =
        "SELECT ID, Object_ID, Name, Type, Stereotype, "
        "       LowerBound, UpperBound, \"Default\", Notes, "
        "       Pos, Classifier, Length, ea_guid "
        "FROM t_attribute "
        "WHERE Object_ID IN (" + in_clause + ") "
        "ORDER BY Object_ID, Pos;";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_); return result;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAAttribute attr;
        attr.id          = getInt(stmt, 0);
        attr.object_id   = getInt(stmt, 1);
        attr.name        = getString(stmt, 2);
        attr.type        = getString(stmt, 3);
        attr.stereotype  = getString(stmt, 4);
        attr.lower_bound = getString(stmt, 5);
        attr.upper_bound = getString(stmt, 6);
        attr.default_val = getString(stmt, 7);
        attr.notes       = getString(stmt, 8);
        attr.pos         = getInt(stmt, 9);
        attr.classifier  = getInt(stmt, 10);
        attr.length      = getInt(stmt, 11);
        attr.ea_guid     = getString(stmt, 12);
        result.push_back(attr);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ------------------------------------------------------------
// t_attributetag
// ------------------------------------------------------------
std::vector<EAAttributeTag> EAReader::readAttributeTagsByElements(
    const std::set<int>& element_ids)
{
    std::vector<EAAttributeTag> result;
    if (!db_ || element_ids.empty()) return result;

    std::string in_clause;
    for (auto it = element_ids.begin(); it != element_ids.end(); ++it) {
        if (it != element_ids.begin()) in_clause += ",";
        in_clause += std::to_string(*it);
    }

    std::string sql =
        "SELECT PropertyID, ElementID, Property, VALUE, ea_guid "
        "FROM t_attributetag "
        "WHERE ElementID IN (" + in_clause + ");";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_); return result;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAAttributeTag tag;
        tag.property_id = getInt(stmt, 0);
        tag.element_id  = getInt(stmt, 1);
        tag.property    = getString(stmt, 2);
        tag.value       = getString(stmt, 3);
        tag.ea_guid     = getString(stmt, 4);
        result.push_back(tag);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ------------------------------------------------------------
// t_connector
// ------------------------------------------------------------
std::vector<EAConnector> EAReader::readConnectors(
    const std::set<int>& object_ids)
{
    std::vector<EAConnector> result;
    if (!db_ || object_ids.empty()) return result;

    std::string in_clause;
    for (auto it = object_ids.begin(); it != object_ids.end(); ++it) {
        if (it != object_ids.begin()) in_clause += ",";
        in_clause += std::to_string(*it);
    }

    std::string sql =
        "SELECT Connector_ID, Connector_Type, Stereotype, SubType, "
        "       Start_Object_ID, End_Object_ID, ea_guid "
        "FROM t_connector "
        "WHERE Start_Object_ID IN (" + in_clause + ") "
        "   OR End_Object_ID   IN (" + in_clause + ");";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_); return result;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAConnector conn;
        conn.connector_id    = getInt(stmt, 0);
        conn.connector_type  = getString(stmt, 1);
        conn.stereotype      = getString(stmt, 2);
        conn.sub_type        = getString(stmt, 3);
        conn.start_object_id = getInt(stmt, 4);
        conn.end_object_id   = getInt(stmt, 5);
        conn.ea_guid         = getString(stmt, 6);
        result.push_back(conn);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ------------------------------------------------------------
// t_objectproperties
// ------------------------------------------------------------
std::vector<EAObjectProperty> EAReader::readObjectProperties(
    const std::set<int>& object_ids)
{
    std::vector<EAObjectProperty> result;
    if (!db_ || object_ids.empty()) return result;

    std::string in_clause;
    for (auto it = object_ids.begin(); it != object_ids.end(); ++it) {
        if (it != object_ids.begin()) in_clause += ",";
        in_clause += std::to_string(*it);
    }

    std::string sql =
        "SELECT ID, Object_ID, Property, Value, ea_guid "
        "FROM t_objectproperties "
        "WHERE Object_ID IN (" + in_clause + ") "
        "AND Property IN ('type','domain','typedef','typeSynonyms',"
        "                 'kind','extensibility');";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_); return result;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAObjectProperty prop;
        prop.id        = getInt(stmt, 0);
        prop.object_id = getInt(stmt, 1);
        prop.property  = getString(stmt, 2);
        prop.value     = getString(stmt, 3);
        prop.ea_guid   = getString(stmt, 4);
        result.push_back(prop);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ------------------------------------------------------------
// t_taggedvalue
// ------------------------------------------------------------
std::vector<EATaggedValue> EAReader::readTaggedValues(
    const std::set<int>& object_ids)
{
    std::vector<EATaggedValue> result;
    if (!db_ || object_ids.empty()) return result;

    std::string in_clause;
    for (auto it = object_ids.begin(); it != object_ids.end(); ++it) {
        if (it != object_ids.begin()) in_clause += ",";
        in_clause += std::to_string(*it);
    }

    // Get ea_guids for the objects
    std::string guid_sql =
        "SELECT ea_guid FROM t_object "
        "WHERE Object_ID IN (" + in_clause + ");";

    sqlite3_stmt* guid_stmt = nullptr;
    std::vector<std::string> guids;
    if (sqlite3_prepare_v2(db_, guid_sql.c_str(), -1, &guid_stmt, nullptr)
        == SQLITE_OK) {
        while (sqlite3_step(guid_stmt) == SQLITE_ROW) {
            std::string g = getString(guid_stmt, 0);
            if (!g.empty()) guids.push_back(g);
        }
        sqlite3_finalize(guid_stmt);
    }
    if (guids.empty()) return result;

    std::string guid_in;
    for (size_t i = 0; i < guids.size(); ++i) {
        if (i > 0) guid_in += ",";
        guid_in += "'" + guids[i] + "'";
    }

    std::string sql =
        "SELECT PropertyID, ElementID, BaseClass, TagValue, Notes "
        "FROM t_taggedvalue "
        "WHERE ElementID IN (" + guid_in + ");";

    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        last_error_ = sqlite3_errmsg(db_); return result;
    }
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EATaggedValue tv;
        tv.property_id = getString(stmt, 0);
        tv.element_id  = getString(stmt, 1);
        tv.base_class  = getString(stmt, 2);
        tv.tag_value   = getString(stmt, 3);
        tv.notes       = getString(stmt, 4);
        result.push_back(tv);
    }
    sqlite3_finalize(stmt);
    return result;
}

// ------------------------------------------------------------
// Collect required parent package IDs
// ------------------------------------------------------------
std::set<int> EAReader::collectRequiredPackageIds(
    const std::vector<EAObject>& objects)
{
    std::set<int> required;
    if (!db_) return required;

    for (const auto& obj : objects) {
        if (obj.package_id > 0) required.insert(obj.package_id);
    }

    bool changed = true;
    while (changed) {
        changed = false;
        std::set<int> new_ids;
        for (int pkg_id : required) {
            std::string sql =
                "SELECT Parent_ID FROM t_package "
                "WHERE Package_ID = " + std::to_string(pkg_id) + ";";
            sqlite3_stmt* stmt = nullptr;
            if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr)
                == SQLITE_OK) {
                if (sqlite3_step(stmt) == SQLITE_ROW) {
                    int parent_id = getInt(stmt, 0);
                    if (parent_id > 0 &&
                        required.find(parent_id) == required.end()) {
                        new_ids.insert(parent_id);
                        changed = true;
                    }
                }
                sqlite3_finalize(stmt);
            }
        }
        for (int id : new_ids) required.insert(id);
    }
    return required;
}

} // namespace EA
