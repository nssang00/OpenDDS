#include <iostream>
#include <fstream>
#include <string>
#include <functional>
#include "ea/EAReader.h"
#include "ea/EAConverter.h"
#include "repository/SQLiteRepository.h"
#include "dds/DDSModels.h"
#include "dds/DDSLoader.h"
#include "generator/IDLGenerator.h"

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cout << "Usage: DDSCollab <qea_file> <output_db>"
                     " [project_name] [root_package]\n\n";
        std::cout << "  qea_file     : Sparx EA QEA file path\n";
        std::cout << "  output_db    : Output SQLite DB path\n";
        std::cout << "  project_name : Project name (optional)\n";
        std::cout << "  root_package : Process only this package subtree (optional)\n";
        std::cout << "                 Recommended when QEA contains non-DDS elements\n\n";
        std::cout << "Extraction policy:\n";
        std::cout << "  Always extracts all Class/Interface/Enumeration/DataType\n";
        std::cout << "  regardless of stereotype.\n";
        std::cout << "  DDS-specific stereotypes (struct/enum/union/typedef) are used\n";
        std::cout << "  as hints. Class without stereotype defaults to struct.\n\n";
        std::cout << "Examples:\n";
        std::cout << "  DDSCollab DDS.qea out.db \"MyProject\" \"DDS Models\"\n";
        std::cout << "  DDSCollab EA.qea  out.db \"MyProject\" \"My Package\"\n";
        std::cout << "  DDSCollab EA.qea  out.db \"MyProject\"\n";
        return 1;
    }

    std::string qea_path     = argv[1];
    std::string db_path      = argv[2];
    std::string project_name = argc > 3 ? argv[3] : "DDS Project";
    std::string root_package = argc > 4 ? argv[4] : "";

    std::cout << "=== DDS Collab Converter ===\n";
    std::cout << "QEA  : " << qea_path << "\n";
    std::cout << "DB   : " << db_path  << "\n";
    if (!root_package.empty())
        std::cout << "Root : " << root_package << "\n";
    std::cout << "\n";

    // 1. Open repository
    Repo::SQLiteRepository repo;
    if (!repo.open(db_path)) {
        std::cerr << "DB open failed: " << repo.getLastError() << "\n";
        return 1;
    }
    if (!repo.initSchema("dds_collab.sql"))
        std::cout << "[WARN] DDL file not found. Using existing schema.\n";

    Repo::Project project;
    project.id          = "proj-001";
    project.name        = project_name;
    project.description = "Converted from QEA";
    project.version     = "1.0";
    repo.saveProject(project);

    // 2. EA -> Repository
    EA::EAReader reader;
    if (!reader.open(qea_path)) {
        std::cerr << "QEA open failed: " << reader.getLastError() << "\n";
        return 1;
    }

    Converter::EAConverter converter(reader, repo);
    auto result = converter.convert(project.id, qea_path, root_package);
    reader.close();

    std::cout << "=== Conversion Result ===\n";
    std::cout << "packages    : " << result.packages     << "\n";
    std::cout << "types       : " << result.types        << "\n";
    std::cout << "type_members: " << result.type_members << "\n";
    std::cout << "domains     : " << result.domains      << "\n";
    std::cout << "topics      : " << result.topics       << "\n";
    std::cout << "participants: " << result.participants  << "\n";

    for (const auto& e : result.errors)
        std::cerr << "[ERROR] " << e << "\n";

    // 3. Load DDS Model
    std::cout << "\n=== Load DDS Model ===\n";
    DDS::DDSLoader loader(repo);
    DDS::DDSProject dds_project = loader.loadProject(project.id);

    int total_types = 0;
    std::function<void(const DDS::DDSPackage&)> countTypes =
        [&](const DDS::DDSPackage& pkg) {
            total_types += (int)pkg.types.size();
            for (const auto& c : pkg.children) countTypes(c);
        };
    for (const auto& pkg : dds_project.packages) countTypes(pkg);

    std::cout << "Project  : " << dds_project.name             << "\n";
    std::cout << "Packages : " << dds_project.packages.size()  << "\n";
    std::cout << "Types    : " << total_types                   << "\n";
    std::cout << "Domains  : " << dds_project.domains.size()   << "\n";

    // 4. Generate IDL
    std::cout << "\n=== Generate IDL ===\n";
    Generator::IDLGenerator idl_gen;
    std::string idl_content = idl_gen.generateIDL(dds_project);

    std::string idl_path = db_path + ".idl";
    std::ofstream idl_file(idl_path);
    if (idl_file.is_open()) {
        idl_file << idl_content;
        idl_file.close();
        std::cout << "IDL saved: " << idl_path << "\n\n";
    }

    std::cout << idl_content;

    // 5. Save JSON
    std::ofstream json_file(db_path + ".json");
    if (json_file.is_open()) {
        json_file << dds_project.toJson();
        json_file.close();
    }

    repo.close();
    std::cout << "Done!\n";
    return 0;
}
