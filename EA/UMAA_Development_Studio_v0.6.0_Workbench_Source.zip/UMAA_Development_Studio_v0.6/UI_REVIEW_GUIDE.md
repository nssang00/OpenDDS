# UMAA Development Studio Mock v0.5.0 — UI 검토 안내

## 반영 구조

- **UMAA Standard Catalog**: 8개 공식 Functional Area 분류, 기존 확인된 14개 서비스 *예시*는 원본 변경 불가. 전체 6.0 Service를 수록했다고 주장하지 않음.
- **Project Extensions**: 사용자가 Functional Area 및 Custom Service 추가 가능. 사용자 Service가 표준 영역(MO/SA 등)을 분류로 참조하더라도 원본 UMAA 항목은 아님.
- **Service Contract**: 통신 패턴 템플릿은 서비스 생성 단계에서 결정. Operation → DDS Action(`publish`/`subscribe`/`dispose`) → Topic → MessageType 연결. Custom 계약에 Message Type, Topic, Operation 추가 가능.
- **Types**: 독립 탐색(표준 MessageType은 원본 IDL 참조, Custom MessageType·Struct·Enum은 작성/확장 가능).
- **Components**: Provider/Consumer Service Binding, Service Connection, QoS/Domain/Partition/GUID/Command Arbitration/Host 설정. 통신 패턴을 Component에서 재선택하지 않음.
- **React Flow**: Services 탭의 항목을 Component 위로 드래그하면 역할 선택 후 Binding 추가. 동일 서비스의 Provider/Consumer Port를 이어 연결. 연결선을 클릭하면 DDS Action·Topic·Type 및 Command 정책 안내.
- **Generated DLL/SO Scaffold**: CMake shared library, 버전 확인·설정·시작·종료 C ABI, Contract JSON, Endpoint Matrix, Custom IDL, Runtime/QoS JSON, Component Manifest 생성.

## UI를 확인하는 방법

1. **PREVIEW_UI.html**을 브라우저에서 엽니다. 이는 *외부 패키지 없이 여는 독립형 UI 콘셉트 미리보기*입니다. React/Ant Design/React Flow 앱 자체의 빌드 결과는 아닙니다.
2. 좌측 `Project`에서 `MO` → `GlobalVectorControl` 또는 `SA` → `GlobalPoseStatus`를 선택합니다. 우측에서 Operation·Action·Topic·IDL 관계를 확인합니다.
3. 중앙의 Autopilot/USV Navigation/Mission Executor 노드 또는 연결선을 클릭해 컴포넌트 역할과 통신 패턴을 확인합니다.
4. 좌측 상단 `A+ / S+ / T+ / Q+ / C+`를 눌러 사용자 추가 항목이 표준 Catalog와 분리되는지 확인합니다. `JSON 내보내기`로 미리보기 모델을 저장할 수 있습니다.
5. **실제 React IDE**는 npm 의존성 설치 후 `npm install` → `npm run build` → `index.html`로 실행합니다. 빌드는 정적 IIFE JS/CSS를 `dist/`에 만듭니다. 이 환경에서는 네트워크 DNS 오류 때문에 npm 설치/React 번들 빌드를 완료하지 못했습니다.

## 현재 검증 범위 (2026-11-04)

- `npm run check:static`: PASS
- `npm run test:icd`: PASS (14 Service / 7P+7C / 56 Operation / 32 Topic / 32 Autopilot Endpoint)
- `npm run test:design`: PASS (8 FA, Custom Service–Type–Topic 연결, runtime 설정, C ABI)
- CMake로 실제 `libAutopilot.so` 골격 빌드: PASS (GNU C++14, CMake 3.31)
- 독립 미리보기 HTML Chromium 렌더링: PASS (Playwright `page.set_content`), 영역 추가 UI 조작: PASS
- `npm run test:layout` / 실제 React 브라우저 번들 QA: **NOT VERIFIED** (npm 의존성 미설치)
- 실제 DDS Reader/Writer 송수신, 명령 상태 머신 실행, 공식 IDL TypeSupport 및 UMAA 적합성: **NOT IMPLEMENTED**

## 주의사항

- 순수 UI mock이므로 공식 ICD/IDL 모든 타입 필드가 포함되어 있지 않습니다. 기존 14개 AutoPilot Service 예제의 이름/Operation/Topic은 인수인계 자료를 바탕으로 유지했습니다.
- Custom Service의 패턴은 **사용자 정의 템플릿**입니다. 공식 UMAA에서 보장하는 계약으로 표시하지 않습니다.
- QoS Profile은 현재 Project/Component 범위 값으로만 관리하며 Endpoint별 실제 DDS QoS 적용 및 호환성 검증은 미구현입니다.
- 기존 localStorage JSON은 v0.5 schema로 자동 보강됩니다. 중요한 프로젝트는 JSON으로 백업하고 테스트하십시오.
