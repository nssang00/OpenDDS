import { useState } from 'react';
import { Alert, Button, Descriptions, Empty, Select, Space, Table, Tabs, Tag, Typography } from 'antd';
import { ApartmentOutlined, BuildOutlined, NodeIndexOutlined, PlusOutlined, ThunderboltOutlined } from '@ant-design/icons';
import { useEditorStore } from '../stores/useEditorStore.js';
import { Diagram } from './Diagram.jsx';
import { RuntimeSettings } from './DesignDetails.jsx';
import { CommunicationView } from './CommunicationView.jsx';
import { ServiceWorkbench, TopicWorkbench, OperationWorkbench, FunctionalAreaWorkbench, QosWorkbench } from './ContractWorkbench.jsx';
import { TypeWorkbench } from './TypeWorkbench.jsx';
import { deriveEndpoints } from '../logic/endpoints.js';
const {Text}=Typography;
export function WorkspaceWorkbench({ onNewComponent, onNewService, onGenerate }) {
  const snapshot=useEditorStore(s=>s.snapshot);
  const selection=useEditorStore(s=>s.selection);
  const select=useEditorStore(s=>s.select);
  const autoLayout=useEditorStore(s=>s.autoLayout);
  const [componentTab,setComponentTab]=useState('diagram');
  const kind=selection?.kind??'diagram';
  const component=kind==='component'?snapshot?.components.find(c=>c.id===selection.id):null;
  const isAssembly=['diagram','component','binding'].includes(kind);
  if(!snapshot)return <Empty/>;
  if(isAssembly)return <div className="assembly-workbench">
    <div className="workspace-toolbar">
      <div><Typography.Title level={5} style={{margin:0}}><NodeIndexOutlined/> System Diagram · Component Assembly</Typography.Title>
        <Text type="secondary">서비스 포트의 P/C 논리 연결을 설계합니다. 연결선을 클릭하면 DDS 통신 상세가 열립니다.</Text></div>
      <Space wrap><Button size="small" onClick={()=>select({kind:'diagram',id:'system'})}>전체 다이어그램</Button><Button size="small" onClick={autoLayout}>자동 배치</Button><Button size="small" icon={<PlusOutlined/>} onClick={onNewComponent}>Component</Button><Button size="small" icon={<PlusOutlined/>} onClick={onNewService}>Custom Service</Button></Space>
    </div>
    {component&&<div className="component-context-tabs"><Tabs size="small" activeKey={componentTab} onChange={setComponentTab} items={[
      {key:'diagram',label:'Diagram'}, {key:'bindings',label:`Bindings (${snapshot.bindings.filter(b=>b.componentId===component.id).length})`}, {key:'runtime',label:'Runtime / QoS'}
    ]}/></div>}
    {(!component||componentTab==='diagram')&&<div className="canvas-section"><Diagram/></div>}
    {component&&componentTab==='bindings'&&<div className="assembly-details center-workbench"><h2>{component.name} · Service Bindings</h2>
      <Table size="small" rowKey="id" pagination={false} dataSource={snapshot.bindings.filter(b=>b.componentId===component.id)} columns={[
        {title:'Service',render:(_,r)=><Button size="small" type="link" onClick={()=>select({kind:'service',id:r.serviceId})}>{snapshot.services.find(s=>s.id===r.serviceId)?.name}</Button>},
        {title:'Role',dataIndex:'role',render:v=><Tag color={v==='provider'?'blue':'orange'}>{v}</Tag>},
        {title:'DDS Endpoints',render:(_,r)=>deriveEndpoints(snapshot,component.id).filter(e=>e.bindingId===r.id).length}
      ]}/><Alert showIcon type="info" message="Service 계약과 P/C Binding은 분리됩니다." description="Binding 역할에 따라 Reader/Writer를 자동 파생하며, 명령 패턴은 Service에서 정의합니다."/></div>}
    {component&&componentTab==='runtime'&&<div className="assembly-details center-workbench"><h2>{component.name} · Runtime Configuration</h2><RuntimeSettings componentId={component.id}/></div>}
  </div>;
  if(kind==='connection')return <CommunicationView connectionId={selection.id} onBack={()=>select({kind:'diagram',id:'system'})}/>;
  if(kind==='service')return <ServiceWorkbench key={selection.id} serviceId={selection.id}/>;
  if(kind==='interface')return <ServiceWorkbench key={selection.id} serviceId={snapshot.interfaces.find(i=>i.id===selection.id)?.serviceId}/>;
  if(kind==='operation')return <OperationWorkbench operationId={selection.id}/>;
  if(kind==='message'||kind==='dataType')return <TypeWorkbench key={selection.id} kind={kind} id={selection.id}/>;
  if(kind==='topic')return <TopicWorkbench topicId={selection.id}/>;
  if(kind==='functionalArea')return <FunctionalAreaWorkbench id={selection.id}/>;
  if(kind==='qos')return <QosWorkbench id={selection.id}/>;
  if(kind==='build')return <div className="center-workbench"><div className="editor-heading"><div><Text type="secondary" className="editor-eyebrow">BUILD & DEPLOYMENT</Text><h2><BuildOutlined/> Component Wrapper / DLL / SO</h2></div><Button type="primary" icon={<ThunderboltOutlined/>} onClick={onGenerate}>Generate Files</Button></div>
    <Alert showIcon type="warning" message="현재는 DDS가 연결되지 않은 C++ 공유 라이브러리 골격입니다." description="Component별 Endpoint 목록, Custom IDL, C ABI, CMake 및 Config를 만듭니다. 공식 IDL 연동과 실제 DDS DomainParticipant/Reader/Writer 구현 및 Host 로딩은 미구현입니다."/>
    <Descriptions bordered column={1} style={{marginTop:16}}><Descriptions.Item label="Target">{snapshot.project.targetPlatform==='windows'?'Windows · DLL':'Linux · SO'}</Descriptions.Item><Descriptions.Item label="DDS vendor metadata">{snapshot.project.ddsVendor}</Descriptions.Item><Descriptions.Item label="Components">{snapshot.components.length}</Descriptions.Item><Descriptions.Item label="Contract bindings">{snapshot.bindings.length}</Descriptions.Item></Descriptions>
    <h3>Generation Targets</h3><Table size="small" rowKey="id" pagination={false} dataSource={snapshot.components.map(c=>({...c,endpointCount:deriveEndpoints(snapshot,c.id).length}))} columns={[
      {title:'Component',dataIndex:'name',render:(v,r)=><Button type="link" onClick={()=>select({kind:'component',id:r.id})}>{v}</Button>},
      {title:'DDS Endpoint specs',dataIndex:'endpointCount'},
      {title:'Artifact',render:()=>snapshot.project.targetPlatform==='windows'?'.dll scaffold':'.so scaffold'}]}/>
    <Button type="primary" onClick={onGenerate}>Generated C++ / IDL / Config 파일 미리보기 및 ZIP 다운로드</Button></div>;
  return <Empty description="왼쪽에서 편집할 객체를 선택하세요"/>;
}
