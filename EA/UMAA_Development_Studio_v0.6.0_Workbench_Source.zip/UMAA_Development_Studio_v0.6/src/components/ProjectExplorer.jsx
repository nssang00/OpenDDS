import { useEffect, useMemo, useState } from 'react';
import { Button, Empty, Input, Tag, Tree, Typography } from 'antd';
import {
  ApartmentOutlined, ApiOutlined, BuildOutlined, CodeOutlined, ControlOutlined,
  DatabaseOutlined, DeploymentUnitOutlined, FileTextOutlined, FolderOpenOutlined,
  LinkOutlined, NodeIndexOutlined, SettingOutlined
} from '@ant-design/icons';
import { useEditorStore } from '../stores/useEditorStore.js';

const tinyTag = (label, color = 'default') => <Tag color={color} className="explorer-tag">{label}</Tag>;
export function ProjectExplorer({ onCreate }) {
  const snapshot = useEditorStore(s => s.snapshot);
  const selection = useEditorStore(s => s.selection);
  const select = useEditorStore(s => s.select);
  const [filter, setFilter] = useState('');
  const [expanded, setExpanded] = useState(['project-root','project-components','project-types','standard-root','standard-areas','area:MO']);

  useEffect(() => {
    if(!selection || !snapshot) return;
    const keys=['project-root'];
    if(selection.kind==='service') {
      const service=snapshot.services.find(s=>s.id===selection.id);
      if(service?.source==='standard') keys.push('standard-root','standard-areas',`functionalArea:${service.functionalArea}`);
      else keys.push('project-services');
    }
    if(selection.kind==='component'||selection.kind==='binding') keys.push('project-components');
    if(selection.kind==='dataType') keys.push('project-types','project-datatypes');
    if(selection.kind==='message') {
      const m=snapshot.messages.find(m=>m.id===selection.id);
      keys.push(m?.source==='custom'?'project-types':'standard-root',m?.source==='custom'?'project-messages':'standard-messages');
    }
    if(selection.kind==='qos')keys.push('project-qos');
    if(selection.kind==='topic')keys.push('project-topics');
    if(selection.kind==='connection')keys.push('project-connections');
    setExpanded(current=>{const next=new Set([...current,...keys]);return next.size===current.length?current:[...next];});
  },[selection,snapshot]);
  const tree = useMemo(() => {
    if (!snapshot) return [];
    const keyword = filter.trim().toLowerCase();
    const matches = (...values) => !keyword || values.join(' ').toLowerCase().includes(keyword);
    const serviceNode = service => ({
      key: `service:${service.id}`, icon: <ApiOutlined />,
      title: <span draggable title="클릭: Service 계약 편집 · 드래그: Component에 Binding 추가"
        onDragStart={e=>{ e.stopPropagation(); e.dataTransfer.setData('application/umaa-service-id', service.id); e.dataTransfer.effectAllowed='copy'; }}>
        {service.name}{service.source==='custom' && tinyTag('EXT', 'purple')}
      </span>,
      children: (keyword ? [] : snapshot.interfaces.filter(i=>i.serviceId===service.id).map(i=>({
        key:`interface:${i.id}`, icon:<LinkOutlined/>,title:i.name,
        children:i.operationIds.map(id=>snapshot.operations.find(op=>op.id===id)).filter(Boolean).map(op=>({
          key:`operation:${op.id}`,icon:<FileTextOutlined/>,title:<span>{op.name} <span className="explorer-secondary">{op.action}</span></span>
        }))
      })))
    });
    const servicesOf = area => snapshot.services.filter(s=>s.source==='standard' && s.functionalArea===area.id);
    const areaNodes = snapshot.functionalAreas.filter(a=>a.source!=='custom').map(area => ({
      key:`functionalArea:${area.id}`, icon:<DeploymentUnitOutlined/>,
      title:<span>{area.id} · {area.name} {tinyTag(servicesOf(area).length)}</span>,
      children:servicesOf(area).filter(s=>matches(s.name,area.name,area.id)).map(serviceNode),
    }));
    const customServices=snapshot.services.filter(s=>s.source==='custom');
    const customMessageTypes=snapshot.messages.filter(m=>m.source==='custom');
    const customTopics=snapshot.topics.filter(t=>snapshot.operations.some(o=>o.topicId===t.id && customServices.some(s=>s.id===o.serviceId)));
    const standardMessages=snapshot.messages.filter(m=>m.source!=='custom');
    const standardTopics=snapshot.topics.filter(t=>snapshot.operations.some(o=>o.topicId===t.id && snapshot.services.some(s=>s.id===o.serviceId && s.source!=='custom')));
    const list=(key,title,icon,items)=>({key,title,icon,children:items});
    const item=(kind,id,name,icon,ext=false)=>({key:`${kind}:${id}`,title:<span>{name}{ext?tinyTag('EXT','purple'):null}</span>,icon});
    const componentNodes=snapshot.components.filter(c=>matches(c.name,'component')).map(c=>({
      ...item('component',c.id,c.name,<ApartmentOutlined/>),
      children:snapshot.bindings.filter(b=>b.componentId===c.id).map(b=>{
        const svc=snapshot.services.find(s=>s.id===b.serviceId);
        return {key:`binding:${b.id}`,title:<span>{svc?.name??'Unknown'} {tinyTag(b.role==='provider'?'P':'C',b.role==='provider'?'blue':'orange')}</span>,icon:<ApiOutlined/>};
      })
    }));
    const projectRoot={key:'project-root', title:<b>{snapshot.project.name}</b>,icon:<FolderOpenOutlined/>,children:[
      {key:'diagram:system',title:<b>System Diagram</b>,icon:<NodeIndexOutlined/>},
      list('project-components',`Components (${snapshot.components.length})`,<ApartmentOutlined/>,componentNodes),
      list('project-services',`Custom Services (${customServices.length})`,<ApiOutlined/>,customServices.filter(s=>matches(s.name)).map(serviceNode)),
      list('project-types',`Custom Types (${customMessageTypes.length+(snapshot.dataTypes??[]).length})`,<CodeOutlined/>,[
        list('project-messages',`Message Types (${customMessageTypes.length})`,<FolderOpenOutlined/>,customMessageTypes.filter(m=>matches(m.name)).map(m=>item('message',m.id,m.name,<FileTextOutlined/>,true))),
        list('project-datatypes',`Data Types (${snapshot.dataTypes?.length??0})`,<FolderOpenOutlined/>,(snapshot.dataTypes??[]).filter(t=>matches(t.name)).map(t=>item('dataType',t.id,`${t.name} · ${t.kind}`,<CodeOutlined/>,true)))
      ]),
      list('project-topics',`Custom Topics (${customTopics.length})`,<DatabaseOutlined/>,customTopics.filter(t=>matches(t.name)).map(t=>item('topic',t.id,t.name,<DatabaseOutlined/>))),
      list('project-areas','Custom Functional Areas',<DeploymentUnitOutlined/>,snapshot.functionalAreas.filter(a=>a.source==='custom').map(a=>item('functionalArea',a.id,`${a.id} · ${a.name}`,<DeploymentUnitOutlined/>,true))),
      list('project-qos',`DDS QoS Profiles (${snapshot.qosProfiles?.length??0})`,<ControlOutlined/>,(snapshot.qosProfiles??[]).filter(q=>matches(q.name)).map(q=>item('qos',q.id,q.name,<ControlOutlined/>))),
      list('project-connections',`Service Connections (${snapshot.connections.length})`,<LinkOutlined/>,snapshot.connections.filter(c=>{
        const b=snapshot.bindings.find(b=>b.id===c.providerBindingId);
        return matches(snapshot.services.find(s=>s.id===b?.serviceId)?.name??'');
      }).map(c=>{
        const b=snapshot.bindings.find(b=>b.id===c.providerBindingId);
        const svc=snapshot.services.find(s=>s.id===b?.serviceId);
        return item('connection',c.id,svc?.name??'Service',<LinkOutlined/>);
      })),
      {key:'build:project',title:<b>Build & Deployment</b>,icon:<BuildOutlined/>}
    ]};
    return [projectRoot,{
      key:'standard-root',title:<b>UMAA 6.0 Library {tinyTag('READ ONLY')}</b>,icon:<FolderOpenOutlined/>,children:[
        list('standard-areas','8 Functional Areas',<DeploymentUnitOutlined/>,areaNodes),
        list('standard-messages',`Standard Message Types (${standardMessages.length})`,<CodeOutlined/>,standardMessages.filter(m=>matches(m.name)).map(m=>item('message',m.id,m.name,<FileTextOutlined/>))),
        list('standard-topics',`Standard Topics (${standardTopics.length})`,<DatabaseOutlined/>,standardTopics.filter(t=>matches(t.name)).map(t=>item('topic',t.id,t.name,<DatabaseOutlined/>))),
        {key:'library-patterns',title:'Patterns: Command/Response · Request/Reply',icon:<SettingOutlined/>}
      ]
    }];
  }, [snapshot, filter]);
  const selected=selection?`${selection.kind}:${selection.id}`:'';
  const filterExpanded = useMemo(()=>{ const out=[];const walk=nodes=>nodes.forEach(n=>{if(n.children?.length){out.push(n.key);walk(n.children);}});walk(tree);return out;},[tree]);
  if(!snapshot) return <Empty description="Loading project"/>;
  return <div className="sidebar-section explorer-unified">
    <Typography.Text type="secondary" className="side-label">PROJECT + STANDARD LIBRARY</Typography.Text>
    <Input.Search allowClear size="small" value={filter} onChange={e=>setFilter(e.target.value)} placeholder="Service · Component · IDL Type 검색" className="explorer-search"/>
    <div className="explorer-shortcuts">
      <Button size="small" icon={<ApartmentOutlined/>} onClick={()=>select({kind:'diagram',id:'system'})}>Diagram</Button>
      <Button size="small" icon={<CodeOutlined/>} onClick={()=>onCreate?.('type')}>+ Type</Button>
      <Button size="small" icon={<ApiOutlined/>} onClick={()=>onCreate?.('service')}>+ Service</Button>
    </div>
    <Tree showIcon showLine blockNode autoExpandParent={Boolean(filter)}
      expandedKeys={filter ? filterExpanded : expanded}
      onExpand={keys=>setExpanded(keys)} defaultExpandedKeys={expanded}
      treeData={tree} selectedKeys={selected?[selected]:[]}
      onSelect={keys=>{
        const raw=String(keys[0]??'');const idx=raw.indexOf(':');if(idx<0)return;
        const kind=raw.slice(0,idx);
        if(['diagram','build','functionalArea','component','service','interface','operation','topic','message','dataType','qos','binding','connection'].includes(kind)) select({kind,id:raw.slice(idx+1)});
      }} />
    <Typography.Text className="small-hint" type="secondary">Service를 Component 노드에 드래그하면 P/C 바인딩을 추가할 수 있습니다. 표준 정의는 읽기 전용입니다.</Typography.Text>
  </div>;
}
