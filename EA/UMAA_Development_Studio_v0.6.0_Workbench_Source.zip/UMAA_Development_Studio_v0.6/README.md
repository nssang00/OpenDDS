> **v0.6 UI 개편:** 먼저 [`WORKBENCH_v0.6_README.md`](WORKBENCH_v0.6_README.md)를 확인하세요. 기존 내용에는 v0.5 UI 구조가 포함될 수 있습니다.

# UMAA Development Studio Mock v0.5.0 — Design Model Integration

**Review:** Open `PREVIEW_UI.html` for an offline concept preview (not the actual React build). See [UI_REVIEW_GUIDE.md](UI_REVIEW_GUIDE.md) for implemented behaviors, build steps, and limitations.

---

# UMAA Web IDE — JavaScript/JSX + Autopilot 6.0 Mock Contract

**실행 목적:** 서버 없이 실행하는 React/AntD/React Flow/Dagre/Zustand 기반 프런트엔드 프로토타입. PostgreSQL 연결 전까지 Mock Repository를 사용합니다.

## 시작

```bash
npm install
npm run build
```

- 프로젝트 루트의 **`index.html`**을 브라우저에서 직접 엽니다. esbuild는 JavaScript/JSX를 IIFE 번들 `dist/main.js`와 CSS `dist/main.css`로 출력합니다. **실행용 HTTP 서버 없음**.
- 편집 시 `npm run watch`: 소스 변경에 따라 자동 재빌드하며 서버는 실행하지 않습니다.
- 모든 애플리케이션 소스는 **`.js`/`.jsx`**. `tsc`, `tsx`, `tsconfig`, Vite가 필요 없습니다.
- 파일 URL(`file://`)에서 `localStorage` 사용이 브라우저 정책에 의해 차단될 수 있습니다. 이 경우 메모리 저장 + 프로젝트 JSON Export/Import를 사용하세요.

## 대표 모델: UMAA Autopilot

**선택한 기준:** *UMAA Component Definitions v1.0*, Section 3.1.3 (UMAA 6.0 서비스 릴리스). 이 문서는 아래 14개 Service를 Autopilot에 연결합니다. `~`는 Consumer, 나머지는 Provider입니다.

| Role | Service | Functional Area | Flow Control |
|---|---|---|---|
| Provider | PrimitiveDriverControl | MO | Command/Response |
| Provider | GlobalVectorControl | MO | Command/Response |
| Provider | UVPlatformSpecs | EO | Request/Reply |
| Provider | LogReport | SO | Request/Reply |
| Provider | GlobalHoverControl | MO | Command/Response |
| Provider | HealthReport | SO | Request/Reply |
| Provider | ActiveConstraintsControl | MM | Command/Response |
| Consumer | GlobalPoseStatus | SA | Request/Reply |
| Consumer | VelocityStatus | SA | Request/Reply |
| Consumer | SpeedStatus | SA | Request/Reply |
| Consumer | WindStatus | SA | Request/Reply |
| Consumer | WaterCurrentStatus | SA | Request/Reply |
| Consumer | MissionPlanConstraintControl | MM | Command/Response (Add/Delete 두 흐름) |
| Consumer | ConditionalReport | MM | Request/Reply + Large Set 데이터 규칙 |

**Mock 모델의 현재 등록량:** 8개 Functional Area 분류 / **14개 Service** / 14개 도구 내 InterfaceBlock 탐색 투영 / **56개 Operation** / **32개 DDS Topic** / 32개 대응 IDL Message Type 참조 / 7개 Component / 44개 Binding / 28개 Service Connection. Autopilot에만 14개 Binding, 32개 Writer/Reader Endpoint가 파생됩니다.

### 왜 일반적인 통신 패턴 두 가지만 있나요?

UMAA 6.0 ICD 5장의 Flow Control은 `Command/Response`, `Request/Reply`입니다. 실제 DDS I/O는 Topic 기반 Publish/Subscribe이며, `query`는 대개 별도 메시지를 발행하지 않고 구독으로 구현합니다. `cancel`은 DDS instance `dispose`에 매핑합니다. `Large Collections`, `Generalization/Specialization`는 별도 데이터 처리 규칙입니다.

- **GlobalVectorControl / GlobalHoverControl / PrimitiveDriverControl**: Command, CommandStatus, CommandAckReport, ExecutionStatusReport의 서로 다른 Topic 및 Query/Cancel 동작을 연결합니다.
- **ActiveConstraintsControl**: Command, CommandStatus, CommandAckReport의 **3개 Topic**만 연결합니다. 이 서비스에 존재하지 않는 ExecutionStatus Topic을 생성하지 않습니다.
- **MissionPlanConstraintControl**: `Add`와 `Delete` Command, Status, Ack를 **별도의 6개 Topic**으로 등록합니다.
- **ConditionalReport**: `ConditionalReportType` 보고 Topic + `ConditionalReportTypeConditionalsSetElement` Large Set 요소 Topic을 연결합니다.
- **UVPlatformSpecs**: Capabilities/Specs에 대한 서로 다른 Report Topic 2개를 연결합니다.

### App 사용 흐름

1. 좌측 Explorer에서 Functional Area → Service → InterfaceBlock(탐색 투영) → Operation → Topic/IDL 참조를 탐색합니다.
2. 하단 **Autopilot (14 Services)** 탭에서 전체 계약을 확인하고 `모두 펼치기`로 56개 Operation을 볼 수 있습니다.
3. React Flow에서 Component별 Service Provider/Consumer 포트를 연결합니다. Dagre 자동 배치를 지원합니다.
4. 하단 `ICD → Operation → Topic/IDL`, `DDS Endpoint Matrix`, `Mock Flow Simulation`을 통해 매핑을 검사합니다.
5. 코드 생성에서 `Autopilot`을 고르면 C++ CMake 골격과 `contracts/service-operations.json`, `contracts/topic-endpoints.csv`, `component.manifest.json`을 내려받을 수 있습니다.
6. 프로젝트 JSON Export/Import 및 Mock 저장을 지원합니다. **기존 v0.3 Mock 로컬 저장소와 별도 키**를 사용하므로 새 프로젝트가 즉시 적용됩니다.

### 생성되는 C++ 코드는 무엇인가요?

`generateComponentFiles()`는 CMake `SHARED` 타깃, C ABI `start/stop/name`, DDS Endpoint 계약 목록, Component Manifest, 표준 IDL 의존성 목록 및 **Custom Service일 때만 IDL 소스**를 생성합니다. 이 골격은 CMake로 `.dll/.so`를 빌드할 수 있습니다.

**미구현:** 공식 UMAA IDL 내용, DDS 공급사 TypeSupport 코드, DDS DataReader/Writer 엔티티, Command/Response 상태 머신, 실제 통신 및 규격 인증. 즉 **IDL Topic / Operation의 모델 매핑이 완료**되었다는 의미이며 **실제 UMAA 호환 소프트웨어 구현 완료는 아닙니다**. 표준 필드와 QoS를 임의로 채우지 않았습니다.

### 다른 Autopilot 문서와의 차이

*UMAA SDK Autopilot Component Specification* (2024-11-05)에는 **15개 Component Interface** 목록이 있고 `Conditional Control Svc IF`도 포함됩니다. 반면 이 프로젝트의 **14개 Service/역할 기준은 Component Definitions v1.0 §3.1.3**입니다. 버전과 역할이 서로 다른 문서를 혼합하여 임의로 15개 바인딩으로 만들지 않았습니다. SDK Component Specification 기반의 별도 프로파일을 만들 때에는 추가 매핑 검증이 필요합니다.

## 테스트

```bash
npm run check:static   # 서버 없는 esbuild/JS 파일 구조 검사; npm install 불필요
npm run test:icd       # 14 서비스, 56 Operation, 32 Topic 및 Endpoint/코드생성; npm install 불필요
npm run test:layout    # Dagre 위치·노드 겹침 검사; npm install 필요
npm test               # 전체 검사; npm install 필요
```

## DB 교체 계획

현재 `src/repository/mockRepository.js`만 브라우저 localStorage/메모리에 접근합니다. 다른 파일은 Snapshot과 Repository 계약을 사용합니다. PostgreSQL 단계에서는 서버 API를 추가하고 해당 Adapter를 교체할 수 있습니다. **브라우저가 PostgreSQL에 직접 연결하는 구성은 보안·배포상 권장하지 않습니다.** SQL 초안은 `docs/postgresql-schema.sql`에 남겨두었습니다.

## 서비스 총수 용어 주의

등록된 Mock Service와 UMAA 6.0 전체 공개 ICD의 Service를 혼동하지 마세요. **이 프로젝트는 Autopilot에 필요한 14개만 상세 모델링**합니다. 자세한 문서 집계는 `docs/SERVICE_COUNTS.md`를 참고하세요.
