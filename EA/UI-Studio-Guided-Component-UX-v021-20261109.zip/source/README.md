> **2026-11-09 · v0.21 UX PoC:** 새 컴포넌트 템플릿, 4단계 제작 안내, 간편 Props·Events 공개, Native TSX Export 준비 상태를 추가했습니다. 자세한 내용과 미검증 범위는 [GUIDED-UX-V021.md](./GUIDED-UX-V021.md)를 참조하세요. 기존 v0.20 공식 기준선은 변경하지 않았습니다.

# UI Studio v0.16 — Verified Canvas Hierarchy Baseline

Status: **195 Core / 15 Studio Chrome / 1 independent React Consumer E2E PASS**, GitHub CI completed/success.
See [`V016-VERIFICATION.md`](V016-VERIFICATION.md) for the run, commit, source SHA-256, limitations and reproduction. v0.16 improves element hierarchy moves and Frame gap/alignment without changing the canonical v6 model.

---

## Earlier project overview (v0.15)

# UI Studio v0.15 — Visual-first editing UX

> Scope: [V015-SCOPE.md](V015-SCOPE.md). v0.15 is CI-verified at commit `7c56f9f870d47746e59254e04ab9e2ab69b3fd65` (188 Core, 13 Studio Chrome E2E, 1 independent Consumer E2E).
> v0.15 full Core / real-Chrome / independent Consumer verification: [V015-VERIFICATION.md](V015-VERIFICATION.md).

# UI Studio v0.14 — Visual-First Component Builder

**Build visually, connect data and actions, reuse as a component, then run the same
canonical Definition in React and SDUI-style dynamic rendering.** No JSON or JSX
editing is required for the supported paths.

See [V014-VERIFICATION.md](V014-VERIFICATION.md) for features, exact commands,
and deliberate limits. Includes 171 inherited Core cases plus 12 new visual-authoring
Core cases, and the existing Playwright journeys plus two new visual flows.

---

# UI Studio v0.14 — Component-First IDE

UI Studio creates reusable React components that may contain other user-authored reusable components. Definitions remain unique references; each placed Instance carries its own bindings and overrides. The Page is a preview/test harness, not the primary authoring unit.

To create: **New Component → choose name → Insert basic or user components → Expose Property/Event → choose a reusable Definition in Component Library → Preview Instance → React Component ZIP**.

Run `npm test`, `node tools/verify-syntax.mjs`, `npm run verify:runtime`, `npm run build`, `npm run export:v013`, and `npm run test:e2e`.

See [V013-VERIFICATION.md](V013-VERIFICATION.md) for the external consumer project and successful CI verification sequence. **GitHub Actions #39877164077: 171 Core passed; 9 Studio E2E passed; 1 separate React consumer E2E passed.** Source-root reproducibility workflow: `.github/workflows/component-first-e2e.yml`.

---

# UI Studio v0.12 — Dynamic Composition (Visual React Component IDE)

v0.11의 Definition / Instance / Named Slot / 독립 React Export 구조를 유지하면서, **동적 조건부 표시(when)와 배열 반복(repeat)**을 모든 Frame·기본 Control·UserControl Instance에 적용했습니다. 별도의 JavaScript 실행이나 React JSX 파싱 없이 Canonical JSON v6을 공유합니다.

## v0.12 시작하기

```bash
npm install
npm run dev
```

상단 **↻ Dynamic 예제** → Component Tree의 `ItemList` Definition 선택 → Code / Preview 전환. 목록을 수정하려면 **Preview Page**에서 `listA` 또는 `listB` 인스턴스를 선택하고 Inspector의 `items` JSON 배열을 편집합니다. 두 인스턴스는 동일한 Definition을 참조합니다.

- `when: {kind:'binding',source:'props',path:['showTitle'],mode:'OneWay'}`: true인 경우에만 표시
- `repeat: {items:{kind:'binding',source:'props',path:['items'],mode:'OneWay'},keyPath:['id']}`: 목록의 항목마다 컴포넌트 인스턴스 렌더링
- 반복 항목에서 `{{context.item.label}}`, `{{context.index}}` 바인딩 가능. 중첩된 반복은 `context.parent`로 한 단계 상위 항목 참조
- Repeat를 먼저 실행한 뒤 **각 반복 항목에서 when 조건을 평가**합니다
- 목록 항목의 키가 중복되거나 누락되면 인덱스로 대체하므로, 순서가 바뀌는 배열은 고유 `id`를 권장합니다
- Definition의 루트 Frame에서 `array`, `boolean`, `string`, `number`, `object` 타입의 **매핑 없는 공개 Props** 등록 가능
- v6 DSL, JSON Import/Export, React Runtime, 독립적인 TypeScript React 컴포넌트 ZIP에서 동일한 구조 사용

### 독립적인 React 컴포넌트 생성

```bash
npm test
npm run verify:runtime
npm run export:dynamic
```

`examples/ItemList-react-component-v0.12.zip`은 `ItemList`와 필요한 공통 Core만 포함하며, 다른 React 프로젝트에서 `items`와 `showTitle` Props로 사용할 수 있도록 생성했습니다. 자세한 사용 예시는 `examples/ItemList-usage.tsx`를 참조하세요.

**검증 상태:** 자동 테스트·테스트 렌더러 Runtime·정적 구문·독립 ZIP 구조 검증은 가능하지만, npm 모듈 다운로드가 차단돼 Vite 빌드와 실제 브라우저 DOM E2E는 이 환경에서 수행되지 않았습니다. 따라서 실사용 완료/프로덕션 완성을 주장하지 않습니다. Inspector의 실마우스 입력도 브라우저 검증이 필요합니다.

---

## 이전 버전(v0.11) 기록

# UI Studio v0.11 — Named Slots & Portable React Components

> **Component-first:** assemble controls into a UserControl, reuse that UserControl inside other UserControls, publish Props/Events, preview, and export a reusable React package.

This is a **development prototype**. It is not a finished general-purpose Component IDE or a production-certified browser editor. Ant Design is the current adapter, not the canonical model.

## Run

```bash
npm install
npm run dev
```

Open http://127.0.0.1:5173. The unified v6 editor opens on the **SearchBox Definition**. The page is retained as a test harness and for v0.9 compatibility, not as the product's primary artifact.

If you cannot reach the npm registry, the headless tests and deterministic example export can still run with Node 22:

```bash
npm test
npm run export:lego
npm run export:slots
npm run verify:runtime  # TypeScript transpiler 필요
```

## Try the Lego workflow

1. Click **🧱 LEGO 재사용 예제**. There are three reusable Definitions: **SearchBox → FilterBar → CustomerBrowser**. Definitions reference each other; they do not clone their children.
2. Use the **Component Tree** button for each Definition. Select **CustomerBrowser** and inspect the nested FilterBar and Table.
3. Use **＋ Insert** to add components to a Definition. Move or resize components in the Design Canvas, and try **Code** to edit the same canonical v6 tree.
4. Select a nested UserControl (diamond icon) in a Definition and publish one of its public properties or events using the Inspector. This forwards the nested contract to the containing Definition.
5. Go to **Preview Page** to try two CustomerBrowser Instances bound to separate `state.customer.keyword` and `state.product.keyword`. Return to a Definition to edit the original.
6. Select a Definition and click **📦 React Component ZIP**. Only that Definition, its transitive dependencies, the required Core/React runtime/AntD adapter and its public TS declarations are exported.
7. Or run `npm run export:lego` to reproduce `examples/CustomerBrowser-component.zip` without a browser. Unzip and run `npm install && npm run build` in the exported folder (requires internet/package cache).

**Create from scratch:** select **＋ New Component**. Give it a PascalCase name (e.g. `CustomerCard`), drag controls from Insert, and select a child Frame to **Create UserControl from Frame**. A newly created component automatically appears in Insert when you edit other components.

## Named Slot: UserControl 안에 또 다른 부품 끼우기

1. **▣ Slots 예제** 버튼으로 `SlotPanel` / `SearchCard` / `SearchBox` Definition을 불러옵니다.
2. `SlotPanel` Definition의 내부 Frame을 선택합니다. 오른쪽 Inspector의 **Named Slot**에서 `content`라는 이름으로 공개합니다(예제에는 이미 등록되어 있습니다).
3. `SearchCard` Definition으로 이동해 `SlotPanel` 인스턴스를 선택합니다. 오른쪽 **Slot · content**에서 Input, Button, Frame 또는 기존 UserControl을 추가합니다.
4. **비우기**는 빈 콘텐츠로 덮어씁니다. **원본 복원**은 인스턴스의 슬롯 지정을 삭제하고 원본 Frame의 기본 콘텐츠를 되돌립니다.
5. Slot 내부 요소는 Component Tree에서 선택해 속성을 변경하거나 삭제할 수 있습니다. JSON과 제한된 JSX DSL은 슬롯 콘텐츠를 보존합니다.
6. **Preview Page**에서 두 개의 SearchCard가 서로 다른 상태와 검색 이벤트로 동작하는 것을 확인합니다.
7. **📦 React Component ZIP**으로 선택한 Definition을 내보낼 수 있습니다. `npm run export:slots`는 동일한 샘플을 오프라인에서 생성합니다.

`content` 이름의 Slot은 내보낸 React 패키지에서 표준 `children` Props에 대응됩니다:

```tsx
import { SlotPanel } from 'ui-studio-slot-panel';

export default function Demo() {
  return <SlotPanel><button>React에서 추가한 요소</button></SlotPanel>;
}
```

다른 Slot 이름(예: `header`)은 `header?: React.ReactNode` 공개 속성으로 내보냅니다. **UI Studio 내부**에서 Slot에 추가한 콘텐츠는 IR 노드로 저장되고, **React 외부 사용**에서는 같은 위치를 ReactNode로 채울 수 있습니다. 이는 런타임 기반 Export에 적용됩니다.

## Portable React component example

The generated `CustomerBrowser` ZIP contains `src/CustomerBrowser.tsx`, `src/index.ts`, `src/index.d.ts`, transitive Definition data, a copied lightweight Runtime and adapter, `package.json`, and `vite.config.js`. There is **no import from the UI Studio application or absolute Studio source paths**.

After building and installing the exported package in another React project:

```tsx
import React, { useState } from 'react';
import { CustomerBrowser } from 'ui-studio-customer-browser';

export default function App() {
  const [keyword, setKeyword] = useState('');
  return <CustomerBrowser
    value={keyword}
    placeholder="Search customers"
    onValueChange={setKeyword}
    onSearch={(payload) => console.log('search', payload)}
  />;
}
```

The resulting component includes a **runtime dependency inside the exported package**, and still uses React and Ant Design as peer/dependency libraries. **A plain hand-written-looking JSX-only export is not implemented.** The sample package's React build has *not* been executed here, because npm installation is blocked by DNS.

## Limits and behavior

- **Canonical document:** v6 JSON; independent `pages` (preview harness) and `definitions` (reusable component source). `Designer ↔ JSX-shaped DSL` syncs a selected tree. The DSL is not arbitrary executable React/TypeScript.
- **Nested components:** transitive Definition references and cycle rejection. Stable Definition node IDs. Runtime instance path isolates mutable state.
- **Property propagation:** nested exposed property is projected through the child's public props; TwoWay writes climb up via DataContext, without touching unrelated instances.
- **Events:** nested public events can be re-exposed at each level. Exported React callbacks are only fired for the exported root Instance (avoids duplicate nested events).
- **Controlled/uncontrolled props:** supplied React Props update the component store; omitted values keep instance-local state. TwoWay changes call `onXChange`.
- **Export isolation:** dependencies on global `state`, `sources`, or `context` inside Definitions are intentionally rejected by the portable exporter. Expose those dependencies as public Props instead. This prevents secretly shipping app-specific sample state.
- **Current exclusions:** arbitrary custom TypeScript control authoring, SVG primitive designer, Canvas/Absolute layout, full Action Engine, plugin sandbox, XML converter, generalized dynamic If/Repeat, animations, Native JSX-only exporter, and full browser E2E validation.
- **Legacy:** older v5 remains under the Legacy UI, with a one-way v5→v6 import path.

## Evidence

`npm test` currently runs **155 Node tests**, including composable-component and named-slot regression tests for nested bindings, events, edits, cycle detection, preview harness, portable dependency closure, safe export and JSON roundtrip. `node tools/export-lego.mjs` reproduces an inspectable portable ZIP. See `EVIDENCE.md` for commands, outcomes and explicit limitations.

**Important:** Browser drag/resize behavior, `npm run build` and the exported component's actual installation/build remain unverified due to npm registry DNS resolution errors in this execution environment. Static parsing and Node tests do not establish browser correctness.

### 검증 환경의 한계

`npm test`: Schema/Editor/Slot/Exporter Core의 155개 회귀 테스트. `npm run verify:runtime`: 실제 React Runtime JSX 소스를 TypeScript로 변환하고 **가짜 테스트 렌더러**로 실행해, 중첩 Slot 두 인스턴스의 TwoWay 바인딩·이벤트, 외부 ReactNode Slot, 바인딩 불가능 공개 속성의 Props 전달을 검사합니다. 이는 실제 React/AntD 브라우저를 구동하는 E2E 테스트가 **아닙니다**.

이 환경에서는 npmjs.org가 `EAI_AGAIN`으로 접근되지 않고 Chromium headless도 GPU 초기화 오류로 종료되어, Vite 빌드·실제 UI 드래그 및 외부 프로젝트 설치는 확인하지 못했습니다.

## Experimental Native shadcn/ui TSX Export (2026-11-08)

The project is moving toward a **visual React component builder with editable, native React TSX output**. A **restricted experimental** exporter has been added without replacing the existing Ant Design Runtime exporter. In One Studio, choose a reusable Component Definition, then use **Project menu → shadcn Native TSX (실험)**. Or run `npm run export:shadcn` for a standalone SearchBox example. The generated files target an *existing* shadcn/ui (Base UI) React project. The current PoC also emits **nested component Definitions and Slot fills as separate editable TSX files** and supports uncontrolled public TwoWay fields. Run `npm run verify:native-tsx` for an **offline TypeScript stub check** (this is not a real shadcn consumer build). Supported features, limitations, verification, and next actions are documented in [NATIVE-SHADCN-POC.md](./NATIVE-SHADCN-POC.md).
