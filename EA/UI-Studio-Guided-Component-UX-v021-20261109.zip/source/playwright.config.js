import { defineConfig, devices } from '@playwright/test';

/** Real Chromium DOM E2E: runs against the production Vite preview after build. */
export default defineConfig({
  testDir: './e2e',
  testMatch: ['**/one-studio-v020.spec.js','**/guided-v021.spec.js'],
  testIgnore: '**/consumer-v013/**',
  timeout: 45_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  workers: process.env.CI ? 1 : undefined,
  retries: process.env.CI ? 1 : 0,
  globalTimeout: 15 * 60_000,
  reporter: process.env.CI
    ? [['list'], ['html', { open: 'never' }], ['junit', { outputFile: 'test-results/e2e-junit.xml' }]]
    : [['list'], ['html', { open: 'never' }]],
  use: {
    baseURL: 'http://127.0.0.1:4173',
    trace: 'retain-on-failure',
    screenshot: 'only-on-failure',
    video: process.env.CI ? 'off' : 'retain-on-failure',
    actionTimeout: 15_000,
  },
  projects: [{ name: 'chromium', use: { ...devices['Desktop Chrome'], ...(process.env.UI_STUDIO_USE_SYSTEM_CHROME === '1' ? { channel: 'chrome' } : {}), viewport: { width: 1600, height: 1000 } } }],
  webServer: {
    command: 'npm run preview -- --host 127.0.0.1 --port 4173 --strictPort',
    url: 'http://127.0.0.1:4173',
    reuseExistingServer: !process.env.CI,
    timeout: 90_000,
  },
});
