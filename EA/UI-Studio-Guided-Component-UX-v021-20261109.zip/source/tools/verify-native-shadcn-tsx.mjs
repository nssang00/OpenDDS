/** Offline structural TypeScript check of generated shadcn Native TSX.
 * Uses intentionally lightweight declarations. It does NOT verify actual
 * shadcn/Base UI component APIs, CSS, DOM events, accessibility or browser UI.
 * Full consumer validation needs real shadcn CLI dependencies and Chrome.
 */
import {mkdtempSync,mkdirSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {spawnSync} from 'node:child_process';
import {createSearchBoxDocument} from '../packages/schema/index.js';
import {createDefaultRegistry} from '../packages/core/registry.js';
import {createSlotExampleDocument} from '../packages/core/workspace.js';
import {createGuidedComponent} from '../packages/core/guided.js';
import {createNativeShadcnFiles} from '../packages/exporter-react/native-shadcn.js';

const mockTypes=`// This is a compile-only shim, NOT real @base-ui/react or shadcn/ui.
declare namespace JSX { interface IntrinsicElements { [elemName: string]: any } }
declare module 'react' {
  export type ReactNode = any;
  export function useState<T>(initial: T | (() => T)): [T, (value: T) => void];
  export const Fragment: (props: {children?: ReactNode}) => any;
}
declare module 'react/jsx-runtime' {
  export const jsx: any;
  export const jsxs: any;
  export const Fragment: any;
  export namespace JSX { interface IntrinsicElements { [elemName: string]: any } }
}
declare module '@/components/ui/input' {
  export function Input(props: {onChange?: (event: {currentTarget: {value: string}}) => void; [key: string]: any}): any;
}
declare module '@/components/ui/button' {
  export function Button(props: {onClick?: () => void; [key: string]: any}): any;
}
declare module '@/components/ui/checkbox' {
  export function Checkbox(props: {onCheckedChange?: (value: boolean) => void; [key: string]: any}): any;
}
declare module '@/components/ui/card' {
  export function Card(props: any): any;
  export function CardHeader(props: any): any;
  export function CardTitle(props: any): any;
  export function CardDescription(props: any): any;
}
declare module '@/components/ui/label' { export function Label(props: any): any; }
declare module '@/components/ui/separator' { export function Separator(props: any): any; }
declare module '@/components/ui/badge' { export function Badge(props: any): any; }
`;
const registry=createDefaultRegistry(),location=mkdtempSync(join(tmpdir(),'ui-studio-native-tsx-'));
try{
  const entries=[['search',createSearchBoxDocument(),'SearchBox'],['composite',createSlotExampleDocument(registry),'SearchCard'],['guided',createGuidedComponent(createSearchBoxDocument(),'CustomerLookup',registry,{template:'search',fresh:true}),'CustomerLookup']];
  for(const [folder,doc,id] of entries){
    const files=createNativeShadcnFiles(doc,registry,id);
    for(const [name,code] of Object.entries(files)){
      if(!name.endsWith('.tsx'))continue;
      const filename=join(location,folder,name);
      mkdirSync(dirname(filename),{recursive:true});writeFileSync(filename,code);
    }
  }
  writeFileSync(join(location,'shims.d.ts'),mockTypes);
  writeFileSync(join(location,'tsconfig.json'),JSON.stringify({compilerOptions:{target:'ES2022',module:'ESNext',moduleResolution:'Bundler',jsx:'react-jsx',strict:true,noEmit:true,skipLibCheck:true},include:['**/*.tsx','shims.d.ts']},null,2));
  const compiler=process.platform==='win32'?'tsc.cmd':'tsc';
  const run=spawnSync(compiler,['--project',join(location,'tsconfig.json'),'--pretty','false'],{encoding:'utf8',timeout:20000});
  if(run.error)throw new Error(`TypeScript compiler를 실행할 수 없습니다: ${run.error.message}. 먼저 npm install을 실행하세요.`);
  if(run.status!==0)throw new Error(`Generated TSX typecheck 실패:\n${run.stdout}\n${run.stderr}`);
  console.log('PASS: generated SearchBox + SearchCard (3 files) + CustomerLookup template TypeScript strict check — OFFLINE STUBS ONLY');
  console.log('NOT CHECKED: actual shadcn/Base UI components, Tailwind, browser interaction and accessibility');
}finally{rmSync(location,{recursive:true,force:true});}
