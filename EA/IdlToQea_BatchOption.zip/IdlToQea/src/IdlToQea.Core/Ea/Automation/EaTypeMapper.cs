using Idl.Model;

namespace Ea.Automation;

public sealed record EaElementMapping(string ElementType, string? Stereotype);

public sealed class EaTypeMapper
{
    private readonly EaMappingPolicy _policy;

    public EaTypeMapper(EaMappingPolicy? policy = null) => _policy = policy ?? new EaMappingPolicy();

    public EaMappingPolicy Policy => _policy;

    public EaElementMapping MapDeclaration(IdlDeclaration declaration) => declaration switch
    {
        // These mappings follow common UML/EA conventions and are intentionally fixed.
        IdlStruct => new("Class", "IDLStruct"),
        IdlEnum => new("Enumeration", "IDLEnum"),
        IdlInterface => new("Interface", "IDLInterface"),

        // These mappings are project policy and may be customized later.
        IdlTypedef => _policy.Typedef,
        IdlUnion => _policy.Union,
        IdlConstant => _policy.Constant,
        _ => throw new NotSupportedException($"EA element mapping is not defined for {declaration.GetType().Name}.")
    };

    public string MapAttributeType(IdlTypeReference type) => type.Kind switch
    {
        IdlTypeKind.Primitive => type.Name,
        IdlTypeKind.String => _policy.FormatString(type),
        IdlTypeKind.WString => _policy.FormatWString(type),
        IdlTypeKind.Sequence => _policy.FormatSequence(MapAttributeType(type.ElementType!), type.BoundExpression),
        IdlTypeKind.Set => _policy.FormatSet(MapAttributeType(type.ElementType!), type.BoundExpression),
        IdlTypeKind.Map => _policy.FormatMap(MapAttributeType(type.KeyType!), MapAttributeType(type.ElementType!), type.BoundExpression),
        IdlTypeKind.Named => type.Name,
        _ => type.Name
    };

    public string MapTypeKind(IdlTypeReference type) => type.Kind.ToString().ToLowerInvariant();
}
