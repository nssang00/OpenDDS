using Idl.Model;

namespace Ea.Automation;

/// <summary>
/// Defines the IDL-to-EA representation choices that may vary between projects.
/// Defaults preserve the current IdlToQea mapping exactly.
/// </summary>
public sealed class EaMappingPolicy
{
    public EaElementMapping Typedef { get; init; } = new("DataType", "IDLTypedef");
    public EaElementMapping Union { get; init; } = new("Class", "IDLUnion");
    public EaElementMapping Constant { get; init; } = new("DataType", "IDLConstant");

    public string ArrayDimensionsTag { get; init; } = "idl.arrayDimensions";
    public string BoundTag { get; init; } = "idl.bound";

    public string FormatString(IdlTypeReference type)
        => type.BoundExpression is null ? "string" : $"string<{type.BoundExpression}>";

    public string FormatWString(IdlTypeReference type)
        => type.BoundExpression is null ? "wstring" : $"wstring<{type.BoundExpression}>";

    public string FormatSequence(string elementType, string? bound)
        => $"sequence<{elementType}{FormatBound(bound)}>";

    public string FormatSet(string elementType, string? bound)
        => $"set<{elementType}{FormatBound(bound)}>";

    public string FormatMap(string keyType, string elementType, string? bound)
        => $"map<{keyType},{elementType}{FormatBound(bound)}>";

    private static string FormatBound(string? bound) => bound is null ? string.Empty : $",{bound}";
}
