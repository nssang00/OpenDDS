using Idl.Model;
using Idl.Parsing;
using Idl.Parsing.Input;

namespace Idl.Symbols;

/// <summary>
/// Merges parsed IDL documents, builds the symbol table, and resolves named type references.
/// </summary>
public sealed class IdlModelResolver
{
    private readonly IdlDocumentParser _parser = new();
    private readonly IdlSymbolTable _symbols = new();
    private readonly List<IdlDiagnostic> _diagnostics = [];

    public IReadOnlyList<IdlDiagnostic> Diagnostics => _diagnostics;
    public int SymbolCount => _symbols.Count;
    public IReadOnlyDictionary<string, IdlDeclaration> Symbols => _symbols.Symbols;
    public int DocumentCount { get; private set; }
    public bool Success => _diagnostics.All(x => x.Severity != IdlDiagnosticSeverity.Error);

    public IdlModule Resolve(IdlSourceSet sourceSet, Action<int, int>? progress = null)
    {
        ArgumentNullException.ThrowIfNull(sourceSet);
        _symbols.Clear();
        _diagnostics.Clear();
        DocumentCount = 0;

        _diagnostics.AddRange(sourceSet.Diagnostics);
        var topLevelDeclarations = new List<IdlDeclaration>();

        var orderedFiles = sourceSet.Files.OrderBy(x => x.RelativePath, StringComparer.OrdinalIgnoreCase).ToArray();
        foreach (var sourceFile in orderedFiles)
        {
            var parse = _parser.Parse(sourceFile);
            DocumentCount++;
            _diagnostics.AddRange(parse.Diagnostics);
            AssignSourcePath(parse.Document.Declarations, parse.Document.SourcePath);
            topLevelDeclarations.AddRange(parse.Document.Declarations);
            progress?.Invoke(DocumentCount, orderedFiles.Length);
        }

        var root = BuildRoot(topLevelDeclarations);
        if (!Success) return root;

        var rootScope = root.IsSynthetic ? Array.Empty<string>() : new[] { root.Name };
        CollectSymbols(root.Declarations, rootScope);
        if (!Success) return root;

        ResolveDeclarations(root.Declarations, rootScope);
        return root;
    }

    private static IdlModule BuildRoot(IReadOnlyList<IdlDeclaration> declarations)
    {
        var modules = declarations.OfType<IdlModule>().ToList();
        var nonModules = declarations.Where(x => x is not IdlModule).ToList();
        var rootNames = modules.Select(x => x.Name).Distinct(StringComparer.Ordinal).ToList();

        if (nonModules.Count == 0 && rootNames.Count == 1)
        {
            var root = new IdlModule(rootNames[0]);
            foreach (var module in modules) MergeModule(root, module);
            return root;
        }

        var syntheticRoot = new IdlModule("IDL", isSynthetic: true);
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule sourceModule)
            {
                var targetModule = syntheticRoot.Declarations.OfType<IdlModule>()
                    .FirstOrDefault(x => x.Name == sourceModule.Name);
                if (targetModule is null)
                    syntheticRoot.Add(sourceModule);
                else
                    MergeModule(targetModule, sourceModule);
            }
            else
            {
                syntheticRoot.Add(declaration);
            }

            if (!string.IsNullOrWhiteSpace(declaration.SourcePath))
                syntheticRoot.AddSourcePath(declaration.SourcePath!);
        }

        return syntheticRoot;
    }

    private static void AssignSourcePath(IEnumerable<IdlDeclaration> declarations, string sourcePath)
    {
        foreach (var declaration in declarations)
        {
            declaration.SourcePath = sourcePath;
            if (declaration is IdlModule module)
            {
                module.AddSourcePath(sourcePath);
                AssignSourcePath(module.Declarations, sourcePath);
            }
        }
    }

    private static void MergeModule(IdlModule target, IdlModule source)
    {
        foreach (var path in source.SourcePaths) target.AddSourcePath(path);

        foreach (var declaration in source.Declarations)
        {
            if (declaration is IdlModule sourceChild)
            {
                var targetChild = target.Declarations.OfType<IdlModule>().FirstOrDefault(x => x.Name == sourceChild.Name);
                if (targetChild is null)
                    target.Add(sourceChild);
                else
                    MergeModule(targetChild, sourceChild);
            }
            else
            {
                target.Add(declaration);
            }
        }
    }

    private void CollectSymbols(IEnumerable<IdlDeclaration> declarations, IReadOnlyList<string> scope)
    {
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
            {
                CollectSymbols(module.Declarations, [.. scope, module.Name]);
                continue;
            }

            if (!IsTypeDeclaration(declaration)) continue;
            var scopedName = "::" + string.Join("::", scope.Append(declaration.Name));
            if (!_symbols.TryAdd(scopedName, declaration))
            {
                _diagnostics.Add(new IdlDiagnostic(
                    "IDL2001",
                    IdlDiagnosticSeverity.Error,
                    $"Duplicate IDL type declaration: {scopedName}",
                    declaration.SourcePath ?? string.Empty));
            }
        }
    }

    private void ResolveDeclarations(IEnumerable<IdlDeclaration> declarations, IReadOnlyList<string> scope)
    {
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
            {
                ResolveDeclarations(module.Declarations, [.. scope, module.Name]);
                continue;
            }

            switch (declaration)
            {
                case IdlStruct s:
                    if (s.BaseType is not null) ResolveType(s.BaseType, scope, declaration, $"base struct {s.Name}");
                    foreach (var field in s.Fields) ResolveType(field.Type, scope, declaration, $"field {s.Name}.{field.Name}");
                    break;
                case IdlTypedef t:
                    ResolveType(t.UnderlyingType, scope, declaration, $"typedef {t.Name}");
                    break;
                case IdlInterface i:
                    foreach (var baseType in i.BaseInterfaces) ResolveType(baseType, scope, declaration, $"base interface {i.Name}");
                    foreach (var op in i.Operations)
                    {
                        if (op.ReturnType is not null) ResolveType(op.ReturnType, scope, declaration, $"operation {i.Name}.{op.Name} return");
                        foreach (var p in op.Parameters) ResolveType(p.Type, scope, declaration, $"parameter {i.Name}.{op.Name}.{p.Name}");
                    }
                    break;
                case IdlUnion u:
                    ResolveType(u.DiscriminatorType, scope, declaration, $"union {u.Name} discriminator");
                    foreach (var c in u.Cases) ResolveType(c.Field.Type, scope, declaration, $"union {u.Name}.{c.Field.Name}");
                    break;
                case IdlConstant c:
                    ResolveType(c.Type, scope, declaration, $"const {c.Name}");
                    break;
            }
        }
    }

    private void ResolveType(IdlTypeReference type, IReadOnlyList<string> scope, IdlDeclaration owner, string usage)
    {
        if ((type.Kind is IdlTypeKind.Sequence or IdlTypeKind.Set) && type.ElementType is not null)
            ResolveType(type.ElementType, scope, owner, usage + " element");

        if (type.Kind == IdlTypeKind.Map)
        {
            if (type.KeyType is not null) ResolveType(type.KeyType, scope, owner, usage + " key");
            if (type.ElementType is not null) ResolveType(type.ElementType, scope, owner, usage + " value");
        }

        if (type.Kind != IdlTypeKind.Named) return;

        var resolved = _symbols.Resolve(type.Name, scope);
        if (resolved is null)
        {
            _diagnostics.Add(new IdlDiagnostic(
                "IDL2002",
                IdlDiagnosticSeverity.Error,
                $"Unresolved IDL type '{type.Name}' used by {usage}.",
                owner.SourcePath ?? string.Empty));
            return;
        }

        type.ResolvedScopedName = resolved;
    }

    private static bool IsTypeDeclaration(IdlDeclaration declaration) => declaration is
        IdlStruct or IdlEnum or IdlTypedef or IdlInterface or IdlUnion;
}
