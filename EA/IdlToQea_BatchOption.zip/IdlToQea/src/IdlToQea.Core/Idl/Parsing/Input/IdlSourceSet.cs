using Idl.Model;

namespace Idl.Parsing.Input;

public sealed class IdlSourceSet
{
    private readonly Dictionary<string, IdlSourceFile> _files =
        new(StringComparer.OrdinalIgnoreCase);
    private readonly List<IdlDiagnostic> _diagnostics = [];

    public IReadOnlyCollection<IdlSourceFile> Files => _files.Values;
    public IReadOnlyList<IdlDiagnostic> Diagnostics => _diagnostics;

    public void AddFile(IdlSourceFile file)
    {
        if (!_files.TryAdd(file.RelativePath, file))
        {
            throw new InvalidOperationException($"Duplicate IDL path: {file.RelativePath}");
        }
    }

    public bool TryGetFile(string relativePath, out IdlSourceFile? file) =>
        _files.TryGetValue(relativePath, out file);

    public void AddDiagnostic(IdlDiagnostic diagnostic) => _diagnostics.Add(diagnostic);
}
