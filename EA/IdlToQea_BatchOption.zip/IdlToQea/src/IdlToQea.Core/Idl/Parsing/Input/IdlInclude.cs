namespace Idl.Parsing.Input;

public sealed class IdlInclude
{
    public IdlInclude(string path, IdlIncludeKind kind, int lineNumber)
    {
        Path = path;
        Kind = kind;
        LineNumber = lineNumber;
    }

    public string Path { get; }
    public IdlIncludeKind Kind { get; }
    public int LineNumber { get; }
    public string? ResolvedPath { get; private set; }
    public bool IsResolved => ResolvedPath is not null;

    public void ResolveTo(string resolvedPath)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(resolvedPath);
        ResolvedPath = resolvedPath;
    }
}
