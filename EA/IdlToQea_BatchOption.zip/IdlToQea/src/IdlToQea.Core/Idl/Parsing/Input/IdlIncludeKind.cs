namespace Idl.Parsing.Input;

public enum IdlIncludeKind
{
    Quoted,
    AngleBracket
}
