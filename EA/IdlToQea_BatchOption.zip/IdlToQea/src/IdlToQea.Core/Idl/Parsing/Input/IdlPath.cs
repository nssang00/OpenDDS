namespace Idl.Parsing.Input;

internal static class IdlPath
{
    public static string Normalize(string path)
    {
        if (!TryNormalize(path, out var normalized))
        {
            throw new InvalidDataException($"IDL path escapes the source root: {path}");
        }

        return normalized;
    }

    public static bool TryNormalize(string path, out string normalized)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(path);

        var parts = path.Replace('\\', '/').Split('/', StringSplitOptions.RemoveEmptyEntries);
        var stack = new Stack<string>();

        foreach (var part in parts)
        {
            if (part == ".")
            {
                continue;
            }

            if (part == "..")
            {
                if (stack.Count == 0)
                {
                    normalized = string.Empty;
                    return false;
                }

                stack.Pop();
                continue;
            }

            stack.Push(part);
        }

        normalized = string.Join('/', stack.Reverse());
        return true;
    }

    public static string Combine(string? directory, string path)
    {
        var combined = string.IsNullOrEmpty(directory) ? path : $"{directory}/{path}";
        return Normalize(combined);
    }

    public static bool TryCombine(string? directory, string path, out string combined)
    {
        var candidate = string.IsNullOrEmpty(directory) ? path : $"{directory}/{path}";
        return TryNormalize(candidate, out combined);
    }
}
