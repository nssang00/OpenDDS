using System.Diagnostics;
using System.Runtime.InteropServices;
using Ea.Automation;
using Idl.Model;
using Idl.Parsing;
using Idl.Symbols;

internal static class Program
{
    [STAThread]
    public static int Main(string[] args)
    {
        if (args.Length == 0 || args.Contains("--help", StringComparer.OrdinalIgnoreCase) || args.Contains("-h", StringComparer.OrdinalIgnoreCase))
        {
            PrintUsage();
            return 0;
        }

        string stage = "startup";
        var stopwatch = Stopwatch.StartNew();
        try
        {
            var options = ParseArguments(args);
            ValidateInput(options.InputPath);
            ValidateOutput(options.OutputPath);

            Console.WriteLine($"Input     : {options.InputPath}");
            if (options.Batch)
                Console.WriteLine("Mode      : Batch");

            stage = "IDL parsing";
            var workspace = new IdlSourceWorkspace();
            var sourceSet = workspace.Load(options.InputPath);
            var modelResolver = new IdlModelResolver();
            using var parsingProgress = new ConsoleProgress("Parsing IDL", showCount: true);
            var model = modelResolver.Resolve(sourceSet, parsingProgress.Report);
            parsingProgress.Complete();

            Console.WriteLine($"IDL files : {sourceSet.Files.Count}");
            Console.WriteLine($"Symbols   : {modelResolver.SymbolCount}");

            var errors = modelResolver.Diagnostics
                .Where(x => x.Severity == IdlDiagnosticSeverity.Error)
                .ToArray();
            if (errors.Length > 0)
            {
                foreach (var error in errors.Take(50))
                    Console.Error.WriteLine($"{error.Code}: {error.SourcePath}:{error.LineNumber} {error.Message}");
                if (errors.Length > 50)
                    Console.Error.WriteLine($"... {errors.Length - 50} more errors");
                return 2;
            }

            if (!OperatingSystem.IsWindows())
                throw new PlatformNotSupportedException("IDL parsing succeeded, but QEA generation requires Windows with Sparx Enterprise Architect installed.");

            var outputPath = Path.GetFullPath(options.OutputPath);
            Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
            if (File.Exists(outputPath))
                throw new IOException($"Output already exists: {outputPath}");

            object? repositoryObject = null;
            var copiedBase = false;
            var success = false;

            try
            {
                stage = "EA.Repository COM creation";
                var repositoryType = Type.GetTypeFromProgID("EA.Repository", throwOnError: true)
                    ?? throw new InvalidOperationException("Sparx Enterprise Architect Automation COM registration was not found.");

                repositoryObject = Activator.CreateInstance(repositoryType)
                    ?? throw new InvalidOperationException("Could not create EA.Repository COM object.");
                dynamic repository = repositoryObject;

                stage = "EABase.qea discovery";
                var basePath = ResolveEaBasePath(options.EaBasePath);

                stage = "QEA base copy";
                File.Copy(basePath, outputPath, overwrite: false);
                copiedBase = true;

                stage = "EA.Repository.OpenFile";
                var opened = (bool)repository.OpenFile(outputPath);
                if (!opened)
                    throw new InvalidOperationException($"EA.Repository.OpenFile returned false for '{outputPath}'.");

                if (options.Batch)
                {
                    stage = "EA batch mode";
                    repository.BatchAppend = true;
                    repository.EnableUIUpdates = false;
                }

                stage = "EA model generation";
                var generator = new EaModelGenerator();
                using var eaProgress = new ConsoleProgress("Generating EA", showCount: false);
                Action<int, int> reportEaProgress = eaProgress.Report;
                generator.Generate(model, (object)repository, progress: reportEaProgress);
                eaProgress.Complete();

                stopwatch.Stop();
                Console.WriteLine($"EA elements: {generator.Elements.Count}");
                Console.WriteLine($"Output     : {outputPath}");
                Console.WriteLine($"Elapsed    : {stopwatch.Elapsed.TotalSeconds:F2}s");
                Console.WriteLine("Result     : Success");
                success = true;
                return 0;
            }
            finally
            {
                if (repositoryObject is not null)
                {
                    if (options.Batch)
                    {
                        try { ((dynamic)repositoryObject).BatchAppend = false; }
                        catch (Exception batchEx) { Console.Error.WriteLine($"Warning: EA BatchAppend reset failed: {batchEx.Message}"); }
                        try { ((dynamic)repositoryObject).EnableUIUpdates = true; }
                        catch (Exception uiEx) { Console.Error.WriteLine($"Warning: EA EnableUIUpdates reset failed: {uiEx.Message}"); }
                    }

                    try { ((dynamic)repositoryObject).CloseFile(); }
                    catch (Exception closeEx) { Console.Error.WriteLine($"Warning: EA CloseFile failed: {closeEx.Message}"); }
                    try { ((dynamic)repositoryObject).Exit(); }
                    catch (Exception exitEx) { Console.Error.WriteLine($"Warning: EA Exit failed: {exitEx.Message}"); }
                    try
                    {
                        if (Marshal.IsComObject(repositoryObject))
                            Marshal.FinalReleaseComObject(repositoryObject);
                    }
                    catch { }
                }

                if (!success && copiedBase)
                {
                    try { File.Delete(outputPath); } catch { }
                }
            }
        }
        catch (Exception ex)
        {
            stopwatch.Stop();
            Console.Error.WriteLine("Result  : Failed");
            Console.Error.WriteLine($"Stage   : {stage}");
            Console.Error.WriteLine($"Error   : {ex.Message}");
            Console.Error.WriteLine($"Elapsed : {stopwatch.Elapsed.TotalSeconds:F2}s");
            if (ex.HResult != 0)
                Console.Error.WriteLine($"HRESULT: 0x{ex.HResult:X8}");
            return 1;
        }
    }

    private static string ResolveEaBasePath(string? explicitPath)
    {
        if (!string.IsNullOrWhiteSpace(explicitPath))
        {
            var full = Path.GetFullPath(explicitPath);
            if (!File.Exists(full))
                throw new FileNotFoundException("Specified EABase.qea was not found.", full);
            return full;
        }

        var bundledPath = Path.Combine(AppContext.BaseDirectory, "Resources", "EABase.qea");
        if (File.Exists(bundledPath))
            return bundledPath;

        throw new FileNotFoundException(
            "Bundled Resources\\EABase.qea was not found. Rebuild/publish the CLI or use --ea-base <path-to-EABase.qea>.",
            bundledPath);
    }

    private static CliOptions ParseArguments(string[] args)
    {
        string? input = null;
        string? output = null;
        string? eaBase = null;
        var batch = false;

        for (var i = 0; i < args.Length; i++)
        {
            switch (args[i].ToLowerInvariant())
            {
                case "--input":
                case "-i":
                    input = RequireValue(args, ref i);
                    break;
                case "--output":
                case "-o":
                    output = RequireValue(args, ref i);
                    break;
                case "--ea-base":
                    eaBase = RequireValue(args, ref i);
                    break;
                case "--batch":
                    batch = true;
                    break;
                default:
                    if (args[i].StartsWith('-'))
                        throw new ArgumentException($"Unknown option: {args[i]}");
                    if (input is null) input = args[i];
                    else if (output is null) output = args[i];
                    else throw new ArgumentException($"Unexpected argument: {args[i]}");
                    break;
            }
        }

        if (string.IsNullOrWhiteSpace(input) || string.IsNullOrWhiteSpace(output))
            throw new ArgumentException("Both input and output paths are required. Use --help for usage.");

        return new CliOptions(
            Path.GetFullPath(input),
            Path.GetFullPath(output),
            string.IsNullOrWhiteSpace(eaBase) ? null : Path.GetFullPath(eaBase),
            batch);
    }

    private static string RequireValue(string[] args, ref int index)
    {
        if (++index >= args.Length)
            throw new ArgumentException($"Missing value for {args[index - 1]}.");
        return args[index];
    }

    private static void ValidateInput(string inputPath)
    {
        if (Directory.Exists(inputPath)) return;
        if (File.Exists(inputPath) && string.Equals(Path.GetExtension(inputPath), ".zip", StringComparison.OrdinalIgnoreCase)) return;
        throw new FileNotFoundException("Input must be an existing directory or .zip file.", inputPath);
    }

    private static void ValidateOutput(string outputPath)
    {
        if (!string.Equals(Path.GetExtension(outputPath), ".qea", StringComparison.OrdinalIgnoreCase))
            throw new ArgumentException("Output file must use the .qea extension.");
    }

    private static void PrintUsage()
    {
        Console.WriteLine("IdlToQea - Convert UMAA IDL to a Sparx Enterprise Architect QEA model");
        Console.WriteLine();
        Console.WriteLine("Usage:");
        Console.WriteLine("  IdlToQea.exe --input <zip-or-folder> --output <file.qea> [--batch]");
        Console.WriteLine("  IdlToQea.exe <zip-or-folder> <file.qea>");
        Console.WriteLine();
        Console.WriteLine("Optional:");
        Console.WriteLine("  --ea-base <EABase.qea>   Override the bundled Resources\\EABase.qea template.");
        Console.WriteLine("  --batch                   Enable EA BatchAppend bulk-insert optimization.");
        Console.WriteLine();
        Console.WriteLine("Requirements:");
        Console.WriteLine("  Windows with Sparx Enterprise Architect installed and EA.Repository COM registered.");
    }


    private sealed class ConsoleProgress : IDisposable
    {
        private readonly string _label;
        private readonly bool _showCount;
        private int _lastPercent = -1;
        private int _lastLength;
        private bool _completed;

        public ConsoleProgress(string label, bool showCount)
        {
            _label = label;
            _showCount = showCount;
        }

        public void Report(int current, int total)
        {
            if (Console.IsOutputRedirected || total <= 0) return;

            var percent = Math.Clamp(current * 100 / total, 0, 100);
            if (percent == _lastPercent && current < total) return;
            _lastPercent = percent;

            const int width = 20;
            var filled = percent * width / 100;
            var bar = new string('#', filled) + new string('-', width - filled);
            var count = _showCount ? $"  {current}/{total}" : string.Empty;
            var text = $"{_label,-13} [{bar}] {percent,3}%{count}";

            Console.Write('\r');
            Console.Write(text);
            if (_lastLength > text.Length)
                Console.Write(new string(' ', _lastLength - text.Length));
            _lastLength = text.Length;
        }

        public void Complete()
        {
            if (_completed) return;
            _completed = true;
            if (!Console.IsOutputRedirected && _lastLength > 0)
                Console.WriteLine();
        }

        public void Dispose() => Complete();
    }

    private sealed record CliOptions(string InputPath, string OutputPath, string? EaBasePath, bool Batch);
}
