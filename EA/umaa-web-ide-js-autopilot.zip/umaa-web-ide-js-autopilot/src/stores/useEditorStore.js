import { create } from 'zustand';
import { repository } from '../repository/mockRepository.js';
import { parseWorkspaceImport } from '../model/validateImport.js';
import { canConnect } from '../logic/validation.js';
import { ensureComponentPositions, layoutComponentPositions } from '../logic/layout.js';
import { uuid } from '../model/types.js';
const projectId = 'demo-usv';
const update = (set, transform) => {
    set(s => s.snapshot ? { snapshot: transform(s.snapshot), dirty: true } : {});
};
const makeField = (name, type, key = false) => ({ name, type, key, optional: false });
// Topology/port changes change the Dagre node sizes and ranks. Relayout together.
const updateTopology = (set, transform) => {
    set(s => {
        if (!s.snapshot)
            return {};
        const changed = transform(s.snapshot);
        return {
            snapshot: { ...changed, positions: layoutComponentPositions(changed) },
            dirty: true,
            layoutRevision: s.layoutRevision + 1,
        };
    });
};
export const useEditorStore = create((set, get) => ({
    snapshot: null,
    selection: null,
    loading: false,
    saving: false,
    dirty: false,
    layoutRevision: 0,
    autoLayout() {
        const snapshot = get().snapshot;
        if (!snapshot)
            return;
        set(s => ({
            snapshot: { ...snapshot, positions: layoutComponentPositions(snapshot) },
            layoutRevision: s.layoutRevision + 1,
            dirty: true,
        }));
    },
    async load() {
        set({ loading: true });
        try {
            const snapshot = ensureComponentPositions(await repository.load(projectId));
            set(s => ({ snapshot, dirty: false, selection: { kind: 'component', id: 'autopilot' }, layoutRevision: s.layoutRevision + 1 }));
        }
        finally {
            set({ loading: false });
        }
    },
    async save() {
        const snapshot = get().snapshot;
        if (!snapshot)
            return;
        set({ saving: true });
        try {
            await repository.save(projectId, snapshot);
            set({ dirty: false });
        }
        finally {
            set({ saving: false });
        }
    },
    async reset() {
        set({ loading: true });
        try {
            const snapshot = ensureComponentPositions(await repository.reset(projectId));
            set(s => ({ snapshot, dirty: false, selection: { kind: 'component', id: 'autopilot' }, layoutRevision: s.layoutRevision + 1 }));
        }
        finally {
            set({ loading: false });
        }
    },
    importSnapshot(value) {
        const snapshot = parseWorkspaceImport(value);
        set(s => ({ snapshot: ensureComponentPositions(structuredClone(snapshot)), dirty: true, selection: { kind: 'component', id: 'autopilot' }, layoutRevision: s.layoutRevision + 1 }));
    },
    select(selection) { set({ selection }); },
    addComponent(name) {
        const trimmed = name.trim();
        if (!trimmed)
            return;
        const component = { id: uuid(), name: trimmed, description: '' };
        updateTopology(set, s => ({ ...s, components: [...s.components, component] }));
        set({ selection: { kind: 'component', id: component.id } });
    },
    addBinding(componentId, serviceId, role) {
        const s = get().snapshot;
        if (!s || !s.components.some(c => c.id === componentId) || !s.services.some(v => v.id === serviceId))
            return false;
        if (s.bindings.some(b => b.componentId === componentId && b.serviceId === serviceId && b.role === role))
            return false;
        const binding = { id: uuid(), componentId, serviceId, role };
        updateTopology(set, old => ({ ...old, bindings: [...old.bindings, binding] }));
        set({ selection: { kind: 'binding', id: binding.id } });
        return true;
    },
    removeBinding(bindingId) {
        updateTopology(set, s => ({
            ...s,
            bindings: s.bindings.filter(b => b.id !== bindingId),
            connections: s.connections.filter(c => c.providerBindingId !== bindingId && c.consumerBindingId !== bindingId),
        }));
        set({ selection: null });
    },
    addCustomService(name, flow) {
        const s = get().snapshot;
        const trimmed = name.trim();
        if (!s || !/^[A-Za-z][A-Za-z0-9_]*$/.test(trimmed) || s.services.some(x => x.name.toLowerCase() === trimmed.toLowerCase()))
            return false;
        const sid = uuid();
        const namespace = `ProjectCustom::${trimmed}`;
        const svc = { id: sid, name: trimmed, namespace, functionalArea: 'CUSTOM', source: 'custom', version: '1.0', flowControl: flow, description: '사용자 정의 서비스 (UMAA 표준 서비스 아님)' };
        const messages = [];
        const topics = [];
        const operations = [];
        const make = (suffix, fields) => {
            const typeId = uuid();
            const topicId = uuid();
            const typeName = `${trimmed}${suffix}Type`;
            messages.push({ id: typeId, name: typeName, namespace, source: 'custom', fields });
            topics.push({ id: topicId, name: typeName, messageTypeId: typeId });
            return topicId;
        };
        if (flow === 'request-reply') {
            const t = make('Report', [makeField('entityId', 'string', true), makeField('value', 'double')]);
            operations.push({ id: uuid(), serviceId: sid, name: 'report' + trimmed, topicId: t, action: 'publish', actor: 'provider' });
            operations.push({ id: uuid(), serviceId: sid, name: 'query' + trimmed, topicId: t, action: 'subscribe', actor: 'consumer' });
        }
        else {
            const tCommand = make('Command', [makeField('sessionId', 'string', true), makeField('destinationId', 'string'), makeField('targetValue', 'double')]);
            const tStatus = make('CommandStatus', [makeField('sessionId', 'string', true), makeField('status', 'string')]);
            operations.push({ id: uuid(), serviceId: sid, name: 'set' + trimmed, topicId: tCommand, action: 'publish', actor: 'consumer' });
            operations.push({ id: uuid(), serviceId: sid, name: 'report' + trimmed + 'CommandStatus', topicId: tStatus, action: 'publish', actor: 'provider' });
            operations.push({ id: uuid(), serviceId: sid, name: 'cancel' + trimmed, topicId: tCommand, action: 'dispose', actor: 'consumer' });
        }
        update(set, old => ({ ...old, services: [...old.services, svc],
            interfaces: [...old.interfaces, { id: uuid(), serviceId: sid, name: `${trimmed} · Operation Interface`,
                    description: 'Custom Service의 Operation 그룹', operationIds: operations.map(o => o.id) }],
            topics: [...old.topics, ...topics], messages: [...old.messages, ...messages], operations: [...old.operations, ...operations] }));
        set({ selection: { kind: 'service', id: sid } });
        return true;
    },
    addMessageField(messageId, name, type) {
        const s = get().snapshot;
        const msg = s?.messages.find(m => m.id === messageId);
        if (!msg || msg.source !== 'custom' || !/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name) || msg.fields.some(f => f.name === name))
            return false;
        update(set, old => ({ ...old, messages: old.messages.map(m => m.id === messageId ? { ...m, fields: [...m.fields, makeField(name, type)] } : m) }));
        return true;
    },
    removeMessageField(messageId, name) {
        update(set, s => ({ ...s, messages: s.messages.map(m => m.id === messageId && m.source === 'custom' ? { ...m, fields: m.fields.filter(f => f.name !== name) } : m) }));
    },
    connect(providerBindingId, consumerBindingId) {
        const s = get().snapshot;
        if (!s || !canConnect(s, providerBindingId, consumerBindingId))
            return false;
        updateTopology(set, old => ({ ...old, connections: [...old.connections, { id: uuid(), providerBindingId, consumerBindingId }] }));
        return true;
    },
    removeConnection(id) {
        updateTopology(set, s => ({ ...s, connections: s.connections.filter(c => c.id !== id) }));
        set({ selection: null });
    },
    moveComponent(componentId, position) {
        update(set, s => ({ ...s, positions: { ...s.positions, [componentId]: position } }));
    },
    changePlatform(platform) { update(set, s => ({ ...s, project: { ...s.project, targetPlatform: platform } })); },
    changeVendor(vendor) { update(set, s => ({ ...s, project: { ...s.project, ddsVendor: vendor } })); },
}));
