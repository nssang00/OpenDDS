import { useMemo, useCallback, useEffect, useRef } from 'react';
import { ReactFlow, Background, Controls, MiniMap, MarkerType } from '@xyflow/react';
import { message } from 'antd';
import { canConnect } from '../logic/validation.js';
import { useEditorStore } from '../stores/useEditorStore.js';
import { ComponentNode } from './ComponentNode.jsx';
import '@xyflow/react/dist/style.css';
const nodeTypes = { component: ComponentNode };
export function Diagram() {
    const snapshot = useEditorStore(s => s.snapshot);
    const selection = useEditorStore(s => s.selection);
    const layoutRevision = useEditorStore(s => s.layoutRevision);
    const flowRef = useRef(null);
    const select = useEditorStore(s => s.select);
    const moveComponent = useEditorStore(s => s.moveComponent);
    const connect = useEditorStore(s => s.connect);
    const removeConnection = useEditorStore(s => s.removeConnection);
    const nodes = useMemo(() => !snapshot ? [] : snapshot.components.map((component, i) => ({
        id: component.id,
        type: 'component',
        position: snapshot.positions[component.id] ?? { x: i * 320, y: 120 },
        selected: selection?.kind === 'component' && selection.id === component.id,
        data: {
            title: component.name,
            description: component.description,
            ports: snapshot.bindings.filter(b => b.componentId === component.id).map(b => ({
                id: b.id, role: b.role,
                name: snapshot.services.find(s => s.id === b.serviceId)?.name ?? 'Unknown',
                origin: snapshot.services.find(s => s.id === b.serviceId)?.source ?? 'custom',
            })),
        },
    })), [snapshot, selection]);
    const edges = useMemo(() => !snapshot ? [] : snapshot.connections.flatMap(c => {
        const from = snapshot.bindings.find(b => b.id === c.providerBindingId);
        const to = snapshot.bindings.find(b => b.id === c.consumerBindingId);
        if (!from || !to)
            return [];
        const service = snapshot.services.find(s => s.id === from.serviceId);
        return [{
                id: c.id, source: from.componentId, target: to.componentId,
                sourceHandle: from.id, targetHandle: to.id, type: 'smoothstep',
                label: service?.name ?? 'Unknown',
                markerEnd: { type: MarkerType.ArrowClosed, color: '#4384d3' },
                style: { stroke: '#4384d3', strokeWidth: 2 },
                labelStyle: { fontSize: 11, fill: '#466487', fontWeight: 600 },
                selected: selection?.kind === 'connection' && selection.id === c.id,
            }];
    }), [snapshot, selection]);
    const onNodesChange = useCallback((changes) => {
        // Controlled React Flow nodes must receive updates throughout the drag.
        for (const change of changes) {
            if (change.type === 'position' && change.position) {
                moveComponent(change.id, change.position);
            }
        }
    }, [moveComponent]);
    useEffect(() => {
        // The layout button updates stored node coordinates; fit the new graph in the canvas.
        const frame = requestAnimationFrame(() => {
            void flowRef.current?.fitView({ padding: 0.18, duration: 300 });
        });
        return () => cancelAnimationFrame(frame);
    }, [layoutRevision]);
    const onEdgesChange = useCallback((changes) => {
        for (const change of changes)
            if (change.type === 'remove')
                removeConnection(change.id);
    }, [removeConnection]);
    const isValidConnection = useCallback((c) => Boolean(snapshot && c.sourceHandle && c.targetHandle && canConnect(snapshot, c.sourceHandle, c.targetHandle)), [snapshot]);
    const onConnect = useCallback((c) => {
        if (!c.sourceHandle || !c.targetHandle || !connect(c.sourceHandle, c.targetHandle)) {
            message.warning('같은 Service의 Provider 포트에서 Consumer 포트로만 연결할 수 있습니다.');
        }
        else
            message.success('Service Connection을 추가했습니다.');
    }, [connect]);
    return <div className="diagram">
    <ReactFlow nodes={nodes} edges={edges} nodeTypes={nodeTypes} onInit={instance => { flowRef.current = instance; }} onNodesChange={onNodesChange} onEdgesChange={onEdgesChange} onConnect={onConnect} isValidConnection={isValidConnection} onNodeClick={(_, node) => select({ kind: 'component', id: node.id })} onEdgeClick={(_, edge) => select({ kind: 'connection', id: edge.id })} onPaneClick={() => select(null)} deleteKeyCode={['Backspace', 'Delete']} connectionLineStyle={{ stroke: '#4384d3', strokeWidth: 2 }} fitView fitViewOptions={{ padding: 0.18 }} minZoom={0.3} maxZoom={1.8}>
      <Background color="#dce8f2" gap={20} size={1}/>
      <Controls showInteractive={false}/>
      <MiniMap pannable zoomable style={{ background: '#f3f6fa' }} nodeStrokeWidth={2}/>
    </ReactFlow>
  </div>;
}
