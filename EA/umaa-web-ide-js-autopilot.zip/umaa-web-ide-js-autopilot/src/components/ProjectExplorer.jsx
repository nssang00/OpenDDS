import { Empty, Tree, Typography, Tag, Tooltip } from 'antd';
import { ApartmentOutlined, ApiOutlined, FolderOpenOutlined, LinkOutlined, FileTextOutlined, DeploymentUnitOutlined } from '@ant-design/icons';
import { useMemo } from 'react';
import { useEditorStore } from '../stores/useEditorStore.js';
export function ProjectExplorer() {
    const snapshot = useEditorStore(s => s.snapshot);
    const select = useEditorStore(s => s.select);
    const selected = useEditorStore(s => s.selection);
    const tree = useMemo(() => !snapshot ? [] : [{
            key: 'project', title: <b>{snapshot.project.name}</b>, icon: <FolderOpenOutlined />,
            children: [
                { key: 'functional-areas-folder', title: `Functional Areas (${snapshot.functionalAreas.length})`, icon: <FolderOpenOutlined />,
                    children: snapshot.functionalAreas.map(fa => ({
                        key: `functionalArea:${fa.id}`, title: <span>{fa.id} · {fa.name} <Tag style={{ marginLeft: 4 }}>{snapshot.services.filter(s => s.functionalArea === fa.id).length}</Tag></span>, icon: <DeploymentUnitOutlined />,
                        children: snapshot.services.filter(s => s.functionalArea === fa.id).map(service => ({
                            key: `service:${service.id}`, title: service.name, icon: <ApiOutlined />,
                            children: snapshot.interfaces.filter(i => i.serviceId === service.id).map(iface => ({
                                key: `interface:${iface.id}`, title: <Tooltip title="도구 내 Operation 그룹. 별도 공식 Interface 명칭이 아닙니다.">{iface.name}</Tooltip>, icon: <LinkOutlined />,
                                children: iface.operationIds.map(opId => snapshot.operations.find(o => o.id === opId)).filter(op => op !== undefined).map(op => {
                                    const topic = snapshot.topics.find(t => t.id === op.topicId);
                                    const msg = snapshot.messages.find(m => m.id === topic?.messageTypeId);
                                    return {
                                        key: `operation:${op.id}`, title: `${op.name} (${op.action})`, icon: <FileTextOutlined />,
                                        children: topic ? [{ key: `topic:${topic.id}`, title: `Topic: ${topic.name}`, icon: <ApiOutlined />,
                                                children: msg ? [{ key: `message:${msg.id}`, title: `IDL: ${msg.name}`, icon: <FileTextOutlined /> }] : [] }] : [],
                                    };
                                }),
                            })),
                        })),
                    })) },
                { key: 'components-folder', title: `Components (${snapshot.components.length})`, icon: <ApartmentOutlined />,
                    children: snapshot.components.map(c => ({
                        key: `component:${c.id}`, title: c.name, icon: <ApartmentOutlined />,
                        children: snapshot.bindings.filter(b => b.componentId === c.id).map(b => ({
                            key: `binding:${b.id}`, icon: <ApiOutlined />,
                            title: <span>{snapshot.services.find(s => s.id === b.serviceId)?.name ?? 'Unknown'} <Tag color={b.role === 'provider' ? 'blue' : 'orange'} style={{ margin: 0 }}>{b.role === 'provider' ? 'P' : 'C'}</Tag></span>,
                        })),
                    })) },
                { key: 'connections-folder', title: `Connections (${snapshot.connections.length})`, icon: <LinkOutlined />,
                    children: snapshot.connections.map(c => ({
                        key: `connection:${c.id}`, title: snapshot.services.find(v => v.id === snapshot.bindings.find(b => b.id === c.providerBindingId)?.serviceId)?.name ?? 'Service', icon: <LinkOutlined />,
                    })) },
            ],
        }], [snapshot]);
    if (!snapshot)
        return <Empty description="프로젝트 로딩 중"/>;
    const key = selected ? `${selected.kind}:${selected.id}` : '';
    return <div className="sidebar-section">
    <Typography.Text type="secondary" className="side-label">PROJECT + ICD EXPLORER</Typography.Text>
    <Tree showIcon showLine defaultExpandedKeys={['project', 'functional-areas-folder', 'components-folder', 'functionalArea:SA', 'functionalArea:MO']} blockNode treeData={tree} selectedKeys={key ? [key] : []} onSelect={keys => {
            const raw = String(keys[0] ?? '');
            const idx = raw.indexOf(':');
            if (idx < 0)
                return;
            const kind = raw.slice(0, idx);
            if (['functionalArea', 'component', 'service', 'interface', 'operation', 'topic', 'message', 'binding', 'connection'].includes(kind)) {
                select({ kind: kind, id: raw.slice(idx + 1) });
            }
        }}/>
  </div>;
}
