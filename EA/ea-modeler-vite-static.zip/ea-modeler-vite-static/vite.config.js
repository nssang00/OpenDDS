import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // dist/index.html을 file:// 또는 임의의 정적 경로에서 열 수 있게 상대 경로로 빌드합니다.
  base: './',
  build: {
    outDir: 'dist',
    assetsDir: '',
    cssCodeSplit: false,
    chunkSizeWarningLimit: 1500,
    rollupOptions: {
      output: {
        // webpack 시절처럼 파일명을 예측하기 쉽게 고정합니다.
        entryFileNames: 'app.js',
        chunkFileNames: 'chunk-[name].js',
        assetFileNames: 'app.[ext]',
        manualChunks: () => 'app',
      },
    },
  },
});
