# EA Modeler JS - Vite Static Build Version

Sparx EA/QEA 연동 전에 웹 기술스택의 연결 흐름을 익히기 위한 JavaScript 기반 MVP입니다.

이 버전은 **Vite 개발 프로젝트**이면서, `npm run build` 후 webpack처럼 정적 산출물로 배포할 수 있게 설정되어 있습니다.

## 포함된 기술

- React + Vite
- JavaScript, TypeScript 없음
- Ant Design Layout / Tree / Form / Table / TextArea
- Zustand 상태 관리
- React Flow diagram
- Mock model data

## 개발 서버 실행

```bash
npm install
npm run dev
```

## 정적 빌드 생성

```bash
npm run build
```

빌드 결과는 `dist/`에 생성됩니다.

```text
dist/
 ├─ index.html
 ├─ app.js
 ├─ app.css
 └─ chunk-rolldown-runtime.js
```

`vite.config.js`에서 다음 설정을 넣어 정적 배포에 적합하게 만들었습니다.

```js
base: './'
cssCodeSplit: false
entryFileNames: 'app.js'
assetFileNames: 'app.[ext]'
manualChunks: () => 'app'
```

## 빌드된 결과 바로 확인

이 ZIP에는 이미 빌드된 `dist/` 폴더가 포함되어 있습니다.

압축을 푼 뒤 아래 파일을 브라우저로 열어보세요.

```text
dist/index.html
```

대부분의 경우 Chrome/Edge에서 더블클릭으로 확인할 수 있습니다.

만약 브라우저 보안 정책이나 로컬 경로 문제로 열리지 않으면, 정적 서버로 확인하세요.

```bash
npx serve dist
```

또는 Python이 있으면:

```bash
cd dist
python -m http.server 8080
```

## 먼저 볼 파일

```text
vite.config.js                          정적 빌드 설정
src/model/mockModel.js                  샘플 모델 데이터
src/store/modelStore.js                 Zustand 상태 저장소
src/app/AppShell.jsx                    전체 3분할 화면
src/features/explorer/ModelTree.jsx     Tree
src/features/diagram/ModelDiagram.jsx   React Flow diagram
src/features/properties/PropertyPanel.jsx 속성 패널
src/features/members/MemberTable.jsx    구조체 멤버 테이블
src/features/text-editor/TextEditor.jsx IDL/QoS TextArea
```

## 핵심 흐름

```text
ModelTree 클릭
  -> selectedElementId 변경
  -> PropertyPanel 내용 변경
  -> Diagram 선택 표시 변경

Diagram Node 클릭
  -> selectedElementId 변경
  -> Tree 선택 변경
  -> PropertyPanel 내용 변경

PropertyPanel 수정
  -> elementsById 변경
  -> Tree 이름/Diagram 이름 함께 변경
  -> dirty 상태 modified로 변경
```

## 다음 단계 추천

1. mockModel.js에 Topic, Struct, Participant를 더 추가해보기
2. PropertyPanel.jsx에 QoS 항목을 더 추가해보기
3. MemberTable.jsx에서 타입을 Input 대신 Select로 바꿔보기
4. TextEditor.jsx를 나중에 CodeMirror로 교체해보기
5. QEA SQLite read-only importer를 별도 파일로 추가하기


## 참고

현재 Vite 최신 버전은 아주 작은 런타임 청크(`chunk-rolldown-runtime.js`)를 함께 만들 수 있습니다. 실제 앱 코드는 `app.js`에 묶여 있고, `index.html`은 상대 경로로 이 파일들을 참조합니다. 따라서 `dist/` 폴더 전체를 같이 배포하면 됩니다.
