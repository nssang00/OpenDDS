
using Idl.Model;

namespace Ea.Automation;

/// <summary>
/// Generates the Enterprise Architect model directly through the EA Automation object model.
/// The repository argument is expected to be an EA.Repository instance in production.
/// Dynamic dispatch is intentionally confined to this EA Automation boundary so Core does not require Interop.EA.dll.
/// </summary>
public sealed class EaModelGenerator
{
    private readonly EaTypeMapper _typeMapper;
    private readonly EaMappingPolicy _mappingPolicy;
    private readonly Dictionary<string, object> _elements = new(StringComparer.Ordinal);
    private readonly Dictionary<string, object> _packages = new(StringComparer.Ordinal);

    public EaModelGenerator(EaTypeMapper? typeMapper = null, EaMappingPolicy? mappingPolicy = null)
    {
        if (typeMapper is not null && mappingPolicy is not null)
            throw new ArgumentException("Specify either typeMapper or mappingPolicy, not both.");

        _typeMapper = typeMapper ?? new EaTypeMapper(mappingPolicy);
        _mappingPolicy = _typeMapper.Policy;
    }

    public IReadOnlyDictionary<string, object> Elements => _elements;

    public void Generate(IdlModule model, dynamic repository, string rootPackageName = "IDL Modules", Action<int, int>? progress = null)
    {
        ArgumentNullException.ThrowIfNull(model);
        ArgumentNullException.ThrowIfNull(repository);

        _elements.Clear();
        _packages.Clear();

        dynamic root = AddRootPackage(repository, rootPackageName);
        _packages["::"] = root;

        // Pass 1: create the package/type skeleton.
        var declarations = model.IsSynthetic
            ? model.Declarations
            : new IdlDeclaration[] { model };
        var semanticCount = CountSemanticDeclarations(declarations);
        var sourceCount = _mappingPolicy.CreateSourceArtifacts ? model.SourcePaths.Count() : 0;
        var totalWork = semanticCount * 3 + sourceCount;
        var completedWork = 0;
        Action reportProgress = () => progress?.Invoke(++completedWork, totalWork);

        CreateDeclarations((object)root, declarations, Array.Empty<string>(), null, reportProgress);

        // Pass 2: populate details after all target ElementIDs exist.
        PopulateDeclarations(declarations, Array.Empty<string>(), reportProgress);

        // Pass 3: create relationships after all referenced elements exist.
        CreateRelationships(declarations, Array.Empty<string>(), reportProgress);

        if (_mappingPolicy.CreateSourceArtifacts)
            CreateSourceTree(model.SourcePaths, (object)repository, reportProgress);
    }

    private void CreateDeclarations(dynamic package, IEnumerable<IdlDeclaration> declarations, IReadOnlyList<string> scope, string? inheritedSourcePath, Action progress)
    {
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
            {
                var moduleScope = scope.Append(module.Name).ToArray();
                var packageKey = "::" + string.Join("::", moduleScope);
                if (!_packages.TryGetValue(packageKey, out var cached))
                {
                    dynamic child = AddPackage(package, module.Name);
                    cached = child;
                    _packages[packageKey] = cached;
                }

                CreateDeclarations((dynamic)cached, module.Declarations, moduleScope, module.SourcePath ?? inheritedSourcePath, progress);
                continue;
            }

            var mapping = _typeMapper.MapDeclaration(declaration);
            dynamic element = AddElement(package, declaration.Name, mapping.ElementType, mapping.Stereotype);
            ApplyAnnotations(element, declaration.Annotations);
            AddElementTag(element, "idl.sourcePath", declaration.SourcePath ?? inheritedSourcePath ?? string.Empty);
            if (_mappingPolicy.WriteScopedNameTag)
                AddElementTag(element, "idl.scopedName", Scoped(scope, declaration.Name));
            _elements[Scoped(scope, declaration.Name)] = element;
            progress();
        }
    }

    private void PopulateDeclarations(IEnumerable<IdlDeclaration> declarations, IReadOnlyList<string> scope, Action progress)
    {
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
            {
                PopulateDeclarations(module.Declarations, [.. scope, module.Name], progress);
                continue;
            }

            if (!_elements.TryGetValue(Scoped(scope, declaration.Name), out var cached))
                continue;

            dynamic element = cached;
            switch (declaration)
            {
                case IdlStruct s:
                    foreach (var field in s.Fields) AddField(element, field);
                    break;
                case IdlEnum e:
                    foreach (var value in e.Values) AddAttribute(element, value, string.Empty, "enum");
                    break;
                case IdlUnion u:
                    PopulateUnion(element, u);
                    break;
                case IdlTypedef t:
                    PopulateTypedef(element, t);
                    break;
                case IdlConstant c:
                    PopulateConstant(element, c);
                    break;
            }
            progress();
        }
    }


    private void CreateRelationships(IEnumerable<IdlDeclaration> declarations, IReadOnlyList<string> scope, Action progress)
    {
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
            {
                CreateRelationships(module.Declarations, [.. scope, module.Name], progress);
                continue;
            }

            if (_elements.TryGetValue(Scoped(scope, declaration.Name), out var cached))
            {
                dynamic element = cached;
                switch (declaration)
                {
                    case IdlStruct s when s.BaseType is not null:
                        AddGeneralization(element, s.BaseType, $"struct {s.Name}");
                        break;
                    case IdlInterface i:
                        foreach (var baseInterface in i.BaseInterfaces)
                            AddGeneralization(element, baseInterface, $"interface {i.Name}");
                        break;
                }
            }

            progress();
        }
    }

    private void AddGeneralization(dynamic child, IdlTypeReference baseType, string description)
    {
        if (baseType.ResolvedScopedName is not { } resolved)
            return;
        if (!_elements.TryGetValue(resolved, out var cachedParent))
            return;

        dynamic parent = cachedParent;
        dynamic connector = child.Connectors.AddNew(string.Empty, "Generalization");
        connector.SupplierID = (int)parent.ElementID;
        EnsureUpdated(connector, $"generalization for {description}");
    }

    private static void CreateSourceTree(IEnumerable<string> sourcePaths, dynamic repository, Action progress)
    {
        dynamic root = AddRootPackage(repository, "IDL Sources");
        var packages = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase) { [string.Empty] = root };

        foreach (var sourcePath in sourcePaths.OrderBy(x => x, StringComparer.OrdinalIgnoreCase))
        {
            var normalized = sourcePath.Replace('\\', '/').Trim('/');
            var parts = normalized.Split('/', StringSplitOptions.RemoveEmptyEntries);
            dynamic current = root;
            var currentPath = string.Empty;

            foreach (var folder in parts.Take(Math.Max(0, parts.Length - 1)))
            {
                currentPath = currentPath.Length == 0 ? folder : currentPath + "/" + folder;
                if (!packages.TryGetValue(currentPath, out var cached))
                {
                    dynamic next = AddPackage(current, folder);
                    cached = next;
                    packages[currentPath] = cached;
                }
                current = (dynamic)cached;
            }

            var fileName = parts.Length == 0 ? sourcePath : parts[^1];
            dynamic artifact = AddElement(current, fileName, "Artifact", "IDLFile");
            AddElementTag(artifact, "idl.sourcePath", sourcePath);
            progress();
        }
    }


    private static int CountSemanticDeclarations(IEnumerable<IdlDeclaration> declarations)
    {
        var count = 0;
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
                count += CountSemanticDeclarations(module.Declarations);
            else
                count++;
        }
        return count;
    }

    private void PopulateUnion(dynamic element, IdlUnion union)
    {
        AddTypeMetadata(element, union.DiscriminatorType, "idl.discriminator");
        AddElementTag(element, "idl.discriminatorType", _typeMapper.MapAttributeType(union.DiscriminatorType));
        var index = 0;
        foreach (var unionCase in union.Cases)
        {
            dynamic attribute = AddField(element, unionCase.Field);
            AddAttributeTag(attribute, "idl.union.caseIndex", index++.ToString());
            AddAttributeTag(attribute, "idl.union.labels", string.Join(",", unionCase.Labels));
            if (unionCase.IsDefault) AddAttributeTag(attribute, "idl.union.default", "true");
        }
    }

    private void PopulateTypedef(dynamic element, IdlTypedef typedef)
    {
        AddTypeMetadata(element, typedef.UnderlyingType, "idl.underlying");
        AddElementTag(element, "idl.underlyingType", _typeMapper.MapAttributeType(typedef.UnderlyingType));
        if (typedef.ArrayDimensions.Count > 0)
            AddElementTag(element, _mappingPolicy.ArrayDimensionsTag, string.Join(",", typedef.ArrayDimensions));
    }

    private void PopulateConstant(dynamic element, IdlConstant constant)
    {
        AddTypeMetadata(element, constant.Type, "idl.type");
        AddElementTag(element, "idl.type", _typeMapper.MapAttributeType(constant.Type));
        AddElementTag(element, "idl.value", constant.ValueExpression);
    }

    private void AddTypeMetadata(dynamic element, IdlTypeReference type, string prefix)
    {
        AddElementTag(element, $"{prefix}.kind", _typeMapper.MapTypeKind(type));
        if (type.BoundExpression is not null)
            AddElementTag(element, $"{prefix}.bound", type.BoundExpression);
        if (type.ElementType is not null)
            AddElementTag(element, $"{prefix}.elementType", _typeMapper.MapAttributeType(type.ElementType));
        if (type.KeyType is not null)
            AddElementTag(element, $"{prefix}.keyType", _typeMapper.MapAttributeType(type.KeyType));
        if (type.ResolvedScopedName is not null)
            AddElementTag(element, $"{prefix}.resolved", type.ResolvedScopedName);
    }

    private dynamic AddField(dynamic owner, IdlField field)
    {
        dynamic attribute = AddAttribute(owner, field.Name, _typeMapper.MapAttributeType(field.Type));
        if (field.Type.Kind == IdlTypeKind.Named && field.Type.ResolvedScopedName is { } resolved && _elements.TryGetValue(resolved, out var target))
        {
            dynamic targetElement = target;
            attribute.ClassifierID = (int)targetElement.ElementID;
            EnsureUpdated(attribute, $"attribute {field.Name}");
        }

        if (field.Dimensions.Count > 0)
            AddAttributeTag(attribute, _mappingPolicy.ArrayDimensionsTag, string.Join(",", field.Dimensions));
        if (field.Type.BoundExpression is not null)
            AddAttributeTag(attribute, _mappingPolicy.BoundTag, field.Type.BoundExpression);

        foreach (var annotation in field.Annotations)
        {
            var value = annotation.Arguments ?? "true";
            if (!ApplyCanonicalAnnotation(attribute, annotation.Name, value))
                AddAttributeTag(attribute, $"idl.annotation.{annotation.Name}", value);
        }

        return attribute;
    }

    private static void ApplyAnnotations(dynamic element, IEnumerable<IdlAnnotation> annotations)
    {
        foreach (var annotation in annotations)
        {
            var value = annotation.Arguments ?? "true";
            if (!ApplyCanonicalAnnotation(element, annotation.Name, value, isAttribute: false))
                AddElementTag(element, $"idl.annotation.{annotation.Name}", value);
        }
    }

    private static bool ApplyCanonicalAnnotation(dynamic owner, string name, string value, bool isAttribute = true)
    {
        string? tag = name.ToLowerInvariant() switch
        {
            "key" => "idl.key",
            "optional" => "idl.optional",
            "nested" => "idl.nested",
            _ => null
        };

        if (tag is null) return false;
        if (isAttribute) AddAttributeTag(owner, tag, value);
        else AddElementTag(owner, tag, value);
        return true;
    }

    private static dynamic AddRootPackage(dynamic repository, string name)
    {
        dynamic models = repository.Models;
        dynamic package = models.AddNew(name, "");
        EnsureUpdated(package, $"root package {name}");
        return package;
    }

    private static dynamic AddPackage(dynamic parent, string name)
    {
        dynamic packages = parent.Packages;
        dynamic package = packages.AddNew(name, "");
        EnsureUpdated(package, $"package {name}");
        return package;
    }

    private static dynamic AddElement(dynamic package, string name, string type, string? stereotype = null)
    {
        dynamic elements = package.Elements;
        dynamic element = elements.AddNew(name, type);
        if (!string.IsNullOrWhiteSpace(stereotype)) element.Stereotype = stereotype;
        EnsureUpdated(element, $"element {name}");
        return element;
    }

    private static dynamic AddAttribute(dynamic element, string name, string typeName, string? stereotype = null)
    {
        dynamic attributes = element.Attributes;
        dynamic attribute = attributes.AddNew(name, typeName);
        if (!string.IsNullOrWhiteSpace(stereotype)) attribute.Stereotype = stereotype;
        EnsureUpdated(attribute, $"attribute {name}");
        return attribute;
    }

    private static void AddElementTag(dynamic element, string name, string value)
    {
        dynamic tag = element.TaggedValues.AddNew(name, "string");
        tag.Value = value;
        EnsureUpdated(tag, $"tag {name}");
    }

    private static void AddAttributeTag(dynamic attribute, string name, string value)
    {
        dynamic tag = attribute.TaggedValues.AddNew(name, "string");
        tag.Value = value;
        EnsureUpdated(tag, $"attribute tag {name}");
    }

    private static void EnsureUpdated(dynamic item, string description)
    {
        if ((bool)item.Update()) return;
        string error;
        try { error = (string)item.GetLastError(); }
        catch { error = "Unknown EA Automation error."; }
        throw new InvalidOperationException($"Failed to update EA {description}: {error}");
    }

    private static string Scoped(IReadOnlyList<string> scope, string name) => "::" + string.Join("::", scope.Append(name));
}
