import { build } from 'esbuild';
import { spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const temp = mkdtempSync(join(tmpdir(), 'umaa-layout-'));
const entry = join(temp, 'test.cjs');
try {
  await build({ absWorkingDir: root, entryPoints: ['tests/layout.test.ts'], outfile: entry,
    bundle: true, platform: 'node', format: 'cjs', target: 'node20', logLevel: 'warning' });
  const run = spawnSync(process.execPath, [entry], { stdio: 'inherit' });
  if (run.error) throw run.error;
  if (run.status !== 0) process.exitCode = run.status || 1;
} finally {
  rmSync(temp, { recursive: true, force: true });
}
