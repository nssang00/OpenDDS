import type { WorkspaceSnapshot } from './types';

// Service, Operation and Topic names below reflect UMAA 6.0 ICD examples.
// The Standard IDL files are external references, not reconstructed approximations.
export const seedWorkspace: WorkspaceSnapshot = {
  project: {
    id: 'demo-usv', name: 'Demo USV Autonomy', standardVersion: 'UMAA 6.0',
    targetPlatform: 'linux', ddsVendor: 'fastdds',
  },
  components: [
    { id: 'nav', name: 'USV Navigation', description: '위치 및 자세 정보를 제공' },
    { id: 'autopilot', name: 'Autopilot', description: '기동 제어 수행' },
    { id: 'mission', name: 'Mission Executor', description: '임무 명령 생성 및 서비스 사용' },
  ],
  services: [
    { id: 'svc-pose', name: 'GlobalPoseStatus', functionalArea: 'SA', namespace: 'UMAA::SA::GlobalPoseStatus', source: 'standard', version: '6.0', flowControl: 'request-reply', description: '현재 전역 위치·자세 보고. Query는 Topic 구독으로 처리.' },
    { id: 'svc-vector', name: 'GlobalVectorControl', functionalArea: 'MO', namespace: 'UMAA::MO::GlobalVectorControl', source: 'standard', version: '6.0', flowControl: 'command-response', description: '속력·이동방향 등을 명령하고 실행 상태를 추적.' },
  ],
  messages: [
    { id: 'type-pose', name: 'GlobalPoseReportType', namespace: 'UMAA::SA::GlobalPoseStatus', source: 'standard', fields: [], externalIdlPath: 'UMAA/SA/GlobalPoseStatus (official release IDL)' },
    { id: 'type-command', name: 'GlobalVectorCommandType', namespace: 'UMAA::MO::GlobalVectorControl', source: 'standard', fields: [], externalIdlPath: 'UMAA/MO/GlobalVectorControl (official release IDL)' },
    { id: 'type-status', name: 'GlobalVectorCommandStatusType', namespace: 'UMAA::MO::GlobalVectorControl', source: 'standard', fields: [], externalIdlPath: 'UMAA/MO/GlobalVectorControl (official release IDL)' },
    { id: 'type-ack', name: 'GlobalVectorCommandAckReportType', namespace: 'UMAA::MO::GlobalVectorControl', source: 'standard', fields: [], externalIdlPath: 'UMAA/MO/GlobalVectorControl (official release IDL)' },
    { id: 'type-execution', name: 'GlobalVectorExecutionStatusReportType', namespace: 'UMAA::MO::GlobalVectorControl', source: 'standard', fields: [], externalIdlPath: 'UMAA/MO/GlobalVectorControl (official release IDL)' },
  ],
  topics: [
    { id: 'topic-pose', name: 'GlobalPoseReportType', messageTypeId: 'type-pose' },
    { id: 'topic-command', name: 'GlobalVectorCommandType', messageTypeId: 'type-command' },
    { id: 'topic-status', name: 'GlobalVectorCommandStatusType', messageTypeId: 'type-status' },
    { id: 'topic-ack', name: 'GlobalVectorCommandAckReportType', messageTypeId: 'type-ack' },
    { id: 'topic-execution', name: 'GlobalVectorExecutionStatusReportType', messageTypeId: 'type-execution' },
  ],
  operations: [
    { id: 'op-pose-report', serviceId: 'svc-pose', name: 'reportGlobalPose', topicId: 'topic-pose', action: 'publish', actor: 'provider' },
    { id: 'op-pose-query', serviceId: 'svc-pose', name: 'queryGlobalPose', topicId: 'topic-pose', action: 'subscribe', actor: 'consumer' },
    { id: 'op-vector-set', serviceId: 'svc-vector', name: 'setGlobalVector', topicId: 'topic-command', action: 'publish', actor: 'consumer' },
    { id: 'op-vector-status', serviceId: 'svc-vector', name: 'reportGlobalVectorCommandStatus', topicId: 'topic-status', action: 'publish', actor: 'provider' },
    { id: 'op-vector-ack', serviceId: 'svc-vector', name: 'reportGlobalVectorCommandAck', topicId: 'topic-ack', action: 'publish', actor: 'provider', optionalConsumer: true },
    { id: 'op-vector-execution', serviceId: 'svc-vector', name: 'reportGlobalVectorExecutionStatus', topicId: 'topic-execution', action: 'publish', actor: 'provider', optionalConsumer: true },
    { id: 'op-vector-cancel', serviceId: 'svc-vector', name: 'cancelGlobalVectorCommand', topicId: 'topic-command', action: 'dispose', actor: 'consumer' },
  ],
  bindings: [
    { id: 'bind-nav-pose', componentId: 'nav', serviceId: 'svc-pose', role: 'provider' },
    { id: 'bind-auto-pose', componentId: 'autopilot', serviceId: 'svc-pose', role: 'consumer' },
    { id: 'bind-mission-pose', componentId: 'mission', serviceId: 'svc-pose', role: 'consumer' },
    { id: 'bind-auto-vector', componentId: 'autopilot', serviceId: 'svc-vector', role: 'provider' },
    { id: 'bind-mission-vector', componentId: 'mission', serviceId: 'svc-vector', role: 'consumer' },
  ],
  connections: [
    { id: 'con-pose-auto', providerBindingId: 'bind-nav-pose', consumerBindingId: 'bind-auto-pose' },
    { id: 'con-pose-mission', providerBindingId: 'bind-nav-pose', consumerBindingId: 'bind-mission-pose' },
    { id: 'con-vector', providerBindingId: 'bind-auto-vector', consumerBindingId: 'bind-mission-vector' },
  ],
  // Empty means the first load will compute a left-to-right Dagre layout.
  positions: {},
};
