# Build & verification notes — Dagre update

## Verified in this environment

- `npm run check:static`: **PASS** (12 checks), including React Flow v12 named import, Dagre dependency, LR graph layout and Zustand layout action.
- `npm run check:core`: **PASS** (TypeScript checks for core model, seed, endpoints, validation, code generator).
- TypeScript global `transpileModule` syntax check: **PASS** for Diagram.tsx, layout.ts, useEditorStore.ts, App.tsx and layout.test.ts.
- Source layout review: initial seed has no fixed positions; load computes Dagre layout; component/binding/connection topology changes relayout; button explicitly relayouts; dragging updates Zustand coordinates.

## Not verified here (dependency download unavailable)

- `npm install`: **FAILED** due to `EAI_AGAIN` DNS/network access to registry.npmjs.org.
- `npm run build`, `npm run typecheck`, and `npm run test:layout`: **NOT RUN**, because npm dependencies were unavailable.
- Browser/file:// runtime test: **NOT RUN**.

## Verify on a development PC

```bash
npm install
npm run typecheck
npm run test:layout
npm run build
```

Open the root `index.html` to run without a server (the `dist/` files must exist from build). Click **Dagre 자동 배치** to re-layout the Component graph.

## Key changes

1. `src/components/Diagram.tsx`: `ReactFlow` is a **named** export of `@xyflow/react` v12, not a default export. Refit after layout changes.
2. `src/logic/layout.ts`: Dagre LR layout using actual component port counts to estimate node height.
3. `src/stores/useEditorStore.ts`: `autoLayout` and relayout on graph topology edits.
4. `src/model/seed.ts`: no hard-coded positions in new mock workspace; initial graph uses Dagre.
5. `src/App.tsx`: explicit **Dagre 자동 배치** button.
6. `package.json`: `@dagrejs/dagre` dependency and `test:layout` script.
