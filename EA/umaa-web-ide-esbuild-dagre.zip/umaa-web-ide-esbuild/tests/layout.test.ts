import assert from 'node:assert/strict';
import { seedWorkspace } from '../src/model/seed';
import { componentNodeHeight, COMPONENT_NODE_WIDTH, ensureComponentPositions, layoutComponentPositions } from '../src/logic/layout';

const positions = layoutComponentPositions(seedWorkspace);
assert.deepEqual(Object.keys(positions).sort(), ['autopilot', 'mission', 'nav']);
assert.ok(positions.nav.x < positions.autopilot.x, 'Navigation provider should be before Autopilot consumer');
assert.ok(positions.autopilot.x < positions.mission.x, 'Autopilot provider should be before Mission consumer');

for (let i = 0; i < seedWorkspace.components.length; i++) {
  for (let j = i + 1; j < seedWorkspace.components.length; j++) {
    const a = seedWorkspace.components[i];
    const b = seedWorkspace.components[j];
    const pa = positions[a.id];
    const pb = positions[b.id];
    const overlaps = pa.x < pb.x + COMPONENT_NODE_WIDTH &&
      pa.x + COMPONENT_NODE_WIDTH > pb.x &&
      pa.y < pb.y + componentNodeHeight(seedWorkspace, b.id) &&
      pa.y + componentNodeHeight(seedWorkspace, a.id) > pb.y;
    assert.equal(overlaps, false, `${a.name} and ${b.name} should not overlap`);
  }
}

const manuallyMoved = { x: 12345, y: 123 };
const partial = ensureComponentPositions({
  ...seedWorkspace,
  positions: { nav: manuallyMoved },
});
assert.deepEqual(partial.positions.nav, manuallyMoved, 'Manual positions must survive load');
assert.ok(partial.positions.autopilot, 'Missing component position must be filled');
assert.ok(partial.positions.mission, 'Missing component position must be filled');

const expanded = {
  ...seedWorkspace,
  components: [...seedWorkspace.components, { id: 'extra', name: 'Extra', description: '' }],
};
assert.ok(layoutComponentPositions(expanded).extra, 'Disconnected component must be laid out');
console.log('PASS  Dagre layout: direction, no overlap, positions preservation, disconnected nodes');
