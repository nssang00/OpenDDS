# UMAA Web IDE — esbuild 정적 실행 Mock MVP

[nssang00/ea_react](https://github.com/nssang00/ea_react)의 **정적 esbuild 번들 패턴**을 참고하여 기존 UMAA Web IDE를 수정한 버전입니다.

- React + TypeScript + Ant Design + React Flow v12 (`@xyflow/react`) + Zustand + Dagre (`@dagrejs/dagre`)
- **Vite 제거**, `esbuild`로 프런트엔드 JS/CSS 번들 생성
- **런타임 서버 필요 없음**: 빌드 후 루트 `index.html`을 `file://`로 직접 열거나 정적 호스팅에 복사
- **API 호출이나 PostgreSQL 연결 없음**: 브라우저 Mock Repository 사용
- 기존 **Component/Service/Interface 설계 → 연결 검증 → DDS Endpoint 계산 → Mock Simulation → C++/Custom IDL/CMake ZIP 생성** 흐름 유지
- JSON 파일로 프로젝트 상태 가져오기/내보내기 추가

## 1. 최초 빌드 (Node.js 20+)

```bash
npm install
npm run build
```

빌드되면 파일은 다음처럼 위치합니다.

```text
umaa-web-ide-esbuild/
  index.html          # 직접 열기
  dist/
    main.js           # 모든 React/AntD/React Flow/Zustand 의존성 번들
    main.css          # 앱 및 React Flow CSS 번들
    main.js.map       # 개발 디버깅용 소스맵
    main.css.map      # 개발 디버깅용 소스맵
  src/                # 개발용 소스
  scripts/build.mjs   # esbuild 빌드 스크립트
```

**실행:** Windows에서는 `index.html` 더블클릭, Linux/macOS에서는 파일 열기로 브라우저에서 실행합니다. `npm run build`가 파일을 생성할 때만 Node.js를 사용합니다. 브라우저 실행에는 서버/Node/npm이 필요 없습니다.

> 주의: 이 ZIP에는 `node_modules` 및 `dist`를 포함하지 않았습니다. **최초 빌드 시 `npm install`이 필요**합니다. 독립 실행 가능한 `index.html` 단일 파일은 아닙니다. `index.html`과 `dist/` 디렉터리를 함께 배포해야 합니다.

## 2. 참조 repo와의 대응

| ea_react | 이 프로젝트 |
|---|---|
| `index.html`에서 `./dist/main.js` 참조 | 동일 |
| `./dist/main.css` 링크 | 동일 |
| `esbuild --bundle --format=iife` | `scripts/build.mjs`에서 동일한 IIFE 번들 |
| `npm run build` | 동일 |
| esbuild `watch` | `npm run watch` (서버 생성 없음) |
| esbuild `--serve` 기반 `dev` | **미사용**. 이 프로젝트의 `dev`는 `watch` 별칭 |

`npm run watch`는 소스를 감시하여 `dist/`를 갱신하기만 합니다. HTTP 서버를 시작하지 않습니다. 수정사항 확인을 위해 브라우저에서 파일을 새로고침합니다.

## 3. 실행 시나리오

1. 좌측 Project Explorer에서 Component를 선택해 Service Binding을 추가합니다.
2. Service Catalog에서 표준/Custom Service 및 Operation·Topic 정보를 확인합니다.
3. React Flow 캔버스에서 **Provider → 동일 Service Consumer** 핸들을 연결합니다. Dagre가 좌→우(LR)로 Component를 자동 배치합니다. 노드는 수동 드래그할 수 있으며, 상단 **Dagre 자동 배치** 버튼으로 전체 재정렬합니다.
4. Validation / DDS Endpoint Matrix / Mock Flow Simulation을 확인합니다.
5. 상단 **코드 생성**에서 CMake/C++/Custom IDL/Endpoint Manifest 산출물을 ZIP으로 받습니다.

Mock 프로젝트의 기본 Component는 `USV Navigation`, `Autopilot`, `Mission Executor`입니다. Service는 `GlobalPoseStatus`, `GlobalVectorControl`이 포함됩니다.

## 4. 파일 실행(`file://`)과 저장

브라우저별 보안 정책에 따라 `file://`로 연 HTML 문서의 `localStorage`에 접근하지 못할 수 있습니다. 이 프로젝트는 해당 오류로 앱이 중단되지 않도록 **메모리 저장소로 자동 대체**합니다. 단, 메모리 저장소는 탭을 닫으면 소실됩니다.

따라서 별도 서버가 없는 환경에서도 데이터를 안전하게 보관하려면 상단의 **JSON 내보내기**로 파일에 저장하고, 다시 실행할 때 **JSON 가져오기**로 복원하세요.

`localStorage`가 허용된 브라우저에서는 **저장** 버튼으로 유지되지만 `file://`의 저장 동작은 브라우저마다 달라 영속성이 항상 보장되지는 않습니다. 배포 환경에 따라 프로젝트 간 저장소가 구분될 수도 있습니다.

## 5. 개발/검사 명령어

```bash
npm run watch        # esbuild 파일 감시/재빌드 (서버 미구동)
npm run check:static # 정적 진입점/설정 검사 (패키지 설치 불필요)
npm run typecheck    # 의존성 설치 후 TypeScript 검사
npm run check:core   # 핵심 모델/생성기 TS 검사
npm run test:layout  # Dagre 레이아웃 회귀 테스트 (의존성 설치 필요)
```

## 6. 생성기 동작 범위

- **생성 가능**: CMake 기반 공유 라이브러리 골격, 사용자 정의 Service IDL, DDS Endpoint Intent/Manifest, 개발자 구현 함수 골격.
- **아직 미구현**: 실제 DDS DataWriter/DataReader, 완전한 UMAA Command 상태 머신, 공식 UMAA IDL/벤더 SDK 코드 생성, 실제 DDS 통신, UMAA 적합성 인증.
- **표준 IDL**: 모델에서 임의 재구성하지 않고 외부 공식 배포본을 참조합니다.
- **빌드 환경**: 생성 ZIP의 C++ 공유 라이브러리를 컴파일하려면 별도의 CMake/컴파일러가 필요합니다. 브라우저는 C++ 빌드를 수행하지 않습니다.

## 7. PostgreSQL 전환 계획

현재 `src/repository/ProjectRepository.ts`의 `load/save/reset` 인터페이스를 Mock Repository로 구현했습니다. 향후 백엔드를 추가하면 `HttpProjectRepository`로 대체할 수 있고 React Flow/Zustand 모델 및 코드 생성 규칙은 유지할 수 있습니다.

DB 테이블 초안은 `docs/postgresql-schema.sql`에 있습니다. **현 버전에서 PostgreSQL은 실행에 전혀 필요하지 않습니다.**

## 8. React Flow import 오류 해결 및 Dagre 레이아웃

- **React Flow v12**는 기본 import가 아니라 `import { ReactFlow, ... } from '@xyflow/react'`를 사용합니다. CSS는 `@xyflow/react/dist/style.css`입니다. 구형 `reactflow` 패키지를 별도로 설치할 필요가 없습니다.
- `src/logic/layout.ts`에서 `@dagrejs/dagre`를 사용해 **LR(좌→우) 자동 배치**를 계산합니다. Component의 Service Binding 수에 따라 실제 노드 높이를 계산하여 겹침을 줄입니다.
- 기본 Mock 데이터는 좌표를 비워둡니다. 최초 로딩 시 Dagre로 배치한 뒤 Zustand에 위치를 기록합니다. Component·Binding·Connection 추가/제거 시 레이아웃을 다시 계산하고, 선택 버튼으로도 강제 재배치할 수 있습니다.
- 노드를 드래그해서 변경한 좌표는 Mock Repository에 저장할 수 있습니다. 기존 저장된 JSON 좌표는 불러올 때 보존합니다.
- `npm run test:layout`으로 기본 3개 Component의 좌→우 순서, 노드 비중첩, 수동 좌표 보존을 검사합니다.
- **서버 없음**은 앱 실행 시 웹/API 서버가 필요 없다는 뜻입니다. npm으로 프런트엔드를 최초 빌드하는 과정과 브라우저 내 Mock 모델은 별개입니다.
