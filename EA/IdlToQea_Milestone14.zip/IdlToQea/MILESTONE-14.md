# Milestone 14 - CLI and real EA.Repository entry point

## Scope
- Add a Windows CLI entry point.
- Accept either an IDL ZIP or a parent folder as input.
- Produce a `.qea` output file.
- Instantiate the installed Sparx `EA.Repository` COM object directly through its ProgID.
- Run `IdlSourceWorkspace -> IdlModelBuilder -> IdlModule -> EaModelGenerator`.

## Usage
```powershell
IdlToQea.exe --input C:\UMAA\umaa-6.0-idl-with-exp-services.zip --output C:\Models\umaa.qea
IdlToQea.exe --input C:\UMAA\IDL --output C:\Models\umaa.qea
```

Positional form is also supported:
```powershell
IdlToQea.exe C:\UMAA\IDL C:\Models\umaa.qea
```

## Runtime requirement
The CLI requires Windows with Sparx Enterprise Architect installed and the `EA.Repository` Automation COM class registered.
