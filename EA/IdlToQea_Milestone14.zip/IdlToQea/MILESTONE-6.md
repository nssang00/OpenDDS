# Milestone 6 - UMAA Preprocessor

## Scope
- Implement the exact preprocessor subset used by UMAA 6.0 IDL.
- Keep include resolution separate from parse-time preprocessing.
- Feed preprocessed content into ANTLR while preserving line count.

## Supported directives
- `#include`
- `#ifndef`
- `#define`
- `#endif`

`#include` is masked for ANTLR and is resolved separately by `IdlIncludeResolver`.
`#ifndef/#define/#endif` are evaluated by `IdlPreprocessor`.
Unsupported directives are reported as `IDLPP001`.

## UMAA 6.0 verification
Uploaded `umaa-6.0-idl-with-exp-services.zip` was inspected:
- 594 IDL files
- 1,705 `#include`
- 595 `#ifndef`
- 595 `#define`
- 595 `#endif`
- 0 unsupported directives
- 0 malformed name-only guard macros
- 0 unmatched / unterminated guard blocks

## Tests added
`IdlPreprocessorTests` covers:
- normal UMAA include guard
- duplicate include guard behavior
- include masking
- unsupported directive diagnostic
- missing `#endif` diagnostic
- parser integration with a guarded IDL document

## Validation note
The execution environment does not provide the .NET SDK, so C# tests were authored but could not be executed with `dotnet test` here.
