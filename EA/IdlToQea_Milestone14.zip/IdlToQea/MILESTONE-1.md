# Milestone 1 — UMAA IDL Source Workspace

## Scope

This milestone intentionally stops before ANTLR grammar parsing and Sparx EA Automation.

Implemented:

- directory-based `.idl` discovery
- ZIP-based `.idl` discovery
- normalized relative source paths
- quoted `#include "..."` scanning
- angle-bracket `#include <...>` scanning
- relative include resolution
- configurable include roots
- unresolved-include diagnostics
- preservation of include source line numbers

## Tests authored

1. directory loader ignores non-IDL files and preserves paths
2. ZIP loader discovers nested IDL files
3. scanner recognizes quoted and angle-bracket includes
4. quoted include resolves relative to the current IDL file
5. duplicate file names in different folders resolve by relative path
6. unresolved include emits `IDL001`
7. angle include resolves from a configured include root

## Execution status

The current build environment does not contain `dotnet`, `csc`, or `mcs`, so the C# test suite could not be compiled/executed here. The test project is included and is ready for `dotnet test` on a .NET 8 SDK environment.

## Next slice

After this milestone is verified with `dotnet test`, the next isolated slice should add the public ANTLR IDL grammar and prove that representative UMAA declarations can be parsed without yet implementing EA Automation.
