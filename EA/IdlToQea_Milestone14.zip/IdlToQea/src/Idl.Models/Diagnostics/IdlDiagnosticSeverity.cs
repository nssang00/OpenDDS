namespace Idl.Models.Diagnostics;

public enum IdlDiagnosticSeverity
{
    Info,
    Warning,
    Error
}
