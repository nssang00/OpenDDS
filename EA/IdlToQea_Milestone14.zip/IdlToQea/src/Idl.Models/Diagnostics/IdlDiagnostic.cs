namespace Idl.Models.Diagnostics;

public sealed record IdlDiagnostic(
    string Code,
    IdlDiagnosticSeverity Severity,
    string Message,
    string? SourcePath = null,
    int? LineNumber = null);
