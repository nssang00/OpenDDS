namespace Idl.Models.Sources;

public enum IdlIncludeKind
{
    Quoted,
    AngleBracket
}
