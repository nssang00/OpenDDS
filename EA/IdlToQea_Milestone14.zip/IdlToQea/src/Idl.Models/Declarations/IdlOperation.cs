namespace Idl.Models.Declarations;

public sealed class IdlOperation
{
    private readonly List<IdlParameter> _parameters = [];
    public IdlOperation(string name, IdlTypeReference? returnType)
    {
        Name = name;
        ReturnType = returnType;
    }
    public string Name { get; }
    public IdlTypeReference? ReturnType { get; }
    public IReadOnlyList<IdlParameter> Parameters => _parameters;
    public void AddParameter(IdlParameter parameter) => _parameters.Add(parameter);
}

public enum IdlParameterDirection { In, Out, InOut }
public sealed record IdlParameter(string Name, IdlTypeReference Type, IdlParameterDirection Direction);
