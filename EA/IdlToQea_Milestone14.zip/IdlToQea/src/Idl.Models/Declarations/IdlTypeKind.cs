namespace Idl.Models.Declarations;

public enum IdlTypeKind
{
    Primitive,
    Named,
    Sequence,
    Set,
    Map,
    String,
    WString
}
