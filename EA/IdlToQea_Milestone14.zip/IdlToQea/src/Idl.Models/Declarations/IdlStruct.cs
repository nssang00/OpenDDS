namespace Idl.Models.Declarations;

public sealed class IdlStruct : IdlDeclaration
{
    private readonly List<IdlField> _fields = [];
    public IdlStruct(string name, IdlTypeReference? baseType = null) : base(name) => BaseType = baseType;
    public IdlTypeReference? BaseType { get; }
    public IReadOnlyList<IdlField> Fields => _fields;
    public void AddField(IdlField field) => _fields.Add(field);
}
