using Idl.Models.Diagnostics;

namespace Idl.Models.Declarations;

public sealed class IdlParseResult
{
    private readonly List<IdlDiagnostic> _diagnostics = [];
    public IdlParseResult(IdlDocument document) => Document = document;
    public IdlDocument Document { get; }
    public IReadOnlyList<IdlDiagnostic> Diagnostics => _diagnostics;
    public bool Success => _diagnostics.All(x => x.Severity != IdlDiagnosticSeverity.Error);
    public void AddDiagnostic(IdlDiagnostic diagnostic) => _diagnostics.Add(diagnostic);
}
