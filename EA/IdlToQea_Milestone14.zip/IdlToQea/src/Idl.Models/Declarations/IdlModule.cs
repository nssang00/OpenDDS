namespace Idl.Models.Declarations;

public sealed class IdlModule : IdlDeclaration
{
    private readonly List<IdlDeclaration> _declarations = [];
    private readonly HashSet<string> _sourcePaths = new(StringComparer.OrdinalIgnoreCase);

    public IdlModule(string name) : base(name) { }

    public IReadOnlyList<IdlDeclaration> Declarations => _declarations;
    public IReadOnlyCollection<string> SourcePaths => _sourcePaths;

    public void Add(IdlDeclaration declaration) => _declarations.Add(declaration);
    public void AddSourcePath(string sourcePath)
    {
        if (!string.IsNullOrWhiteSpace(sourcePath))
        {
            _sourcePaths.Add(sourcePath);
            SourcePath ??= sourcePath;
        }
    }
}
