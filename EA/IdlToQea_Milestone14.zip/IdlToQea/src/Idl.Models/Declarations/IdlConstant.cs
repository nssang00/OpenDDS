namespace Idl.Models.Declarations;

public sealed class IdlConstant : IdlDeclaration
{
    public IdlConstant(string name, IdlTypeReference type, string valueExpression) : base(name)
    {
        Type = type;
        ValueExpression = valueExpression;
    }

    public IdlTypeReference Type { get; }
    public string ValueExpression { get; }
}
