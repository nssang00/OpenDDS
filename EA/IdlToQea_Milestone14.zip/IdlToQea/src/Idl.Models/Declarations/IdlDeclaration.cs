namespace Idl.Models.Declarations;

public abstract class IdlDeclaration
{
    private readonly List<IdlAnnotation> _annotations = [];
    protected IdlDeclaration(string name) => Name = name;
    public string Name { get; }
    public string? SourcePath { get; set; }
    public IReadOnlyList<IdlAnnotation> Annotations => _annotations;
    public void AddAnnotation(IdlAnnotation annotation) => _annotations.Add(annotation);
}
