namespace Idl.Models.Declarations;

public sealed record IdlAnnotation(string Name, string? Arguments = null);
