namespace Idl.Models.Declarations;

public sealed class IdlUnion : IdlDeclaration
{
    private readonly List<IdlUnionCase> _cases = [];
    public IdlUnion(string name, IdlTypeReference discriminatorType) : base(name) => DiscriminatorType = discriminatorType;
    public IdlTypeReference DiscriminatorType { get; }
    public IReadOnlyList<IdlUnionCase> Cases => _cases;
    public void AddCase(IdlUnionCase unionCase) => _cases.Add(unionCase);
}

public sealed record IdlUnionCase(
    IReadOnlyList<string> Labels,
    IdlField Field,
    bool IsDefault = false);
