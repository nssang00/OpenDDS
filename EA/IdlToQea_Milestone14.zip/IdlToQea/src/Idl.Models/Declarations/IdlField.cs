namespace Idl.Models.Declarations;

public sealed class IdlField
{
    private readonly List<IdlAnnotation> _annotations = [];

    public IdlField(string name, IdlTypeReference type, IReadOnlyList<string>? arrayDimensions = null)
    {
        Name = name;
        Type = type;
        Dimensions = arrayDimensions ?? Array.Empty<string>();
    }

    public string Name { get; }
    public IdlTypeReference Type { get; }
    public IReadOnlyList<string> Dimensions { get; }
    public IReadOnlyList<IdlAnnotation> Annotations => _annotations;
    public void AddAnnotation(IdlAnnotation annotation) => _annotations.Add(annotation);
}
