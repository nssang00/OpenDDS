namespace Idl.Models.Declarations;

public sealed class IdlInterface : IdlDeclaration
{
    private readonly List<IdlTypeReference> _baseInterfaces = [];
    private readonly List<IdlOperation> _operations = [];
    public IdlInterface(string name) : base(name) { }
    public IReadOnlyList<IdlTypeReference> BaseInterfaces => _baseInterfaces;
    public IReadOnlyList<IdlOperation> Operations => _operations;
    public void AddBaseInterface(IdlTypeReference type) => _baseInterfaces.Add(type);
    public void AddOperation(IdlOperation operation) => _operations.Add(operation);
}
