using System.Runtime.InteropServices;
using Ea.Automation.Generation;
using Idl.Models.Diagnostics;
using Idl.Parser;

return ProgramMain(args);

static int ProgramMain(string[] args)
{
    if (args.Length == 0 || args.Contains("--help", StringComparer.OrdinalIgnoreCase) || args.Contains("-h", StringComparer.OrdinalIgnoreCase))
    {
        PrintUsage();
        return 0;
    }

    try
    {
        var options = ParseArguments(args);
        ValidateInput(options.InputPath);
        ValidateOutput(options.OutputPath);

        Console.WriteLine($"Input : {options.InputPath}");
        Console.WriteLine($"Output: {options.OutputPath}");

        var workspace = new IdlSourceWorkspace();
        var sourceSet = workspace.Load(options.InputPath);
        var modelBuilder = new IdlModelBuilder();
        var model = modelBuilder.Build(sourceSet);

        Console.WriteLine($"IDL files: {sourceSet.Files.Count}");
        Console.WriteLine($"Symbols  : {modelBuilder.SymbolCount}");

        var errors = modelBuilder.Diagnostics
            .Where(x => x.Severity == IdlDiagnosticSeverity.Error)
            .ToArray();
        if (errors.Length > 0)
        {
            foreach (var error in errors.Take(50))
                Console.Error.WriteLine($"{error.Code}: {error.SourcePath}:{error.LineNumber} {error.Message}");
            if (errors.Length > 50)
                Console.Error.WriteLine($"... {errors.Length - 50} more errors");
            return 2;
        }

        if (!OperatingSystem.IsWindows())
            throw new PlatformNotSupportedException("IDL parsing succeeded, but QEA generation requires Windows with Sparx Enterprise Architect installed.");

        var outputPath = Path.GetFullPath(options.OutputPath);
        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        if (File.Exists(outputPath))
            throw new IOException($"Output already exists: {outputPath}");

        object? repositoryObject = null;
        var created = false;
        var success = false;

        try
        {
            var repositoryType = Type.GetTypeFromProgID("EA.Repository", throwOnError: true)
                ?? throw new InvalidOperationException("Sparx Enterprise Architect Automation COM registration was not found.");

            repositoryObject = Activator.CreateInstance(repositoryType)
                ?? throw new InvalidOperationException("Could not create EA.Repository COM object.");
            dynamic repository = repositoryObject;

            // CreateModelType.cmEAPFromBase == 0. The CLI requires a .qea destination.
            created = (bool)repository.CreateModel(0, outputPath, 0);
            if (!created)
                throw new InvalidOperationException($"EA.Repository.CreateModel failed for '{outputPath}'.");

            var generator = new EaModelGenerator();
            generator.Generate(model, repository);

            Console.WriteLine($"EA elements: {generator.Elements.Count}");
            Console.WriteLine($"Result     : Success");
            success = true;
            return 0;
        }
        finally
        {
            if (repositoryObject is not null)
            {
                try { ((dynamic)repositoryObject).CloseFile(); } catch { }
                try { ((dynamic)repositoryObject).Exit(); } catch { }
                try
                {
                    if (Marshal.IsComObject(repositoryObject))
                        Marshal.FinalReleaseComObject(repositoryObject);
                }
                catch { }
            }

            if (!success && created)
            {
                try { File.Delete(outputPath); } catch { }
            }
        }
    }
    catch (Exception ex)
    {
        Console.Error.WriteLine($"Result: Failed");
        Console.Error.WriteLine(ex.Message);
        return 1;
    }
}

static CliOptions ParseArguments(string[] args)
{
    string? input = null;
    string? output = null;

    for (var i = 0; i < args.Length; i++)
    {
        switch (args[i].ToLowerInvariant())
        {
            case "--input":
            case "-i":
                input = RequireValue(args, ref i);
                break;
            case "--output":
            case "-o":
                output = RequireValue(args, ref i);
                break;
            default:
                if (args[i].StartsWith('-'))
                    throw new ArgumentException($"Unknown option: {args[i]}");
                if (input is null) input = args[i];
                else if (output is null) output = args[i];
                else throw new ArgumentException($"Unexpected argument: {args[i]}");
                break;
        }
    }

    if (string.IsNullOrWhiteSpace(input) || string.IsNullOrWhiteSpace(output))
        throw new ArgumentException("Both input and output paths are required. Use --help for usage.");

    return new CliOptions(Path.GetFullPath(input), Path.GetFullPath(output));
}

static string RequireValue(string[] args, ref int index)
{
    if (++index >= args.Length)
        throw new ArgumentException($"Missing value for {args[index - 1]}.");
    return args[index];
}

static void ValidateInput(string inputPath)
{
    if (Directory.Exists(inputPath)) return;
    if (File.Exists(inputPath) && string.Equals(Path.GetExtension(inputPath), ".zip", StringComparison.OrdinalIgnoreCase)) return;
    throw new FileNotFoundException("Input must be an existing directory or .zip file.", inputPath);
}

static void ValidateOutput(string outputPath)
{
    if (!string.Equals(Path.GetExtension(outputPath), ".qea", StringComparison.OrdinalIgnoreCase))
        throw new ArgumentException("Output file must use the .qea extension.");
}

static void PrintUsage()
{
    Console.WriteLine("IdlToQea - Convert UMAA IDL to a Sparx Enterprise Architect QEA model");
    Console.WriteLine();
    Console.WriteLine("Usage:");
    Console.WriteLine("  IdlToQea.exe --input <zip-or-folder> --output <file.qea>");
    Console.WriteLine("  IdlToQea.exe <zip-or-folder> <file.qea>");
    Console.WriteLine();
    Console.WriteLine("Requirements:");
    Console.WriteLine("  Windows with Sparx Enterprise Architect installed and EA.Repository COM registered.");
}

internal sealed record CliOptions(string InputPath, string OutputPath);
