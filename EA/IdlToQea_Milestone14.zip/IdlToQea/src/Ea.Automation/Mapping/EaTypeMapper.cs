using Idl.Models.Declarations;

namespace Ea.Automation.Mapping;

public sealed record EaElementMapping(string ElementType, string? Stereotype);

public sealed class EaTypeMapper
{
    public EaElementMapping MapDeclaration(IdlDeclaration declaration) => declaration switch
    {
        IdlStruct => new("Class", "IDLStruct"),
        IdlEnum => new("Enumeration", "IDLEnum"),
        IdlInterface => new("Interface", "IDLInterface"),
        IdlTypedef => new("DataType", "IDLTypedef"),
        IdlUnion => new("Class", "IDLUnion"),
        IdlConstant => new("DataType", "IDLConstant"),
        _ => throw new NotSupportedException($"EA element mapping is not defined for {declaration.GetType().Name}.")
    };

    public string MapAttributeType(IdlTypeReference type) => type.Kind switch
    {
        IdlTypeKind.Primitive => type.Name,
        IdlTypeKind.String => type.BoundExpression is null ? "string" : $"string<{type.BoundExpression}>",
        IdlTypeKind.WString => type.BoundExpression is null ? "wstring" : $"wstring<{type.BoundExpression}>",
        IdlTypeKind.Sequence => $"sequence<{MapAttributeType(type.ElementType!)}{FormatBound(type.BoundExpression)}>",
        IdlTypeKind.Set => $"set<{MapAttributeType(type.ElementType!)}{FormatBound(type.BoundExpression)}>",
        IdlTypeKind.Map => $"map<{MapAttributeType(type.KeyType!)},{MapAttributeType(type.ElementType!)}{FormatBound(type.BoundExpression)}>",
        IdlTypeKind.Named => type.Name,
        _ => type.Name
    };

    public string MapTypeKind(IdlTypeReference type) => type.Kind.ToString().ToLowerInvariant();

    private static string FormatBound(string? bound) => bound is null ? string.Empty : $",{bound}";
}
