# Ea.Automation

Minimal Sparx Enterprise Architect Automation layer.

Production flow:

`IdlModule -> EaModelGenerator -> EA.Repository -> QEA`

The project intentionally does not wrap `EA.Repository` behind repository interfaces. `EaModelGenerator` calls the Enterprise Architect Automation object model directly (`Models`, `Packages`, `Elements`, `Attributes`, `TaggedValues`).

`EaTypeMapper` contains only IDL-to-EA type/element mapping policy.
