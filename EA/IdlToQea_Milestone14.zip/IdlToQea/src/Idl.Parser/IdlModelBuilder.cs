using Idl.Models.Declarations;
using Idl.Models.Diagnostics;
using Idl.Models.Sources;

namespace Idl.Parser;

/// <summary>
/// Builds the single UMAA root module from all IDL source files and resolves named type references.
/// Diagnostics and symbol counts are build-time information and are not part of the final IDL model.
/// </summary>
public sealed class IdlModelBuilder
{
    private readonly IdlDocumentParser _parser = new();
    private readonly Dictionary<string, IdlDeclaration> _symbols = new(StringComparer.Ordinal);
    private readonly List<IdlDiagnostic> _diagnostics = [];

    public IReadOnlyList<IdlDiagnostic> Diagnostics => _diagnostics;
    public int SymbolCount => _symbols.Count;
    public IReadOnlyDictionary<string, IdlDeclaration> Symbols => _symbols;
    public int DocumentCount { get; private set; }
    public bool Success => _diagnostics.All(x => x.Severity != IdlDiagnosticSeverity.Error);

    public IdlModule Build(IdlSourceSet sourceSet)
    {
        ArgumentNullException.ThrowIfNull(sourceSet);
        _symbols.Clear();
        _diagnostics.Clear();
        DocumentCount = 0;

        _diagnostics.AddRange(sourceSet.Diagnostics);
        var root = new IdlModule("UMAA");

        foreach (var sourceFile in sourceSet.Files.OrderBy(x => x.RelativePath, StringComparer.OrdinalIgnoreCase))
        {
            var parse = _parser.Parse(sourceFile);
            DocumentCount++;
            _diagnostics.AddRange(parse.Diagnostics);
            AssignSourcePath(parse.Document.Declarations, parse.Document.SourcePath);

            foreach (var declaration in parse.Document.Declarations)
            {
                if (declaration is IdlModule module && module.Name == root.Name)
                    MergeModule(root, module);
                else
                    root.Add(declaration);
            }
        }

        if (!Success) return root;

        CollectSymbols(root.Declarations, [root.Name]);
        if (!Success) return root;

        ResolveDeclarations(root.Declarations, [root.Name]);
        return root;
    }

    private static void AssignSourcePath(IEnumerable<IdlDeclaration> declarations, string sourcePath)
    {
        foreach (var declaration in declarations)
        {
            declaration.SourcePath = sourcePath;
            if (declaration is IdlModule module)
            {
                module.AddSourcePath(sourcePath);
                AssignSourcePath(module.Declarations, sourcePath);
            }
        }
    }

    private static void MergeModule(IdlModule target, IdlModule source)
    {
        foreach (var path in source.SourcePaths) target.AddSourcePath(path);

        foreach (var declaration in source.Declarations)
        {
            if (declaration is IdlModule sourceChild)
            {
                var targetChild = target.Declarations.OfType<IdlModule>().FirstOrDefault(x => x.Name == sourceChild.Name);
                if (targetChild is null)
                    target.Add(sourceChild);
                else
                    MergeModule(targetChild, sourceChild);
            }
            else
            {
                target.Add(declaration);
            }
        }
    }

    private void CollectSymbols(IEnumerable<IdlDeclaration> declarations, IReadOnlyList<string> scope)
    {
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
            {
                CollectSymbols(module.Declarations, [.. scope, module.Name]);
                continue;
            }

            if (!IsTypeDeclaration(declaration)) continue;
            var scopedName = "::" + string.Join("::", scope.Append(declaration.Name));
            if (!_symbols.TryAdd(scopedName, declaration))
            {
                _diagnostics.Add(new IdlDiagnostic(
                    "IDL2001",
                    IdlDiagnosticSeverity.Error,
                    $"Duplicate IDL type declaration: {scopedName}",
                    declaration.SourcePath ?? string.Empty));
            }
        }
    }

    private void ResolveDeclarations(IEnumerable<IdlDeclaration> declarations, IReadOnlyList<string> scope)
    {
        foreach (var declaration in declarations)
        {
            if (declaration is IdlModule module)
            {
                ResolveDeclarations(module.Declarations, [.. scope, module.Name]);
                continue;
            }

            switch (declaration)
            {
                case IdlStruct s:
                    if (s.BaseType is not null) ResolveType(s.BaseType, scope, declaration, $"base struct {s.Name}");
                    foreach (var field in s.Fields) ResolveType(field.Type, scope, declaration, $"field {s.Name}.{field.Name}");
                    break;
                case IdlTypedef t:
                    ResolveType(t.UnderlyingType, scope, declaration, $"typedef {t.Name}");
                    break;
                case IdlInterface i:
                    foreach (var baseType in i.BaseInterfaces) ResolveType(baseType, scope, declaration, $"base interface {i.Name}");
                    foreach (var op in i.Operations)
                    {
                        if (op.ReturnType is not null) ResolveType(op.ReturnType, scope, declaration, $"operation {i.Name}.{op.Name} return");
                        foreach (var p in op.Parameters) ResolveType(p.Type, scope, declaration, $"parameter {i.Name}.{op.Name}.{p.Name}");
                    }
                    break;
                case IdlUnion u:
                    ResolveType(u.DiscriminatorType, scope, declaration, $"union {u.Name} discriminator");
                    foreach (var c in u.Cases) ResolveType(c.Field.Type, scope, declaration, $"union {u.Name}.{c.Field.Name}");
                    break;
                case IdlConstant c:
                    ResolveType(c.Type, scope, declaration, $"const {c.Name}");
                    break;
            }
        }
    }

    private void ResolveType(IdlTypeReference type, IReadOnlyList<string> scope, IdlDeclaration owner, string usage)
    {
        if ((type.Kind is IdlTypeKind.Sequence or IdlTypeKind.Set) && type.ElementType is not null)
            ResolveType(type.ElementType, scope, owner, usage + " element");

        if (type.Kind == IdlTypeKind.Map)
        {
            if (type.KeyType is not null) ResolveType(type.KeyType, scope, owner, usage + " key");
            if (type.ElementType is not null) ResolveType(type.ElementType, scope, owner, usage + " value");
        }

        if (type.Kind != IdlTypeKind.Named) return;

        var resolved = FindSymbol(type.Name, scope);
        if (resolved is null)
        {
            _diagnostics.Add(new IdlDiagnostic(
                "IDL2002",
                IdlDiagnosticSeverity.Error,
                $"Unresolved IDL type '{type.Name}' used by {usage}.",
                owner.SourcePath ?? string.Empty));
            return;
        }

        type.ResolvedScopedName = resolved;
    }

    private string? FindSymbol(string name, IReadOnlyList<string> scope)
    {
        if (name.StartsWith("::", StringComparison.Ordinal))
            return _symbols.ContainsKey(name) ? name : null;

        var parts = name.Split("::", StringSplitOptions.RemoveEmptyEntries);
        for (var length = scope.Count; length >= 0; length--)
        {
            var candidate = "::" + string.Join("::", scope.Take(length).Concat(parts));
            if (_symbols.ContainsKey(candidate)) return candidate;
        }
        return null;
    }

    private static bool IsTypeDeclaration(IdlDeclaration declaration) => declaration is
        IdlStruct or IdlEnum or IdlTypedef or IdlInterface or IdlUnion;
}
