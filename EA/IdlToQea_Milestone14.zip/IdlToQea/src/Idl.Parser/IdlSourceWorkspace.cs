using Idl.Models.Sources;
using Idl.Models.Declarations;
using Idl.Parser.PreProcessor;
using Idl.Parser.Sources;

namespace Idl.Parser;

public sealed class IdlSourceWorkspace
{
    private readonly IdlSourceLoader _loader = new();
    private readonly IdlIncludeScanner _scanner = new();
    private readonly IdlIncludeResolver _resolver = new();

    public IdlModule BuildModel(string inputPath, IEnumerable<string>? includeRoots = null)
    {
        var sourceSet = Load(inputPath, includeRoots);
        return new IdlModelBuilder().Build(sourceSet);
    }

    public IdlSourceSet Load(string inputPath, IEnumerable<string>? includeRoots = null)
    {
        var sourceSet = _loader.Load(inputPath);

        foreach (var sourceFile in sourceSet.Files)
        {
            foreach (var include in _scanner.Scan(sourceFile.Content))
            {
                sourceFile.AddInclude(include);
            }
        }

        _resolver.Resolve(sourceSet, includeRoots);
        return sourceSet;
    }
}
