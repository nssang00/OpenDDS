using Antlr4.Runtime;
using Idl.Models.Declarations;
using Idl.Models.Diagnostics;

namespace Idl.Parser.Parsing;

internal sealed class IdlSyntaxErrorListener(IdlParseResult result, string sourcePath) : BaseErrorListener
{
    public override void SyntaxError(
        TextWriter output,
        IRecognizer recognizer,
        IToken offendingSymbol,
        int line,
        int charPositionInLine,
        string msg,
        RecognitionException e)
    {
        result.AddDiagnostic(new IdlDiagnostic(
            "IDL100",
            IdlDiagnosticSeverity.Error,
            $"{msg} (column {charPositionInLine + 1})",
            sourcePath,
            line));
    }
}
