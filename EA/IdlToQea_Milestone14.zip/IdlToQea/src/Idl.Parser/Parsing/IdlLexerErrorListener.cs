using Antlr4.Runtime;
using Idl.Models.Declarations;
using Idl.Models.Diagnostics;

namespace Idl.Parser.Parsing;

internal sealed class IdlLexerErrorListener(IdlParseResult result, string sourcePath) : IAntlrErrorListener<int>
{
    public void SyntaxError(
        TextWriter output,
        IRecognizer recognizer,
        int offendingSymbol,
        int line,
        int charPositionInLine,
        string msg,
        RecognitionException e)
    {
        result.AddDiagnostic(new IdlDiagnostic(
            "IDL099",
            IdlDiagnosticSeverity.Error,
            $"{msg} (column {charPositionInLine + 1})",
            sourcePath,
            line));
    }
}
