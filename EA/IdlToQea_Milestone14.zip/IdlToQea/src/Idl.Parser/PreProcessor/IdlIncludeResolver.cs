using Idl.Models.Diagnostics;
using Idl.Models.Sources;
using Idl.Parser.Sources;

namespace Idl.Parser.PreProcessor;

public sealed class IdlIncludeResolver
{
    public void Resolve(IdlSourceSet sourceSet, IEnumerable<string>? includeRoots = null)
    {
        ArgumentNullException.ThrowIfNull(sourceSet);

        var normalizedRoots = (includeRoots ?? [])
            .Select(IdlPath.Normalize)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToArray();

        foreach (var sourceFile in sourceSet.Files)
        {
            foreach (var include in sourceFile.Includes)
            {
                var candidates = GetCandidates(sourceFile, include, normalizedRoots, out var escapedRoot);
                var resolved = candidates.FirstOrDefault(path => sourceSet.TryGetFile(path, out _));

                if (resolved is not null)
                {
                    include.ResolveTo(resolved);
                    continue;
                }

                sourceSet.AddDiagnostic(new IdlDiagnostic(
                    escapedRoot ? "IDL002" : "IDL001",
                    IdlDiagnosticSeverity.Error,
                    escapedRoot
                        ? $"Include path escapes the IDL source root: '{include.Path}'."
                        : $"Unable to resolve include '{include.Path}'.",
                    sourceFile.RelativePath,
                    include.LineNumber));
            }
        }
    }

    private static IReadOnlyList<string> GetCandidates(
        IdlSourceFile sourceFile,
        IdlInclude include,
        IReadOnlyList<string> includeRoots,
        out bool escapedRoot)
    {
        escapedRoot = false;
        var candidates = new List<string>();

        if (include.Kind == IdlIncludeKind.Quoted)
        {
            if (IdlPath.TryCombine(sourceFile.DirectoryPath, include.Path, out var relative))
                candidates.Add(relative);
            else
                escapedRoot = true;
        }

        foreach (var root in includeRoots)
        {
            if (IdlPath.TryCombine(root, include.Path, out var rooted))
                candidates.Add(rooted);
            else
                escapedRoot = true;
        }

        if (IdlPath.TryNormalize(include.Path, out var fromRoot))
            candidates.Add(fromRoot);
        else
            escapedRoot = true;

        return candidates.Distinct(StringComparer.OrdinalIgnoreCase).ToArray();
    }
}
