using System.Text.RegularExpressions;
using Idl.Models.Sources;

namespace Idl.Parser.PreProcessor;

public sealed partial class IdlIncludeScanner
{
    [GeneratedRegex("""^\s*#\s*include\s*(?:"(?<quoted>[^"]+)"|<(?<angle>[^>]+)>)""", RegexOptions.Compiled)]
    private static partial Regex IncludeRegex();

    public IReadOnlyList<IdlInclude> Scan(string content)
    {
        ArgumentNullException.ThrowIfNull(content);

        var includes = new List<IdlInclude>();
        using var reader = new StringReader(content);

        string? line;
        var lineNumber = 0;
        while ((line = reader.ReadLine()) is not null)
        {
            lineNumber++;
            var match = IncludeRegex().Match(line);
            if (!match.Success)
            {
                continue;
            }

            var quoted = match.Groups["quoted"];
            var kind = quoted.Success
                ? IdlIncludeKind.Quoted
                : IdlIncludeKind.AngleBracket;
            var path = quoted.Success
                ? quoted.Value
                : match.Groups["angle"].Value;

            includes.Add(new IdlInclude(
                path.Trim(),
                kind,
                lineNumber));
        }

        return includes;
    }
}
