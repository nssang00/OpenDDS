using Idl.Models.Diagnostics;
using Idl.Parser;

if (args.Length != 1 || !File.Exists(args[0]))
{
    Console.Error.WriteLine("Usage: Umaa.Acceptance <UMAA zip>");
    return 2;
}

var zipPath = Path.GetFullPath(args[0]);
var workspace = new IdlSourceWorkspace();
var sourceSet = workspace.Load(zipPath);
var includeCount = sourceSet.Files.Sum(x => x.Includes.Count);
var unresolvedIncludes = sourceSet.Files.SelectMany(x => x.Includes).Count(x => !x.IsResolved);
var sourceErrors = sourceSet.Diagnostics.Count(x => x.Severity == IdlDiagnosticSeverity.Error);

Console.WriteLine($"Files={sourceSet.Files.Count}");
Console.WriteLine($"Includes={includeCount}");
Console.WriteLine($"UnresolvedIncludes={unresolvedIncludes}");
Console.WriteLine($"SourceErrors={sourceErrors}");

var builder = new IdlModelBuilder();
var model = builder.Build(sourceSet);
var errors = builder.Diagnostics.Where(x => x.Severity == IdlDiagnosticSeverity.Error).ToList();
Console.WriteLine($"RootModule={model.Name}");
Console.WriteLine($"Documents={builder.DocumentCount}");
Console.WriteLine($"Symbols={builder.SymbolCount}");
Console.WriteLine($"Errors={errors.Count}");
foreach (var error in errors.Take(100))
    Console.WriteLine($"{error.Code}: {error.SourcePath}:{error.LineNumber} {error.Message}");

var ok = sourceSet.Files.Count == 594
    && includeCount == 1705
    && unresolvedIncludes == 0
    && sourceErrors == 0
    && model.Name == "UMAA"
    && builder.DocumentCount == 594
    && builder.SymbolCount == 858
    && errors.Count == 0;

return ok ? 0 : 1;
