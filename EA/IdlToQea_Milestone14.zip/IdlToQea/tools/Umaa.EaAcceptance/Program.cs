using Ea.Automation.Generation;
using Idl.Models.Diagnostics;
using Idl.Parser;

if (args.Length != 1 || !File.Exists(args[0])) { Console.Error.WriteLine("Usage: Umaa.EaAcceptance <UMAA zip>"); return 2; }
var sourceSet = new IdlSourceWorkspace().Load(Path.GetFullPath(args[0]));
var builder = new IdlModelBuilder();
var model = builder.Build(sourceSet);
var errors = builder.Diagnostics.Count(x => x.Severity == IdlDiagnosticSeverity.Error);
if (errors != 0) { Console.WriteLine($"SemanticErrors={errors}"); return 1; }

var repo = new FakeEaRepository();
var generator = new EaModelGenerator();
generator.Generate(model, repo);

Console.WriteLine($"Documents={builder.DocumentCount}");
Console.WriteLine($"Symbols={builder.SymbolCount}");
Console.WriteLine($"MappedElements={generator.Elements.Count}");
Console.WriteLine($"RootPackages={repo.RootPackages.Count}");
Console.WriteLine($"Packages={repo.AllPackages.Count()}");
Console.WriteLine($"Elements={repo.AllElements.Count()}");
Console.WriteLine($"Attributes={repo.AllElements.Sum(x => x.Attributes.Items.Count)}");
Console.WriteLine($"ClassifierLinks={repo.AllElements.SelectMany(x => x.Attributes.Items).Count(x => x.ClassifierID.HasValue)}");
Console.WriteLine($"UnionElements={repo.AllElements.Count(x => x.Stereotype == "IDLUnion")}");
Console.WriteLine($"ConstantElements={repo.AllElements.Count(x => x.Stereotype == "IDLConstant")}");
Console.WriteLine($"EnumElements={repo.AllElements.Count(x => x.Stereotype == "IDLEnum")}");
Console.WriteLine($"TypedefElements={repo.AllElements.Count(x => x.Stereotype == "IDLTypedef")}");
var sourceTagged = repo.AllElements.Count(x => x.Tags.ContainsKey("idl.sourcePath"));
Console.WriteLine($"SourceTaggedElements={sourceTagged}");
var semanticElements = repo.AllElements.Count(x => x.Stereotype != "IDLFile");
var sourceArtifacts = repo.AllElements.Count(x => x.Stereotype == "IDLFile");
Console.WriteLine($"SemanticElements={semanticElements}");
Console.WriteLine($"SourceArtifacts={sourceArtifacts}");
Console.WriteLine($"KeyTags={repo.AllElements.SelectMany(x => x.Attributes.Items).Count(x => x.Tags.ContainsKey("idl.key"))}");
Console.WriteLine($"OptionalTags={repo.AllElements.SelectMany(x => x.Attributes.Items).Count(x => x.Tags.ContainsKey("idl.optional"))}");
Console.WriteLine($"NestedTags={repo.AllElements.Count(x => x.Tags.ContainsKey("idl.nested"))}");

var ok = builder.DocumentCount == 594
    && builder.SymbolCount == 858
    && generator.Elements.Count == 1482
    && semanticElements == 1482
    && sourceArtifacts == 594
    && repo.AllElements.Count(x => x.Stereotype == "IDLUnion") == 17
    && repo.AllElements.Count(x => x.Stereotype == "IDLConstant") == 624
    && repo.AllElements.Count(x => x.Stereotype == "IDLEnum") == 97
    && repo.AllElements.Count(x => x.Stereotype == "IDLTypedef") == 139
    && repo.AllElements.SelectMany(x => x.Attributes.Items).Count(x => x.Tags.ContainsKey("idl.key")) == 739
    && repo.AllElements.SelectMany(x => x.Attributes.Items).Count(x => x.Tags.ContainsKey("idl.optional")) == 453
    && repo.AllElements.Count(x => x.Tags.ContainsKey("idl.nested")) == 222
    && sourceTagged == repo.AllElements.Count();

Console.WriteLine(ok ? "Acceptance=PASS" : "Acceptance=FAIL");
return ok ? 0 : 1;

public sealed class FakeEaRepository
{
    public FakePackageCollection Models { get; } = new();
    public IReadOnlyList<FakePackage> RootPackages => Models.Items;
    public IEnumerable<FakePackage> AllPackages => Walk(RootPackages);
    public IEnumerable<FakeElement> AllElements => AllPackages.SelectMany(x => x.Elements.Items);
    public void RefreshModelView(int packageId) { }
    private static IEnumerable<FakePackage> Walk(IEnumerable<FakePackage> roots)
    {
        foreach (var p in roots) { yield return p; foreach (var x in Walk(p.Children)) yield return x; }
    }
}
public sealed class FakePackageCollection
{
    public List<FakePackage> Items { get; } = [];
    public FakePackage AddNew(string name, string type) { var x = new FakePackage(name); Items.Add(x); return x; }
    public void Refresh() { }
}
public sealed class FakePackage(string name)
{
    public string Name { get; set; } = name;
    public FakePackageCollection Packages { get; } = new();
    public List<FakePackage> Children => Packages.Items;
    public FakeElementCollection Elements { get; } = new();
    public bool Update() => true;
    public string GetLastError() => string.Empty;
}
public sealed class FakeElementCollection
{
    public List<FakeElement> Items { get; } = [];
    public FakeElement AddNew(string name, string type) { var x = new FakeElement(name, type); Items.Add(x); return x; }
    public void Refresh() { }
}
public sealed class FakeElement
{
    private static int _next = 1;
    public FakeElement(string name, string type) { Name = name; Type = type; TaggedValues = new FakeTaggedValueCollection(Tags); }
    public int ElementID { get; } = _next++;
    public string Name { get; set; }
    public string Type { get; set; }
    public string? Stereotype { get; set; }
    public FakeAttributeCollection Attributes { get; } = new();
    public FakeTaggedValueCollection TaggedValues { get; }
    public Dictionary<string,string> Tags { get; } = [];
    public bool Update() => true;
    public string GetLastError() => string.Empty;
}
public sealed class FakeAttributeCollection
{
    public List<FakeAttribute> Items { get; } = [];
    public FakeAttribute AddNew(string name, string type) { var x = new FakeAttribute(name, type); Items.Add(x); return x; }
    public void Refresh() { }
}
public sealed class FakeAttribute
{
    public FakeAttribute(string name, string type) { Name = name; Type = type; TaggedValues = new FakeTaggedValueCollection(Tags); }
    public string Name { get; set; }
    public string Type { get; set; }
    public string? Stereotype { get; set; }
    public int? ClassifierID { get; set; }
    public FakeTaggedValueCollection TaggedValues { get; }
    public Dictionary<string,string> Tags { get; } = [];
    public bool Update() => true;
    public string GetLastError() => string.Empty;
}
public sealed class FakeTaggedValueCollection
{
    private readonly Dictionary<string,string> _target;
    public FakeTaggedValueCollection(Dictionary<string,string> target) => _target = target;
    public FakeTaggedValue AddNew(string name, string type) => new(name, _target);
    public void Refresh() { }
}
public sealed class FakeTaggedValue(string name, Dictionary<string,string> target)
{
    public string Name { get; } = name;
    public string Value { get; set; } = string.Empty;
    public bool Update() { target[Name] = Value; return true; }
    public string GetLastError() => string.Empty;
}
