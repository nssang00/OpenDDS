# UMAA 6.0 Corpus Validation

Acceptance corpus: `umaa-6.0-idl-with-exp-services.zip` supplied by the user.

## Verified inventory

- IDL files: 594
- include directives: 1705
- resolved includes: 1705
- unresolved includes: 0
- preprocessor directives outside the supported UMAA set: 0
- parsed syntax files with the grammar-equivalent independent validator: 594/594
- collected type declarations: 858
- named type references: 2785
- unresolved named type references: 0

## Parser acceptance target

The C# acceptance test is `UmaaCorpusAcceptanceTests`.
Set `UMAA_IDL_ZIP` to the official ZIP path and run:

```bash
UMAA_IDL_ZIP=/path/to/umaa-6.0-idl-with-exp-services.zip dotnet test
```

Expected result:

- 594/594 documents parsed
- 1705/1705 includes resolved
- zero error diagnostics
- 858 type symbols
- zero `IDL2002` unresolved type diagnostics

## Environment limitation

The current execution environment does not contain the .NET SDK, so the generated ANTLR C# parser cannot be compiled and executed here. The uploaded corpus was independently validated using a grammar-equivalent parser and semantic-reference scan. The xUnit test above turns the same corpus expectations into the final .NET acceptance gate.
