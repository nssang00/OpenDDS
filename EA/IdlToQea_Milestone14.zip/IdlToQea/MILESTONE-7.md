# Milestone 7 - UMAA full-corpus parser validation

## Goal
Use the uploaded UMAA 6.0 IDL distribution as the acceptance corpus and move from sample-only parsing to corpus-wide validation.

## Changes
- Replaced the previous reduced grammar slice with a UMAA 6.0 grammar profile aligned with the public antlr/grammars-v4 IDL rule shapes.
- Added string, floating/scientific, long long, unsigned long long and full constant-expression lexical support needed by the UMAA corpus.
- Kept UMAA preprocessor handling separate from IDL grammar parsing.
- Added a corpus integration test entry point that expects the official UMAA ZIP path through UMAA_IDL_ZIP.
- Added a corpus inventory/acceptance report generated from the uploaded official ZIP.

## Acceptance target
- IDL files: 594/594 parse
- Include resolution: 1705/1705
- Syntax diagnostics: 0
- Model build failures: 0
- Unresolved type references: 0

## Environment note
The current execution environment does not contain the .NET SDK, so the xUnit/ANTLR-generated C# parser cannot be compiled and executed here. Static corpus checks are performed against the uploaded ZIP; final 594/594 ANTLR execution must be run in a .NET 8 environment.

## Hardening update

- Lexer errors are now captured as `IDL099` diagnostics instead of being written only to stderr.
- Include paths that escape the virtual IDL source root are rejected as `IDL002`.
- `scripts/test-umaa.sh <zip>` provides a single-command .NET acceptance run when the .NET 8 SDK is available.
