# IdlToQea

Incremental C# architecture for UMAA IDL -> Idl.Models -> Sparx EA Automation -> QEA.

Current milestone: parser input handling plus structured parsing for modules, structs, enums, typedefs, sequences, arrays, interface inheritance, and declaration annotations.

Run tests on a .NET 8 SDK machine:

```bash
dotnet test
```

See MILESTONE-1.md, MILESTONE-2.md, and MILESTONE-3.md.

## Milestone 6
UMAA-specific preprocessing is implemented for `#include`, `#ifndef`, `#define`, and `#endif`. The uploaded UMAA 6.0 distribution was inspected and contains no other preprocessor directive kinds.

## Milestone 7
The official UMAA 6.0 corpus is now the parser acceptance baseline. See `UMAA-VALIDATION.md` and `UmaaCorpusAcceptanceTests.cs`.

## Actual UMAA .NET acceptance status

Using portable .NET 8.0.424 and ANTLR 4.13.1 generated C# sources, the official uploaded UMAA 6.0 corpus was executed through the C# parser and semantic model builder: 594/594 files, 1705/1705 includes, 858 semantic symbols, 0 errors.


## Current EA Automation structure (Milestone 12)

The production Automation layer is intentionally minimal:

```text
IdlModule -> EaModelGenerator -> EA.Repository -> QEA
```

`EaModelGenerator` calls the Sparx Automation object model directly. Repository/package/element wrapper interfaces are no longer used in production. `EaTypeMapper` remains as the small IDL-to-EA mapping policy component.

## Current simplified model flow (Milestone 13)

```text
UMAA IDL -> Idl.Parser -> IdlModule(UMAA) -> EaModelGenerator -> EA.Repository -> QEA
```

`IdlModelBuilder` owns symbol resolution and diagnostics only while building. They are not part of the final IR object passed to EA Automation.

## CLI

Windows with Sparx Enterprise Architect installed:

```powershell
IdlToQea.exe --input C:\UMAA\umaa-6.0-idl-with-exp-services.zip --output C:\Models\umaa.qea
IdlToQea.exe --input C:\UMAA\IDL --output C:\Models\umaa.qea
```

`--input` accepts either a ZIP archive or a parent folder. Folder input is scanned recursively for `.idl` files.

## IdlToQea CLI

The Windows CLI accepts either a ZIP archive or a parent folder and writes one QEA repository.

```powershell
IdlToQea.exe --input C:\UMAA\umaa-6.0-idl-with-exp-services.zip --output C:\Models\umaa.qea
IdlToQea.exe --input C:\UMAA\IDL --output C:\Models\umaa.qea
```

The folder form recursively discovers `.idl` files. The CLI creates the installed Sparx Enterprise Architect `EA.Repository` Automation COM object directly; no repository abstraction layer is used.
