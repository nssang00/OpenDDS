# Milestone 8 — Actual .NET / UMAA acceptance

## Completed
- Portable .NET 8.0.424 SDK executed successfully on Linux.
- ANTLR 4.13.1 complete JAR used to generate C# lexer/parser/visitor from `IDL.g4`.
- Removed `Antlr4BuildTasks` from `Idl.Parser`; generated C# sources are compiled directly.
- Fixed cross-assembly include resolution API (`IdlInclude.ResolveTo`).
- Added `tools/Umaa.Acceptance` executable acceptance runner.

## Actual C# validation against uploaded UMAA 6.0 ZIP
- IDL files: 594
- include directives: 1705
- unresolved includes: 0
- source diagnostics: 0
- parsed documents: 594
- semantic symbols: 858
- semantic errors: 0

This is an actual C#/.NET execution result, not the earlier independent grammar simulation.

## Test project note
The xUnit project remains in the solution, but the uploaded offline NuGet set does not contain all transitive xUnit/Test SDK packages needed for `dotnet test`. The strict UMAA acceptance path is therefore also available as a package-minimal console runner.
