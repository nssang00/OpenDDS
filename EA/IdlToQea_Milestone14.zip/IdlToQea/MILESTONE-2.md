# Milestone 2 - ANTLR parsing to Idl.Models

## Scope

- Keep Milestone 1 source discovery/include resolution unchanged.
- Add an ANTLR4 parsing path.
- Convert parse trees into `Idl.Models` objects.
- Support only the first vertical slice: nested module, struct, enum, basic/scoped field types.
- Mask preprocessor directives before handing text to ANTLR; include relationships remain owned by Milestone 1.

## Why this is deliberately small

UMAA-wide grammar support is not attempted in one step. The first goal is to prove the boundary:

`IDL text -> ANTLR ParseTree -> Idl.Models`

The next milestone replaces the grammar slice with the pinned full upstream grammar and expands model coverage based on actual UMAA syntax.

## Tests added

1. Nested module + struct + enum model building.
2. Scoped type name preservation.
3. `#include` directive masking before syntax parsing.
4. Syntax error diagnostic with source path/line.

Run in a .NET 8 SDK environment:

```bash
dotnet test
```
