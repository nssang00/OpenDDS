using Idl.Models.Declarations;

namespace Idl.Parser.Tests;

public sealed class IdlUmaaCorpusSyntaxTests
{
    [Fact]
    public void Parser_AcceptsUmaaConstantLiteralForms()
    {
        const string idl = """
            module UMAA {
                const string Topic = "UMAA::Example::Topic";
                const double Min = -10000.0;
                const double Max = 1e25;
                const long Count = -100000;
            };
            """;

        var result = new IdlDocumentParser().Parse(idl);

        Assert.True(result.Success);
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        Assert.Equal(4, module.Declarations.OfType<IdlConstant>().Count());
    }

    [Fact]
    public void Parser_AcceptsUmaaLongLongTypedefForms()
    {
        const string idl = """
            module UMAA {
                typedef long long NanosecondsCount;
                typedef unsigned long long LargeCount;
            };
            """;

        var result = new IdlDocumentParser().Parse(idl);

        Assert.True(result.Success);
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        var aliases = module.Declarations.OfType<IdlTypedef>().ToArray();
        Assert.Equal("longlong", aliases[0].UnderlyingType.Name);
        Assert.Equal("unsignedlonglong", aliases[1].UnderlyingType.Name);
    }

    [Fact]
    public void Parser_AcceptsUmaaAnnotatedUnionShape()
    {
        const string idl = """
            module UMAA {
                enum Kind { A_D, B_D };
                @nested union Value switch (Kind) {
                    case A_D: long a;
                    case B_D: string<64> b;
                };
            };
            """;

        var result = new IdlDocumentParser().Parse(idl);

        Assert.True(result.Success);
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        var union = Assert.IsType<IdlUnion>(module.Declarations.Single(x => x is IdlUnion));
        Assert.Equal(2, union.Cases.Count);
        Assert.Contains(union.Annotations, x => x.Name == "nested");
    }
}
