using Idl.Models.Declarations;
using Xunit;

namespace Idl.Parser.Tests;

public sealed class IdlExtendedTypeParserTests
{
    [Fact]
    public void Parse_TypedefSequenceAndArray_BuildsStructuredTypes()
    {
        const string idl = """
            module UMAA {
                typedef sequence<::UMAA::Common::TrackType, 100> TrackList;
                struct Sample {
                    TrackList tracks;
                    long samples[16];
                };
            };
            """;
        var result = new IdlDocumentParser().Parse(idl);
        Assert.True(result.Success);
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        var alias = Assert.IsType<IdlTypedef>(module.Declarations[0]);
        Assert.Equal(IdlTypeKind.Sequence, alias.UnderlyingType.Kind);
        Assert.Equal("::UMAA::Common::TrackType", alias.UnderlyingType.ElementType!.Name);
        Assert.Equal("100", alias.UnderlyingType.BoundExpression);
        var sample = Assert.IsType<IdlStruct>(module.Declarations[1]);
        Assert.Equal("16", sample.Fields[1].Dimensions.Single());
    }

    [Fact]
    public void Parse_InterfaceInheritance_PreservesBaseInterfaces()
    {
        const string idl = "module UMAA { interface Child : ::UMAA::Base, LocalBase { }; };";
        var result = new IdlDocumentParser().Parse(idl);
        Assert.True(result.Success);
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        var iface = Assert.IsType<IdlInterface>(Assert.Single(module.Declarations));
        Assert.Equal(new[] { "::UMAA::Base", "LocalBase" }, iface.BaseInterfaces.Select(x => x.Name));
    }

    [Fact]
    public void Parse_DeclarationAnnotation_PreservesAnnotation()
    {
        const string idl = "module UMAA { @appendable struct A { long value; }; };";
        var result = new IdlDocumentParser().Parse(idl);
        Assert.True(result.Success);
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        var type = Assert.IsType<IdlStruct>(Assert.Single(module.Declarations));
        Assert.Equal("appendable", Assert.Single(type.Annotations).Name);
    }
}
