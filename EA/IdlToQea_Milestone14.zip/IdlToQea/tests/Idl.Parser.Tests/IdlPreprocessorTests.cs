using Idl.Parser;
using Idl.Parser.PreProcessor;
using Xunit;

namespace Idl.Parser.Tests;

public sealed class IdlPreprocessorTests
{
    [Fact]
    public void Process_UMAAIncludeGuard_KeepsBodyAndMasksDirectives()
    {
        const string input = """
            #ifndef UMAA_SAMPLE_IDL
            #define UMAA_SAMPLE_IDL
            module UMAA { struct Sample { long value; }; };
            #endif
            """;

        var result = new IdlPreprocessor().Process(input, "Sample.idl");

        Assert.True(result.Success);
        Assert.Contains("module UMAA", result.Content);
        Assert.DoesNotContain("#ifndef", result.Content);
        Assert.DoesNotContain("#define", result.Content);
        Assert.DoesNotContain("#endif", result.Content);
        Assert.Equal(input.Count(c => c == '\n') + 1, result.Content.Count(c => c == '\n'));
    }

    [Fact]
    public void Process_DuplicateGuard_BlockBecomesInactive()
    {
        const string input = """
            #ifndef UMAA_SAMPLE_IDL
            #define UMAA_SAMPLE_IDL
            module First { struct A { long value; }; };
            #endif
            #ifndef UMAA_SAMPLE_IDL
            module Duplicate { struct B { long value; }; };
            #endif
            """;

        var result = new IdlPreprocessor().Process(input);

        Assert.True(result.Success);
        Assert.Contains("module First", result.Content);
        Assert.DoesNotContain("module Duplicate", result.Content);
    }

    [Fact]
    public void Process_Include_IsMaskedButNotExpanded()
    {
        const string input = """
            #include "Common.idl"
            module UMAA { struct Sample { long value; }; };
            """;

        var result = new IdlPreprocessor().Process(input);

        Assert.True(result.Success);
        Assert.DoesNotContain("#include", result.Content);
        Assert.Contains("module UMAA", result.Content);
    }

    [Fact]
    public void Process_UnsupportedDirective_ReportsDiagnostic()
    {
        const string input = """
            #ifdef SOMETHING
            module UMAA { struct Sample { long value; }; };
            #endif
            """;

        var result = new IdlPreprocessor().Process(input, "Sample.idl");

        Assert.False(result.Success);
        Assert.Contains(result.Diagnostics, x => x.Code == "IDLPP001");
    }

    [Fact]
    public void Process_MissingEndif_ReportsDiagnostic()
    {
        const string input = """
            #ifndef UMAA_SAMPLE_IDL
            #define UMAA_SAMPLE_IDL
            module UMAA { struct Sample { long value; }; };
            """;

        var result = new IdlPreprocessor().Process(input, "Sample.idl");

        Assert.False(result.Success);
        Assert.Contains(result.Diagnostics, x => x.Code == "IDLPP004");
    }

    [Fact]
    public void Parser_ParsesDocumentWithUMAAIncludeGuard()
    {
        const string input = """
            #ifndef UMAA_SAMPLE_IDL
            #define UMAA_SAMPLE_IDL
            #include "Common.idl"
            module UMAA {
                struct Sample { long value; };
            };
            #endif
            """;

        var result = new IdlDocumentParser().Parse(input, "Sample.idl");

        Assert.True(result.Success);
        Assert.Single(result.Document.Declarations);
    }
}
