using Idl.Models.Declarations;
using Idl.Models.Sources;
using Xunit;

namespace Idl.Parser.Tests;

public sealed class IdlDdsCompatibilityTests
{
    [Fact]
    public void Parse_FieldAnnotations_PreservesKeyAndOptional()
    {
        const string idl = """
            module UMAA {
                struct Track {
                    @key long id;
                    @optional string<64> label;
                };
            };
            """;

        var result = new IdlDocumentParser().Parse(idl);

        Assert.True(result.Success, string.Join(Environment.NewLine, result.Diagnostics.Select(x => x.Message)));
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        var type = Assert.IsType<IdlStruct>(Assert.Single(module.Declarations));
        Assert.Equal("key", Assert.Single(type.Fields[0].Annotations).Name);
        Assert.Equal("optional", Assert.Single(type.Fields[1].Annotations).Name);
        Assert.Equal("64", type.Fields[1].Type.BoundExpression);
    }

    [Fact]
    public void Parse_SetMapAndWString_BuildsStructuredTypes()
    {
        const string idl = """
            module UMAA {
                typedef set<::UMAA::Common::TrackType, 32> TrackSet;
                typedef map<long, ::UMAA::Common::TrackType, 64> TrackMap;
                typedef wstring<128> DisplayName;
            };
            """;

        var result = new IdlDocumentParser().Parse(idl);

        Assert.True(result.Success, string.Join(Environment.NewLine, result.Diagnostics.Select(x => x.Message)));
        var module = Assert.IsType<IdlModule>(Assert.Single(result.Document.Declarations));
        var set = Assert.IsType<IdlTypedef>(module.Declarations[0]);
        var map = Assert.IsType<IdlTypedef>(module.Declarations[1]);
        var wstring = Assert.IsType<IdlTypedef>(module.Declarations[2]);

        Assert.Equal(IdlTypeKind.Set, set.UnderlyingType.Kind);
        Assert.Equal("32", set.UnderlyingType.BoundExpression);
        Assert.Equal(IdlTypeKind.Map, map.UnderlyingType.Kind);
        Assert.Equal("long", map.UnderlyingType.KeyType!.Name);
        Assert.Equal("::UMAA::Common::TrackType", map.UnderlyingType.ElementType!.Name);
        Assert.Equal("64", map.UnderlyingType.BoundExpression);
        Assert.Equal(IdlTypeKind.WString, wstring.UnderlyingType.Kind);
        Assert.Equal("128", wstring.UnderlyingType.BoundExpression);
    }

    [Fact]
    public void Build_StructInheritanceAndMapTypes_ResolveAcrossFiles()
    {
        var sources = new IdlSourceSet();
        sources.AddFile(new IdlSourceFile("Common.idl", """
            module UMAA { module Common {
                struct Base { long id; };
                struct TrackType { long id; };
            }; };
            """));
        sources.AddFile(new IdlSourceFile("Feature.idl", """
            module UMAA { module Feature {
                struct Derived : ::UMAA::Common::Base {
                    map<long, ::UMAA::Common::TrackType> tracks;
                };
            }; };
            """));

        var builder = new IdlModelBuilder();
        var model = builder.Build(sources);

        Assert.True(builder.Success, string.Join(Environment.NewLine, builder.Diagnostics.Select(x => x.Message)));
        var derived = Assert.IsType<IdlStruct>(builder.Symbols["::UMAA::Feature::Derived"]);
        Assert.Equal("::UMAA::Common::Base", derived.BaseType!.ResolvedScopedName);
        Assert.Equal("::UMAA::Common::TrackType", Assert.Single(derived.Fields).Type.ElementType!.ResolvedScopedName);
    }
}
