using Idl.Models.Declarations;
using Idl.Models.Sources;
using Xunit;

namespace Idl.Parser.Tests;

public sealed class IdlModelBuilderTests
{
    [Fact]
    public void Build_MultipleFiles_ResolvesAbsoluteAndRelativeTypes()
    {
        var sources = new IdlSourceSet();
        sources.AddFile(new IdlSourceFile("Common/Types.idl", """
            module UMAA { module Common { struct TrackType { long id; }; }; };
            """));
        sources.AddFile(new IdlSourceFile("Vehicle/Vehicle.idl", """
            module UMAA { module Vehicle {
                struct VehicleState {
                    ::UMAA::Common::TrackType absoluteTrack;
                    CommonAlias relativeTrack;
                };
                typedef ::UMAA::Common::TrackType CommonAlias;
            }; };
            """));

        var builder = new IdlModelBuilder();
        var model = builder.Build(sources);

        Assert.True(builder.Success, string.Join(Environment.NewLine, builder.Diagnostics.Select(x => x.Message)));
        Assert.Contains("::UMAA::Common::TrackType", builder.Symbols.Keys);
        Assert.Contains("::UMAA::Vehicle::VehicleState", builder.Symbols.Keys);
        var vehicle = Assert.IsType<IdlStruct>(builder.Symbols["::UMAA::Vehicle::VehicleState"]);
        Assert.Equal("::UMAA::Common::TrackType", vehicle.Fields[0].Type.ResolvedScopedName);
        Assert.Equal("::UMAA::Vehicle::CommonAlias", vehicle.Fields[1].Type.ResolvedScopedName);
    }

    [Fact]
    public void Build_UnresolvedType_ProducesDiagnostic()
    {
        var sources = new IdlSourceSet();
        sources.AddFile(new IdlSourceFile("Broken.idl", "module UMAA { struct A { MissingType value; }; };"));

        var builder = new IdlModelBuilder();
        var model = builder.Build(sources);

        Assert.False(builder.Success);
        Assert.Contains(builder.Diagnostics, x => x.Code == "IDL2002" && x.Message.Contains("MissingType"));
    }

    [Fact]
    public void Build_SameModuleAcrossFiles_MergesNamespaceForResolution()
    {
        var sources = new IdlSourceSet();
        sources.AddFile(new IdlSourceFile("A.idl", "module UMAA { struct A { long value; }; };"));
        sources.AddFile(new IdlSourceFile("B.idl", "module UMAA { struct B { A value; }; };"));

        var builder = new IdlModelBuilder();
        var model = builder.Build(sources);

        Assert.True(builder.Success);
        var b = Assert.IsType<IdlStruct>(builder.Symbols["::UMAA::B"]);
        Assert.Equal("::UMAA::A", Assert.Single(b.Fields).Type.ResolvedScopedName);
    }
}
