#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /path/to/umaa-6.0-idl-with-exp-services.zip" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
dotnet run --project "$ROOT/tools/Umaa.Acceptance/Umaa.Acceptance.csproj" -- "$1"
