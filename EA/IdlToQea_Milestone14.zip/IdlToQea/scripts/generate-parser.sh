#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /path/to/antlr-4.13.1-complete.jar" >&2
  exit 2
fi
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JAR="$(realpath "$1")"
OUT="$ROOT/src/Idl.Parser/Grammar/Generated"
rm -rf "$OUT"
mkdir -p "$OUT"
cd "$ROOT/src/Idl.Parser"
java -jar "$JAR" -Dlanguage=CSharp -visitor -no-listener -o Grammar/Generated Grammar/IDL.g4
