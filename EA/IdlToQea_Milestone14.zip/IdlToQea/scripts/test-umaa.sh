#!/usr/bin/env bash
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 /path/to/umaa-6.0-idl-with-exp-services.zip" >&2
  exit 2
fi

ZIP_PATH="$(realpath "$1")"
if [[ ! -f "$ZIP_PATH" ]]; then
  echo "UMAA ZIP not found: $ZIP_PATH" >&2
  exit 2
fi

export UMAA_IDL_ZIP="$ZIP_PATH"
dotnet restore
dotnet build --no-restore
dotnet test --no-build --filter 'Category=UMAA-Acceptance'
