# Milestone 13 - Simplified Root Model

## Goal
Keep the architecture minimal for the UMAA-only target.

## Changes
- Removed `IdlSemanticModel` from the production model layer.
- Replaced `IdlSemanticModelBuilder` with `IdlModelBuilder`.
- `IdlModelBuilder.Build(...)` now returns the merged root `IdlModule("UMAA")`.
- Symbol table, diagnostics, and document counts remain build-time state on `IdlModelBuilder` only.
- Source paths are preserved on declarations and on the merged module tree.
- `EaModelGenerator.Generate(...)` now accepts `IdlModule` directly.

## Final production flow

```text
UMAA ZIP/IDL
  -> IdlSourceWorkspace
  -> IdlModelBuilder
  -> IdlModule (UMAA)
  -> EaModelGenerator
  -> EA.Repository
  -> QEA
```

## Verification
- UMAA IDL files: 594 / 594
- Includes: 1705 / 1705
- Symbols: 858
- Semantic errors: 0
- EA semantic elements: 1482
- Source artifacts: 594
- Automation tests: 12 / 12 PASS
