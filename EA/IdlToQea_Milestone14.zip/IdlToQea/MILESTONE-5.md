# Milestone 5 - DDS/UMAA compatibility expansion

## Added
- Field-level annotation preservation (`@key`, `@optional`, etc.)
- Struct inheritance model and semantic resolution
- Structured `set<T, N>`, `map<K, V, N>`, and `wstring<N>` types
- Recursive semantic resolution for sequence/set/map content types
- Focused parser/semantic tests for the new behavior

## Validation boundary
The official UMAA 6.0 ZIP could not be fetched from the current environment (HTTP 502), so this milestone does not claim full UMAA compatibility yet.
