# Refactor Notes

## Purpose

This version keeps the folder structure organized around layout, panel, view, and reusable components, while keeping the MVP implementation simple.

## Applied structure

- `layouts/`: application and workspace layout
- `panels/`: tab groups for each workspace area
- `views/`: actual tab content, grouped by area
  - `views/explorer/`
  - `views/workspace/`
  - `views/inspector/`
- `components/`: reusable UI parts

## MVP decision

`ModelView.jsx` uses Ant Design `DirectoryTree` directly.

The following were intentionally not introduced yet:

- `ModelTree.jsx`
- `ModelTreeNode.jsx`
- tree node tags/icons
- search/filter UI
- context menu
- drag and drop
- inline rename

These can be added later only when the MVP grows enough to justify extra component boundaries.

## Build

Verified with:

```bash
npm ci
npm run build
```
