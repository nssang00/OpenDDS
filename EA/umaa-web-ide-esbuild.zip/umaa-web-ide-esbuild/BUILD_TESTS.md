# 빌드/검증 기록

2026-11-04 기준

- `npm run check:static`: **PASS**. HTML 상대경로, IIFE 설정, Vite 제거, 서버 미구동, Mock Repository 저장소 fallback 확인.
- `npm run check:core`: **PASS**. 도메인 모델·Endpoint 계산·Validation·Code Generator의 TypeScript 검사.
- `src/` 내 TS/TSX 파일 19개의 TypeScript transpile syntax 검사: **PASS**.
- `node --check scripts/build.mjs`: **PASS**.
- `node --check scripts/verify-static.mjs`: **PASS**.
- `npm install`: **실패(네트워크 시간 초과)**. 실행 환경에서 npm Registry 접근 불가.
- `npm run build`와 `npm run typecheck`: 필요한 React/esbuild 패키지를 설치하지 못해 **최종 번들 생성/브라우저 실행 미검증**.
- 배포본에 `dist/` 및 `node_modules/` 미포함. 패키지 설치 가능한 PC에서 `npm install && npm run build` 필요.

주의: 코드 생성 결과의 C++ 공유 라이브러리는 DDS 미연결 골격입니다. 정적 프런트엔드 빌드가 곧 UMAA 통신/규격 인증을 뜻하지 않습니다.
