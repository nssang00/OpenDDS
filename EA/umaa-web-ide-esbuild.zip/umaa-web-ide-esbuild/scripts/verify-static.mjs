import { readFileSync, existsSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const html = readFileSync(resolve(root, 'index.html'), 'utf8');
const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));
const source = readFileSync(resolve(root, 'src/repository/mockRepository.ts'), 'utf8');
const buildScript = readFileSync(resolve(root, 'scripts/build.mjs'), 'utf8');
const tests = [
  ['정적 HTML의 JS 번들 경로', html.includes('src="./dist/main.js"')],
  ['정적 HTML의 CSS 번들 경로', html.includes('href="./dist/main.css"')],
  ['브라우저 ESM import 없음', !/<script[^>]+type="module"/.test(html)],
  ['Vite 제거', !('vite' in pkg.devDependencies) && !existsSync(resolve(root,'vite.config.ts'))],
  ['esbuild 사용', Boolean(pkg.devDependencies.esbuild) && buildScript.includes("format: 'iife'")],
  ['런타임 서버 시작 없음', !/servedir|serve\(/.test(buildScript)],
  ['Mock Repository', source.includes('MockProjectRepository')],
  ['file:// 저장소 예외 처리', source.includes('volatileStorage')],
];
for (const [name, ok] of tests) console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}`);
if (tests.some(([, ok]) => !ok)) process.exitCode = 1;
