import { useMemo, useState } from 'react';
import { Button, Descriptions, Divider, Empty, Form, Input, Modal, Select, Space, Table, Tag, Typography, message } from 'antd';
import { DeleteOutlined, PlusOutlined } from '@ant-design/icons';
import type { FieldType, FlowControl, Role } from '../model/types';
import { useEditorStore } from '../stores/useEditorStore';
import { deriveEndpoints } from '../logic/endpoints';

const { Text, Title } = Typography;

export function Inspector() {
  const s = useEditorStore(x => x.snapshot);
  const selection = useEditorStore(x => x.selection);
  const select = useEditorStore(x => x.select);
  const addBinding = useEditorStore(x => x.addBinding);
  const removeBinding = useEditorStore(x => x.removeBinding);
  const removeConnection = useEditorStore(x => x.removeConnection);
  const addField = useEditorStore(x => x.addMessageField);
  const removeField = useEditorStore(x => x.removeMessageField);
  const [bindingModal, setBindingModal] = useState(false);
  const [fieldModal, setFieldModal] = useState(false);
  const [bindingForm] = Form.useForm();
  const [fieldForm] = Form.useForm();
  const entity = useMemo(() => {
    if (!s || !selection) return null;
    if (selection.kind === 'component') return s.components.find(v => v.id === selection.id);
    if (selection.kind === 'service') return s.services.find(v => v.id === selection.id);
    if (selection.kind === 'binding') return s.bindings.find(v => v.id === selection.id);
    if (selection.kind === 'connection') return s.connections.find(v => v.id === selection.id);
    if (selection.kind === 'message') return s.messages.find(v => v.id === selection.id);
    return null;
  }, [s, selection]);
  if (!s || !selection || !entity) return <div className="inspector"><Empty description="Component 또는 Service를 선택하세요" image={Empty.PRESENTED_IMAGE_SIMPLE} /></div>;

  const binding = selection.kind === 'binding' ? s.bindings.find(b => b.id === selection.id) : undefined;
  const component = selection.kind === 'component' ? s.components.find(c => c.id === selection.id) : undefined;
  const service = selection.kind === 'service' ? s.services.find(v => v.id === selection.id) : undefined;
  const msg = selection.kind === 'message' ? s.messages.find(m => m.id === selection.id) : undefined;
  const connection = selection.kind === 'connection' ? s.connections.find(c => c.id === selection.id) : undefined;

  return <div className="inspector">
    <Text type="secondary" className="side-label">PROPERTIES</Text>
    {component && <>
      <Title level={5}>{component.name}</Title>
      <Text type="secondary">{component.description || 'Component의 구현 단위입니다.'}</Text>
      <Divider orientation="left">Service Bindings</Divider>
      <Space direction="vertical" style={{ width: '100%' }} size="small">
        {s.bindings.filter(b => b.componentId === component.id).map(b => {
          const svc = s.services.find(x => x.id === b.serviceId);
          return <div key={b.id} className="inspector-binding clickable-row" onClick={() => select({ kind: 'binding', id: b.id })}>
            <span>{svc?.name ?? 'Unknown'}</span><Tag color={b.role === 'provider' ? 'blue' : 'orange'}>{b.role === 'provider' ? 'Provider' : 'Consumer'}</Tag>
          </div>;
        })}
        <Button block icon={<PlusOutlined />} onClick={() => { bindingForm.resetFields(); setBindingModal(true); }}>Service Binding 추가</Button>
      </Space>
      <Divider orientation="left">DDS Endpoints (파생)</Divider>
      <Table size="small" pagination={false} rowKey={e => `${e.bindingId}-${e.direction}-${e.topicName}`} dataSource={deriveEndpoints(s, component.id)} columns={[
        { title: 'Topic', dataIndex: 'topicName', ellipsis: true },
        { title: '방향', dataIndex: 'direction', width: 82, render: (v: string) => <Tag color={v === 'writer' ? 'blue' : 'orange'}>{v}</Tag> },
      ]} />
      <Text type="secondary" className="small-hint">Writer/Reader는 선택한 Service의 Operation과 역할에서 자동 계산됩니다. 실제 DDS 엔티티는 아직 생성되지 않습니다.</Text>
    </>}

    {service && <>
      <Title level={5}>{service.name}</Title>
      <Space wrap><Tag color={service.source === 'standard' ? 'blue' : 'purple'}>{service.source === 'standard' ? 'UMAA Standard' : 'Custom'}</Tag><Tag>{service.functionalArea}</Tag><Tag>{service.flowControl}</Tag></Space>
      <p className="property-description">{service.description}</p>
      <Descriptions column={1} size="small" bordered>
        <Descriptions.Item label="Namespace"><Text code copyable>{service.namespace}</Text></Descriptions.Item>
        <Descriptions.Item label="Version">{service.version}</Descriptions.Item>
      </Descriptions>
      <Divider orientation="left">Operations</Divider>
      <Table size="small" pagination={false} dataSource={s.operations.filter(op => op.serviceId === service.id)} rowKey="id" columns={[
        { title: 'Operation', dataIndex: 'name', ellipsis: true },
        { title: 'Action', dataIndex: 'action', width: 88 },
        { title: 'Role', dataIndex: 'actor', width: 90 },
      ]} expandable={{ expandedRowRender: op => {
        const topic = s.topics.find(t => t.id === op.topicId);
        const m = s.messages.find(t => t.id === topic?.messageTypeId);
        return <div><Text>Topic: {topic?.name ?? 'N/A'}</Text><br/><Text>Message: </Text>{m ? <Button type="link" size="small" onClick={() => select({ kind: 'message', id: m.id })}>{m.name}</Button> : 'N/A'}</div>;
      } }} />
      <Divider orientation="left">Messages</Divider>
      {s.messages.filter(m => s.topics.some(t => t.messageTypeId === m.id && s.operations.some(op => op.topicId === t.id && op.serviceId === service.id))).map(m =>
        <div className="inspector-binding clickable-row" key={m.id} onClick={() => select({ kind: 'message', id: m.id })}>{m.name}<Tag>{m.source === 'standard' ? 'Official IDL' : 'Custom IDL'}</Tag></div>)}
      {service.source === 'standard' && <Text type="secondary" className="small-hint">표준 Service는 읽기 전용입니다. Operation과 Message 정보는 공식 UMAA IDL/ICD를 기준으로 유지합니다.</Text>}
    </>}

    {binding && <>
      <Title level={5}>Service Binding</Title>
      <Descriptions size="small" bordered column={1}>
        <Descriptions.Item label="Component">{s.components.find(c => c.id === binding.componentId)?.name}</Descriptions.Item>
        <Descriptions.Item label="Service">{s.services.find(svc => svc.id === binding.serviceId)?.name}</Descriptions.Item>
        <Descriptions.Item label="Role"><Tag color={binding.role === 'provider' ? 'blue' : 'orange'}>{binding.role}</Tag></Descriptions.Item>
      </Descriptions>
      <p className="small-hint">React Flow에서 Provider Handle을 같은 Service의 Consumer Handle로 드래그해 연결합니다.</p>
      <Button danger icon={<DeleteOutlined />} block onClick={() => removeBinding(binding.id)}>Binding 제거</Button>
    </>}

    {connection && <>
      <Title level={5}>Service Connection</Title>
      <Descriptions size="small" bordered column={1}>
        <Descriptions.Item label="Provider">{s.components.find(c => c.id === s.bindings.find(b => b.id === connection.providerBindingId)?.componentId)?.name}</Descriptions.Item>
        <Descriptions.Item label="Consumer">{s.components.find(c => c.id === s.bindings.find(b => b.id === connection.consumerBindingId)?.componentId)?.name}</Descriptions.Item>
        <Descriptions.Item label="Service">{s.services.find(svc => svc.id === s.bindings.find(b => b.id === connection.providerBindingId)?.serviceId)?.name}</Descriptions.Item>
      </Descriptions>
      <p className="small-hint">이 Edge는 설계상의 서비스 소비 관계입니다. DDS의 실제 주소 지정이나 전용 Point-to-Point 채널이 아닙니다.</p>
      <Button danger icon={<DeleteOutlined />} block onClick={() => removeConnection(connection.id)}>Connection 제거</Button>
    </>}

    {msg && <>
      <Title level={5}>{msg.name}</Title>
      <Space wrap><Tag color={msg.source === 'standard' ? 'blue' : 'purple'}>{msg.source === 'standard' ? 'Official UMAA IDL' : 'Custom IDL'}</Tag></Space>
      <p><Text code copyable>{msg.namespace}</Text></p>
      {msg.source === 'standard' ? <>
        <Text type="secondary">표준 필드 목록을 임의로 재구성하지 않았습니다. 실제 프로젝트에서는 공식 UMAA 6.0 IDL에서 필드·Key·Optional을 읽어와 표시해야 합니다.</Text>
        <p><Text code>{msg.externalIdlPath}</Text></p>
      </> : <>
        <Table rowKey="name" size="small" pagination={false} dataSource={msg.fields} columns={[
          { title: 'Field', dataIndex: 'name' }, { title: 'Type', dataIndex: 'type', width: 80 },
          { title: '', width: 32, render: (_, r) => <Button type="text" danger size="small" icon={<DeleteOutlined />} onClick={() => removeField(msg.id, r.name)} /> },
        ]} />
        <Button block icon={<PlusOutlined />} onClick={() => { fieldForm.resetFields(); setFieldModal(true); }}>Field 추가</Button>
      </>}
    </>}

    <Modal title="Service Binding 추가" open={bindingModal} okText="추가" onCancel={() => setBindingModal(false)} onOk={async () => {
      try { const v = await bindingForm.validateFields() as { serviceId: string; role: Role };
        if (component && addBinding(component.id, v.serviceId, v.role)) { setBindingModal(false); message.success('Binding을 추가했습니다.'); }
        else message.warning('중복되었거나 잘못된 Binding입니다.');
      } catch { /* AntD form indicates validation errors */ }
    }} destroyOnClose>
      <Form form={bindingForm} layout="vertical" initialValues={{ role: 'consumer' }}>
        <Form.Item label="Service" name="serviceId" rules={[{ required: true, message: 'Service를 선택하세요' }]}>
          <Select showSearch optionFilterProp="label" options={s.services.map(v => ({ label: `${v.name} (${v.source})`, value: v.id }))} />
        </Form.Item>
        <Form.Item label="Role" name="role" rules={[{ required: true }]}>
          <Select options={[{ label: 'Provider', value: 'provider' }, { label: 'Consumer', value: 'consumer' }]} />
        </Form.Item>
      </Form>
    </Modal>
    <Modal title="Custom Message Field 추가" open={fieldModal} okText="추가" onCancel={() => setFieldModal(false)} onOk={async () => {
      try { const v = await fieldForm.validateFields() as { name: string; type: FieldType };
        if (msg && addField(msg.id, v.name, v.type)) { setFieldModal(false); message.success('Field가 추가되었습니다.'); }
        else message.warning('필드명 중복 또는 식별자 오류');
      } catch { /* AntD form handles field errors */ }
    }} destroyOnClose>
      <Form form={fieldForm} layout="vertical" initialValues={{ type: 'double' }}>
        <Form.Item label="Field Name" name="name" rules={[{ required: true }, { pattern: /^[A-Za-z_][A-Za-z0-9_]*$/, message: 'IDL 식별자를 사용하세요' }]}><Input /></Form.Item>
        <Form.Item label="IDL Type" name="type"><Select options={(['string', 'long', 'double', 'boolean'] as FieldType[]).map(t => ({ label: t, value: t }))}/></Form.Item>
      </Form>
    </Modal>
  </div>;
}

export type CustomServiceInput = { name: string; flow: FlowControl };
