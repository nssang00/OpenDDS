import { Empty, Tree, Typography, Tag } from 'antd';
import { ApartmentOutlined, ApiOutlined, FolderOpenOutlined, LinkOutlined } from '@ant-design/icons';
import type { DataNode } from 'antd/es/tree';
import { useMemo } from 'react';
import { useEditorStore } from '../stores/useEditorStore';

export function ProjectExplorer() {
  const snapshot = useEditorStore(s => s.snapshot);
  const select = useEditorStore(s => s.select);
  const selected = useEditorStore(s => s.selection);
  const tree = useMemo<DataNode[]>(() => !snapshot ? [] : [{
    key: 'project', title: <b>{snapshot.project.name}</b>, icon: <FolderOpenOutlined />,
    children: [{ key: 'components-folder', title: 'Components', icon: <ApartmentOutlined />, children:
      snapshot.components.map(c => ({
        key: `component:${c.id}`, title: c.name, icon: <ApartmentOutlined />,
        children: snapshot.bindings.filter(b => b.componentId === c.id).map(b => ({
          key: `binding:${b.id}`, icon: <ApiOutlined />,
          title: <span>{snapshot.services.find(s => s.id === b.serviceId)?.name ?? 'Unknown'} <Tag color={b.role === 'provider' ? 'blue' : 'orange'} style={{ margin: 0 }}>{b.role === 'provider' ? 'P' : 'C'}</Tag></span>,
        })),
      })),
    }, { key: 'connections-folder', title: 'Connections', icon: <LinkOutlined />, children: snapshot.connections.map(c => ({
      key: `connection:${c.id}`, title: snapshot.services.find(v => v.id === snapshot.bindings.find(b => b.id === c.providerBindingId)?.serviceId)?.name ?? 'Service', icon: <LinkOutlined />,
    })) }],
  }], [snapshot]);
  if (!snapshot) return <Empty description="프로젝트 로딩 중" />;
  const key = selected ? `${selected.kind}:${selected.id}` : '';
  return <div className="sidebar-section">
    <Typography.Text type="secondary" className="side-label">PROJECT EXPLORER</Typography.Text>
    <Tree showIcon showLine defaultExpandAll blockNode treeData={tree} selectedKeys={key ? [key] : []}
      onSelect={keys => {
        const raw = String(keys[0] ?? ''); const idx = raw.indexOf(':');
        if (idx < 0) return;
        const kind = raw.slice(0, idx);
        if (kind === 'component' || kind === 'binding' || kind === 'connection') select({ kind, id: raw.slice(idx + 1) });
      }} />
  </div>;
}
