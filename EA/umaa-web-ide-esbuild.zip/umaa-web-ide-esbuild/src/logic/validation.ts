import type { ValidationIssue, WorkspaceSnapshot } from '../model/types';

export function validateWorkspace(s: WorkspaceSnapshot): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const error = (code: string, message: string, entityId?: string) => issues.push({ severity: 'error', code, message, entityId });
  const warn = (code: string, message: string, entityId?: string) => issues.push({ severity: 'warning', code, message, entityId });

  for (const b of s.bindings) {
    if (!s.components.some(c => c.id === b.componentId)) error('MISSING_COMPONENT', `Binding ${b.id}의 Component가 없습니다.`, b.id);
    if (!s.services.some(v => v.id === b.serviceId)) error('MISSING_SERVICE', `Binding ${b.id}의 Service가 없습니다.`, b.id);
  }
  for (const op of s.operations) {
    if (!s.services.some(v => v.id === op.serviceId)) error('MISSING_SERVICE', `Operation ${op.name}의 Service가 없습니다.`, op.id);
    if (!s.topics.some(t => t.id === op.topicId)) error('MISSING_TOPIC', `Operation ${op.name}의 Topic이 없습니다.`, op.id);
  }
  for (const t of s.topics) {
    if (!s.messages.some(m => m.id === t.messageTypeId)) error('MISSING_TYPE', `Topic ${t.name}의 Message Type이 없습니다.`, t.id);
  }
  for (const svc of s.services) {
    if (!s.operations.some(o => o.serviceId === svc.id)) error('EMPTY_SERVICE', `Service ${svc.name}에 Operation이 없습니다.`, svc.id);
  }
  for (const m of s.messages.filter(m => m.source === 'custom')) {
    if (m.fields.length === 0) error('EMPTY_MESSAGE', `Custom Message ${m.name}에 Field가 없습니다.`, m.id);
    const names = new Set<string>();
    for (const field of m.fields) {
      if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(field.name)) error('INVALID_FIELD', `${m.name}.${field.name}는 IDL 식별자로 적합하지 않습니다.`, m.id);
      if (names.has(field.name)) error('DUPLICATE_FIELD', `${m.name}.${field.name} 필드가 중복되었습니다.`, m.id);
      names.add(field.name);
      if (field.key && field.optional) error('INVALID_KEY', `${m.name}.${field.name}는 Key와 Optional을 동시에 지정할 수 없습니다.`, m.id);
    }
  }
  for (const c of s.connections) {
    const p = s.bindings.find(b => b.id === c.providerBindingId);
    const u = s.bindings.find(b => b.id === c.consumerBindingId);
    if (!p || !u) error('ORPHAN_CONNECTION', `연결 ${c.id}의 Binding이 없습니다.`, c.id);
    else if (p.role !== 'provider' || u.role !== 'consumer' || p.serviceId !== u.serviceId) {
      error('INVALID_CONNECTION', `연결 ${c.id}: 동일 Service의 Provider → Consumer만 허용합니다.`, c.id);
    }
  }
  for (const b of s.bindings.filter(b => b.role === 'consumer')) {
    if (!s.connections.some(c => c.consumerBindingId === b.id)) {
      const svc = s.services.find(v => v.id === b.serviceId);
      warn('UNCONNECTED_CONSUMER', `${svc?.name || b.serviceId} Consumer가 Provider에 연결되지 않았습니다.`, b.id);
    }
  }
  for (const b of s.bindings.filter(b => b.role === 'provider')) {
    if (!s.connections.some(c => c.providerBindingId === b.id)) {
      const svc = s.services.find(v => v.id === b.serviceId);
      warn('UNUSED_PROVIDER', `${svc?.name || b.serviceId} Provider에 연결된 Consumer가 없습니다.`, b.id);
    }
  }
  return issues;
}

export function canConnect(s: WorkspaceSnapshot, sourceBindingId: string, targetBindingId: string): boolean {
  const a = s.bindings.find(b => b.id === sourceBindingId);
  const b = s.bindings.find(b => b.id === targetBindingId);
  return Boolean(a && b && a.role === 'provider' && b.role === 'consumer' && a.serviceId === b.serviceId && a.componentId !== b.componentId && !s.connections.some(c => c.providerBindingId === a.id && c.consumerBindingId === b.id));
}
