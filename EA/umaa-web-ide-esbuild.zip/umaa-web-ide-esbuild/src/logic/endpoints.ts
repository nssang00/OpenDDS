import type { Role, WorkspaceSnapshot } from '../model/types';

export interface Endpoint {
  bindingId: string;
  serviceId: string;
  serviceName: string;
  role: Role;
  direction: 'writer' | 'reader';
  topicName: string;
  typeName: string;
  messageTypeId: string;
  operations: string[];
  optional: boolean;
}

/**
 * Derive logical DDS endpoints from service operations and a binding role.
 * It deliberately does not construct a vendor DDS Entity; that requires an SDK.
 */
export function deriveEndpoints(snapshot: WorkspaceSnapshot, componentId: string): Endpoint[] {
  const endpoints: Endpoint[] = [];
  const componentBindings = snapshot.bindings.filter(b => b.componentId === componentId);
  for (const binding of componentBindings) {
    const service = snapshot.services.find(s => s.id === binding.serviceId);
    if (!service) continue;
    for (const op of snapshot.operations.filter(o => o.serviceId === service.id)) {
      const topic = snapshot.topics.find(t => t.id === op.topicId);
      if (!topic) continue;
      const msg = snapshot.messages.find(m => m.id === topic.messageTypeId);
      if (!msg) continue;
      let direction: 'writer' | 'reader' | undefined;
      if (op.action === 'publish') direction = op.actor === binding.role ? 'writer' : 'reader';
      else if (op.action === 'subscribe' && op.actor === binding.role) direction = 'reader';
      else if (op.action === 'dispose') direction = op.actor === binding.role ? 'writer' : 'reader';
      if (!direction) continue;
      const prev = endpoints.find(e => e.bindingId === binding.id && e.direction === direction && e.topicName === topic.name);
      if (prev) {
        if (!prev.operations.includes(op.name)) prev.operations.push(op.name);
        prev.optional = prev.optional && Boolean(op.optionalConsumer && binding.role === 'consumer');
      } else {
        endpoints.push({
          bindingId: binding.id, serviceId: service.id, serviceName: service.name,
          role: binding.role, direction, topicName: topic.name,
          typeName: msg.name, messageTypeId: msg.id, operations: [op.name],
          optional: Boolean(op.optionalConsumer && binding.role === 'consumer'),
        });
      }
    }
  }
  return endpoints;
}
