import { seedWorkspace } from '../model/seed';
import { parseWorkspaceImport } from '../model/validateImport';
import type { WorkspaceSnapshot } from '../model/types';
import type { ProjectRepository } from './ProjectRepository';

const storageKey = (projectId: string) => `umaa-mock-v1:${projectId}`;
const wait = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));
const clone = <T,>(v: T): T => structuredClone(v);
const volatileStorage = new Map<string, string>();

/** file:// pages can have an opaque origin; the browser may deny localStorage access. */
export function canPersistLocally(): boolean {
  try {
    const key = '__umaa_static_storage_probe__';
    window.localStorage.setItem(key, '1');
    window.localStorage.removeItem(key);
    return true;
  } catch {
    return false;
  }
}

function getSaved(key: string): string | null {
  try { return window.localStorage.getItem(key) ?? volatileStorage.get(key) ?? null; }
  catch { return volatileStorage.get(key) ?? null; }
}
function setSaved(key: string, value: string): void {
  volatileStorage.set(key, value);
  try { window.localStorage.setItem(key, value); } catch { /* volatile fallback */ }
}
function removeSaved(key: string): void {
  volatileStorage.delete(key);
  try { window.localStorage.removeItem(key); } catch { /* volatile fallback */ }
}

export class MockProjectRepository implements ProjectRepository {
  async load(projectId: string): Promise<WorkspaceSnapshot> {
    await wait(80);
    const saved = getSaved(storageKey(projectId));
    if (!saved) return clone(seedWorkspace);
    try { return clone(parseWorkspaceImport(JSON.parse(saved) as unknown)); }
    catch { return clone(seedWorkspace); }
  }
  async save(projectId: string, snapshot: WorkspaceSnapshot): Promise<void> {
    await wait(50);
    setSaved(storageKey(projectId), JSON.stringify(snapshot));
  }
  async reset(projectId: string): Promise<WorkspaceSnapshot> {
    await wait(40);
    removeSaved(storageKey(projectId));
    return clone(seedWorkspace);
  }
}

export const repository: ProjectRepository = new MockProjectRepository();
