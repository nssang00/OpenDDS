import type { WorkspaceSnapshot } from '../model/types';

// This contract remains unchanged when PostgreSQL-backed HTTP APIs replace MockRepository.
export interface ProjectRepository {
  load(projectId: string): Promise<WorkspaceSnapshot>;
  save(projectId: string, snapshot: WorkspaceSnapshot): Promise<void>;
  reset(projectId: string): Promise<WorkspaceSnapshot>;
}
