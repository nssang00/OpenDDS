export type Role = 'provider' | 'consumer';
export type FlowControl = 'request-reply' | 'command-response';
export type SourceKind = 'standard' | 'custom';
export type FieldType = 'string' | 'long' | 'double' | 'boolean';
export type OperationAction = 'publish' | 'subscribe' | 'dispose';

export interface Project {
  id: string;
  name: string;
  standardVersion: string;
  targetPlatform: 'linux' | 'windows';
  ddsVendor: 'fastdds' | 'connext';
}
export interface Component {
  id: string;
  name: string;
  description: string;
}
export interface MessageField {
  name: string;
  type: FieldType;
  key: boolean;
  optional: boolean;
}
export interface MessageType {
  id: string;
  name: string;
  namespace: string;
  source: SourceKind;
  // Standard fields are intentionally NOT fabricated from incomplete metadata.
  fields: MessageField[];
  externalIdlPath?: string;
}
export interface Topic {
  id: string;
  name: string;
  messageTypeId: string;
}
export interface Service {
  id: string;
  name: string;
  functionalArea: string;
  namespace: string;
  source: SourceKind;
  version: string;
  flowControl: FlowControl;
  description: string;
}
export interface Operation {
  id: string;
  serviceId: string;
  name: string;
  topicId: string;
  action: OperationAction;
  actor: Role;
  optionalConsumer?: boolean;
}
export interface ServiceBinding {
  id: string;
  componentId: string;
  serviceId: string;
  role: Role;
}
export interface ServiceConnection {
  id: string;
  providerBindingId: string;
  consumerBindingId: string;
}
export interface Point { x: number; y: number }
export interface WorkspaceSnapshot {
  project: Project;
  components: Component[];
  services: Service[];
  operations: Operation[];
  topics: Topic[];
  messages: MessageType[];
  bindings: ServiceBinding[];
  connections: ServiceConnection[];
  positions: Record<string, Point>;
}
export interface ValidationIssue {
  severity: 'error' | 'warning';
  code: string;
  message: string;
  entityId?: string;
}
export interface GeneratedFile { path: string; content: string }

export const uuid = () => {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) return crypto.randomUUID();
  return `mock-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
};
