import type { WorkspaceSnapshot } from './types';

/** Defensive parsing for a user-selected JSON file (not a UMAA semantic compliance check). */
export function parseWorkspaceImport(value: unknown): WorkspaceSnapshot {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('프로젝트 JSON 객체가 아닙니다.');
  }
  const r = value as Record<string, unknown>;
  const project = r.project as Record<string, unknown> | null;
  if (!project || typeof project !== 'object' ||
      typeof project.id !== 'string' || typeof project.name !== 'string' ||
      typeof project.standardVersion !== 'string' ||
      !['linux', 'windows'].includes(String(project.targetPlatform)) ||
      !['fastdds', 'connext'].includes(String(project.ddsVendor))) {
    throw new Error('프로젝트 설정이 올바르지 않습니다.');
  }
  for (const k of ['components', 'services', 'operations', 'topics', 'messages', 'bindings', 'connections']) {
    if (!Array.isArray(r[k])) throw new Error(`${k} 배열이 없습니다.`);
  }
  if (!r.positions || typeof r.positions !== 'object' || Array.isArray(r.positions)) {
    throw new Error('노드 위치 정보가 없습니다.');
  }
  const rows = (key: string) => r[key] as Record<string, unknown>[];
  for (const k of ['components', 'services', 'operations', 'topics', 'messages', 'bindings', 'connections']) {
    for (const entry of rows(k)) {
      if (!entry || typeof entry !== 'object' || typeof entry.id !== 'string') {
        throw new Error(`${k}에 잘못된 항목이 포함되어 있습니다.`);
      }
    }
  }
  for (const entry of rows('messages')) {
    if (!Array.isArray(entry.fields)) throw new Error('Message Type의 fields가 올바르지 않습니다.');
  }
  for (const entry of rows('bindings')) {
    if (typeof entry.componentId !== 'string' || typeof entry.serviceId !== 'string' ||
        !['provider', 'consumer'].includes(String(entry.role))) {
      throw new Error('Service Binding 정의가 올바르지 않습니다.');
    }
  }
  for (const entry of rows('operations')) {
    if (typeof entry.serviceId !== 'string' || typeof entry.topicId !== 'string' ||
        !['publish','subscribe','dispose'].includes(String(entry.action))) {
      throw new Error('Operation 정의가 올바르지 않습니다.');
    }
  }
  // Defensive structural check only. Business consistency is validated separately.
  return value as WorkspaceSnapshot;
}
