import { create } from 'zustand';
import { repository } from '../repository/mockRepository';
import { parseWorkspaceImport } from '../model/validateImport';
import { canConnect } from '../logic/validation';
import type { Component, FieldType, FlowControl, MessageField, Point, Role, WorkspaceSnapshot } from '../model/types';
import { uuid } from '../model/types';

type Selection = { kind: 'component' | 'service' | 'binding' | 'connection' | 'message'; id: string } | null;

interface EditorState {
  snapshot: WorkspaceSnapshot | null;
  selection: Selection;
  loading: boolean;
  saving: boolean;
  dirty: boolean;
  load: () => Promise<void>;
  save: () => Promise<void>;
  reset: () => Promise<void>;
  importSnapshot: (value: unknown) => void;
  select: (selection: Selection) => void;
  addComponent: (name: string) => void;
  addBinding: (componentId: string, serviceId: string, role: Role) => boolean;
  removeBinding: (bindingId: string) => void;
  addCustomService: (name: string, flow: FlowControl) => boolean;
  addMessageField: (messageId: string, name: string, type: FieldType) => boolean;
  removeMessageField: (messageId: string, name: string) => void;
  connect: (providerBindingId: string, consumerBindingId: string) => boolean;
  removeConnection: (id: string) => void;
  moveComponent: (componentId: string, position: Point) => void;
  changePlatform: (platform: 'linux' | 'windows') => void;
  changeVendor: (vendor: 'fastdds' | 'connext') => void;
}

const projectId = 'demo-usv';
const update = (set: (fn: (s: EditorState) => Partial<EditorState>) => void, transform: (s: WorkspaceSnapshot) => WorkspaceSnapshot) => {
  set(s => s.snapshot ? { snapshot: transform(s.snapshot), dirty: true } : {});
};
const makeField = (name: string, type: FieldType, key = false): MessageField => ({ name, type, key, optional: false });

export const useEditorStore = create<EditorState>((set, get) => ({
  snapshot: null,
  selection: null,
  loading: false,
  saving: false,
  dirty: false,
  async load() {
    set({ loading: true });
    try { const snapshot = await repository.load(projectId); set({ snapshot, dirty: false, selection: null }); }
    finally { set({ loading: false }); }
  },
  async save() {
    const snapshot = get().snapshot;
    if (!snapshot) return;
    set({ saving: true });
    try { await repository.save(projectId, snapshot); set({ dirty: false }); }
    finally { set({ saving: false }); }
  },
  async reset() {
    set({ loading: true });
    try { const snapshot = await repository.reset(projectId); set({ snapshot, dirty: false, selection: null }); }
    finally { set({ loading: false }); }
  },
  importSnapshot(value) {
    const snapshot = parseWorkspaceImport(value);
    set({ snapshot: structuredClone(snapshot), dirty: true, selection: null });
  },
  select(selection) { set({ selection }); },
  addComponent(name) {
    const trimmed = name.trim();
    if (!trimmed) return;
    const component: Component = { id: uuid(), name: trimmed, description: '' };
    update(set, s => ({ ...s, components: [...s.components, component], positions: { ...s.positions, [component.id]: { x: 160 + 80 * s.components.length, y: 130 + 70 * s.components.length } } }));
    set({ selection: { kind: 'component', id: component.id } });
  },
  addBinding(componentId, serviceId, role) {
    const s = get().snapshot;
    if (!s || !s.components.some(c => c.id === componentId) || !s.services.some(v => v.id === serviceId)) return false;
    if (s.bindings.some(b => b.componentId === componentId && b.serviceId === serviceId && b.role === role)) return false;
    const binding = { id: uuid(), componentId, serviceId, role };
    update(set, old => ({ ...old, bindings: [...old.bindings, binding] }));
    set({ selection: { kind: 'binding', id: binding.id } });
    return true;
  },
  removeBinding(bindingId) {
    update(set, s => ({
      ...s,
      bindings: s.bindings.filter(b => b.id !== bindingId),
      connections: s.connections.filter(c => c.providerBindingId !== bindingId && c.consumerBindingId !== bindingId),
    }));
    set({ selection: null });
  },
  addCustomService(name, flow) {
    const s = get().snapshot;
    const trimmed = name.trim();
    if (!s || !/^[A-Za-z][A-Za-z0-9_]*$/.test(trimmed) || s.services.some(x => x.name.toLowerCase() === trimmed.toLowerCase())) return false;
    const sid = uuid();
    const namespace = `ProjectCustom::${trimmed}`;
    const svc = { id: sid, name: trimmed, namespace, functionalArea: 'CUSTOM', source: 'custom' as const, version: '1.0', flowControl: flow, description: '사용자 정의 서비스 (UMAA 표준 서비스 아님)' };
    const messages = [] as WorkspaceSnapshot['messages'];
    const topics = [] as WorkspaceSnapshot['topics'];
    const operations = [] as WorkspaceSnapshot['operations'];
    const make = (suffix: string, fields: MessageField[]) => {
      const typeId = uuid(); const topicId = uuid(); const typeName = `${trimmed}${suffix}Type`;
      messages.push({ id: typeId, name: typeName, namespace, source: 'custom', fields });
      topics.push({ id: topicId, name: typeName, messageTypeId: typeId });
      return topicId;
    };
    if (flow === 'request-reply') {
      const t = make('Report', [makeField('entityId', 'string', true), makeField('value', 'double')]);
      operations.push({ id: uuid(), serviceId: sid, name: 'report' + trimmed, topicId: t, action: 'publish', actor: 'provider' });
      operations.push({ id: uuid(), serviceId: sid, name: 'query' + trimmed, topicId: t, action: 'subscribe', actor: 'consumer' });
    } else {
      const tCommand = make('Command', [makeField('sessionId', 'string', true), makeField('destinationId', 'string'), makeField('targetValue', 'double')]);
      const tStatus = make('CommandStatus', [makeField('sessionId', 'string', true), makeField('status', 'string')]);
      operations.push({ id: uuid(), serviceId: sid, name: 'set' + trimmed, topicId: tCommand, action: 'publish', actor: 'consumer' });
      operations.push({ id: uuid(), serviceId: sid, name: 'report' + trimmed + 'CommandStatus', topicId: tStatus, action: 'publish', actor: 'provider' });
      operations.push({ id: uuid(), serviceId: sid, name: 'cancel' + trimmed, topicId: tCommand, action: 'dispose', actor: 'consumer' });
    }
    update(set, old => ({ ...old, services: [...old.services, svc], topics: [...old.topics, ...topics], messages: [...old.messages, ...messages], operations: [...old.operations, ...operations] }));
    set({ selection: { kind: 'service', id: sid } });
    return true;
  },
  addMessageField(messageId, name, type) {
    const s = get().snapshot;
    const msg = s?.messages.find(m => m.id === messageId);
    if (!msg || msg.source !== 'custom' || !/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(name) || msg.fields.some(f => f.name === name)) return false;
    update(set, old => ({ ...old, messages: old.messages.map(m => m.id === messageId ? { ...m, fields: [...m.fields, makeField(name, type)] } : m) }));
    return true;
  },
  removeMessageField(messageId, name) {
    update(set, s => ({ ...s, messages: s.messages.map(m => m.id === messageId && m.source === 'custom' ? { ...m, fields: m.fields.filter(f => f.name !== name) } : m) }));
  },
  connect(providerBindingId, consumerBindingId) {
    const s = get().snapshot;
    if (!s || !canConnect(s, providerBindingId, consumerBindingId)) return false;
    update(set, old => ({ ...old, connections: [...old.connections, { id: uuid(), providerBindingId, consumerBindingId }] }));
    return true;
  },
  removeConnection(id) {
    update(set, s => ({ ...s, connections: s.connections.filter(c => c.id !== id) }));
    set({ selection: null });
  },
  moveComponent(componentId, position) {
    update(set, s => ({ ...s, positions: { ...s.positions, [componentId]: position } }));
  },
  changePlatform(platform) { update(set, s => ({ ...s, project: { ...s.project, targetPlatform: platform } })); },
  changeVendor(vendor) { update(set, s => ({ ...s, project: { ...s.project, ddsVendor: vendor } })); },
}));
