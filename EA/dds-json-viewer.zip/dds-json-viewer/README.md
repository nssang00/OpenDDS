# DDS JSON Viewer

OMG DDS-JSON 스펙 기반 시각화 툴. Types(UML), QoS(편집 가능), Domains, Participants를 ReactFlow로 표시합니다.

## 시작하기

```bash
npm install
npm run dev      # http://localhost:3000
```

## 빌드

```bash
npm run build    # dist/ 에 번들 생성
npm run preview  # http://localhost:4000 으로 빌드 결과 확인
```

## 구조

```
dds-json-viewer/
├── public/
│   └── index.html
├── src/
│   ├── index.jsx       # 진입점
│   └── App.jsx         # 메인 컴포넌트 (DDS JSON 뷰어 전체)
├── scripts/
│   ├── dev.js          # esbuild dev 서버 (watch 모드)
│   ├── build.js        # esbuild 프로덕션 빌드
│   └── preview.js      # 빌드 결과 미리보기 서버
└── package.json
```

## 탭 설명

| 탭 | 뷰 모드 | 설명 |
|---|---|---|
| Types | diagram / json | struct·enum을 UML 카드로 표시, 타입 참조 엣지 |
| QoS | form / diagram / json | 프로파일 값 직접 편집, raw JSON 반영 |
| Domains | diagram / json | 도메인·토픽 레지스트리 |
| Participants | diagram / json | Publisher·Subscriber 데이터 플로우 |
