const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = 4000;
const OUT_DIR = path.join(__dirname, "../dist");

const server = http.createServer((req, res) => {
  let filePath = path.join(OUT_DIR, req.url === "/" ? "index.html" : req.url);

  if (!fs.existsSync(filePath)) {
    filePath = path.join(OUT_DIR, "index.html");
  }

  const ext = path.extname(filePath);
  const mimeTypes = {
    ".html": "text/html",
    ".js": "application/javascript",
    ".css": "text/css",
  };

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404);
      res.end("Not found");
      return;
    }
    res.writeHead(200, { "Content-Type": mimeTypes[ext] || "text/plain" });
    res.end(data);
  });
});

server.listen(PORT, () => {
  console.log(`Preview server running at http://localhost:${PORT}`);
});
