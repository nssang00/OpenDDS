const esbuild = require("esbuild");
const fs = require("fs");
const path = require("path");

const OUT_DIR = path.join(__dirname, "../dist");

if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

fs.copyFileSync(
  path.join(__dirname, "../public/index.html"),
  path.join(OUT_DIR, "index.html")
);

esbuild
  .build({
    entryPoints: ["src/index.jsx"],
    bundle: true,
    outfile: "dist/bundle.js",
    platform: "browser",
    format: "iife",
    jsx: "automatic",
    minify: true,
    sourcemap: false,
    define: {
      "process.env.NODE_ENV": '"production"',
    },
    loader: { ".css": "text" },
    metafile: true,
  })
  .then((result) => {
    const outSize = fs.statSync("dist/bundle.js").size;
    console.log(`Build complete. bundle.js: ${(outSize / 1024).toFixed(1)} KB`);

    const outputs = result.metafile?.outputs || {};
    Object.entries(outputs).forEach(([file, meta]) => {
      console.log(`  ${file}: ${(meta.bytes / 1024).toFixed(1)} KB`);
    });
  })
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
