const esbuild = require("esbuild");
const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = 3000;
const OUT_DIR = path.join(__dirname, "../dist");

if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

// Copy index.html to dist
fs.copyFileSync(
  path.join(__dirname, "../public/index.html"),
  path.join(OUT_DIR, "index.html")
);

esbuild
  .context({
    entryPoints: ["src/index.jsx"],
    bundle: true,
    outfile: "dist/bundle.js",
    platform: "browser",
    format: "iife",
    jsx: "automatic",
    sourcemap: true,
    define: {
      "process.env.NODE_ENV": '"development"',
    },
    loader: { ".css": "text" },
  })
  .then(async (ctx) => {
    await ctx.watch();

    const server = http.createServer((req, res) => {
      let filePath = path.join(OUT_DIR, req.url === "/" ? "index.html" : req.url);

      if (!fs.existsSync(filePath)) {
        filePath = path.join(OUT_DIR, "index.html");
      }

      const ext = path.extname(filePath);
      const mimeTypes = {
        ".html": "text/html",
        ".js": "application/javascript",
        ".css": "text/css",
        ".map": "application/json",
      };

      fs.readFile(filePath, (err, data) => {
        if (err) {
          res.writeHead(404);
          res.end("Not found");
          return;
        }
        res.writeHead(200, { "Content-Type": mimeTypes[ext] || "text/plain" });
        res.end(data);
      });
    });

    server.listen(PORT, () => {
      console.log(`Dev server running at http://localhost:${PORT}`);
      console.log("Watching for changes...");
    });
  })
  .catch(() => process.exit(1));
