import Docxtemplater from 'docxtemplater';
import expressionParser from 'docxtemplater/expressions.js';
import PizZip from 'pizzip';
import { renderAsync } from 'docx-preview';

const parser = expressionParser.configure({ csp: true });
const TEMPLATE_TAG_HIGHLIGHT = 'docx-template-tag';
const TAG_PATTERN = /\{[^{}\r\n]+\}/g;

export function renderDocx(templateBuffer, documentData) {
  const zip = new PizZip(templateBuffer);
  const doc = new Docxtemplater(zip, {
    parser,
    paragraphLoop: true,
    linebreaks: true,
  });

  doc.render(documentData);
  const generatedBlob = doc.getZip().generate({
    type: 'blob',
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  });

  return generatedBlob.arrayBuffer().then((generatedBuffer) => ({ generatedBlob, generatedBuffer }));
}

export async function previewDocx(bufferOrBlob, container) {
  if (!bufferOrBlob || !container) return;
  clearTemplateTagHighlights();
  container.innerHTML = '';
  // Keep docx-preview completely in charge of page size, margins, fonts and layout.
  await renderAsync(bufferOrBlob, container);
}

export function scheduleTemplateTagHighlights(container) {
  if (!container || !supportsCustomHighlights()) return () => {};

  let cancelled = false;
  const run = () => {
    if (cancelled) return;
    highlightVisibleTemplateTags(container);
  };

  let handle;
  if ('requestIdleCallback' in window) {
    handle = window.requestIdleCallback(run);
    return () => {
      cancelled = true;
      window.cancelIdleCallback?.(handle);
      clearTemplateTagHighlights();
    };
  }

  handle = window.setTimeout(run, 100);
  return () => {
    cancelled = true;
    window.clearTimeout(handle);
    clearTemplateTagHighlights();
  };
}

export function clearTemplateTagHighlights() {
  if (typeof CSS !== 'undefined' && CSS.highlights) {
    CSS.highlights.delete(TEMPLATE_TAG_HIGHLIGHT);
  }
}

function highlightVisibleTemplateTags(container) {
  if (!supportsCustomHighlights()) return;

  const ranges = [];
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);

  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    if (!text || !text.includes('{')) continue;

    TAG_PATTERN.lastIndex = 0;
    let match;
    while ((match = TAG_PATTERN.exec(text)) !== null) {
      const range = new Range();
      range.setStart(node, match.index);
      range.setEnd(node, match.index + match[0].length);
      ranges.push(range);
    }
  }

  CSS.highlights.set(TEMPLATE_TAG_HIGHLIGHT, new Highlight(...ranges));
}

function supportsCustomHighlights() {
  return (
    typeof CSS !== 'undefined' &&
    Boolean(CSS.highlights) &&
    typeof Highlight !== 'undefined' &&
    typeof Range !== 'undefined'
  );
}

export function downloadDocx(blob, filename = 'generated-document.docx') {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
