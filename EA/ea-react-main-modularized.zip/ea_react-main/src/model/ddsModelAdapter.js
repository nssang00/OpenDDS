import { updatePath } from '../utils/objectPath.js';

export function syncElementPathToDds(ddsJson, element, path, value) {
  if (!element) return ddsJson;

  if (element.type === 'Domain') {
    const domains = ddsJson?.domains?.domain_library?.domains;
    if (!Array.isArray(domains)) return ddsJson;
    return {
      ...ddsJson,
      domains: {
        ...ddsJson.domains,
        domain_library: {
          ...ddsJson.domains.domain_library,
          domains: domains.map((domain) => (
            domain.name === element.name ? updatePath(domain, path, value) : domain
          )),
        },
      },
    };
  }

  if (element.type === 'DomainParticipant') {
    const participants = ddsJson?.domainParticipants?.domain_participant_library?.domain_participants;
    if (!Array.isArray(participants)) return ddsJson;
    return {
      ...ddsJson,
      domainParticipants: {
        ...ddsJson.domainParticipants,
        domain_participant_library: {
          ...ddsJson.domainParticipants.domain_participant_library,
          domain_participants: participants.map((participant) => (
            participant.name === element.name ? updatePath(participant, path, value) : participant
          )),
        },
      },
    };
  }

  return ddsJson;
}

export function syncQosPropertyToDds(ddsJson, profileName, entityKey, path, value) {
  const library = ddsJson?.qos?.qos_library;
  const profileKey = Array.isArray(library?.qos_profiles) ? 'qos_profiles' : 'profiles';
  const profiles = library?.[profileKey];
  if (!Array.isArray(profiles)) return ddsJson;

  return {
    ...ddsJson,
    qos: {
      ...ddsJson.qos,
      qos_library: {
        ...ddsJson.qos.qos_library,
        [profileKey]: profiles.map((profile) => (
          profile.name === profileName
            ? updatePath(profile, [entityKey, ...path.split('.')], value)
            : profile
        )),
      },
    },
  };
}

export function syncTypeMembersToDds(ddsJson, model, element, members) {
  if (!element || !['Struct', 'Union'].includes(element.type)) return ddsJson;

  const typePath = typeJsonPath(model, element);
  if (!typePath.length) return ddsJson;

  return {
    ...ddsJson,
    types: updateTypeObjectAtPath(ddsJson?.types, typePath, (typeObject) => ({
      ...typeObject,
      members,
    })),
  };
}

function typeJsonPath(model, element) {
  const path = [element.name];
  let parent = model?.elementsById?.[element.parentId];

  while (parent) {
    if (parent.type === 'Module') path.unshift(parent.name);
    parent = model.elementsById[parent.parentId];
  }

  return path.filter(Boolean);
}

function updateTypeObjectAtPath(types, path, updateType) {
  if (!types || !path.length) return types;
  const [key, ...rest] = path;
  const current = types[key];
  if (!current) return types;

  if (!rest.length) {
    return {
      ...types,
      [key]: updateType(current),
    };
  }

  return {
    ...types,
    [key]: {
      ...current,
      [rest[0]]: updateTypeObjectAtPath({ [rest[0]]: current[rest[0]] }, rest, updateType)[rest[0]],
    },
  };
}
