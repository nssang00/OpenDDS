import { readPath, updatePath } from '../utils/objectPath.js';

export function updateElement(model, id, patch) {
  const current = model?.elementsById[id];
  if (!current) return model;

  return replaceElement(model, id, { ...current, ...patch });
}

export function updateElementProperty(model, id, key, value) {
  const current = model?.elementsById[id];
  if (!current) return model;

  return replaceElement(model, id, {
    ...current,
    properties: {
      ...current.properties,
      [key]: value,
    },
  });
}

export function updateElementPath(model, id, path, value) {
  const current = model?.elementsById[id];
  if (!current) return model;

  const nextElement = {
    ...current,
    properties: updatePath(current.properties, path, value),
  };

  return replaceElement(model, id, nextElement);
}

export function appendElementPath(model, id, path, value) {
  const current = model?.elementsById[id];
  if (!current) return model;

  const currentList = readPath(current.properties, path);
  const nextList = Array.isArray(currentList) ? [...currentList, value] : [value];
  return updateElementPath(model, id, path, nextList);
}

export function removeElementPath(model, id, path, index) {
  const current = model?.elementsById[id];
  if (!current) return model;

  const currentList = readPath(current.properties, path);
  if (!Array.isArray(currentList)) return model;

  const nextList = currentList.filter((_, itemIndex) => itemIndex !== index);
  return updateElementPath(model, id, path, nextList);
}

export function updateQosProperty(model, id, entityKey, path, value) {
  const current = model?.elementsById[id];
  if (!current) return model;

  const nextProperties = updatePath(current.properties, [entityKey, ...path.split('.')], value);
  const nextElement = {
    ...current,
    properties: withQosJson(nextProperties),
  };

  return replaceElement(model, id, nextElement);
}

export function updateQosPath(model, profileId, path, value) {
  const profile = model?.elementsById[profileId];
  if (!profile || profile.type !== 'QosProfile') return model;

  const nextProperties = updatePath(profile.properties, path, value);
  const nextProfile = {
    ...profile,
    properties: withQosJson(nextProperties),
  };

  const nextElementsById = Object.fromEntries(Object.entries(model.elementsById).map(([id, element]) => {
    if (id === profileId) return [id, nextProfile];
    if (element.type === 'QosPolicy' && element.properties?.policyPath) {
      const policyValue = readPath(nextProfile.properties, element.properties.policyPath);
      return [id, {
        ...element,
        properties: {
          ...element.properties,
          qosJson: JSON.stringify(policyValue ?? {}, null, 2),
          ...primitiveProperties(policyValue),
        },
      }];
    }
    if (element.type === 'QosValue' && element.properties?.policyPath) {
      return [id, {
        ...element,
        properties: {
          ...element.properties,
          value: readPath(nextProfile.properties, element.properties.policyPath),
        },
      }];
    }
    return [id, element];
  }));

  return { ...model, elementsById: nextElementsById };
}

export function updateMembers(model, id, members) {
  const current = model?.elementsById[id];
  if (!current) return model;

  const nextElement = {
    ...current,
    properties: {
      ...current.properties,
      members,
    },
  };

  return replaceElement(model, id, nextElement);
}

function replaceElement(model, id, element) {
  return {
    ...model,
    elementsById: {
      ...model.elementsById,
      [id]: element,
    },
  };
}

function withQosJson(properties) {
  return {
    ...properties,
    qosJson: JSON.stringify(stripGeneratedProperties(properties), null, 2),
  };
}

function stripGeneratedProperties(properties) {
  const { qosJson, ...rest } = properties;
  return rest;
}

function primitiveProperties(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) return {};
  return Object.fromEntries(Object.entries(value).filter(([, item]) => item === null || typeof item !== 'object' || Array.isArray(item)));
}
