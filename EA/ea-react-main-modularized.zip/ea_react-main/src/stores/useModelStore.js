import { create } from 'zustand';
import { readPath } from '../utils/objectPath.js';
import {
  appendElementPath,
  removeElementPath,
  updateElement,
  updateElementPath,
  updateElementProperty,
  updateMembers,
  updateQosPath,
  updateQosProperty,
} from '../model/modelUpdates.js';
import {
  syncElementPathToDds,
  syncQosPropertyToDds,
  syncTypeMembersToDds,
} from '../model/ddsModelAdapter.js';

export const useModelStore = create((set, get) => ({
  model: null,
  modelProjectId: null,
  projectModels: {},
  dirty: false,

  setProjectModelStatus: (projectId, status, error = null) => {
    set((state) => ({
      projectModels: {
        ...state.projectModels,
        [projectId]: {
          ...state.projectModels[projectId],
          status,
          error,
        },
      },
    }));
  },

  setProjectModel: (projectId, model) => {
    set((state) => ({
      model,
      modelProjectId: projectId,
      projectModels: {
        ...state.projectModels,
        [projectId]: {
          model,
          status: 'loaded',
          error: null,
        },
      },
      dirty: false,
    }));
  },

  activateProjectModel: (projectId) => {
    const model = get().projectModels[projectId]?.model;
    if (!model) return false;

    set({
      model,
      modelProjectId: projectId,
      dirty: false,
    });

    return true;
  },

  updateElement: (id, patch) => applyModelUpdate(set, (model) => updateElement(model, id, patch)),
  updateProperty: (id, key, value) => applyModelUpdate(set, (model) => updateElementProperty(model, id, key, value)),

  updateElementPath: (id, path, value) => applyModelUpdate(set, (model) => {
    const current = model?.elementsById?.[id];
    if (!current) return model;
    const nextModel = updateElementPath(model, id, path, value);
    if (nextModel === model) return model;
    return {
      ...nextModel,
      ddsJson: syncElementPathToDds(model.ddsJson, current, path, value),
    };
  }),

  appendElementPath: (id, path, value) => applyModelUpdate(set, (model) => {
    const current = model?.elementsById?.[id];
    if (!current) return model;
    const currentList = readPath(current.properties, path);
    const nextList = Array.isArray(currentList) ? [...currentList, value] : [value];
    const nextModel = appendElementPath(model, id, path, value);
    if (nextModel === model) return model;
    return {
      ...nextModel,
      ddsJson: syncElementPathToDds(model.ddsJson, current, path, nextList),
    };
  }),

  removeElementPath: (id, path, index) => applyModelUpdate(set, (model) => {
    const current = model?.elementsById?.[id];
    if (!current) return model;
    const currentList = readPath(current.properties, path);
    if (!Array.isArray(currentList)) return model;
    const nextList = currentList.filter((_, itemIndex) => itemIndex !== index);
    const nextModel = removeElementPath(model, id, path, index);
    if (nextModel === model) return model;
    return {
      ...nextModel,
      ddsJson: syncElementPathToDds(model.ddsJson, current, path, nextList),
    };
  }),

  updateQosProperty: (id, entityKey, path, value) => applyModelUpdate(set, (model) => {
    const current = model?.elementsById?.[id];
    if (!current) return model;
    const nextModel = updateQosProperty(model, id, entityKey, path, value);
    if (nextModel === model) return model;
    return {
      ...nextModel,
      ddsJson: syncQosPropertyToDds(model.ddsJson, current.name, entityKey, path, value),
    };
  }),

  updateQosPath: (profileId, path, value) => applyModelUpdate(set, (model) => updateQosPath(model, profileId, path, value)),

  updateMembers: (id, members) => applyModelUpdate(set, (model) => {
    const current = model?.elementsById?.[id];
    if (!current) return model;
    const nextModel = updateMembers(model, id, members);
    if (nextModel === model) return model;
    return {
      ...nextModel,
      ddsJson: syncTypeMembersToDds(model.ddsJson, model, current, members),
    };
  }),
}));

function applyModelUpdate(set, updateModel) {
  set((state) => {
    if (!state.model) return state;
    const nextModel = updateModel(state.model);
    if (nextModel === state.model) return state;

    return {
      model: nextModel,
      projectModels: {
        ...state.projectModels,
        [state.modelProjectId]: {
          ...state.projectModels[state.modelProjectId],
          model: nextModel,
          status: 'loaded',
          error: null,
        },
      },
      dirty: true,
    };
  });
}
