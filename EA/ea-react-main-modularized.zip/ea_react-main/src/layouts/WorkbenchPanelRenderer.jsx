import { useEffect, useMemo, useState } from 'react';
import { Tabs } from 'antd';
import { useWorkbenchPanel } from '../hooks/useWorkbenchPanel.js';

export default function WorkbenchPanelRenderer({ panel }) {
  const {
    activeExplorerViewId,
    activeWorkspaceViewId,
    controlledActiveViewId,
    onActiveViewChange,
  } = useWorkbenchPanel(panel.id);

  const items = useMemo(() => (
    panel.views
      .filter((view) => !view.visibleFor || view.visibleFor.includes(activeExplorerViewId))
      .filter((view) => !view.visibleForWorkspace || view.visibleForWorkspace.includes(activeWorkspaceViewId))
      .map(({ component: View, id, label }) => ({
        key: id,
        label: typeof label === 'function' ? label(activeExplorerViewId) : label,
        children: <View />,
      }))
  ), [activeExplorerViewId, activeWorkspaceViewId, panel.views]);

  const defaultActiveKey = panel.defaultActiveView ?? items[0]?.key;
  const [localActiveKey, setLocalActiveKey] = useState(defaultActiveKey);

  useEffect(() => {
    const preferredView = panel.preferredViewByWorkspace?.[activeWorkspaceViewId];
    if (preferredView) {
      setLocalActiveKey(preferredView);
      return;
    }

    if (panel.preferredViewByWorkspace) {
      setLocalActiveKey(panel.defaultActiveView ?? items[0]?.key);
    }
  }, [activeWorkspaceViewId, items, panel.defaultActiveView, panel.preferredViewByWorkspace]);

  const activeKey = controlledActiveViewId ?? localActiveKey;

  useEffect(() => {
    if (!items.some((item) => item.key === activeKey)) {
      setLocalActiveKey(defaultActiveKey);
    }
  }, [activeKey, defaultActiveKey, items]);

  const handleChange = (key) => {
    if (!controlledActiveViewId) setLocalActiveKey(key);
    onActiveViewChange?.(key);
  };

  const resolvedActiveKey = items.some((item) => item.key === activeKey)
    ? activeKey
    : defaultActiveKey;

  return (
    <Tabs
      activeKey={resolvedActiveKey}
      className={`workbench-panel workbench-panel--${panel.id}`}
      onChange={handleChange}
      items={items}
    />
  );
}
