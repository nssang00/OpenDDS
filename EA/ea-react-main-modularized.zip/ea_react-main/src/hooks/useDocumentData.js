import { useMemo } from 'react';
import { useModelStore } from '../stores/useModelStore.js';
import { createDocumentData } from '../document/documentMapper.js';

export function useDocumentData() {
  const model = useModelStore((state) => state.model);
  return useMemo(() => createDocumentData(model), [model]);
}
