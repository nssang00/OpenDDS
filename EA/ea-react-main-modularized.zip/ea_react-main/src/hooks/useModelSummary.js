import { useMemo } from 'react';
import { useModelStore } from '../stores/useModelStore.js';
import { getModelSummary } from '../model/modelSelectors.js';

const EMPTY_SUMMARY = { topics: 0, structs: 0, qosProfiles: 0 };

export function useModelSummary() {
  const model = useModelStore((state) => state.model);

  return useMemo(() => (
    model ? getModelSummary(model) : EMPTY_SUMMARY
  ), [model]);
}
