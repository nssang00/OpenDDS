import { useMemo } from 'react';
import { useProjects } from './useProjects.js';
import { useModelStore } from '../stores/useModelStore.js';
import { useModelSummary } from './useModelSummary.js';
import { buildConsoleMessages } from '../model/workbenchMessages.js';

export function useConsoleMessages() {
  const dirty = useModelStore((state) => state.dirty);
  const { currentProject } = useProjects();
  const summary = useModelSummary();

  return useMemo(() => (
    buildConsoleMessages({ currentProject, dirty, summary })
  ), [currentProject, dirty, summary]);
}
