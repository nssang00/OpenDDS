import { useMemo } from 'react';
import { getExplorerJsonDocument } from '../model/explorerDocuments.js';
import { useModelStore } from '../stores/useModelStore.js';
import { useUiStore } from '../stores/useUiStore.js';

export function useExplorerJsonDocument() {
  const model = useModelStore((state) => state.model);
  const activeExplorerViewId = useUiStore((state) => state.activeExplorerViewId);

  return useMemo(() => (
    getExplorerJsonDocument(model, activeExplorerViewId)
  ), [activeExplorerViewId, model]);
}
