import { useMemo } from 'react';
import { useModelStore } from '../stores/useModelStore.js';
import { useModelSummary } from './useModelSummary.js';
import { buildOutputItems } from '../model/workbenchMessages.js';

export function useOutputItems() {
  const model = useModelStore((state) => state.model);
  const summary = useModelSummary();

  return useMemo(() => (
    buildOutputItems({ model, summary })
  ), [model, summary]);
}
