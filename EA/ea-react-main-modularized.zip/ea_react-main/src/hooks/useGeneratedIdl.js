import { useMemo } from 'react';
import { useModelStore } from '../stores/useModelStore.js';
import { generateIdl } from '../utils/idlGenerator.js';

export function useGeneratedIdl() {
  const model = useModelStore((state) => state.model);

  return {
    idlText: useMemo(() => model ? generateIdl(model) : '', [model]),
  };
}
