import { useModelStore } from '../stores/useModelStore.js';
import { useUiStore } from '../stores/useUiStore.js';

export function useStructMembers(elementId) {
  const selectedElementId = useUiStore((state) => state.selectedElementId);
  const targetId = elementId ?? selectedElementId;
  const element = useModelStore((state) => (
    targetId ? state.model?.elementsById?.[targetId] : undefined
  ));
  const updateMembers = useModelStore((state) => state.updateMembers);

  return {
    element,
    members: element?.properties?.members,
    updateMembers,
  };
}
