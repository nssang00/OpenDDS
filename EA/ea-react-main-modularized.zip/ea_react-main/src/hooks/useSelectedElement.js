import { useModelStore } from '../stores/useModelStore.js';
import { useUiStore } from '../stores/useUiStore.js';

export function useSelectedElement() {
  const selectedElementId = useUiStore((state) => state.selectedElementId);
  const selectElement = useUiStore((state) => state.selectElement);
  const element = useModelStore((state) => (
    selectedElementId ? state.model?.elementsById?.[selectedElementId] : undefined
  ));
  const updateElement = useModelStore((state) => state.updateElement);
  const updateProperty = useModelStore((state) => state.updateProperty);
  const appendElementPath = useModelStore((state) => state.appendElementPath);
  const removeElementPath = useModelStore((state) => state.removeElementPath);
  const updateElementPath = useModelStore((state) => state.updateElementPath);
  const updateQosPath = useModelStore((state) => state.updateQosPath);

  return {
    element,
    selectedElementId,
    selectElement,
    appendElementPath,
    removeElementPath,
    updateElement,
    updateElementPath,
    updateProperty,
    updateQosPath,
  };
}
