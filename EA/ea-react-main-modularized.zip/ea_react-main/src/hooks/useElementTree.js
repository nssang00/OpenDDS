import { useMemo, useState } from 'react';
import { useModelStore } from '../stores/useModelStore.js';
import { useUiStore } from '../stores/useUiStore.js';
import { buildTreeData } from '../model/modelSelectors.js';

export function useElementTree({ filterPlaceholder = 'Filter', types } = {}) {
  const elementsById = useModelStore((state) => state.model?.elementsById);
  const selectedElementId = useUiStore((state) => state.selectedElementId);
  const selectElement = useUiStore((state) => state.selectElement);
  const [filterText, setFilterText] = useState('');

  const treeData = useMemo(() => {
    return buildTreeData(elementsById, { filterText, types });
  }, [elementsById, filterText, types]);

  return {
    filterPlaceholder,
    filterText,
    treeData,
    selectedKeys: selectedElementId ? [selectedElementId] : [],
    hasModel: Boolean(elementsById),
    selectElement,
    setFilterText,
  };
}
