import { useMemo } from 'react';
import { useModelStore } from '../stores/useModelStore.js';
import { useSelectedElement } from './useSelectedElement.js';
import { buildElementPropertyGroups } from '../model/propertyModel.js';

export function useElementProperties() {
  const {
    appendElementPath,
    element,
    removeElementPath,
    updateElement,
    updateElementPath,
    updateProperty,
    updateQosPath,
  } = useSelectedElement();
  const model = useModelStore((state) => state.model);

  const propertyGroups = useMemo(() => {
    return buildElementPropertyGroups(model, element);
  }, [element, model]);

  return {
    model,
    element,
    appendElementPath,
    removeElementPath,
    updateElement,
    updateElementPath,
    updateProperty,
    updateQosPath,
    ...propertyGroups,
  };
}
