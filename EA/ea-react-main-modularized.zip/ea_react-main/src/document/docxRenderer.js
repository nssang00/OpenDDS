import Docxtemplater from 'docxtemplater';
import expressionParser from 'docxtemplater/expressions.js';
import PizZip from 'pizzip';
import { renderAsync } from 'docx-preview';

const parser = expressionParser.configure({ csp: true });

export function renderDocx(templateBuffer, documentData) {
  const zip = new PizZip(templateBuffer);
  const doc = new Docxtemplater(zip, {
    parser,
    paragraphLoop: true,
    linebreaks: true,
  });

  doc.render(documentData);
  const generatedBlob = doc.getZip().generate({
    type: 'blob',
    mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  });

  return generatedBlob.arrayBuffer().then((generatedBuffer) => ({ generatedBlob, generatedBuffer }));
}

export async function previewDocx(bufferOrBlob, container) {
  if (!bufferOrBlob || !container) return;
  container.innerHTML = '';
  // Use docx-preview defaults so its original page size, margins, fonts and layout stay intact.
  await renderAsync(bufferOrBlob, container);
}

export function downloadDocx(blob, filename = 'generated-document.docx') {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
