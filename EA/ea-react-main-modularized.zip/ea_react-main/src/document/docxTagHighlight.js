const TEMPLATE_TAG_HIGHLIGHT = 'docx-template-tag';
const TAG_PATTERN = /\{[^{}\r\n]+\}/g;

export function scheduleDocxTagHighlight(container) {
  if (!container || !supportsCustomHighlights()) return () => {};

  let cancelled = false;
  let handle = null;

  const run = () => {
    if (cancelled) return;
    try {
      highlightDocxTags(container);
    } catch {
      // Highlighting is optional. Never let it affect the DOCX viewer.
    }
  };

  if ('requestIdleCallback' in window) {
    handle = window.requestIdleCallback(run, { timeout: 1000 });
    return () => {
      cancelled = true;
      window.cancelIdleCallback?.(handle);
      clearDocxTagHighlight();
    };
  }

  handle = window.setTimeout(run, 100);
  return () => {
    cancelled = true;
    window.clearTimeout(handle);
    clearDocxTagHighlight();
  };
}

export function clearDocxTagHighlight() {
  try {
    if (typeof CSS !== 'undefined' && CSS.highlights) {
      CSS.highlights.delete(TEMPLATE_TAG_HIGHLIGHT);
    }
  } catch {
    // Optional viewer decoration only.
  }
}

function highlightDocxTags(container) {
  if (!supportsCustomHighlights()) return;

  const ranges = [];
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);

  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    if (!text || !text.includes('{')) continue;

    TAG_PATTERN.lastIndex = 0;
    let match;
    while ((match = TAG_PATTERN.exec(text)) !== null) {
      const range = new Range();
      range.setStart(node, match.index);
      range.setEnd(node, match.index + match[0].length);
      ranges.push(range);
    }
  }

  if (ranges.length === 0) {
    clearDocxTagHighlight();
    return;
  }

  CSS.highlights.set(TEMPLATE_TAG_HIGHLIGHT, new Highlight(...ranges));
}

function supportsCustomHighlights() {
  return (
    typeof window !== 'undefined' &&
    typeof CSS !== 'undefined' &&
    Boolean(CSS.highlights) &&
    typeof Highlight !== 'undefined' &&
    typeof Range !== 'undefined'
  );
}
