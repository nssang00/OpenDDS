import { create } from 'zustand';

const initialState = {
  templateFile: null,
  templateBuffer: null,
  templateName: '',
  detectedTags: [],
  validationResult: null,
  generatedBlob: null,
  generatedBuffer: null,
  previewMode: 'template',
};

export const useDocumentStore = create((set) => ({
  ...initialState,

  setTemplate: (file, buffer) => set({
    templateFile: file,
    templateBuffer: buffer,
    templateName: file?.name ?? '',
    detectedTags: [],
    validationResult: null,
    generatedBlob: null,
    generatedBuffer: null,
    previewMode: 'template',
  }),
  setDetectedTags: (detectedTags) => set({ detectedTags }),
  setValidationResult: (validationResult) => set({ validationResult }),
  setGeneratedDocument: (generatedBlob, generatedBuffer) => set({ generatedBlob, generatedBuffer }),
  setPreviewMode: (previewMode) => set({ previewMode }),
  resetDocument: () => set(initialState),
}));
