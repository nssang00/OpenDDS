#include "ea/EAConverter.h"

#include <cassert>

int main() {
    dds::ea::EAObject object;
    object.name = "Telemetry";
    object.objectType = "Class";
    object.stereotype = "idlStruct";
    object.eaGuid = "{TYPE-GUID}";

    dds::ea::EAConverter converter;
    dds::DDSType type = converter.convertType(object, "project", "");
    assert(type.kind == "struct");
    assert(type.source == "ea");

    dds::ea::EAAttribute attribute;
    attribute.name = "samples";
    attribute.type = "long";
    attribute.lowerBound = "1";
    attribute.upperBound = "32";
    dds::DDSMember member = converter.convertMember(attribute, type.id);
    assert(member.primitiveType == "int32");
    assert(member.isSequence);
    assert(member.sequenceBound == 32);
    return 0;
}
