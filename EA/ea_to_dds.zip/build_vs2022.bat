@echo off
setlocal
call "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvars64.bat"
if errorlevel 1 exit /b %errorlevel%
if not exist build mkdir build
cl /nologo /EHsc /std:c++14 /W4 /I src /I third_party\sqlite3 ^
  src\dds\DDSModels.cpp ^
  src\dds\DDSLoader.cpp ^
  src\repository\SQLiteRepository.cpp ^
  src\generator\IDLGenerator.cpp ^
  src\generator\MarkdownGenerator.cpp ^
  src\ea\EAConverter.cpp ^
  src\ea\EAReader.cpp ^
  src\main.cpp ^
  third_party\sqlite3\sqlite3.c ^
  /Fe:build\dds_collab.exe
exit /b %errorlevel%
