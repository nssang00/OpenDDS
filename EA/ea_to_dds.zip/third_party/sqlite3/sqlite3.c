#include "sqlite3.h"

#define WIN32_LEAN_AND_MEAN
#include <windows.h>

typedef int (*fn_sqlite3_open)(const char*, sqlite3**);
typedef int (*fn_sqlite3_close)(sqlite3*);
typedef int (*fn_sqlite3_exec)(sqlite3*, const char*, sqlite3_callback, void*, char**);
typedef int (*fn_sqlite3_prepare_v2)(sqlite3*, const char*, int, sqlite3_stmt**, const char**);
typedef int (*fn_sqlite3_step)(sqlite3_stmt*);
typedef int (*fn_sqlite3_finalize)(sqlite3_stmt*);
typedef const char* (*fn_sqlite3_errmsg)(sqlite3*);
typedef void (*fn_sqlite3_free)(void*);
typedef int (*fn_sqlite3_bind_text)(sqlite3_stmt*, int, const char*, int, void(*)(void*));
typedef int (*fn_sqlite3_bind_null)(sqlite3_stmt*, int);
typedef int (*fn_sqlite3_bind_int)(sqlite3_stmt*, int, int);
typedef const unsigned char* (*fn_sqlite3_column_text)(sqlite3_stmt*, int);
typedef int (*fn_sqlite3_column_int)(sqlite3_stmt*, int);
typedef int (*fn_sqlite3_column_type)(sqlite3_stmt*, int);

static HMODULE g_sqlite = NULL;
static fn_sqlite3_open p_open = NULL;
static fn_sqlite3_close p_close = NULL;
static fn_sqlite3_exec p_exec = NULL;
static fn_sqlite3_prepare_v2 p_prepare_v2 = NULL;
static fn_sqlite3_step p_step = NULL;
static fn_sqlite3_finalize p_finalize = NULL;
static fn_sqlite3_errmsg p_errmsg = NULL;
static fn_sqlite3_free p_free = NULL;
static fn_sqlite3_bind_text p_bind_text = NULL;
static fn_sqlite3_bind_null p_bind_null = NULL;
static fn_sqlite3_bind_int p_bind_int = NULL;
static fn_sqlite3_column_text p_column_text = NULL;
static fn_sqlite3_column_int p_column_int = NULL;
static fn_sqlite3_column_type p_column_type = NULL;

static FARPROC load_symbol(const char* name) {
    return g_sqlite == NULL ? NULL : GetProcAddress(g_sqlite, name);
}

static int load_sqlite(void) {
    if (g_sqlite != NULL) {
        return 1;
    }

    g_sqlite = LoadLibraryA("sqlite3.dll");
    if (g_sqlite == NULL) {
        g_sqlite = LoadLibraryA("C:\\Program Files\\DB Browser for SQLite\\sqlite3.dll");
    }
    if (g_sqlite == NULL) {
        g_sqlite = LoadLibraryA("C:\\Python\\Python313\\DLLs\\sqlite3.dll");
    }
    if (g_sqlite == NULL) {
        return 0;
    }

    p_open = (fn_sqlite3_open)load_symbol("sqlite3_open");
    p_close = (fn_sqlite3_close)load_symbol("sqlite3_close");
    p_exec = (fn_sqlite3_exec)load_symbol("sqlite3_exec");
    p_prepare_v2 = (fn_sqlite3_prepare_v2)load_symbol("sqlite3_prepare_v2");
    p_step = (fn_sqlite3_step)load_symbol("sqlite3_step");
    p_finalize = (fn_sqlite3_finalize)load_symbol("sqlite3_finalize");
    p_errmsg = (fn_sqlite3_errmsg)load_symbol("sqlite3_errmsg");
    p_free = (fn_sqlite3_free)load_symbol("sqlite3_free");
    p_bind_text = (fn_sqlite3_bind_text)load_symbol("sqlite3_bind_text");
    p_bind_null = (fn_sqlite3_bind_null)load_symbol("sqlite3_bind_null");
    p_bind_int = (fn_sqlite3_bind_int)load_symbol("sqlite3_bind_int");
    p_column_text = (fn_sqlite3_column_text)load_symbol("sqlite3_column_text");
    p_column_int = (fn_sqlite3_column_int)load_symbol("sqlite3_column_int");
    p_column_type = (fn_sqlite3_column_type)load_symbol("sqlite3_column_type");

    return p_open && p_close && p_exec && p_prepare_v2 && p_step && p_finalize &&
           p_errmsg && p_free && p_bind_text && p_bind_null && p_bind_int &&
           p_column_text && p_column_int && p_column_type;
}

int sqlite3_open(const char* filename, sqlite3** ppDb) {
    return load_sqlite() ? p_open(filename, ppDb) : 1;
}

int sqlite3_close(sqlite3* db) {
    return load_sqlite() ? p_close(db) : 1;
}

int sqlite3_exec(sqlite3* db, const char* sql, sqlite3_callback callback, void* data, char** errmsg) {
    return load_sqlite() ? p_exec(db, sql, callback, data, errmsg) : 1;
}

int sqlite3_prepare_v2(sqlite3* db, const char* sql, int nByte, sqlite3_stmt** ppStmt, const char** pzTail) {
    return load_sqlite() ? p_prepare_v2(db, sql, nByte, ppStmt, pzTail) : 1;
}

int sqlite3_step(sqlite3_stmt* stmt) {
    return load_sqlite() ? p_step(stmt) : 1;
}

int sqlite3_finalize(sqlite3_stmt* stmt) {
    return load_sqlite() ? p_finalize(stmt) : 1;
}

const char* sqlite3_errmsg(sqlite3* db) {
    return load_sqlite() ? p_errmsg(db) : "sqlite3.dll could not be loaded";
}

void sqlite3_free(void* value) {
    if (load_sqlite()) {
        p_free(value);
    }
}

int sqlite3_bind_text(sqlite3_stmt* stmt, int index, const char* value, int bytes, void(*destructor)(void*)) {
    return load_sqlite() ? p_bind_text(stmt, index, value, bytes, destructor) : 1;
}

int sqlite3_bind_null(sqlite3_stmt* stmt, int index) {
    return load_sqlite() ? p_bind_null(stmt, index) : 1;
}

int sqlite3_bind_int(sqlite3_stmt* stmt, int index, int value) {
    return load_sqlite() ? p_bind_int(stmt, index, value) : 1;
}

const unsigned char* sqlite3_column_text(sqlite3_stmt* stmt, int column) {
    return load_sqlite() ? p_column_text(stmt, column) : NULL;
}

int sqlite3_column_int(sqlite3_stmt* stmt, int column) {
    return load_sqlite() ? p_column_int(stmt, column) : 0;
}

int sqlite3_column_type(sqlite3_stmt* stmt, int column) {
    return load_sqlite() ? p_column_type(stmt, column) : SQLITE_NULL;
}
