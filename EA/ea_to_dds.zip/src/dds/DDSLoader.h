#pragma once

#include "dds/DDSModels.h"
#include "repository/IRepository.h"

namespace dds {

class DDSLoader {
public:
    explicit DDSLoader(IRepository& repository);

    DDSProject loadProject(const std::string& projectId) const;

private:
    IRepository& repository_;
};

} // namespace dds
