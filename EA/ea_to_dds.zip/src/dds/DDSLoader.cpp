#include "dds/DDSLoader.h"

namespace dds {

DDSLoader::DDSLoader(IRepository& repository) : repository_(repository) {
}

DDSProject DDSLoader::loadProject(const std::string& projectId) const {
    return repository_.loadProject(projectId);
}

} // namespace dds
