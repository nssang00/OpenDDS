#include "dds/DDSModels.h"

namespace dds {

namespace {
void addField(std::ostringstream& out, bool& first, const std::string& key, const std::string& value, bool raw = false) {
    if (!first) {
        out << ",";
    }
    first = false;
    out << jsonString(key) << ":" << (raw ? value : jsonString(value));
}

std::string boolJson(bool value) {
    return value ? "true" : "false";
}

std::string intJson(int value) {
    std::ostringstream out;
    out << value;
    return out.str();
}
}

std::string jsonEscape(const std::string& value) {
    std::ostringstream out;
    for (std::string::const_iterator it = value.begin(); it != value.end(); ++it) {
        switch (*it) {
        case '\\': out << "\\\\"; break;
        case '"': out << "\\\""; break;
        case '\b': out << "\\b"; break;
        case '\f': out << "\\f"; break;
        case '\n': out << "\\n"; break;
        case '\r': out << "\\r"; break;
        case '\t': out << "\\t"; break;
        default: out << *it; break;
        }
    }
    return out.str();
}

std::string jsonString(const std::string& value) {
    return "\"" + jsonEscape(value) + "\"";
}

std::string jsonNullable(const std::string& value) {
    return value.empty() ? "null" : jsonString(value);
}

Any DDSMember::toAny() const {
    VariantDict value;
    value["id"] = Any(id);
    value["type_id"] = Any(typeId);
    value["name"] = Any(name);
    value["ordinal"] = Any(ordinal);
    value["member_kind"] = Any(memberKind);
    value["primitive_type"] = Any(primitiveType);
    value["ref_type_id"] = Any(refTypeId);
    value["is_sequence"] = Any(isSequence);
    value["sequence_bound"] = Any(sequenceBound);
    value["is_array"] = Any(isArray);
    value["array_dimensions"] = Any(arrayDimensions);
    value["string_bound"] = Any(stringBound);
    value["is_key"] = Any(isKey);
    value["is_optional"] = Any(isOptional);
    value["description"] = Any(description);
    return Any(value);
}

std::string DDSMember::toJson() const {
    std::ostringstream out;
    bool first = true;
    out << "{";
    addField(out, first, "id", id);
    addField(out, first, "type_id", typeId);
    addField(out, first, "name", name);
    addField(out, first, "ordinal", intJson(ordinal), true);
    addField(out, first, "member_kind", memberKind);
    addField(out, first, "primitive_type", jsonNullable(primitiveType), true);
    addField(out, first, "ref_type_id", jsonNullable(refTypeId), true);
    addField(out, first, "is_sequence", boolJson(isSequence), true);
    addField(out, first, "sequence_bound", sequenceBound < 0 ? "null" : intJson(sequenceBound), true);
    addField(out, first, "is_array", boolJson(isArray), true);
    addField(out, first, "array_dimensions", arrayDimensions.empty() ? "null" : arrayDimensions, true);
    addField(out, first, "string_bound", stringBound < 0 ? "null" : intJson(stringBound), true);
    addField(out, first, "is_key", boolJson(isKey), true);
    addField(out, first, "is_optional", boolJson(isOptional), true);
    addField(out, first, "annotations", annotations.empty() ? "null" : annotations, true);
    addField(out, first, "enum_value", hasEnumValue ? intJson(enumValue) : "null", true);
    addField(out, first, "case_labels", caseLabels.empty() ? "null" : caseLabels, true);
    addField(out, first, "default_value", jsonNullable(defaultValue), true);
    addField(out, first, "description", jsonNullable(description), true);
    out << "}";
    return out.str();
}

Any DDSType::toAny() const {
    VariantDict value;
    VariantList memberValues;
    for (size_t i = 0; i < members.size(); ++i) {
        memberValues.push_back(members[i].toAny());
    }
    value["id"] = Any(id);
    value["project_id"] = Any(projectId);
    value["package_id"] = Any(packageId);
    value["name"] = Any(name);
    value["kind"] = Any(kind);
    value["description"] = Any(description);
    value["members"] = Any(memberValues);
    return Any(value);
}

std::string DDSType::toJson() const {
    std::ostringstream out;
    bool first = true;
    out << "{";
    addField(out, first, "id", id);
    addField(out, first, "project_id", projectId);
    addField(out, first, "package_id", jsonNullable(packageId), true);
    addField(out, first, "name", name);
    addField(out, first, "kind", kind);
    addField(out, first, "base_type_id", jsonNullable(baseTypeId), true);
    addField(out, first, "extensibility", extensibility);
    addField(out, first, "description", jsonNullable(description), true);
    addField(out, first, "annotations", annotations.empty() ? "null" : annotations, true);
    out << ",\"members\":[";
    for (size_t i = 0; i < members.size(); ++i) {
        if (i > 0) {
            out << ",";
        }
        out << members[i].toJson();
    }
    out << "]}";
    return out.str();
}

Any DDSPackage::toAny() const {
    VariantDict value;
    value["id"] = Any(id);
    value["project_id"] = Any(projectId);
    value["parent_id"] = Any(parentId);
    value["name"] = Any(name);
    value["kind"] = Any(kind);
    return Any(value);
}

std::string DDSPackage::toJson() const {
    std::ostringstream out;
    bool first = true;
    out << "{";
    addField(out, first, "id", id);
    addField(out, first, "project_id", projectId);
    addField(out, first, "parent_id", jsonNullable(parentId), true);
    addField(out, first, "name", name);
    addField(out, first, "kind", kind);
    addField(out, first, "description", jsonNullable(description), true);
    addField(out, first, "ordinal", intJson(ordinal), true);
    out << "}";
    return out.str();
}

Any DDSProject::toAny() const {
    VariantDict value;
    VariantList packageValues;
    VariantList typeValues;
    for (size_t i = 0; i < packages.size(); ++i) {
        packageValues.push_back(packages[i].toAny());
    }
    for (size_t i = 0; i < types.size(); ++i) {
        typeValues.push_back(types[i].toAny());
    }
    value["id"] = Any(id);
    value["name"] = Any(name);
    value["description"] = Any(description);
    value["version"] = Any(version);
    value["packages"] = Any(packageValues);
    value["types"] = Any(typeValues);
    return Any(value);
}

std::string DDSProject::toJson() const {
    std::ostringstream out;
    out << "{";
    out << "\"id\":" << jsonString(id);
    out << ",\"name\":" << jsonString(name);
    out << ",\"description\":" << jsonNullable(description);
    out << ",\"version\":" << jsonNullable(version);
    out << ",\"packages\":[";
    for (size_t i = 0; i < packages.size(); ++i) {
        if (i > 0) out << ",";
        out << packages[i].toJson();
    }
    out << "],\"types\":[";
    for (size_t i = 0; i < types.size(); ++i) {
        if (i > 0) out << ",";
        out << types[i].toJson();
    }
    out << "]}";
    return out.str();
}

} // namespace dds
