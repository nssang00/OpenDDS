#pragma once

#include "utils/Any.h"

#include <sstream>
#include <string>
#include <vector>

namespace dds {

struct DDSMember {
    std::string id;
    std::string typeId;
    std::string name;
    int ordinal = 0;
    std::string memberKind = "field";
    std::string primitiveType;
    std::string refTypeId;
    std::string eaTypeName;
    bool isSequence = false;
    int sequenceBound = -1;
    bool isArray = false;
    std::string arrayDimensions;
    int stringBound = -1;
    bool isKey = false;
    bool isOptional = false;
    std::string annotations;
    int enumValue = 0;
    bool hasEnumValue = false;
    std::string caseLabels;
    std::string defaultValue;
    std::string description;
    std::string eaGuid;
    std::string eaStereotype;
    std::string source = "manual";

    Any toAny() const;
    std::string toJson() const;
};

struct DDSType {
    std::string id;
    std::string projectId;
    std::string packageId;
    std::string name;
    std::string kind = "struct";
    std::string baseTypeId;
    std::string extensibility = "appendable";
    std::string description;
    std::string annotations;
    std::string eaGuid;
    std::string eaObjectType;
    std::string eaStereotype;
    std::string source = "manual";
    std::vector<DDSMember> members;

    Any toAny() const;
    std::string toJson() const;
};

struct DDSPackage {
    std::string id;
    std::string projectId;
    std::string parentId;
    std::string name;
    std::string kind = "folder";
    std::string description;
    int ordinal = 0;
    std::string eaGuid;
    std::string eaStereotype;
    std::string source = "manual";

    Any toAny() const;
    std::string toJson() const;
};

struct DDSDomain {
    std::string id;
    std::string projectId;
    std::string packageId;
    std::string name;
    int domainId = 0;
    std::string description;
    std::string eaGuid;
    std::string eaStereotype;
    std::string source = "manual";
};

struct DDSRegisterType {
    std::string id;
    std::string domainId;
    std::string typeId;
    std::string registerName;
    std::string description;
};

struct DDSTopic {
    std::string id;
    std::string projectId;
    std::string packageId;
    std::string domainId;
    std::string name;
    std::string registerTypeId;
    std::string qosProfileId;
    std::string description;
    std::string eaGuid;
    std::string eaStereotype;
    std::string source = "manual";
};

struct DDSQosPolicy {
    std::string id;
    std::string profileId;
    std::string entityKind;
    std::string policyName;
    std::string policyValue;
};

struct DDSQosProfile {
    std::string id;
    std::string projectId;
    std::string name;
    std::string baseProfileId;
    std::string description;
    std::vector<DDSQosPolicy> policies;
};

struct DDSPublisher {
    std::string id;
    std::string participantId;
    std::string name;
    std::string qosProfileId;
    std::string description;
    std::string eaGuid;
    std::string eaStereotype;
    std::string source = "manual";
};

struct DDSSubscriber {
    std::string id;
    std::string participantId;
    std::string name;
    std::string qosProfileId;
    std::string description;
    std::string eaGuid;
    std::string eaStereotype;
    std::string source = "manual";
};

struct DDSWriter {
    std::string id;
    std::string publisherId;
    std::string topicId;
    std::string name;
    std::string qosProfileId;
    std::string description;
    std::string eaGuid;
    std::string eaStereotype;
    std::string source = "manual";
};

struct DDSReader {
    std::string id;
    std::string subscriberId;
    std::string topicId;
    std::string name;
    std::string qosProfileId;
    std::string description;
    std::string eaGuid;
    std::string eaStereotype;
    std::string source = "manual";
};

struct DDSParticipant {
    std::string id;
    std::string projectId;
    std::string packageId;
    std::string domainId;
    std::string name;
    std::string qosProfileId;
    std::string description;
    std::string eaGuid;
    std::string eaStereotype;
    std::string source = "manual";
    std::vector<DDSPublisher> publishers;
    std::vector<DDSSubscriber> subscribers;
};

struct DDSProject {
    std::string id;
    std::string name;
    std::string description;
    std::string version;
    std::vector<DDSPackage> packages;
    std::vector<DDSType> types;
    std::vector<DDSDomain> domains;
    std::vector<DDSRegisterType> registerTypes;
    std::vector<DDSTopic> topics;
    std::vector<DDSQosProfile> qosProfiles;
    std::vector<DDSParticipant> participants;

    Any toAny() const;
    std::string toJson() const;
};

std::string jsonEscape(const std::string& value);
std::string jsonString(const std::string& value);
std::string jsonNullable(const std::string& value);

} // namespace dds
