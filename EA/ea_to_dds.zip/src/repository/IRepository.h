#pragma once

#include "dds/DDSModels.h"

namespace dds {

class IRepository {
public:
    virtual ~IRepository() {}

    virtual void initializeSchema() = 0;

    virtual void saveProject(const DDSProject& project) = 0;
    virtual void savePackage(const DDSPackage& package) = 0;
    virtual void saveType(const DDSType& type) = 0;
    virtual void saveMember(const DDSMember& member) = 0;
    virtual void saveDomain(const DDSDomain& domain) = 0;
    virtual void saveRegisterType(const DDSRegisterType& registerType) = 0;
    virtual void saveTopic(const DDSTopic& topic) = 0;
    virtual void saveQosProfile(const DDSQosProfile& profile) = 0;
    virtual void saveQosPolicy(const DDSQosPolicy& policy) = 0;
    virtual void saveParticipant(const DDSParticipant& participant) = 0;
    virtual void savePublisher(const DDSPublisher& publisher) = 0;
    virtual void saveSubscriber(const DDSSubscriber& subscriber) = 0;
    virtual void saveWriter(const DDSWriter& writer) = 0;
    virtual void saveReader(const DDSReader& reader) = 0;

    virtual DDSProject loadProject(const std::string& id) = 0;
    virtual std::vector<DDSPackage> loadPackages(const std::string& projectId) = 0;
    virtual std::vector<DDSType> loadTypes(const std::string& projectId) = 0;
    virtual std::vector<DDSMember> loadMembers(const std::string& typeId) = 0;
};

} // namespace dds
