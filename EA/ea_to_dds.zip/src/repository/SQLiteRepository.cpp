#include "repository/SQLiteRepository.h"

#include <fstream>
#include <iterator>
#include <stdexcept>
#include <sqlite3.h>

namespace dds {

namespace {
std::string readSchemaFile() {
    std::ifstream file("dds_collab.sql");
    if (!file) {
        throw std::runtime_error("dds_collab.sql not found in working directory");
    }
    return std::string((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
}

int nullableInt(int value) {
    return value < 0 ? 1 : 0;
}
}

SQLiteRepository::SQLiteRepository(const std::string& path) : db_(nullptr) {
    if (sqlite3_open(path.c_str(), &db_) != SQLITE_OK) {
        std::string message = sqlite3_errmsg(db_);
        sqlite3_close(db_);
        db_ = nullptr;
        throw std::runtime_error("failed to open SQLite database: " + message);
    }
    execute("PRAGMA foreign_keys = ON;");
}

SQLiteRepository::~SQLiteRepository() {
    if (db_ != nullptr) {
        sqlite3_close(db_);
    }
}

void SQLiteRepository::initializeSchema() {
    execute(readSchemaFile());
}

void SQLiteRepository::execute(const std::string& sql) {
    char* error = nullptr;
    if (sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &error) != SQLITE_OK) {
        std::string message = error == nullptr ? sqlite3_errmsg(db_) : error;
        sqlite3_free(error);
        throw std::runtime_error("SQLite execute failed: " + message);
    }
}

sqlite3_stmt* SQLiteRepository::prepare(const std::string& sql) {
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        throw std::runtime_error("SQLite prepare failed: " + std::string(sqlite3_errmsg(db_)));
    }
    return stmt;
}

void SQLiteRepository::stepDone(sqlite3_stmt* stmt) {
    int rc = sqlite3_step(stmt);
    if (rc != SQLITE_DONE) {
        std::string message = sqlite3_errmsg(db_);
        sqlite3_finalize(stmt);
        throw std::runtime_error("SQLite step failed: " + message);
    }
    sqlite3_finalize(stmt);
}

void SQLiteRepository::bindText(sqlite3_stmt* stmt, int index, const std::string& value) {
    sqlite3_bind_text(stmt, index, value.c_str(), -1, SQLITE_TRANSIENT);
}

void SQLiteRepository::bindNullableText(sqlite3_stmt* stmt, int index, const std::string& value) {
    if (value.empty()) {
        sqlite3_bind_null(stmt, index);
    } else {
        bindText(stmt, index, value);
    }
}

std::string SQLiteRepository::columnText(sqlite3_stmt* stmt, int index) {
    const unsigned char* text = sqlite3_column_text(stmt, index);
    return text == nullptr ? std::string() : reinterpret_cast<const char*>(text);
}

void SQLiteRepository::saveProject(const DDSProject& project) {
    sqlite3_stmt* stmt = prepare(
        "INSERT OR REPLACE INTO projects(id,name,description,version,created_at,updated_at) "
        "VALUES(?,?,?,?,COALESCE((SELECT created_at FROM projects WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, project.id);
    bindText(stmt, 2, project.name);
    bindNullableText(stmt, 3, project.description);
    bindNullableText(stmt, 4, project.version);
    bindText(stmt, 5, project.id);
    stepDone(stmt);
}

void SQLiteRepository::savePackage(const DDSPackage& package) {
    sqlite3_stmt* stmt = prepare(
        "INSERT OR REPLACE INTO packages(id,project_id,parent_id,name,kind,description,ordinal,ea_guid,ea_stereotype,source,created_at,updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,COALESCE((SELECT created_at FROM packages WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, package.id);
    bindText(stmt, 2, package.projectId);
    bindNullableText(stmt, 3, package.parentId);
    bindText(stmt, 4, package.name);
    bindNullableText(stmt, 5, package.kind);
    bindNullableText(stmt, 6, package.description);
    sqlite3_bind_int(stmt, 7, package.ordinal);
    bindNullableText(stmt, 8, package.eaGuid);
    bindNullableText(stmt, 9, package.eaStereotype);
    bindText(stmt, 10, package.source);
    bindText(stmt, 11, package.id);
    stepDone(stmt);
}

void SQLiteRepository::saveType(const DDSType& type) {
    sqlite3_stmt* stmt = prepare(
        "INSERT OR REPLACE INTO types(id,project_id,package_id,name,kind,base_type_id,extensibility,description,annotations,ea_guid,ea_object_type,ea_stereotype,source,created_at,updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,COALESCE((SELECT created_at FROM types WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, type.id);
    bindText(stmt, 2, type.projectId);
    bindNullableText(stmt, 3, type.packageId);
    bindText(stmt, 4, type.name);
    bindNullableText(stmt, 5, type.kind);
    bindNullableText(stmt, 6, type.baseTypeId);
    bindNullableText(stmt, 7, type.extensibility);
    bindNullableText(stmt, 8, type.description);
    bindNullableText(stmt, 9, type.annotations);
    bindNullableText(stmt, 10, type.eaGuid);
    bindNullableText(stmt, 11, type.eaObjectType);
    bindNullableText(stmt, 12, type.eaStereotype);
    bindText(stmt, 13, type.source);
    bindText(stmt, 14, type.id);
    stepDone(stmt);
}

void SQLiteRepository::saveMember(const DDSMember& member) {
    sqlite3_stmt* stmt = prepare(
        "INSERT OR REPLACE INTO type_members(id,type_id,name,ordinal,member_kind,primitive_type,ref_type_id,ea_type_name,is_sequence,sequence_bound,is_array,array_dimensions,string_bound,is_key,is_optional,annotations,enum_value,case_labels,default_value,description,ea_guid,ea_stereotype,source,created_at,updated_at) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,COALESCE((SELECT created_at FROM type_members WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, member.id);
    bindText(stmt, 2, member.typeId);
    bindText(stmt, 3, member.name);
    sqlite3_bind_int(stmt, 4, member.ordinal);
    bindNullableText(stmt, 5, member.memberKind);
    bindNullableText(stmt, 6, member.primitiveType);
    bindNullableText(stmt, 7, member.refTypeId);
    bindNullableText(stmt, 8, member.eaTypeName);
    sqlite3_bind_int(stmt, 9, member.isSequence ? 1 : 0);
    nullableInt(member.sequenceBound) ? sqlite3_bind_null(stmt, 10) : sqlite3_bind_int(stmt, 10, member.sequenceBound);
    sqlite3_bind_int(stmt, 11, member.isArray ? 1 : 0);
    bindNullableText(stmt, 12, member.arrayDimensions);
    nullableInt(member.stringBound) ? sqlite3_bind_null(stmt, 13) : sqlite3_bind_int(stmt, 13, member.stringBound);
    sqlite3_bind_int(stmt, 14, member.isKey ? 1 : 0);
    sqlite3_bind_int(stmt, 15, member.isOptional ? 1 : 0);
    bindNullableText(stmt, 16, member.annotations);
    member.hasEnumValue ? sqlite3_bind_int(stmt, 17, member.enumValue) : sqlite3_bind_null(stmt, 17);
    bindNullableText(stmt, 18, member.caseLabels);
    bindNullableText(stmt, 19, member.defaultValue);
    bindNullableText(stmt, 20, member.description);
    bindNullableText(stmt, 21, member.eaGuid);
    bindNullableText(stmt, 22, member.eaStereotype);
    bindText(stmt, 23, member.source);
    bindText(stmt, 24, member.id);
    stepDone(stmt);
}

void SQLiteRepository::saveDomain(const DDSDomain& domain) {
    sqlite3_stmt* stmt = prepare("INSERT OR REPLACE INTO domains(id,project_id,package_id,name,domain_id,description,ea_guid,ea_stereotype,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,COALESCE((SELECT created_at FROM domains WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, domain.id);
    bindText(stmt, 2, domain.projectId);
    bindNullableText(stmt, 3, domain.packageId);
    bindText(stmt, 4, domain.name);
    sqlite3_bind_int(stmt, 5, domain.domainId);
    bindNullableText(stmt, 6, domain.description);
    bindNullableText(stmt, 7, domain.eaGuid);
    bindNullableText(stmt, 8, domain.eaStereotype);
    bindText(stmt, 9, domain.source);
    bindText(stmt, 10, domain.id);
    stepDone(stmt);
}

void SQLiteRepository::saveRegisterType(const DDSRegisterType& registerType) {
    sqlite3_stmt* stmt = prepare("INSERT OR REPLACE INTO register_types(id,domain_id,type_id,register_name,description,created_at,updated_at) VALUES(?,?,?,?,?,COALESCE((SELECT created_at FROM register_types WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, registerType.id);
    bindText(stmt, 2, registerType.domainId);
    bindText(stmt, 3, registerType.typeId);
    bindNullableText(stmt, 4, registerType.registerName);
    bindNullableText(stmt, 5, registerType.description);
    bindText(stmt, 6, registerType.id);
    stepDone(stmt);
}

void SQLiteRepository::saveTopic(const DDSTopic& topic) {
    sqlite3_stmt* stmt = prepare("INSERT OR REPLACE INTO topics(id,project_id,package_id,domain_id,name,register_type_id,qos_profile_id,description,ea_guid,ea_stereotype,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,COALESCE((SELECT created_at FROM topics WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, topic.id);
    bindText(stmt, 2, topic.projectId);
    bindNullableText(stmt, 3, topic.packageId);
    bindNullableText(stmt, 4, topic.domainId);
    bindText(stmt, 5, topic.name);
    bindNullableText(stmt, 6, topic.registerTypeId);
    bindNullableText(stmt, 7, topic.qosProfileId);
    bindNullableText(stmt, 8, topic.description);
    bindNullableText(stmt, 9, topic.eaGuid);
    bindNullableText(stmt, 10, topic.eaStereotype);
    bindText(stmt, 11, topic.source);
    bindText(stmt, 12, topic.id);
    stepDone(stmt);
}

void SQLiteRepository::saveQosProfile(const DDSQosProfile& profile) {
    sqlite3_stmt* stmt = prepare("INSERT OR REPLACE INTO qos_profiles(id,project_id,name,base_profile_id,description,created_at,updated_at) VALUES(?,?,?,?,?,COALESCE((SELECT created_at FROM qos_profiles WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, profile.id);
    bindText(stmt, 2, profile.projectId);
    bindText(stmt, 3, profile.name);
    bindNullableText(stmt, 4, profile.baseProfileId);
    bindNullableText(stmt, 5, profile.description);
    bindText(stmt, 6, profile.id);
    stepDone(stmt);
}

void SQLiteRepository::saveQosPolicy(const DDSQosPolicy& policy) {
    sqlite3_stmt* stmt = prepare("INSERT OR REPLACE INTO qos_policies(id,profile_id,entity_kind,policy_name,policy_value,created_at,updated_at) VALUES(?,?,?,?,?,COALESCE((SELECT created_at FROM qos_policies WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, policy.id);
    bindText(stmt, 2, policy.profileId);
    bindNullableText(stmt, 3, policy.entityKind);
    bindText(stmt, 4, policy.policyName);
    bindNullableText(stmt, 5, policy.policyValue);
    bindText(stmt, 6, policy.id);
    stepDone(stmt);
}

void SQLiteRepository::saveParticipant(const DDSParticipant& participant) {
    sqlite3_stmt* stmt = prepare("INSERT OR REPLACE INTO participants(id,project_id,package_id,domain_id,name,qos_profile_id,description,ea_guid,ea_stereotype,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,COALESCE((SELECT created_at FROM participants WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, participant.id);
    bindText(stmt, 2, participant.projectId);
    bindNullableText(stmt, 3, participant.packageId);
    bindNullableText(stmt, 4, participant.domainId);
    bindText(stmt, 5, participant.name);
    bindNullableText(stmt, 6, participant.qosProfileId);
    bindNullableText(stmt, 7, participant.description);
    bindNullableText(stmt, 8, participant.eaGuid);
    bindNullableText(stmt, 9, participant.eaStereotype);
    bindText(stmt, 10, participant.source);
    bindText(stmt, 11, participant.id);
    stepDone(stmt);
}

void SQLiteRepository::savePublisher(const DDSPublisher& publisher) {
    sqlite3_stmt* stmt = prepare("INSERT OR REPLACE INTO publishers(id,participant_id,name,qos_profile_id,description,ea_guid,ea_stereotype,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,COALESCE((SELECT created_at FROM publishers WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, publisher.id);
    bindText(stmt, 2, publisher.participantId);
    bindText(stmt, 3, publisher.name);
    bindNullableText(stmt, 4, publisher.qosProfileId);
    bindNullableText(stmt, 5, publisher.description);
    bindNullableText(stmt, 6, publisher.eaGuid);
    bindNullableText(stmt, 7, publisher.eaStereotype);
    bindText(stmt, 8, publisher.source);
    bindText(stmt, 9, publisher.id);
    stepDone(stmt);
}

void SQLiteRepository::saveSubscriber(const DDSSubscriber& subscriber) {
    sqlite3_stmt* stmt = prepare("INSERT OR REPLACE INTO subscribers(id,participant_id,name,qos_profile_id,description,ea_guid,ea_stereotype,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,COALESCE((SELECT created_at FROM subscribers WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, subscriber.id);
    bindText(stmt, 2, subscriber.participantId);
    bindText(stmt, 3, subscriber.name);
    bindNullableText(stmt, 4, subscriber.qosProfileId);
    bindNullableText(stmt, 5, subscriber.description);
    bindNullableText(stmt, 6, subscriber.eaGuid);
    bindNullableText(stmt, 7, subscriber.eaStereotype);
    bindText(stmt, 8, subscriber.source);
    bindText(stmt, 9, subscriber.id);
    stepDone(stmt);
}

void SQLiteRepository::saveWriter(const DDSWriter& writer) {
    sqlite3_stmt* stmt = prepare("INSERT OR REPLACE INTO writers(id,publisher_id,topic_id,name,qos_profile_id,description,ea_guid,ea_stereotype,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,COALESCE((SELECT created_at FROM writers WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, writer.id);
    bindText(stmt, 2, writer.publisherId);
    bindNullableText(stmt, 3, writer.topicId);
    bindText(stmt, 4, writer.name);
    bindNullableText(stmt, 5, writer.qosProfileId);
    bindNullableText(stmt, 6, writer.description);
    bindNullableText(stmt, 7, writer.eaGuid);
    bindNullableText(stmt, 8, writer.eaStereotype);
    bindText(stmt, 9, writer.source);
    bindText(stmt, 10, writer.id);
    stepDone(stmt);
}

void SQLiteRepository::saveReader(const DDSReader& reader) {
    sqlite3_stmt* stmt = prepare("INSERT OR REPLACE INTO readers(id,subscriber_id,topic_id,name,qos_profile_id,description,ea_guid,ea_stereotype,source,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,COALESCE((SELECT created_at FROM readers WHERE id=?),datetime('now')),datetime('now'))");
    bindText(stmt, 1, reader.id);
    bindText(stmt, 2, reader.subscriberId);
    bindNullableText(stmt, 3, reader.topicId);
    bindText(stmt, 4, reader.name);
    bindNullableText(stmt, 5, reader.qosProfileId);
    bindNullableText(stmt, 6, reader.description);
    bindNullableText(stmt, 7, reader.eaGuid);
    bindNullableText(stmt, 8, reader.eaStereotype);
    bindText(stmt, 9, reader.source);
    bindText(stmt, 10, reader.id);
    stepDone(stmt);
}

DDSProject SQLiteRepository::loadProject(const std::string& id) {
    sqlite3_stmt* stmt = prepare("SELECT id,name,description,version FROM projects WHERE id=?");
    bindText(stmt, 1, id);
    DDSProject project;
    if (sqlite3_step(stmt) == SQLITE_ROW) {
        project.id = columnText(stmt, 0);
        project.name = columnText(stmt, 1);
        project.description = columnText(stmt, 2);
        project.version = columnText(stmt, 3);
    } else {
        sqlite3_finalize(stmt);
        throw std::runtime_error("project not found: " + id);
    }
    sqlite3_finalize(stmt);
    project.packages = loadPackages(project.id);
    project.types = loadTypes(project.id);
    return project;
}

std::vector<DDSPackage> SQLiteRepository::loadPackages(const std::string& projectId) {
    sqlite3_stmt* stmt = prepare("SELECT id,project_id,parent_id,name,kind,description,ordinal,ea_guid,ea_stereotype,source FROM packages WHERE project_id=? ORDER BY ordinal,name");
    bindText(stmt, 1, projectId);
    std::vector<DDSPackage> packages;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        DDSPackage package;
        package.id = columnText(stmt, 0);
        package.projectId = columnText(stmt, 1);
        package.parentId = columnText(stmt, 2);
        package.name = columnText(stmt, 3);
        package.kind = columnText(stmt, 4);
        package.description = columnText(stmt, 5);
        package.ordinal = sqlite3_column_int(stmt, 6);
        package.eaGuid = columnText(stmt, 7);
        package.eaStereotype = columnText(stmt, 8);
        package.source = columnText(stmt, 9);
        packages.push_back(package);
    }
    sqlite3_finalize(stmt);
    return packages;
}

std::vector<DDSType> SQLiteRepository::loadTypes(const std::string& projectId) {
    sqlite3_stmt* stmt = prepare("SELECT id,project_id,package_id,name,kind,base_type_id,extensibility,description,annotations,ea_guid,ea_object_type,ea_stereotype,source FROM types WHERE project_id=? ORDER BY name");
    bindText(stmt, 1, projectId);
    std::vector<DDSType> types;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        DDSType type;
        type.id = columnText(stmt, 0);
        type.projectId = columnText(stmt, 1);
        type.packageId = columnText(stmt, 2);
        type.name = columnText(stmt, 3);
        type.kind = columnText(stmt, 4);
        type.baseTypeId = columnText(stmt, 5);
        type.extensibility = columnText(stmt, 6);
        type.description = columnText(stmt, 7);
        type.annotations = columnText(stmt, 8);
        type.eaGuid = columnText(stmt, 9);
        type.eaObjectType = columnText(stmt, 10);
        type.eaStereotype = columnText(stmt, 11);
        type.source = columnText(stmt, 12);
        type.members = loadMembers(type.id);
        types.push_back(type);
    }
    sqlite3_finalize(stmt);
    return types;
}

std::vector<DDSMember> SQLiteRepository::loadMembers(const std::string& typeId) {
    sqlite3_stmt* stmt = prepare("SELECT id,type_id,name,ordinal,member_kind,primitive_type,ref_type_id,ea_type_name,is_sequence,sequence_bound,is_array,array_dimensions,string_bound,is_key,is_optional,annotations,enum_value,case_labels,default_value,description,ea_guid,ea_stereotype,source FROM type_members WHERE type_id=? ORDER BY ordinal,name");
    bindText(stmt, 1, typeId);
    std::vector<DDSMember> members;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        DDSMember member;
        member.id = columnText(stmt, 0);
        member.typeId = columnText(stmt, 1);
        member.name = columnText(stmt, 2);
        member.ordinal = sqlite3_column_int(stmt, 3);
        member.memberKind = columnText(stmt, 4);
        member.primitiveType = columnText(stmt, 5);
        member.refTypeId = columnText(stmt, 6);
        member.eaTypeName = columnText(stmt, 7);
        member.isSequence = sqlite3_column_int(stmt, 8) != 0;
        member.sequenceBound = sqlite3_column_type(stmt, 9) == SQLITE_NULL ? -1 : sqlite3_column_int(stmt, 9);
        member.isArray = sqlite3_column_int(stmt, 10) != 0;
        member.arrayDimensions = columnText(stmt, 11);
        member.stringBound = sqlite3_column_type(stmt, 12) == SQLITE_NULL ? -1 : sqlite3_column_int(stmt, 12);
        member.isKey = sqlite3_column_int(stmt, 13) != 0;
        member.isOptional = sqlite3_column_int(stmt, 14) != 0;
        member.annotations = columnText(stmt, 15);
        member.hasEnumValue = sqlite3_column_type(stmt, 16) != SQLITE_NULL;
        member.enumValue = member.hasEnumValue ? sqlite3_column_int(stmt, 16) : 0;
        member.caseLabels = columnText(stmt, 17);
        member.defaultValue = columnText(stmt, 18);
        member.description = columnText(stmt, 19);
        member.eaGuid = columnText(stmt, 20);
        member.eaStereotype = columnText(stmt, 21);
        member.source = columnText(stmt, 22);
        members.push_back(member);
    }
    sqlite3_finalize(stmt);
    return members;
}

} // namespace dds
