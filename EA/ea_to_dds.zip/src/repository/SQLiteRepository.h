#pragma once

#include "repository/IRepository.h"

struct sqlite3;
struct sqlite3_stmt;

namespace dds {

class SQLiteRepository : public IRepository {
public:
    explicit SQLiteRepository(const std::string& path);
    ~SQLiteRepository();

    SQLiteRepository(const SQLiteRepository&) = delete;
    SQLiteRepository& operator=(const SQLiteRepository&) = delete;

    void initializeSchema();

    void saveProject(const DDSProject& project);
    void savePackage(const DDSPackage& package);
    void saveType(const DDSType& type);
    void saveMember(const DDSMember& member);
    void saveDomain(const DDSDomain& domain);
    void saveRegisterType(const DDSRegisterType& registerType);
    void saveTopic(const DDSTopic& topic);
    void saveQosProfile(const DDSQosProfile& profile);
    void saveQosPolicy(const DDSQosPolicy& policy);
    void saveParticipant(const DDSParticipant& participant);
    void savePublisher(const DDSPublisher& publisher);
    void saveSubscriber(const DDSSubscriber& subscriber);
    void saveWriter(const DDSWriter& writer);
    void saveReader(const DDSReader& reader);

    DDSProject loadProject(const std::string& id);
    std::vector<DDSPackage> loadPackages(const std::string& projectId);
    std::vector<DDSType> loadTypes(const std::string& projectId);
    std::vector<DDSMember> loadMembers(const std::string& typeId);

private:
    sqlite3* db_;

    void execute(const std::string& sql);
    sqlite3_stmt* prepare(const std::string& sql);
    void stepDone(sqlite3_stmt* stmt);
    static void bindText(sqlite3_stmt* stmt, int index, const std::string& value);
    static void bindNullableText(sqlite3_stmt* stmt, int index, const std::string& value);
    static std::string columnText(sqlite3_stmt* stmt, int index);
};

} // namespace dds
