#pragma once

#include "dds/DDSModels.h"

#include <map>

namespace dds {

class IDLGenerator {
public:
    std::string generateProject(const DDSProject& project) const;
    std::string generateType(const DDSType& type) const;

private:
    std::string generateType(const DDSType& type, const std::map<std::string, std::string>& typeNamesById) const;
    std::string idlTypeName(const DDSMember& member, const std::map<std::string, std::string>& typeNamesById) const;
    std::string arraySuffix(const DDSMember& member) const;
};

} // namespace dds
