#pragma once

#include "dds/DDSModels.h"

namespace dds {

class MarkdownGenerator {
public:
    std::string generateProject(const DDSProject& project) const;
    std::string generateType(const DDSType& type) const;
};

} // namespace dds
