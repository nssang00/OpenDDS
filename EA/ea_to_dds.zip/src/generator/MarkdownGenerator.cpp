#include "generator/MarkdownGenerator.h"

#include <sstream>

namespace dds {

std::string MarkdownGenerator::generateProject(const DDSProject& project) const {
    std::ostringstream out;
    out << "# " << project.name << "\n\n";
    if (!project.description.empty()) {
        out << project.description << "\n\n";
    }
    if (!project.version.empty()) {
        out << "- Version: " << project.version << "\n\n";
    }
    out << "## Types\n\n";
    for (size_t i = 0; i < project.types.size(); ++i) {
        out << generateType(project.types[i]) << "\n";
    }
    return out.str();
}

std::string MarkdownGenerator::generateType(const DDSType& type) const {
    std::ostringstream out;
    out << "### " << type.name << "\n\n";
    out << "- Kind: " << type.kind << "\n";
    out << "- Extensibility: " << type.extensibility << "\n";
    if (!type.description.empty()) {
        out << "- Description: " << type.description << "\n";
    }
    out << "\n";
    if (!type.members.empty()) {
        out << "| Name | Kind | Type | Key | Optional | Description |\n";
        out << "|---|---|---|---|---|---|\n";
        for (size_t i = 0; i < type.members.size(); ++i) {
            const DDSMember& member = type.members[i];
            out << "| " << member.name
                << " | " << member.memberKind
                << " | " << (member.primitiveType.empty() ? member.refTypeId : member.primitiveType)
                << " | " << (member.isKey ? "yes" : "")
                << " | " << (member.isOptional ? "yes" : "")
                << " | " << member.description
                << " |\n";
        }
        out << "\n";
    }
    return out.str();
}

} // namespace dds
