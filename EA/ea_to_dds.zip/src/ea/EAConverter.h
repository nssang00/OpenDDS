#pragma once

#include "dds/DDSModels.h"
#include "ea/EAModels.h"

namespace dds {
namespace ea {

class EAConverter {
public:
    DDSType convertType(const EAObject& object, const std::string& projectId, const std::string& packageId) const;
    DDSMember convertMember(const EAAttribute& attribute, const std::string& typeId) const;

    static std::string mapTypeKind(const std::string& objectType, const std::string& stereotype);
    static std::string mapPrimitiveType(const std::string& eaTypeName);
    static void applyBounds(const std::string& lowerBound, const std::string& upperBound, DDSMember& member);
};

} // namespace ea
} // namespace dds
