#pragma once

#include <string>
#include <vector>

namespace dds {
namespace ea {

struct EAObject {
    int objectId = 0;
    std::string name;
    std::string objectType;
    std::string stereotype;
    int packageId = 0;
    std::string note;
    std::string eaGuid;
    int classifier = 0;
    std::string classifierGuid;
    int parentId = 0;
};

struct EAAttribute {
    int id = 0;
    int objectId = 0;
    std::string name;
    std::string type;
    std::string stereotype;
    std::string lowerBound;
    std::string upperBound;
    std::string defaultValue;
    int classifier = 0;
    std::string notes;
    int pos = 0;
    std::string eaGuid;
};

struct EAPackage {
    int packageId = 0;
    int parentId = 0;
    std::string name;
    std::string notes;
    std::string eaGuid;
    int ordinal = 0;
};

struct EAObjectProperty {
    int objectId = 0;
    std::string property;
    std::string value;
};

struct EAAttributeTag {
    int attributeId = 0;
    std::string property;
    std::string value;
};

struct EAConnector {
    int connectorId = 0;
    int startObjectId = 0;
    int endObjectId = 0;
    std::string connectorType;
    std::string subtype;
    std::string stereotype;
};

} // namespace ea
} // namespace dds
