#include "ea/EAConverter.h"

#include <algorithm>
#include <cctype>
#include <cstdlib>
#include <sstream>

namespace dds {
namespace ea {

namespace {
std::string lower(std::string value) {
    std::transform(value.begin(), value.end(), value.begin(), [](char c) {
        return static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    });
    return value;
}

bool parsePositiveInt(const std::string& value, int& parsed) {
    if (value.empty()) {
        return false;
    }
    char* end = nullptr;
    long result = std::strtol(value.c_str(), &end, 10);
    if (*end != '\0' || result <= 0) {
        return false;
    }
    parsed = static_cast<int>(result);
    return true;
}
}

DDSType EAConverter::convertType(const EAObject& object, const std::string& projectId, const std::string& packageId) const {
    DDSType type;
    type.id = object.eaGuid.empty() ? object.name : object.eaGuid;
    type.projectId = projectId;
    type.packageId = packageId;
    type.name = object.name;
    type.kind = mapTypeKind(object.objectType, object.stereotype);
    type.description = object.note;
    type.eaGuid = object.eaGuid;
    type.eaObjectType = object.objectType;
    type.eaStereotype = object.stereotype;
    type.source = "ea";
    return type;
}

DDSMember EAConverter::convertMember(const EAAttribute& attribute, const std::string& typeId) const {
    DDSMember member;
    member.id = attribute.eaGuid.empty() ? attribute.name : attribute.eaGuid;
    member.typeId = typeId;
    member.name = attribute.name;
    member.ordinal = attribute.pos;
    member.memberKind = "field";
    member.eaTypeName = attribute.type;
    member.primitiveType = mapPrimitiveType(attribute.type);
    if (member.primitiveType.empty()) {
        member.refTypeId = attribute.type;
    }
    member.defaultValue = attribute.defaultValue;
    member.description = attribute.notes;
    member.eaGuid = attribute.eaGuid;
    member.eaStereotype = attribute.stereotype;
    member.source = "ea";
    if (lower(attribute.stereotype) == "key") {
        member.isKey = true;
    }
    applyBounds(attribute.lowerBound, attribute.upperBound, member);
    return member;
}

std::string EAConverter::mapTypeKind(const std::string& objectType, const std::string& stereotype) {
    const std::string ot = lower(objectType);
    const std::string st = lower(stereotype);
    if (ot == "enumeration") return "enum";
    if (ot == "datatype") return "typedef";
    if (ot == "interface") return "struct";
    if (ot == "class") {
        if (st == "enumeration") return "enum";
        if (st == "union") return "union";
        if (st == "typedef" || st == "alias") return "typedef";
        return "struct";
    }
    return "";
}

std::string EAConverter::mapPrimitiveType(const std::string& eaTypeName) {
    const std::string t = lower(eaTypeName);
    if (t == "long" || t == "int") return "int32";
    if (t == "short") return "int16";
    if (t == "unsigned long") return "uint32";
    if (t == "unsigned short") return "uint16";
    if (t == "long long") return "int64";
    if (t == "unsigned long long") return "uint64";
    if (t == "float") return "float32";
    if (t == "double") return "float64";
    if (t == "decimal" || t == "number" || t == "currency") return "float64";
    if (t == "long double") return "float128";
    if (t == "bool" || t == "boolean") return "boolean";
    if (t == "char") return "char";
    if (t == "wchar") return "wchar";
    if (t == "char*" || t == "string") return "string";
    if (t == "date" || t == "datetime" || t == "time") return "string";
    if (t == "wstring") return "wstring";
    if (t == "octet") return "octet";
    return "";
}

void EAConverter::applyBounds(const std::string& lowerBound, const std::string& upperBound, DDSMember& member) {
    if (upperBound == "0" || upperBound == "*") {
        member.isSequence = true;
        member.sequenceBound = -1;
        return;
    }

    int lowerValue = 0;
    int upperValue = 0;
    const bool hasLower = parsePositiveInt(lowerBound, lowerValue) || lowerBound == "0";
    const bool hasUpper = parsePositiveInt(upperBound, upperValue);

    if (lowerBound == "0" && upperBound == "1") {
        member.isOptional = true;
        return;
    }
    if (hasLower && hasUpper && lowerValue == upperValue && upperValue > 1) {
        member.isArray = true;
        std::ostringstream out;
        out << "[" << upperValue << "]";
        member.arrayDimensions = out.str();
        return;
    }
    if (hasLower && hasUpper && lowerValue < upperValue) {
        member.isSequence = true;
        member.sequenceBound = upperValue;
    }
}

} // namespace ea
} // namespace dds
