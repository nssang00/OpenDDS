#include "ea/EAReader.h"

#include <sstream>
#include <stdexcept>
#include <map>
#include <set>
#include <sqlite3.h>

namespace dds {
namespace ea {

EAReader::EAReader(const std::string& qeaPath) : db_(nullptr) {
    if (sqlite3_open(qeaPath.c_str(), &db_) != SQLITE_OK) {
        std::string message = sqlite3_errmsg(db_);
        sqlite3_close(db_);
        db_ = nullptr;
        throw std::runtime_error("failed to open QEA: " + message);
    }
}

EAReader::~EAReader() {
    if (db_ != nullptr) {
        sqlite3_close(db_);
    }
}

sqlite3_stmt* EAReader::prepare(const std::string& sql) const {
    sqlite3_stmt* stmt = nullptr;
    if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &stmt, nullptr) != SQLITE_OK) {
        throw std::runtime_error("QEA prepare failed: " + std::string(sqlite3_errmsg(db_)));
    }
    return stmt;
}

std::string EAReader::columnText(sqlite3_stmt* stmt, int index) {
    const unsigned char* text = sqlite3_column_text(stmt, index);
    return text == nullptr ? std::string() : reinterpret_cast<const char*>(text);
}

std::vector<EAPackage> EAReader::loadPackages() const {
    sqlite3_stmt* stmt = prepare(
        "SELECT Package_ID,Parent_ID,Name,Notes,ea_guid,TPos FROM t_package ORDER BY Parent_ID,TPos,Name");
    std::vector<EAPackage> packages;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAPackage package;
        package.packageId = sqlite3_column_int(stmt, 0);
        package.parentId = sqlite3_column_int(stmt, 1);
        package.name = columnText(stmt, 2);
        package.notes = columnText(stmt, 3);
        package.eaGuid = columnText(stmt, 4);
        package.ordinal = sqlite3_column_int(stmt, 5);
        packages.push_back(package);
    }
    sqlite3_finalize(stmt);
    return packages;
}

std::vector<int> EAReader::targetPackageIds(const std::string& rootPackageName) const {
    std::vector<EAPackage> packages = loadPackages();
    if (rootPackageName.empty()) {
        std::vector<int> ids;
        for (size_t i = 0; i < packages.size(); ++i) {
            ids.push_back(packages[i].packageId);
        }
        return ids;
    }

    std::map<int, std::vector<int> > children;
    std::vector<int> roots;
    for (size_t i = 0; i < packages.size(); ++i) {
        children[packages[i].parentId].push_back(packages[i].packageId);
        if (packages[i].name == rootPackageName) {
            roots.push_back(packages[i].packageId);
        }
    }

    std::set<int> result;
    std::vector<int> stack = roots;
    while (!stack.empty()) {
        int id = stack.back();
        stack.pop_back();
        if (!result.insert(id).second) {
            continue;
        }
        const std::vector<int>& childIds = children[id];
        for (size_t i = 0; i < childIds.size(); ++i) {
            stack.push_back(childIds[i]);
        }
    }
    return std::vector<int>(result.begin(), result.end());
}

std::vector<EAObject> EAReader::loadDdsObjects(const std::string& rootPackageName) const {
    std::vector<int> packageIds = targetPackageIds(rootPackageName);
    if (packageIds.empty()) {
        return std::vector<EAObject>();
    }

    std::ostringstream ids;
    for (size_t i = 0; i < packageIds.size(); ++i) {
        if (i > 0) {
            ids << ",";
        }
        ids << packageIds[i];
    }

    sqlite3_stmt* stmt = prepare(
        "SELECT Object_ID,Name,Object_Type,Stereotype,Package_ID,Note,ea_guid,Classifier,Classifier_guid,ParentID "
        "FROM t_object "
        "WHERE Package_ID IN (" + ids.str() + ") AND ("
        "Object_Type IN ('Class','Interface','Enumeration','DataType') "
        "OR (Object_Type = 'Object' AND ParentID <> 0) "
        "OR (Object_Type IN ('Part','Component','Port') AND Stereotype IN "
        "('topic','domain','domainParticipant','publisher','subscriber','dataWriter','dataReader','qosProperty'))"
        ") "
        "ORDER BY Object_ID");
    std::vector<EAObject> objects;
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAObject object;
        object.objectId = sqlite3_column_int(stmt, 0);
        object.name = columnText(stmt, 1);
        object.objectType = columnText(stmt, 2);
        object.stereotype = columnText(stmt, 3);
        object.packageId = sqlite3_column_int(stmt, 4);
        object.note = columnText(stmt, 5);
        object.eaGuid = columnText(stmt, 6);
        object.classifier = sqlite3_column_int(stmt, 7);
        object.classifierGuid = columnText(stmt, 8);
        object.parentId = sqlite3_column_int(stmt, 9);
        objects.push_back(object);
    }
    sqlite3_finalize(stmt);
    return objects;
}

std::vector<EAObject> EAReader::loadDdsTypeObjects() const {
    std::vector<EAObject> objects = loadDdsObjects();
    std::vector<EAObject> types;
    for (size_t i = 0; i < objects.size(); ++i) {
        if (objects[i].objectType == "Class" || objects[i].objectType == "Interface" ||
            objects[i].objectType == "Enumeration" || objects[i].objectType == "DataType") {
            types.push_back(objects[i]);
        }
    }
    return types;
}

std::vector<EAAttribute> EAReader::loadAttributesForObjects(const std::vector<EAObject>& objects) const {
    std::vector<EAAttribute> attributes;
    if (objects.empty()) {
        return attributes;
    }

    std::ostringstream ids;
    for (size_t i = 0; i < objects.size(); ++i) {
        if (i > 0) {
            ids << ",";
        }
        ids << objects[i].objectId;
    }

    sqlite3_stmt* stmt = prepare(
        "SELECT ID,Object_ID,Name,Type,Stereotype,LowerBound,UpperBound,\"Default\",Classifier,Notes,Pos,ea_guid "
        "FROM t_attribute WHERE Object_ID IN (" + ids.str() + ") ORDER BY Object_ID,Pos");

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAAttribute attribute;
        attribute.id = sqlite3_column_int(stmt, 0);
        attribute.objectId = sqlite3_column_int(stmt, 1);
        attribute.name = columnText(stmt, 2);
        attribute.type = columnText(stmt, 3);
        attribute.stereotype = columnText(stmt, 4);
        attribute.lowerBound = columnText(stmt, 5);
        attribute.upperBound = columnText(stmt, 6);
        attribute.defaultValue = columnText(stmt, 7);
        attribute.classifier = sqlite3_column_int(stmt, 8);
        attribute.notes = columnText(stmt, 9);
        attribute.pos = sqlite3_column_int(stmt, 10);
        attribute.eaGuid = columnText(stmt, 11);
        attributes.push_back(attribute);
    }
    sqlite3_finalize(stmt);
    return attributes;
}

std::vector<EAObjectProperty> EAReader::loadObjectProperties(const std::vector<EAObject>& objects) const {
    std::vector<EAObjectProperty> properties;
    if (objects.empty()) {
        return properties;
    }
    std::ostringstream ids;
    for (size_t i = 0; i < objects.size(); ++i) {
        if (i > 0) ids << ",";
        ids << objects[i].objectId;
    }
    sqlite3_stmt* stmt = prepare("SELECT Object_ID,Property,Value FROM t_objectproperties WHERE Object_ID IN (" + ids.str() + ")");
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAObjectProperty property;
        property.objectId = sqlite3_column_int(stmt, 0);
        property.property = columnText(stmt, 1);
        property.value = columnText(stmt, 2);
        properties.push_back(property);
    }
    sqlite3_finalize(stmt);
    return properties;
}

std::vector<EAAttributeTag> EAReader::loadAttributeTags(const std::vector<EAAttribute>& attributes) const {
    std::vector<EAAttributeTag> tags;
    if (attributes.empty()) {
        return tags;
    }
    std::ostringstream ids;
    for (size_t i = 0; i < attributes.size(); ++i) {
        if (i > 0) ids << ",";
        ids << attributes[i].id;
    }
    sqlite3_stmt* stmt = prepare("SELECT ElementID,Property,VALUE FROM t_attributetag WHERE ElementID IN (" + ids.str() + ")");
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAAttributeTag tag;
        tag.attributeId = sqlite3_column_int(stmt, 0);
        tag.property = columnText(stmt, 1);
        tag.value = columnText(stmt, 2);
        tags.push_back(tag);
    }
    sqlite3_finalize(stmt);
    return tags;
}

std::vector<EAConnector> EAReader::loadConnectors(const std::vector<EAObject>& objects) const {
    std::vector<EAConnector> connectors;
    if (objects.empty()) {
        return connectors;
    }
    std::ostringstream ids;
    for (size_t i = 0; i < objects.size(); ++i) {
        if (i > 0) ids << ",";
        ids << objects[i].objectId;
    }
    const std::string idList = ids.str();
    sqlite3_stmt* stmt = prepare(
        "SELECT Connector_ID,Start_Object_ID,End_Object_ID,Connector_Type,SubType,Stereotype "
        "FROM t_connector WHERE Start_Object_ID IN (" + idList + ") OR End_Object_ID IN (" + idList + ")");
    while (sqlite3_step(stmt) == SQLITE_ROW) {
        EAConnector connector;
        connector.connectorId = sqlite3_column_int(stmt, 0);
        connector.startObjectId = sqlite3_column_int(stmt, 1);
        connector.endObjectId = sqlite3_column_int(stmt, 2);
        connector.connectorType = columnText(stmt, 3);
        connector.subtype = columnText(stmt, 4);
        connector.stereotype = columnText(stmt, 5);
        connectors.push_back(connector);
    }
    sqlite3_finalize(stmt);
    return connectors;
}

} // namespace ea
} // namespace dds
