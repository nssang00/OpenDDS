#pragma once

#include "ea/EAModels.h"

#include <map>
#include <string>
#include <vector>

struct sqlite3;
struct sqlite3_stmt;

namespace dds {
namespace ea {

class EAReader {
public:
    explicit EAReader(const std::string& qeaPath);
    ~EAReader();

    std::vector<EAPackage> loadPackages() const;
    std::vector<EAObject> loadDdsObjects(const std::string& rootPackageName = std::string()) const;
    std::vector<EAObject> loadDdsTypeObjects() const;
    std::vector<EAAttribute> loadAttributesForObjects(const std::vector<EAObject>& objects) const;
    std::vector<EAObjectProperty> loadObjectProperties(const std::vector<EAObject>& objects) const;
    std::vector<EAAttributeTag> loadAttributeTags(const std::vector<EAAttribute>& attributes) const;
    std::vector<EAConnector> loadConnectors(const std::vector<EAObject>& objects) const;

private:
    sqlite3* db_;

    sqlite3_stmt* prepare(const std::string& sql) const;
    static std::string columnText(sqlite3_stmt* stmt, int index);
    std::vector<int> targetPackageIds(const std::string& rootPackageName) const;
};

} // namespace ea
} // namespace dds
