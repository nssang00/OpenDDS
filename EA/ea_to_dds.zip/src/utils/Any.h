#pragma once

#include <map>
#include <stdexcept>
#include <string>
#include <vector>

namespace dds {

class Any;

typedef std::map<std::string, Any> VariantDict;
typedef std::vector<Any> VariantList;

class Any {
public:
    enum Type {
        Null,
        Bool,
        Int,
        String,
        Dict,
        List
    };

    Any() : type_(Null), boolValue_(false), intValue_(0), dictValue_(nullptr), listValue_(nullptr) {}
    Any(bool value) : type_(Bool), boolValue_(value), intValue_(0), dictValue_(nullptr), listValue_(nullptr) {}
    Any(int value) : type_(Int), boolValue_(false), intValue_(value), dictValue_(nullptr), listValue_(nullptr) {}
    Any(const char* value) : type_(String), boolValue_(false), intValue_(0), stringValue_(value == nullptr ? "" : value), dictValue_(nullptr), listValue_(nullptr) {}
    Any(const std::string& value) : type_(String), boolValue_(false), intValue_(0), stringValue_(value), dictValue_(nullptr), listValue_(nullptr) {}
    Any(const VariantDict& value) : type_(Dict), boolValue_(false), intValue_(0), dictValue_(new VariantDict(value)), listValue_(nullptr) {}
    Any(const VariantList& value) : type_(List), boolValue_(false), intValue_(0), dictValue_(nullptr), listValue_(new VariantList(value)) {}

    Any(const Any& other) : type_(Null), boolValue_(false), intValue_(0), dictValue_(nullptr), listValue_(nullptr) {
        copyFrom(other);
    }

    Any& operator=(const Any& other) {
        if (this != &other) {
            clear();
            copyFrom(other);
        }
        return *this;
    }

    ~Any() {
        clear();
    }

    Type type() const { return type_; }
    bool isNull() const { return type_ == Null; }

    bool asBool() const {
        require(Bool);
        return boolValue_;
    }

    int asInt() const {
        require(Int);
        return intValue_;
    }

    const std::string& asString() const {
        require(String);
        return stringValue_;
    }

    const VariantDict& asDict() const {
        require(Dict);
        return *dictValue_;
    }

    const VariantList& asList() const {
        require(List);
        return *listValue_;
    }

private:
    Type type_;
    bool boolValue_;
    int intValue_;
    std::string stringValue_;
    VariantDict* dictValue_;
    VariantList* listValue_;

    void clear() {
        delete dictValue_;
        delete listValue_;
        dictValue_ = nullptr;
        listValue_ = nullptr;
        stringValue_.clear();
        type_ = Null;
        boolValue_ = false;
        intValue_ = 0;
    }

    void copyFrom(const Any& other) {
        type_ = other.type_;
        boolValue_ = other.boolValue_;
        intValue_ = other.intValue_;
        stringValue_ = other.stringValue_;
        if (other.dictValue_ != nullptr) {
            dictValue_ = new VariantDict(*other.dictValue_);
        }
        if (other.listValue_ != nullptr) {
            listValue_ = new VariantList(*other.listValue_);
        }
    }

    void require(Type expected) const {
        if (type_ != expected) {
            throw std::runtime_error("Any type mismatch");
        }
    }
};

template <typename T>
T AnyCast(const Any& value);

template <>
inline bool AnyCast<bool>(const Any& value) {
    return value.asBool();
}

template <>
inline int AnyCast<int>(const Any& value) {
    return value.asInt();
}

template <>
inline std::string AnyCast<std::string>(const Any& value) {
    return value.asString();
}

template <>
inline VariantDict AnyCast<VariantDict>(const Any& value) {
    return value.asDict();
}

template <>
inline VariantList AnyCast<VariantList>(const Any& value) {
    return value.asList();
}

} // namespace dds
