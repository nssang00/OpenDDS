#pragma once

#include <string>

namespace qea
{

class TaggedValue
{
public:
    TaggedValue();
    TaggedValue(const std::string& name, const std::string& value);

    const std::string& getName() const;
    const std::string& getValue() const;

    void setName(const std::string& name);
    void setValue(const std::string& value);

private:
    std::string m_name;
    std::string m_value;
};

}
