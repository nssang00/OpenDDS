#pragma once

#include <string>
#include <vector>
#include "qea/TaggedValue.hpp"
#include "qea/Stereotype.hpp"

namespace qea
{

class Element;

class Connector
{
public:
    Connector();

    long getId() const;
    const std::string& getGuid() const;
    const std::string& getType() const;
    const std::string& getName() const;
    const std::string& getNotes() const;

    long getClientId() const;
    long getSupplierId() const;

    Element* getClient() const;
    Element* getSupplier() const;

    const std::vector<Stereotype>& getStereotypes() const;
    const std::vector<TaggedValue>& getTaggedValues() const;

    bool hasStereotype(const std::string& name) const;
    bool isAssociation() const;
    bool isAggregation() const;
    bool isComposition() const;
    bool isGeneralization() const;
    bool isDependency() const;

    void setId(long value);
    void setGuid(const std::string& value);
    void setType(const std::string& value);
    void setName(const std::string& value);
    void setNotes(const std::string& value);
    void setClientId(long value);
    void setSupplierId(long value);
    void setClient(Element* value);
    void setSupplier(Element* value);
    void addStereotype(const Stereotype& value);
    void addTaggedValue(const TaggedValue& value);

private:
    long m_id;
    std::string m_guid;
    std::string m_type;
    std::string m_name;
    std::string m_notes;
    long m_clientId;
    long m_supplierId;
    Element* m_client;
    Element* m_supplier;
    std::vector<Stereotype> m_stereotypes;
    std::vector<TaggedValue> m_taggedValues;
};

}
