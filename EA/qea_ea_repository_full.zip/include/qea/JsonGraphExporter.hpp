#pragma once

#include <string>
#include "qea/Repository.hpp"

namespace qea
{

class JsonGraphExporter
{
public:
    JsonGraphExporter();
    std::string exportGraph(const Repository& repository) const;

private:
    std::string escape(const std::string& value) const;
};

}
