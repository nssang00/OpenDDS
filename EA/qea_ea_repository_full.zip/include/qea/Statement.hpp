#pragma once

#include <string>
#include <sqlite3.h>

namespace qea
{

class Statement
{
public:
    Statement(sqlite3* db, const std::string& sql);
    ~Statement();

    Statement(Statement&& other);
    Statement& operator=(Statement&& other);

    bool isValid() const;
    const std::string& getError() const;

    bool step();

    int getInt(int column) const;
    long getLong(int column) const;
    std::string getText(int column) const;

    Statement& bindInt(int index, int value);
    Statement& bindLong(int index, long value);
    Statement& bindText(int index, const std::string& value);

private:
    Statement(const Statement&);
    Statement& operator=(const Statement&);

private:
    sqlite3_stmt* m_stmt;
    std::string m_error;
};

}
