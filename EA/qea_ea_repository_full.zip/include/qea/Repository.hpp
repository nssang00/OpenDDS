#pragma once

#include <map>
#include <memory>
#include <string>
#include <vector>
#include "qea/Package.hpp"
#include "qea/Element.hpp"
#include "qea/Attribute.hpp"
#include "qea/Connector.hpp"
#include "qea/Diagram.hpp"

namespace qea
{

class Repository
{
public:
    Repository();
    ~Repository();

    bool load(const std::string& qeaFile);
    void clear();

    const std::vector<Package*>& getModels() const;
    const std::vector<std::shared_ptr<Package> >& getAllPackages() const;
    const std::vector<std::shared_ptr<Element> >& getAllElements() const;
    const std::vector<std::shared_ptr<Connector> >& getAllConnectors() const;
    const std::vector<std::shared_ptr<Diagram> >& getAllDiagrams() const;

    Package* getPackageById(long id) const;
    Element* getElementById(long id) const;
    Element* getElementByGuid(const std::string& guid) const;
    Attribute* getAttributeById(long id) const;
    Attribute* getAttributeByGuid(const std::string& guid) const;
    Connector* getConnectorById(long id) const;
    Connector* getConnectorByGuid(const std::string& guid) const;
    Diagram* getDiagramById(long id) const;

    Element* findElement(const std::string& name) const;
    std::vector<Element*> findElementsByStereotype(const std::string& stereotype) const;

    Package* createPackage();
    Element* createElement();
    Attribute* createAttribute();
    Connector* createConnector();
    Diagram* createDiagram();

    void registerPackage(Package* value);
    void registerElement(Element* value);
    void registerAttribute(Attribute* value);
    void registerConnector(Connector* value);
    void registerDiagram(Diagram* value);

    bool buildReferences();

private:
    std::vector<std::shared_ptr<Package> > m_packages;
    std::vector<std::shared_ptr<Element> > m_elements;
    std::vector<std::shared_ptr<Attribute> > m_attributes;
    std::vector<std::shared_ptr<Connector> > m_connectors;
    std::vector<std::shared_ptr<Diagram> > m_diagrams;

    std::vector<Package*> m_models;

    std::map<long, Package*> m_packageById;
    std::map<long, Element*> m_elementById;
    std::map<std::string, Element*> m_elementByGuid;
    std::map<long, Attribute*> m_attributeById;
    std::map<std::string, Attribute*> m_attributeByGuid;
    std::map<long, Connector*> m_connectorById;
    std::map<std::string, Connector*> m_connectorByGuid;
    std::map<long, Diagram*> m_diagramById;
};

}
