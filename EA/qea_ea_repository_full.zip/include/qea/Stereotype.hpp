#pragma once

#include <string>

namespace qea
{

class Stereotype
{
public:
    Stereotype();
    explicit Stereotype(const std::string& name);

    const std::string& getName() const;
    void setName(const std::string& name);

private:
    std::string m_name;
};

}
