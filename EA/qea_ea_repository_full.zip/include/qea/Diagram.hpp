#pragma once

#include <string>
#include <vector>

namespace qea
{

class Package;
class Element;

class Diagram
{
public:
    Diagram();

    long getId() const;
    long getPackageId() const;
    const std::string& getGuid() const;
    const std::string& getName() const;
    const std::string& getType() const;

    Package* getPackage() const;
    const std::vector<Element*>& getElements() const;

    void setId(long value);
    void setPackageId(long value);
    void setGuid(const std::string& value);
    void setName(const std::string& value);
    void setType(const std::string& value);
    void setPackage(Package* value);
    void addElement(Element* value);

private:
    long m_id;
    long m_packageId;
    std::string m_guid;
    std::string m_name;
    std::string m_type;
    Package* m_package;
    std::vector<Element*> m_elements;
};

}
