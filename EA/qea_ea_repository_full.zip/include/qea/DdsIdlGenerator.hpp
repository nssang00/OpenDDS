#pragma once

#include <sstream>
#include <string>
#include "qea/Repository.hpp"

namespace qea
{

class DdsIdlGenerator
{
public:
    DdsIdlGenerator();

    std::string generate(const Repository& repository) const;

private:
    void generatePackage(std::ostringstream& out, const Package* package, int indent) const;
    void generateElement(std::ostringstream& out, const Element* element, int indent) const;
    std::string mapType(const std::string& eaType) const;
    std::string indentation(int indent) const;
};

}
