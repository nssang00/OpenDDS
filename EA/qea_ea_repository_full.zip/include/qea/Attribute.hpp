#pragma once

#include <string>
#include <vector>
#include "qea/TaggedValue.hpp"
#include "qea/Stereotype.hpp"

namespace qea
{

class Element;

class Attribute
{
public:
    Attribute();

    long getId() const;
    long getOwnerId() const;
    const std::string& getGuid() const;
    const std::string& getName() const;
    const std::string& getType() const;
    const std::string& getDefaultValue() const;
    const std::string& getNotes() const;
    int getPosition() const;

    Element* getOwner() const;
    Element* getReferencedElement() const;

    const std::vector<Stereotype>& getStereotypes() const;
    const std::vector<TaggedValue>& getTaggedValues() const;

    bool hasStereotype(const std::string& name) const;
    bool hasTaggedValue(const std::string& name) const;
    std::string getTaggedValue(const std::string& name) const;

    bool isKey() const;
    bool isOptional() const;

    void setId(long value);
    void setOwnerId(long value);
    void setGuid(const std::string& value);
    void setName(const std::string& value);
    void setType(const std::string& value);
    void setDefaultValue(const std::string& value);
    void setNotes(const std::string& value);
    void setPosition(int value);
    void setOwner(Element* value);
    void setReferencedElement(Element* value);
    void addStereotype(const Stereotype& value);
    void addTaggedValue(const TaggedValue& value);

private:
    long m_id;
    long m_ownerId;
    std::string m_guid;
    std::string m_name;
    std::string m_type;
    std::string m_defaultValue;
    std::string m_notes;
    int m_position;
    Element* m_owner;
    Element* m_referencedElement;
    std::vector<Stereotype> m_stereotypes;
    std::vector<TaggedValue> m_taggedValues;
};

}
