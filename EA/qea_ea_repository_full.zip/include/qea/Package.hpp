#pragma once

#include <string>
#include <vector>

namespace qea
{

class Element;
class Diagram;

class Package
{
public:
    Package();

    long getId() const;
    long getParentId() const;
    const std::string& getGuid() const;
    const std::string& getName() const;
    const std::string& getNotes() const;

    Package* getParent() const;
    const std::vector<Package*>& getPackages() const;
    const std::vector<Element*>& getElements() const;
    const std::vector<Diagram*>& getDiagrams() const;

    void setId(long value);
    void setParentId(long value);
    void setGuid(const std::string& value);
    void setName(const std::string& value);
    void setNotes(const std::string& value);
    void setParent(Package* value);
    void addPackage(Package* value);
    void addElement(Element* value);
    void addDiagram(Diagram* value);

private:
    long m_id;
    long m_parentId;
    std::string m_guid;
    std::string m_name;
    std::string m_notes;
    Package* m_parent;
    std::vector<Package*> m_packages;
    std::vector<Element*> m_elements;
    std::vector<Diagram*> m_diagrams;
};

}
