#pragma once

#include <string>
#include <sqlite3.h>

namespace qea
{

class Statement;

class Database
{
public:
    explicit Database(const std::string& filePath);
    ~Database();

    bool isOpen() const;
    const std::string& getLastError() const;

    Statement prepare(const std::string& sql) const;

private:
    Database(const Database&);
    Database& operator=(const Database&);

private:
    sqlite3* m_db;
    std::string m_lastError;
};

}
