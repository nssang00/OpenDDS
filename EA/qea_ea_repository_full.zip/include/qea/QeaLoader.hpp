#pragma once

#include <string>

namespace qea
{

class Database;
class Repository;

class QeaLoader
{
public:
    QeaLoader();
    bool load(const std::string& filePath, Repository& repository);

private:
    bool loadPackages(Database& db, Repository& repository);
    bool loadElements(Database& db, Repository& repository);
    bool loadAttributes(Database& db, Repository& repository);
    bool loadConnectors(Database& db, Repository& repository);
    bool loadObjectTaggedValues(Database& db, Repository& repository);
    bool loadAttributeTaggedValues(Database& db, Repository& repository);
    bool loadXrefs(Database& db, Repository& repository);
    bool loadDiagrams(Database& db, Repository& repository);
    bool loadDiagramObjects(Database& db, Repository& repository);

    void addStereotypesFromStringToElement(Repository& repository, long elementId, const std::string& values);
    void addStereotypesFromStringToAttribute(Repository& repository, long attributeId, const std::string& values);
    void addStereotypesFromStringToConnector(Repository& repository, long connectorId, const std::string& values);
};

}
