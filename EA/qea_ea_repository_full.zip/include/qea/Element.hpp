#pragma once

#include <string>
#include <vector>
#include "qea/TaggedValue.hpp"
#include "qea/Stereotype.hpp"

namespace qea
{

class Package;
class Attribute;
class Connector;

class Element
{
public:
    Element();

    long getId() const;
    const std::string& getGuid() const;
    const std::string& getName() const;
    const std::string& getAlias() const;
    const std::string& getType() const;
    const std::string& getNotes() const;
    long getPackageId() const;

    Package* getPackage() const;

    const std::vector<Attribute*>& getAttributes() const;
    const std::vector<Connector*>& getConnectors() const;
    const std::vector<Connector*>& getOutgoingConnectors() const;
    const std::vector<Connector*>& getIncomingConnectors() const;

    const std::vector<Stereotype>& getStereotypes() const;
    const std::vector<TaggedValue>& getTaggedValues() const;

    bool hasStereotype(const std::string& name) const;
    bool hasTaggedValue(const std::string& name) const;
    std::string getTaggedValue(const std::string& name) const;

    bool isClass() const;
    bool isInterface() const;
    bool isEnum() const;
    bool isStruct() const;
    bool isTopic() const;
    bool isUnion() const;

    void setId(long value);
    void setGuid(const std::string& value);
    void setName(const std::string& value);
    void setAlias(const std::string& value);
    void setType(const std::string& value);
    void setNotes(const std::string& value);
    void setPackageId(long value);
    void setPackage(Package* value);
    void addAttribute(Attribute* value);
    void addConnector(Connector* value);
    void addOutgoingConnector(Connector* value);
    void addIncomingConnector(Connector* value);
    void addStereotype(const Stereotype& value);
    void addTaggedValue(const TaggedValue& value);

private:
    long m_id;
    std::string m_guid;
    std::string m_name;
    std::string m_alias;
    std::string m_type;
    std::string m_notes;
    long m_packageId;
    Package* m_package;
    std::vector<Attribute*> m_attributes;
    std::vector<Connector*> m_connectors;
    std::vector<Connector*> m_outgoingConnectors;
    std::vector<Connector*> m_incomingConnectors;
    std::vector<Stereotype> m_stereotypes;
    std::vector<TaggedValue> m_taggedValues;
};

}
