#include <iostream>
#include "qea/Repository.hpp"
#include "qea/DdsIdlGenerator.hpp"
#include "qea/JsonGraphExporter.hpp"

int main(int argc, char** argv)
{
    if(argc < 2)
    {
        std::cerr << "usage: qea_dump <model.qea>" << std::endl;
        return 1;
    }

    qea::Repository repository;
    if(!repository.load(argv[1]))
    {
        std::cerr << "failed to load qea file" << std::endl;
        return 1;
    }

    std::cout << "packages: " << repository.getAllPackages().size() << std::endl;
    std::cout << "elements: " << repository.getAllElements().size() << std::endl;
    std::cout << "connectors: " << repository.getAllConnectors().size() << std::endl;
    std::cout << "diagrams: " << repository.getAllDiagrams().size() << std::endl;

    qea::DdsIdlGenerator idlGenerator;
    std::cout << "\n// ---- IDL preview ----\n";
    std::cout << idlGenerator.generate(repository) << std::endl;

    qea::JsonGraphExporter graphExporter;
    std::cout << "\n// ---- JSON graph preview ----\n";
    std::cout << graphExporter.exportGraph(repository) << std::endl;

    return 0;
}
