#include "qea/Database.hpp"
#include "qea/Statement.hpp"

namespace qea
{

Database::Database(const std::string& filePath)
    : m_db(NULL)
{
    int rc = sqlite3_open(filePath.c_str(), &m_db);
    if(rc != SQLITE_OK)
    {
        if(m_db != NULL)
        {
            m_lastError = sqlite3_errmsg(m_db);
        }
        else
        {
            m_lastError = "sqlite3_open failed";
        }
    }
}

Database::~Database()
{
    if(m_db != NULL)
    {
        sqlite3_close(m_db);
        m_db = NULL;
    }
}

bool Database::isOpen() const
{
    return m_db != NULL && m_lastError.empty();
}

const std::string& Database::getLastError() const
{
    return m_lastError;
}

Statement Database::prepare(const std::string& sql) const
{
    return Statement(m_db, sql);
}

}
