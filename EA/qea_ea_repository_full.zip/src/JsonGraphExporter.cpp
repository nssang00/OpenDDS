#include "qea/JsonGraphExporter.hpp"
#include <sstream>

namespace qea
{

JsonGraphExporter::JsonGraphExporter() {}

std::string JsonGraphExporter::exportGraph(const Repository& repository) const
{
    std::ostringstream out;
    out << "{\n";
    out << "  \"nodes\": [\n";

    const std::vector<std::shared_ptr<Element> >& elements = repository.getAllElements();
    for(size_t i = 0; i < elements.size(); ++i)
    {
        Element* elem = elements[i].get();
        out << "    {\"id\": \"" << elem->getId() << "\", ";
        out << "\"label\": \"" << escape(elem->getName()) << "\", ";
        out << "\"type\": \"" << escape(elem->getType()) << "\"}";
        if(i + 1 < elements.size()) out << ",";
        out << "\n";
    }

    out << "  ],\n";
    out << "  \"edges\": [\n";

    const std::vector<std::shared_ptr<Connector> >& connectors = repository.getAllConnectors();
    size_t written = 0;
    for(size_t i = 0; i < connectors.size(); ++i)
    {
        Connector* conn = connectors[i].get();
        if(conn->getClient() == NULL || conn->getSupplier() == NULL) continue;
        if(written > 0) out << ",\n";
        out << "    {\"id\": \"" << conn->getId() << "\", ";
        out << "\"source\": \"" << conn->getClient()->getId() << "\", ";
        out << "\"target\": \"" << conn->getSupplier()->getId() << "\", ";
        out << "\"type\": \"" << escape(conn->getType()) << "\"}";
        ++written;
    }
    out << "\n  ]\n";
    out << "}\n";
    return out.str();
}

std::string JsonGraphExporter::escape(const std::string& value) const
{
    std::string result;
    for(size_t i = 0; i < value.size(); ++i)
    {
        char ch = value[i];
        if(ch == '"') result += "\\\"";
        else if(ch == '\\') result += "\\\\";
        else if(ch == '\n') result += "\\n";
        else if(ch == '\r') result += "\\r";
        else result.push_back(ch);
    }
    return result;
}

}
