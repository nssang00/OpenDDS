#include "qea/QeaLoader.hpp"
#include "qea/Database.hpp"
#include "qea/Statement.hpp"
#include "qea/Repository.hpp"

#include <sstream>
#include <vector>

namespace qea
{

static std::vector<std::string> splitNames(const std::string& text)
{
    std::vector<std::string> result;
    std::string token;
    for(size_t i = 0; i < text.size(); ++i)
    {
        char ch = text[i];
        if(ch == ',' || ch == ';' || ch == '\n' || ch == '\r')
        {
            if(!token.empty())
            {
                result.push_back(token);
                token.clear();
            }
        }
        else if(ch != ' ' && ch != '\t')
        {
            token.push_back(ch);
        }
    }
    if(!token.empty()) result.push_back(token);
    return result;
}

static std::vector<std::string> parseStereotypesFromXrefDescription(const std::string& description)
{
    std::vector<std::string> result;
    size_t pos = 0;
    while(true)
    {
        size_t namePos = description.find("Name=", pos);
        if(namePos == std::string::npos) break;
        namePos += 5;
        size_t endPos = description.find(';', namePos);
        if(endPos == std::string::npos) endPos = description.size();
        std::string name = description.substr(namePos, endPos - namePos);
        if(!name.empty()) result.push_back(name);
        pos = endPos;
    }
    return result;
}

QeaLoader::QeaLoader() {}

bool QeaLoader::load(const std::string& filePath, Repository& repository)
{
    Database db(filePath);
    if(!db.isOpen()) return false;

    if(!loadPackages(db, repository)) return false;
    if(!loadElements(db, repository)) return false;
    if(!loadAttributes(db, repository)) return false;
    if(!loadConnectors(db, repository)) return false;
    loadObjectTaggedValues(db, repository);
    loadAttributeTaggedValues(db, repository);
    loadXrefs(db, repository);
    loadDiagrams(db, repository);
    loadDiagramObjects(db, repository);

    return repository.buildReferences();
}

bool QeaLoader::loadPackages(Database& db, Repository& repository)
{
    Statement stmt = db.prepare("SELECT Package_ID, ea_guid, Name, Parent_ID, Notes FROM t_package");
    if(!stmt.isValid()) return false;
    while(stmt.step())
    {
        Package* pkg = repository.createPackage();
        pkg->setId(stmt.getLong(0));
        pkg->setGuid(stmt.getText(1));
        pkg->setName(stmt.getText(2));
        pkg->setParentId(stmt.getLong(3));
        pkg->setNotes(stmt.getText(4));
        repository.registerPackage(pkg);
    }
    return true;
}

bool QeaLoader::loadElements(Database& db, Repository& repository)
{
    Statement stmt = db.prepare(
        "SELECT Object_ID, ea_guid, Name, Alias, Object_Type, Stereotype, Package_ID, Note "
        "FROM t_object "
        "WHERE Object_Type IN ('Class','Interface','Enumeration','Component','DataType')");
    if(!stmt.isValid()) return false;
    while(stmt.step())
    {
        Element* elem = repository.createElement();
        elem->setId(stmt.getLong(0));
        elem->setGuid(stmt.getText(1));
        elem->setName(stmt.getText(2));
        elem->setAlias(stmt.getText(3));
        elem->setType(stmt.getText(4));
        elem->setPackageId(stmt.getLong(6));
        elem->setNotes(stmt.getText(7));

        std::vector<std::string> stereotypes = splitNames(stmt.getText(5));
        for(size_t i = 0; i < stereotypes.size(); ++i)
        {
            elem->addStereotype(Stereotype(stereotypes[i]));
        }
        repository.registerElement(elem);
    }
    return true;
}

bool QeaLoader::loadAttributes(Database& db, Repository& repository)
{
    Statement stmt = db.prepare(
        "SELECT ID, ea_guid, Object_ID, Name, Type, Stereotype, Default, Notes, Pos "
        "FROM t_attribute ORDER BY Object_ID, Pos");
    if(!stmt.isValid()) return false;
    while(stmt.step())
    {
        Attribute* attr = repository.createAttribute();
        attr->setId(stmt.getLong(0));
        attr->setGuid(stmt.getText(1));
        attr->setOwnerId(stmt.getLong(2));
        attr->setName(stmt.getText(3));
        attr->setType(stmt.getText(4));
        attr->setDefaultValue(stmt.getText(6));
        attr->setNotes(stmt.getText(7));
        attr->setPosition(stmt.getInt(8));

        std::vector<std::string> stereotypes = splitNames(stmt.getText(5));
        for(size_t i = 0; i < stereotypes.size(); ++i)
        {
            attr->addStereotype(Stereotype(stereotypes[i]));
        }
        repository.registerAttribute(attr);
    }
    return true;
}

bool QeaLoader::loadConnectors(Database& db, Repository& repository)
{
    Statement stmt = db.prepare(
        "SELECT Connector_ID, ea_guid, Connector_Type, Name, Notes, "
        "Start_Object_ID, End_Object_ID, Stereotype FROM t_connector");
    if(!stmt.isValid()) return false;
    while(stmt.step())
    {
        Connector* conn = repository.createConnector();
        conn->setId(stmt.getLong(0));
        conn->setGuid(stmt.getText(1));
        conn->setType(stmt.getText(2));
        conn->setName(stmt.getText(3));
        conn->setNotes(stmt.getText(4));
        conn->setClientId(stmt.getLong(5));
        conn->setSupplierId(stmt.getLong(6));

        std::vector<std::string> stereotypes = splitNames(stmt.getText(7));
        for(size_t i = 0; i < stereotypes.size(); ++i)
        {
            conn->addStereotype(Stereotype(stereotypes[i]));
        }
        repository.registerConnector(conn);
    }
    return true;
}

bool QeaLoader::loadObjectTaggedValues(Database& db, Repository& repository)
{
    Statement stmt = db.prepare("SELECT Object_ID, Property, Value FROM t_objectproperties");
    if(!stmt.isValid()) return false;
    while(stmt.step())
    {
        Element* elem = repository.getElementById(stmt.getLong(0));
        if(elem != NULL)
        {
            elem->addTaggedValue(TaggedValue(stmt.getText(1), stmt.getText(2)));
        }
    }
    return true;
}

bool QeaLoader::loadAttributeTaggedValues(Database& db, Repository& repository)
{
    Statement stmt = db.prepare("SELECT ElementID, Property, VALUE FROM t_attributetag");
    if(!stmt.isValid()) return false;
    while(stmt.step())
    {
        Attribute* attr = repository.getAttributeById(stmt.getLong(0));
        if(attr != NULL)
        {
            attr->addTaggedValue(TaggedValue(stmt.getText(1), stmt.getText(2)));
        }
    }
    return true;
}

bool QeaLoader::loadXrefs(Database& db, Repository& repository)
{
    Statement stmt = db.prepare("SELECT Client, Name, Type, Description FROM t_xref");
    if(!stmt.isValid()) return false;
    while(stmt.step())
    {
        std::string client = stmt.getText(0);
        std::string name = stmt.getText(1);
        std::string type = stmt.getText(2);
        std::string description = stmt.getText(3);
        if(type != "element property" && name != "Stereotypes")
        {
            continue;
        }

        std::vector<std::string> stereotypes = parseStereotypesFromXrefDescription(description);
        Element* elem = repository.getElementByGuid(client);
        Attribute* attr = repository.getAttributeByGuid(client);
        Connector* conn = repository.getConnectorByGuid(client);

        for(size_t i = 0; i < stereotypes.size(); ++i)
        {
            Stereotype stereo(stereotypes[i]);
            if(elem != NULL) elem->addStereotype(stereo);
            if(attr != NULL) attr->addStereotype(stereo);
            if(conn != NULL) conn->addStereotype(stereo);
        }
    }
    return true;
}

bool QeaLoader::loadDiagrams(Database& db, Repository& repository)
{
    Statement stmt = db.prepare("SELECT Diagram_ID, ea_guid, Name, Diagram_Type, Package_ID FROM t_diagram");
    if(!stmt.isValid()) return false;
    while(stmt.step())
    {
        Diagram* diagram = repository.createDiagram();
        diagram->setId(stmt.getLong(0));
        diagram->setGuid(stmt.getText(1));
        diagram->setName(stmt.getText(2));
        diagram->setType(stmt.getText(3));
        diagram->setPackageId(stmt.getLong(4));
        repository.registerDiagram(diagram);
    }
    return true;
}

bool QeaLoader::loadDiagramObjects(Database& db, Repository& repository)
{
    Statement stmt = db.prepare("SELECT Diagram_ID, Object_ID FROM t_diagramobjects");
    if(!stmt.isValid()) return false;
    while(stmt.step())
    {
        Diagram* diagram = repository.getDiagramById(stmt.getLong(0));
        Element* elem = repository.getElementById(stmt.getLong(1));
        if(diagram != NULL && elem != NULL)
        {
            diagram->addElement(elem);
        }
    }
    return true;
}

void QeaLoader::addStereotypesFromStringToElement(Repository& repository, long elementId, const std::string& values)
{
    Element* elem = repository.getElementById(elementId);
    if(elem == NULL) return;
    std::vector<std::string> stereotypes = splitNames(values);
    for(size_t i = 0; i < stereotypes.size(); ++i) elem->addStereotype(Stereotype(stereotypes[i]));
}

void QeaLoader::addStereotypesFromStringToAttribute(Repository& repository, long attributeId, const std::string& values)
{
    Attribute* attr = repository.getAttributeById(attributeId);
    if(attr == NULL) return;
    std::vector<std::string> stereotypes = splitNames(values);
    for(size_t i = 0; i < stereotypes.size(); ++i) attr->addStereotype(Stereotype(stereotypes[i]));
}

void QeaLoader::addStereotypesFromStringToConnector(Repository& repository, long connectorId, const std::string& values)
{
    Connector* conn = repository.getConnectorById(connectorId);
    if(conn == NULL) return;
    std::vector<std::string> stereotypes = splitNames(values);
    for(size_t i = 0; i < stereotypes.size(); ++i) conn->addStereotype(Stereotype(stereotypes[i]));
}

}
