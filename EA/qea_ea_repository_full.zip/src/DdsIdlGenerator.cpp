#include "qea/DdsIdlGenerator.hpp"

namespace qea
{

DdsIdlGenerator::DdsIdlGenerator() {}

std::string DdsIdlGenerator::generate(const Repository& repository) const
{
    std::ostringstream out;
    const std::vector<Package*>& models = repository.getModels();
    for(size_t i = 0; i < models.size(); ++i)
    {
        generatePackage(out, models[i], 0);
    }
    return out.str();
}

void DdsIdlGenerator::generatePackage(std::ostringstream& out, const Package* package, int indent) const
{
    if(package == NULL) return;

    out << indentation(indent) << "module " << package->getName() << "\n";
    out << indentation(indent) << "{\n";

    const std::vector<Element*>& elements = package->getElements();
    for(size_t i = 0; i < elements.size(); ++i)
    {
        generateElement(out, elements[i], indent + 1);
    }

    const std::vector<Package*>& packages = package->getPackages();
    for(size_t i = 0; i < packages.size(); ++i)
    {
        generatePackage(out, packages[i], indent + 1);
    }

    out << indentation(indent) << "};\n\n";
}

void DdsIdlGenerator::generateElement(std::ostringstream& out, const Element* element, int indent) const
{
    if(element == NULL) return;

    if(element->isEnum())
    {
        out << indentation(indent) << "enum " << element->getName() << "\n";
        out << indentation(indent) << "{\n";
        const std::vector<Attribute*>& attrs = element->getAttributes();
        for(size_t i = 0; i < attrs.size(); ++i)
        {
            out << indentation(indent + 1) << attrs[i]->getName();
            if(i + 1 < attrs.size()) out << ",";
            out << "\n";
        }
        out << indentation(indent) << "};\n\n";
        return;
    }

    if(element->isClass() || element->isStruct() || element->isTopic() || element->isUnion())
    {
        out << indentation(indent) << "struct " << element->getName() << "\n";
        out << indentation(indent) << "{\n";
        const std::vector<Attribute*>& attrs = element->getAttributes();
        for(size_t i = 0; i < attrs.size(); ++i)
        {
            const Attribute* attr = attrs[i];
            out << indentation(indent + 1);
            if(attr->isKey()) out << "@key ";
            if(attr->isOptional()) out << "@optional ";
            out << mapType(attr->getType()) << " " << attr->getName() << ";\n";
        }
        out << indentation(indent) << "};\n\n";
    }
}

std::string DdsIdlGenerator::mapType(const std::string& eaType) const
{
    if(eaType == "int" || eaType == "integer" || eaType == "Integer") return "long";
    if(eaType == "long") return "long";
    if(eaType == "short") return "short";
    if(eaType == "float") return "float";
    if(eaType == "double") return "double";
    if(eaType == "bool" || eaType == "boolean" || eaType == "Boolean") return "boolean";
    if(eaType == "string" || eaType == "String") return "string";
    return eaType;
}

std::string DdsIdlGenerator::indentation(int indent) const
{
    std::string value;
    for(int i = 0; i < indent; ++i) value += "    ";
    return value;
}

}
