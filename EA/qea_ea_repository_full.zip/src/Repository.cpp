#include "qea/Repository.hpp"
#include "qea/QeaLoader.hpp"

namespace qea
{

TaggedValue::TaggedValue() {}
TaggedValue::TaggedValue(const std::string& name, const std::string& value) : m_name(name), m_value(value) {}
const std::string& TaggedValue::getName() const { return m_name; }
const std::string& TaggedValue::getValue() const { return m_value; }
void TaggedValue::setName(const std::string& name) { m_name = name; }
void TaggedValue::setValue(const std::string& value) { m_value = value; }

Stereotype::Stereotype() {}
Stereotype::Stereotype(const std::string& name) : m_name(name) {}
const std::string& Stereotype::getName() const { return m_name; }
void Stereotype::setName(const std::string& name) { m_name = name; }

Attribute::Attribute() : m_id(0), m_ownerId(0), m_position(0), m_owner(NULL), m_referencedElement(NULL) {}
long Attribute::getId() const { return m_id; }
long Attribute::getOwnerId() const { return m_ownerId; }
const std::string& Attribute::getGuid() const { return m_guid; }
const std::string& Attribute::getName() const { return m_name; }
const std::string& Attribute::getType() const { return m_type; }
const std::string& Attribute::getDefaultValue() const { return m_defaultValue; }
const std::string& Attribute::getNotes() const { return m_notes; }
int Attribute::getPosition() const { return m_position; }
Element* Attribute::getOwner() const { return m_owner; }
Element* Attribute::getReferencedElement() const { return m_referencedElement; }
const std::vector<Stereotype>& Attribute::getStereotypes() const { return m_stereotypes; }
const std::vector<TaggedValue>& Attribute::getTaggedValues() const { return m_taggedValues; }
bool Attribute::hasStereotype(const std::string& name) const { for(size_t i=0;i<m_stereotypes.size();++i){ if(m_stereotypes[i].getName()==name) return true; } return false; }
bool Attribute::hasTaggedValue(const std::string& name) const { for(size_t i=0;i<m_taggedValues.size();++i){ if(m_taggedValues[i].getName()==name) return true; } return false; }
std::string Attribute::getTaggedValue(const std::string& name) const { for(size_t i=0;i<m_taggedValues.size();++i){ if(m_taggedValues[i].getName()==name) return m_taggedValues[i].getValue(); } return std::string(); }
bool Attribute::isKey() const { return hasStereotype("key") || hasStereotype("dds_key") || getTaggedValue("key") == "true" || getTaggedValue("isKey") == "true"; }
bool Attribute::isOptional() const { return hasStereotype("optional") || getTaggedValue("optional") == "true"; }
void Attribute::setId(long value) { m_id=value; }
void Attribute::setOwnerId(long value) { m_ownerId=value; }
void Attribute::setGuid(const std::string& value) { m_guid=value; }
void Attribute::setName(const std::string& value) { m_name=value; }
void Attribute::setType(const std::string& value) { m_type=value; }
void Attribute::setDefaultValue(const std::string& value) { m_defaultValue=value; }
void Attribute::setNotes(const std::string& value) { m_notes=value; }
void Attribute::setPosition(int value) { m_position=value; }
void Attribute::setOwner(Element* value) { m_owner=value; }
void Attribute::setReferencedElement(Element* value) { m_referencedElement=value; }
void Attribute::addStereotype(const Stereotype& value) { if(!hasStereotype(value.getName())) m_stereotypes.push_back(value); }
void Attribute::addTaggedValue(const TaggedValue& value) { m_taggedValues.push_back(value); }

Connector::Connector() : m_id(0), m_clientId(0), m_supplierId(0), m_client(NULL), m_supplier(NULL) {}
long Connector::getId() const { return m_id; }
const std::string& Connector::getGuid() const { return m_guid; }
const std::string& Connector::getType() const { return m_type; }
const std::string& Connector::getName() const { return m_name; }
const std::string& Connector::getNotes() const { return m_notes; }
long Connector::getClientId() const { return m_clientId; }
long Connector::getSupplierId() const { return m_supplierId; }
Element* Connector::getClient() const { return m_client; }
Element* Connector::getSupplier() const { return m_supplier; }
const std::vector<Stereotype>& Connector::getStereotypes() const { return m_stereotypes; }
const std::vector<TaggedValue>& Connector::getTaggedValues() const { return m_taggedValues; }
bool Connector::hasStereotype(const std::string& name) const { for(size_t i=0;i<m_stereotypes.size();++i){ if(m_stereotypes[i].getName()==name) return true; } return false; }
bool Connector::isAssociation() const { return m_type == "Association"; }
bool Connector::isAggregation() const { return m_type == "Aggregation"; }
bool Connector::isComposition() const { return hasStereotype("composite") || m_type == "Composition"; }
bool Connector::isGeneralization() const { return m_type == "Generalization"; }
bool Connector::isDependency() const { return m_type == "Dependency"; }
void Connector::setId(long value) { m_id=value; }
void Connector::setGuid(const std::string& value) { m_guid=value; }
void Connector::setType(const std::string& value) { m_type=value; }
void Connector::setName(const std::string& value) { m_name=value; }
void Connector::setNotes(const std::string& value) { m_notes=value; }
void Connector::setClientId(long value) { m_clientId=value; }
void Connector::setSupplierId(long value) { m_supplierId=value; }
void Connector::setClient(Element* value) { m_client=value; }
void Connector::setSupplier(Element* value) { m_supplier=value; }
void Connector::addStereotype(const Stereotype& value) { if(!hasStereotype(value.getName())) m_stereotypes.push_back(value); }
void Connector::addTaggedValue(const TaggedValue& value) { m_taggedValues.push_back(value); }

Element::Element() : m_id(0), m_packageId(0), m_package(NULL) {}
long Element::getId() const { return m_id; }
const std::string& Element::getGuid() const { return m_guid; }
const std::string& Element::getName() const { return m_name; }
const std::string& Element::getAlias() const { return m_alias; }
const std::string& Element::getType() const { return m_type; }
const std::string& Element::getNotes() const { return m_notes; }
long Element::getPackageId() const { return m_packageId; }
Package* Element::getPackage() const { return m_package; }
const std::vector<Attribute*>& Element::getAttributes() const { return m_attributes; }
const std::vector<Connector*>& Element::getConnectors() const { return m_connectors; }
const std::vector<Connector*>& Element::getOutgoingConnectors() const { return m_outgoingConnectors; }
const std::vector<Connector*>& Element::getIncomingConnectors() const { return m_incomingConnectors; }
const std::vector<Stereotype>& Element::getStereotypes() const { return m_stereotypes; }
const std::vector<TaggedValue>& Element::getTaggedValues() const { return m_taggedValues; }
bool Element::hasStereotype(const std::string& name) const { for(size_t i=0;i<m_stereotypes.size();++i){ if(m_stereotypes[i].getName()==name) return true; } return false; }
bool Element::hasTaggedValue(const std::string& name) const { for(size_t i=0;i<m_taggedValues.size();++i){ if(m_taggedValues[i].getName()==name) return true; } return false; }
std::string Element::getTaggedValue(const std::string& name) const { for(size_t i=0;i<m_taggedValues.size();++i){ if(m_taggedValues[i].getName()==name) return m_taggedValues[i].getValue(); } return std::string(); }
bool Element::isClass() const { return m_type == "Class"; }
bool Element::isInterface() const { return m_type == "Interface"; }
bool Element::isEnum() const { return m_type == "Enumeration" || hasStereotype("enum") || hasStereotype("dds_enum"); }
bool Element::isStruct() const { return hasStereotype("struct") || hasStereotype("dds_struct") || hasStereotype("idl_struct"); }
bool Element::isTopic() const { return hasStereotype("topic") || hasStereotype("dds_topic"); }
bool Element::isUnion() const { return hasStereotype("union") || hasStereotype("dds_union"); }
void Element::setId(long value) { m_id=value; }
void Element::setGuid(const std::string& value) { m_guid=value; }
void Element::setName(const std::string& value) { m_name=value; }
void Element::setAlias(const std::string& value) { m_alias=value; }
void Element::setType(const std::string& value) { m_type=value; }
void Element::setNotes(const std::string& value) { m_notes=value; }
void Element::setPackageId(long value) { m_packageId=value; }
void Element::setPackage(Package* value) { m_package=value; }
void Element::addAttribute(Attribute* value) { m_attributes.push_back(value); }
void Element::addConnector(Connector* value) { m_connectors.push_back(value); }
void Element::addOutgoingConnector(Connector* value) { m_outgoingConnectors.push_back(value); }
void Element::addIncomingConnector(Connector* value) { m_incomingConnectors.push_back(value); }
void Element::addStereotype(const Stereotype& value) { if(!hasStereotype(value.getName())) m_stereotypes.push_back(value); }
void Element::addTaggedValue(const TaggedValue& value) { m_taggedValues.push_back(value); }

Package::Package() : m_id(0), m_parentId(0), m_parent(NULL) {}
long Package::getId() const { return m_id; }
long Package::getParentId() const { return m_parentId; }
const std::string& Package::getGuid() const { return m_guid; }
const std::string& Package::getName() const { return m_name; }
const std::string& Package::getNotes() const { return m_notes; }
Package* Package::getParent() const { return m_parent; }
const std::vector<Package*>& Package::getPackages() const { return m_packages; }
const std::vector<Element*>& Package::getElements() const { return m_elements; }
const std::vector<Diagram*>& Package::getDiagrams() const { return m_diagrams; }
void Package::setId(long value) { m_id=value; }
void Package::setParentId(long value) { m_parentId=value; }
void Package::setGuid(const std::string& value) { m_guid=value; }
void Package::setName(const std::string& value) { m_name=value; }
void Package::setNotes(const std::string& value) { m_notes=value; }
void Package::setParent(Package* value) { m_parent=value; }
void Package::addPackage(Package* value) { m_packages.push_back(value); }
void Package::addElement(Element* value) { m_elements.push_back(value); }
void Package::addDiagram(Diagram* value) { m_diagrams.push_back(value); }

Diagram::Diagram() : m_id(0), m_packageId(0), m_package(NULL) {}
long Diagram::getId() const { return m_id; }
long Diagram::getPackageId() const { return m_packageId; }
const std::string& Diagram::getGuid() const { return m_guid; }
const std::string& Diagram::getName() const { return m_name; }
const std::string& Diagram::getType() const { return m_type; }
Package* Diagram::getPackage() const { return m_package; }
const std::vector<Element*>& Diagram::getElements() const { return m_elements; }
void Diagram::setId(long value) { m_id=value; }
void Diagram::setPackageId(long value) { m_packageId=value; }
void Diagram::setGuid(const std::string& value) { m_guid=value; }
void Diagram::setName(const std::string& value) { m_name=value; }
void Diagram::setType(const std::string& value) { m_type=value; }
void Diagram::setPackage(Package* value) { m_package=value; }
void Diagram::addElement(Element* value) { m_elements.push_back(value); }

Repository::Repository() {}
Repository::~Repository() {}
bool Repository::load(const std::string& qeaFile) { clear(); QeaLoader loader; return loader.load(qeaFile, *this); }
void Repository::clear() { m_packages.clear(); m_elements.clear(); m_attributes.clear(); m_connectors.clear(); m_diagrams.clear(); m_models.clear(); m_packageById.clear(); m_elementById.clear(); m_elementByGuid.clear(); m_attributeById.clear(); m_attributeByGuid.clear(); m_connectorById.clear(); m_connectorByGuid.clear(); m_diagramById.clear(); }
const std::vector<Package*>& Repository::getModels() const { return m_models; }
const std::vector<std::shared_ptr<Package> >& Repository::getAllPackages() const { return m_packages; }
const std::vector<std::shared_ptr<Element> >& Repository::getAllElements() const { return m_elements; }
const std::vector<std::shared_ptr<Connector> >& Repository::getAllConnectors() const { return m_connectors; }
const std::vector<std::shared_ptr<Diagram> >& Repository::getAllDiagrams() const { return m_diagrams; }
Package* Repository::getPackageById(long id) const { std::map<long,Package*>::const_iterator it=m_packageById.find(id); return it==m_packageById.end()?NULL:it->second; }
Element* Repository::getElementById(long id) const { std::map<long,Element*>::const_iterator it=m_elementById.find(id); return it==m_elementById.end()?NULL:it->second; }
Element* Repository::getElementByGuid(const std::string& guid) const { std::map<std::string,Element*>::const_iterator it=m_elementByGuid.find(guid); return it==m_elementByGuid.end()?NULL:it->second; }
Attribute* Repository::getAttributeById(long id) const { std::map<long,Attribute*>::const_iterator it=m_attributeById.find(id); return it==m_attributeById.end()?NULL:it->second; }
Attribute* Repository::getAttributeByGuid(const std::string& guid) const { std::map<std::string,Attribute*>::const_iterator it=m_attributeByGuid.find(guid); return it==m_attributeByGuid.end()?NULL:it->second; }
Connector* Repository::getConnectorById(long id) const { std::map<long,Connector*>::const_iterator it=m_connectorById.find(id); return it==m_connectorById.end()?NULL:it->second; }
Connector* Repository::getConnectorByGuid(const std::string& guid) const { std::map<std::string,Connector*>::const_iterator it=m_connectorByGuid.find(guid); return it==m_connectorByGuid.end()?NULL:it->second; }
Diagram* Repository::getDiagramById(long id) const { std::map<long,Diagram*>::const_iterator it=m_diagramById.find(id); return it==m_diagramById.end()?NULL:it->second; }
Element* Repository::findElement(const std::string& name) const { for(size_t i=0;i<m_elements.size();++i){ if(m_elements[i]->getName()==name) return m_elements[i].get(); } return NULL; }
std::vector<Element*> Repository::findElementsByStereotype(const std::string& stereotype) const { std::vector<Element*> result; for(size_t i=0;i<m_elements.size();++i){ if(m_elements[i]->hasStereotype(stereotype)) result.push_back(m_elements[i].get()); } return result; }
Package* Repository::createPackage() { std::shared_ptr<Package> p(new Package()); m_packages.push_back(p); return p.get(); }
Element* Repository::createElement() { std::shared_ptr<Element> p(new Element()); m_elements.push_back(p); return p.get(); }
Attribute* Repository::createAttribute() { std::shared_ptr<Attribute> p(new Attribute()); m_attributes.push_back(p); return p.get(); }
Connector* Repository::createConnector() { std::shared_ptr<Connector> p(new Connector()); m_connectors.push_back(p); return p.get(); }
Diagram* Repository::createDiagram() { std::shared_ptr<Diagram> p(new Diagram()); m_diagrams.push_back(p); return p.get(); }
void Repository::registerPackage(Package* value) { if(value!=NULL) m_packageById[value->getId()] = value; }
void Repository::registerElement(Element* value) { if(value!=NULL){ m_elementById[value->getId()] = value; if(!value->getGuid().empty()) m_elementByGuid[value->getGuid()] = value; } }
void Repository::registerAttribute(Attribute* value) { if(value!=NULL){ m_attributeById[value->getId()] = value; if(!value->getGuid().empty()) m_attributeByGuid[value->getGuid()] = value; } }
void Repository::registerConnector(Connector* value) { if(value!=NULL){ m_connectorById[value->getId()] = value; if(!value->getGuid().empty()) m_connectorByGuid[value->getGuid()] = value; } }
void Repository::registerDiagram(Diagram* value) { if(value!=NULL) m_diagramById[value->getId()] = value; }

bool Repository::buildReferences()
{
    m_models.clear();
    for(size_t i=0;i<m_packages.size();++i)
    {
        Package* pkg = m_packages[i].get();
        Package* parent = getPackageById(pkg->getParentId());
        pkg->setParent(parent);
        if(parent != NULL && parent != pkg) parent->addPackage(pkg); else m_models.push_back(pkg);
    }
    for(size_t i=0;i<m_elements.size();++i)
    {
        Element* e = m_elements[i].get();
        Package* pkg = getPackageById(e->getPackageId());
        e->setPackage(pkg);
        if(pkg != NULL) pkg->addElement(e);
    }
    for(size_t i=0;i<m_attributes.size();++i)
    {
        Attribute* a = m_attributes[i].get();
        Element* owner = getElementById(a->getOwnerId());
        a->setOwner(owner);
        if(owner != NULL) owner->addAttribute(a);
        Element* ref = findElement(a->getType());
        a->setReferencedElement(ref);
    }
    for(size_t i=0;i<m_connectors.size();++i)
    {
        Connector* c = m_connectors[i].get();
        Element* client = getElementById(c->getClientId());
        Element* supplier = getElementById(c->getSupplierId());
        c->setClient(client);
        c->setSupplier(supplier);
        if(client != NULL){ client->addConnector(c); client->addOutgoingConnector(c); }
        if(supplier != NULL){ supplier->addConnector(c); supplier->addIncomingConnector(c); }
    }
    for(size_t i=0;i<m_diagrams.size();++i)
    {
        Diagram* d = m_diagrams[i].get();
        Package* pkg = getPackageById(d->getPackageId());
        d->setPackage(pkg);
        if(pkg != NULL) pkg->addDiagram(d);
    }
    return true;
}

}
