#include "qea/Statement.hpp"

namespace qea
{

Statement::Statement(sqlite3* db, const std::string& sql)
    : m_stmt(NULL)
{
    int rc = sqlite3_prepare_v2(db, sql.c_str(), -1, &m_stmt, NULL);
    if(rc != SQLITE_OK)
    {
        if(db != NULL)
        {
            m_error = sqlite3_errmsg(db);
        }
        else
        {
            m_error = "sqlite database handle is null";
        }
    }
}

Statement::~Statement()
{
    if(m_stmt != NULL)
    {
        sqlite3_finalize(m_stmt);
        m_stmt = NULL;
    }
}

Statement::Statement(Statement&& other)
    : m_stmt(other.m_stmt), m_error(other.m_error)
{
    other.m_stmt = NULL;
}

Statement& Statement::operator=(Statement&& other)
{
    if(this != &other)
    {
        if(m_stmt != NULL)
        {
            sqlite3_finalize(m_stmt);
        }
        m_stmt = other.m_stmt;
        m_error = other.m_error;
        other.m_stmt = NULL;
    }
    return *this;
}

bool Statement::isValid() const
{
    return m_stmt != NULL && m_error.empty();
}

const std::string& Statement::getError() const
{
    return m_error;
}

bool Statement::step()
{
    if(m_stmt == NULL)
    {
        return false;
    }
    return sqlite3_step(m_stmt) == SQLITE_ROW;
}

int Statement::getInt(int column) const
{
    return sqlite3_column_int(m_stmt, column);
}

long Statement::getLong(int column) const
{
    return static_cast<long>(sqlite3_column_int64(m_stmt, column));
}

std::string Statement::getText(int column) const
{
    const unsigned char* text = sqlite3_column_text(m_stmt, column);
    if(text == NULL)
    {
        return std::string();
    }
    return std::string(reinterpret_cast<const char*>(text));
}

Statement& Statement::bindInt(int index, int value)
{
    sqlite3_bind_int(m_stmt, index, value);
    return *this;
}

Statement& Statement::bindLong(int index, long value)
{
    sqlite3_bind_int64(m_stmt, index, static_cast<sqlite3_int64>(value));
    return *this;
}

Statement& Statement::bindText(int index, const std::string& value)
{
    sqlite3_bind_text(m_stmt, index, value.c_str(), -1, SQLITE_TRANSIENT);
    return *this;
}

}
