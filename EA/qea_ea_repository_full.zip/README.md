# QEA EA-style Repository

C++11 Sparx EA QEA(SQLite) loader skeleton.

## 목표

- Sparx EA Add-In과 유사한 이름 유지
  - Repository
  - Package
  - Element
  - Attribute
  - Connector
  - Diagram
- 실제 SQLite3로 QEA 파일 로딩
- Web 관계도 / OMG IDL 생성을 위한 최소 모델만 메모리에 구성
- QEA 전체 테이블 1:1 매핑이 아니라 필요한 정보만 객체화

## 읽는 테이블

- `t_package`
- `t_object`
- `t_attribute`
- `t_connector`
- `t_xref`
- `t_objectproperties`
- `t_diagram`
- `t_diagramobjects`

## 빌드

```bash
mkdir build
cd build
cmake ..
cmake --build .
```

## 사용

```bash
./qea_dump your_model.qea
```

## 주의

Sparx EA QEA 스키마는 버전/DB 종류에 따라 일부 컬럼명이 달라질 수 있습니다.
대표 컬럼 기준으로 작성했으며, 필요하면 `QeaLoader.cpp`의 SQL을 조정하세요.
