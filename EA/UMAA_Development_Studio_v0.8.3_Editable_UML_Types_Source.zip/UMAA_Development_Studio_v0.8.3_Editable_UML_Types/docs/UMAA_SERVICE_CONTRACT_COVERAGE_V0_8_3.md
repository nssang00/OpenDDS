# UMAA 6.0 Service 계약 모델 vs. Studio v0.8.3 — Gap 검토

## 근거 문서

인계 ZIP의 공식 `UMAA-SPEC-MOICD-v6.0.pdf`를 중심으로 확인했다.
- §3.2 Definition: 서비스와 required interfaces의 구현 준수, 서비스는 Component 내에서 자유롭게 그룹화 가능
- §3.4 Naming Conventions: SoaML participant, serviceInterface, service port, request port; Operation/MessageType 규칙, Query·Cancel 예외
- §5: Request/Reply 및 Command/Response DDS Flow Control과 초기화·종료 절차
- §6.1 Services and Interfaces: Service Requests(Inputs), Service Responses(Outputs), Operation의 설명·Namespace·Topic·Data Type·Member Attributes, `*`/`†` 어노테이션
- §6.1.5 GlobalVectorControl (Table 22–26): 4개의 DDS Topic 및 명령/상태/응답 등 Operation
- §3.8 Large Sets/Lists, §3.9 Generalization/Specialization: 동기화용 Topic과 메타데이터 관계

## 현재 범위 요약

| ICD/SoaML 계약 요소 | v0.8.3 표현 | 추가 과제 |
|---|---|---|
| Functional Area / Service 이름·설명·Namespace | 기본 필드 | 서비스별 전체 ICD 속성, 원문 출처의 버전 추적 |
| ServiceInterface, 서비스 포트, 요청 포트, required/provided | Operation 묶음 `interfaces`만 있음 | SoaML ServiceInterface/포트의 의미·방향·계약 연결을 일급 모델로 구성 |
| Service Requests/Responses | Operation actor/action 및 Topic 참조로 부분 표현 | ICD 원문의 Input/Output operation 구분, 직접 DDS 처리되는 operation 및 NOOP 명시 |
| Operation, DDS Action(publish/subscribe/dispose) | 표현 | Operation 서술·파라미터·예외 규칙·형식별 요구사항 |
| DDS Topic, fully qualified Name, MessageType | 표현(목 카탈로그) | 공식 IDL import, vendor TypeSupport/필터·key 적합성 |
| Struct 필드, common Type 상속, @key/@optional | ICD 기반 목 필드 32 + 공통 17; UML 클래스 일반화 표시 | 실제 IDL 검증, bound/typedef/union/enum/annotation 정합성 |
| Command/Response 상태 전이, 생명주기, Query, Cancel | 역할별 Endpoint, Subscribe/Dispose 투영 | 상태 머신, timeout, GUID/sessionID, recovery 및 검증 규칙 |
| LargeSet/List 다중 Topic | ConditionalReport LargeSet 1개 목 관계 | 리스트 요소·메타데이터 원자적 동기화/삭제/회복 |
| Generalization/Specialization(멀티 Topic) | 없음(일반 Struct 상속과 별개) | specializationTopic/ID/timestamp 및 동기화 흐름 |
| QoS, Domain/Partition, 컴포넌트 배치 | Project Runtime Profile | ICD별 QoS 적합성·reader/writer 호환성 검증 |
| Component Provider/Consumer | Service Binding 역할 | Interface와 Endpoint의 다중 연결 검증 |

**주의**: IDL `struct : Parent`의 상속 관계는 §3.9의 멀티 Topic 일반화/특수화 데이터 프로토콜과 구분해야 한다.

## GlobalVectorControl 실제 비교

MO ICD §6.1.5 Table 22는 setGlobalVector, queryCommandAck, queryExecutionStatus, cancelCommand 요청, 그리고 CommandStatus/Ack/ExecutionStatus/CancelStatus 응답을 정의한다. `report...CancelCommandStatus`는 DDS에서 별도 Topic으로 발생하지 않는 MDE completeness용 operation이다.

현행 Studio는 `GlobalVectorControl`에 **Service 1, UI용 Interface 묶음 1, Operation 7, DDS Topic 4, MessageType 4**를 매핑한다. 7개 Operation은 4개 Topic으로 향하는 publish/subscribe/dispose 동작을 표현한다. CancelStatus NOOP는 독립 Operation으로 등록되지 않았고, Query에 독립 Topic을 추가하지 않은 것은 ICD 설명과 부합한다. 그러나 표준의 SoaML ServiceInterface, provider/request port, Flow Control state machine, semantics 검증까지 표현한다고 볼 수 없다.

## 구현 권장 순서

P0. 지금의 Service–Operation–DDS Action–Topic–Type 그래프를 **DDS Mapping View**라고 명확히 명명. 전체 Service 계약으로 오해되지 않게 안내.

P1. Service Overview에 `Provided/Required Interface`, `Input/Output Operations`, `Flow Protocol`, `References`를 별도 메타데이터/작은 관계 박스로 정의. 기존 Graph 노드 수를 늘리기보다 탭/속성에 표시.

P2. §5 DDS flow 및 §3.8/3.9 다중 Topic 관계를 별도 Protocol View/validation rule로 구현.

P3. 실제 공식 IDL import와 ICD-version mapping 후, namespace/type/annotation, Topic/Operation 매핑을 규칙 기반 검증.
