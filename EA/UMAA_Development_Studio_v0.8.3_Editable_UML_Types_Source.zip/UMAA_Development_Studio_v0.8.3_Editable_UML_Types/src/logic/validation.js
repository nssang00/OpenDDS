export function validateWorkspace(s) {
    const issues = [];
    const error = (code, message, entityId) => issues.push({ severity: 'error', code, message, entityId });
    const warn = (code, message, entityId) => issues.push({ severity: 'warning', code, message, entityId });
    for (const b of s.bindings) {
        if (!s.components.some(c => c.id === b.componentId))
            error('MISSING_COMPONENT', `Binding ${b.id}의 Component가 없습니다.`, b.id);
        if (!s.services.some(v => v.id === b.serviceId))
            error('MISSING_SERVICE', `Binding ${b.id}의 Service가 없습니다.`, b.id);
    }
    for (const op of s.operations) {
        if (!s.services.some(v => v.id === op.serviceId))
            error('MISSING_SERVICE', `Operation ${op.name}의 Service가 없습니다.`, op.id);
        if (!s.topics.some(t => t.id === op.topicId))
            error('MISSING_TOPIC', `Operation ${op.name}의 Topic이 없습니다.`, op.id);
    }
    for (const i of s.interfaces ?? []) {
        if (!s.services.some(v => v.id === i.serviceId))
            error('MISSING_SERVICE', `Interface ${i.name}의 Service가 없습니다.`, i.id);
        for (const opId of i.operationIds) {
            if (!s.operations.some(o => o.id === opId && o.serviceId === i.serviceId))
                error('INVALID_INTERFACE_OPERATION', `${i.name}에 속한 Operation ${opId}가 유효하지 않습니다.`, i.id);
        }
    }
    for (const relation of s.topicRelations ?? []) {
        if (!s.topics.some(t => t.id === relation.parentTopicId) || !s.topics.some(t => t.id === relation.relatedTopicId)) {
            error('INVALID_TOPIC_RELATION', `Topic 관계 ${relation.id}가 유효하지 않습니다.`, relation.id);
        }
    }
    for (const t of s.topics) {
        if (!s.messages.some(m => m.id === t.messageTypeId))
            error('MISSING_TYPE', `Topic ${t.name}의 Message Type이 없습니다.`, t.id);
    }
    for (const svc of s.services) {
        if (!s.operations.some(o => o.serviceId === svc.id))
            error('EMPTY_SERVICE', `Service ${svc.name}에 Operation이 없습니다.`, svc.id);
    }
    for (const t of [...s.messages, ...(s.dataTypes ?? [])].filter(t => t.projectOverride)) {
        warn('ICD_MOCK_OVERRIDE', `${t.namespace}::${t.name}은 프로젝트에서 수정한 ICD Mock입니다. 실제 DDS IDL 호환성은 별도 검증해야 합니다.`, t.id);
    }
    for (const m of s.messages.filter(m => m.source === 'custom')) {
        if (m.fields.length === 0)
            error('EMPTY_MESSAGE', `Custom Message ${m.name}에 Field가 없습니다.`, m.id);
        const names = new Set();
        for (const field of m.fields) {
            if (!/^[a-zA-Z_][a-zA-Z0-9_]*$/.test(field.name))
                error('INVALID_FIELD', `${m.name}.${field.name}는 IDL 식별자로 적합하지 않습니다.`, m.id);
            if (names.has(field.name))
                error('DUPLICATE_FIELD', `${m.name}.${field.name} 필드가 중복되었습니다.`, m.id);
            names.add(field.name);
            if (field.key && field.optional)
                error('INVALID_KEY', `${m.name}.${field.name}는 Key와 Optional을 동시에 지정할 수 없습니다.`, m.id);
        }
    }
    const customTypes = (s.dataTypes ?? []).map(t => `${t.namespace}::${t.name}`);
    for (const type of s.dataTypes ?? []) {
        if (type.source !== 'custom') continue;
        if (type.kind === 'struct' && (!Array.isArray(type.fields) || !type.fields.length))
            error('EMPTY_CUSTOM_TYPE', `Custom Struct ${type.name}은 Field가 필요합니다.`, type.id);
        for (const f of type.kind === 'struct' ? (type.fields ?? []) : []) {
            if (f.key && f.optional) error('INVALID_KEY', `${type.name}.${f.name}는 Key와 Optional을 동시에 지정할 수 없습니다.`, type.id);
        }
        if (type.kind === 'enum' && (!Array.isArray(type.members) || !type.members.length))
            error('EMPTY_CUSTOM_ENUM', `Custom Enum ${type.name}은 Enumerator가 필요합니다.`, type.id);
    }
    for (const field of [...s.messages.filter(m=>m.source==='custom').flatMap(m=>m.fields), ...(s.dataTypes??[]).filter(t=>t.kind==='struct').flatMap(t=>t.fields)]) {
        if (typeof field.type==='string' && field.type.startsWith('ProjectCustom::Types::') && !customTypes.includes(field.type))
            error('MISSING_CUSTOM_TYPE', `필드가 찾을 수 없는 Custom Type ${field.type}을 참조합니다.`);
    }
    for (const component of s.components) {
        const runtime = s.componentRuntime?.[component.id];
        if (!runtime) continue;
        if (!s.qosProfiles?.some(q=>q.id===runtime.qosProfileId))
            error('MISSING_QOS', `${component.name}의 QoS Profile이 없습니다.`, component.id);
        if (!Number.isInteger(runtime.domainId) || runtime.domainId<0)
            error('INVALID_DOMAIN', `${component.name}의 DDS Domain ID가 유효하지 않습니다.`, component.id);
        if (runtime.commandArbitration==='user-implementation' && s.bindings.some(b=>b.componentId===component.id && b.role==='provider' && s.services.some(v=>v.id===b.serviceId && v.flowControl==='command-response')))
            warn('COMMAND_POLICY_TODO', `${component.name}의 Command 충돌 처리 구현 정책이 미확정입니다.`, component.id);
    }
    for (const c of s.connections) {
        const p = s.bindings.find(b => b.id === c.providerBindingId);
        const u = s.bindings.find(b => b.id === c.consumerBindingId);
        if (!p || !u)
            error('ORPHAN_CONNECTION', `연결 ${c.id}의 Binding이 없습니다.`, c.id);
        else if (p.role !== 'provider' || u.role !== 'consumer' || p.serviceId !== u.serviceId) {
            error('INVALID_CONNECTION', `연결 ${c.id}: 동일 Service의 Provider → Consumer만 허용합니다.`, c.id);
        }
    }
    for (const b of s.bindings.filter(b => b.role === 'consumer')) {
        if (!s.connections.some(c => c.consumerBindingId === b.id)) {
            const svc = s.services.find(v => v.id === b.serviceId);
            warn('UNCONNECTED_CONSUMER', `${svc?.name || b.serviceId} Consumer가 Provider에 연결되지 않았습니다.`, b.id);
        }
    }
    for (const b of s.bindings.filter(b => b.role === 'provider')) {
        if (!s.connections.some(c => c.providerBindingId === b.id)) {
            const svc = s.services.find(v => v.id === b.serviceId);
            warn('UNUSED_PROVIDER', `${svc?.name || b.serviceId} Provider에 연결된 Consumer가 없습니다.`, b.id);
        }
    }
    return issues;
}
export function canConnect(s, sourceBindingId, targetBindingId) {
    const a = s.bindings.find(b => b.id === sourceBindingId);
    const b = s.bindings.find(b => b.id === targetBindingId);
    return Boolean(a && b && a.role === 'provider' && b.role === 'consumer' && a.serviceId === b.serviceId && a.componentId !== b.componentId && !s.connections.some(c => c.providerBindingId === a.id && c.consumerBindingId === b.id));
}
