import { create } from 'zustand';
import { repository } from '../repository/mockRepository.js';
import { parseWorkspaceImport } from '../model/validateImport.js';
import { canConnect } from '../logic/validation.js';
import { ensureComponentPositions, layoutComponentPositions } from '../logic/layout.js';
import { uuid } from '../model/types.js';
import { defaultRuntime, isValidIdlName } from '../model/workspaceSchema.js';
import { editTypeField, editTypeDefinition, restoreTypeMock } from '../model/typeEditing.js';
const projectId = 'demo-usv';
const update = (set, transform) => {
    set(s => s.snapshot ? { snapshot: transform(s.snapshot), dirty: true } : {});
};
const makeField = (name, type, key = false) => ({ name, type, key, optional: false });
// Topology/port changes change the Dagre node sizes and ranks. Relayout together.
const updateTopology = (set, transform) => {
    set(s => {
        if (!s.snapshot)
            return {};
        const changed = transform(s.snapshot);
        return {
            snapshot: { ...changed, positions: layoutComponentPositions(changed) },
            dirty: true,
            layoutRevision: s.layoutRevision + 1,
        };
    });
};
export const useEditorStore = create((set, get) => ({
    snapshot: null,
    selection: null,
    highlightedComponentId: null,
    loading: false,
    saving: false,
    dirty: false,
    layoutRevision: 0,
    autoLayout() {
        const snapshot = get().snapshot;
        if (!snapshot)
            return;
        set(s => ({
            snapshot: { ...snapshot, positions: layoutComponentPositions(snapshot) },
            layoutRevision: s.layoutRevision + 1,
            dirty: true,
        }));
    },
    async load() {
        set({ loading: true });
        try {
            const snapshot = ensureComponentPositions(await repository.load(projectId));
            set(s => ({ snapshot, dirty: false, selection: { kind: 'diagram', id: 'system' }, layoutRevision: s.layoutRevision + 1 }));
        }
        finally {
            set({ loading: false });
        }
    },
    async save() {
        const snapshot = get().snapshot;
        if (!snapshot)
            return;
        set({ saving: true });
        try {
            await repository.save(projectId, snapshot);
            set({ dirty: false });
        }
        finally {
            set({ saving: false });
        }
    },
    async reset() {
        set({ loading: true });
        try {
            const snapshot = ensureComponentPositions(await repository.reset(projectId));
            set(s => ({ snapshot, dirty: false, selection: { kind: 'diagram', id: 'system' }, layoutRevision: s.layoutRevision + 1 }));
        }
        finally {
            set({ loading: false });
        }
    },
    importSnapshot(value) {
        const snapshot = parseWorkspaceImport(value);
        set(s => ({ snapshot: ensureComponentPositions(structuredClone(snapshot)), dirty: true, selection: { kind: 'diagram', id: 'system' }, layoutRevision: s.layoutRevision + 1 }));
    },
    select(selection) { set({ selection, highlightedComponentId: null }); },
    highlightComponent(id) { set({ highlightedComponentId: id }); },
    addComponent(name) {
        const trimmed = name.trim();
        if (!trimmed)
            return;
        const component = { id: uuid(), name: trimmed, description: '', source: 'project' };
        updateTopology(set, s => ({ ...s, components: [...s.components, component], componentRuntime: { ...s.componentRuntime, [component.id]: defaultRuntime() } }));
        set({ selection: { kind: 'component', id: component.id } });
    },
    addBinding(componentId, serviceId, role) {
        const s = get().snapshot;
        if (!s || !s.components.some(c => c.id === componentId) || !s.services.some(v => v.id === serviceId))
            return false;
        if (s.bindings.some(b => b.componentId === componentId && b.serviceId === serviceId && b.role === role))
            return false;
        const binding = { id: uuid(), componentId, serviceId, role };
        updateTopology(set, old => ({ ...old, bindings: [...old.bindings, binding] }));
        set({ selection: { kind: 'binding', id: binding.id } });
        return true;
    },
    removeBinding(bindingId) {
        updateTopology(set, s => ({
            ...s,
            bindings: s.bindings.filter(b => b.id !== bindingId),
            connections: s.connections.filter(c => c.providerBindingId !== bindingId && c.consumerBindingId !== bindingId),
        }));
        set({ selection: null });
    },
    addFunctionalArea(code, name) {
        const s = get().snapshot;
        const id = String(code ?? '').trim().toUpperCase();
        const label = String(name ?? '').trim();
        if (!s || !/^[A-Z][A-Z0-9_]{1,11}$/.test(id) || !label || s.functionalAreas.some(a => a.id === id)) return false;
        update(set, old => ({ ...old, functionalAreas: [...old.functionalAreas, {
            id, name: label, icd: 'Project extension — not an official UMAA ICD', source: 'custom',
        }] }));
        set({ selection: { kind: 'functionalArea', id } });
        return true;
    },
    addQosProfile(name) {
        const s = get().snapshot;
        const trimmed = String(name ?? '').trim();
        if (!s || !trimmed || s.qosProfiles.some(q => q.name.toLowerCase() === trimmed.toLowerCase())) return false;
        const profile = { id: uuid(), name: trimmed, source: 'project', reliability: 'reliable', durability: 'volatile', historyKind: 'keep_last', historyDepth: 10, note: 'User-defined DDS QoS configuration' };
        update(set, old => ({ ...old, qosProfiles: [...old.qosProfiles, profile] }));
        set({ selection: { kind: 'qos', id: profile.id } });
        return true;
    },
    updateQosProfile(id, patch) {
        update(set, old => ({ ...old, qosProfiles: old.qosProfiles.map(q => q.id === id ? { ...q, ...patch } : q) }));
    },
    updateComponentRuntime(id, patch) {
        update(set, old => ({ ...old, componentRuntime: { ...old.componentRuntime,
            [id]: { ...defaultRuntime(), ...old.componentRuntime[id], ...patch } } }));
    },
    addDataType(name, kind = 'struct') {
        const s = get().snapshot;
        const trimmed = String(name ?? '').trim();
        if (!s || !isValidIdlName(trimmed) || !['struct','enum'].includes(kind) ||
            s.dataTypes.some(t => t.name.toLowerCase() === trimmed.toLowerCase()) ||
            s.messages.some(t => t.name.toLowerCase() === trimmed.toLowerCase())) return false;
        const type = { id: uuid(), name: trimmed, kind, namespace: 'ProjectCustom::Types', source: 'custom',
            fields: kind === 'struct' ? [makeField('value', 'double')] : [],
            members: kind === 'enum' ? ['UNKNOWN'] : [] };
        update(set, old => ({ ...old, dataTypes: [...old.dataTypes, type] }));
        set({ selection: { kind: 'dataType', id: type.id } });
        return true;
    },
    addStandaloneMessageType(name) {
        const snap=get().snapshot;
        const trimmed=String(name??'').trim();
        if(!snap||!isValidIdlName(trimmed)||[...snap.messages,...snap.dataTypes].some(t=>t.namespace==='ProjectCustom::Messages'&&t.name===trimmed))return false;
        const type={id:uuid(),name:trimmed,namespace:'ProjectCustom::Messages',source:'custom',kind:'struct',fields:[]};
        update(set,old=>({...old,messages:[...old.messages,type]}));
        set({selection:{kind:'message',id:type.id}});return true;
    },
    // Standard-derived mock types are editable as project overrides. The original reference data is retained.
    applyTypeFieldEdit(kind, typeId, action, payload) {
        const snap = get().snapshot;
        if (!snap) return false;
        const next = editTypeField(snap,kind,typeId,action,payload);
        if (!next) return false;
        set({ snapshot: next, dirty: true }); return true;
    },
    updateTypeDefinition(kind, id, patch) {
        const snap=get().snapshot;
        const next=snap&&editTypeDefinition(snap,kind,id,patch);
        if(!next)return false;
        set({snapshot:next,dirty:true});return true;
    },
    restoreTypeOverride(kind,id) {
        const snap=get().snapshot;
        const next=snap&&restoreTypeMock(snap,kind,id);
        if(!next)return false;
        set({snapshot:next,dirty:true});return true;
    },
    addDataTypeField(id,name,type,options={}) { return get().applyTypeFieldEdit('dataType',id,'add',{name,type,...options}); },
    updateDataTypeField(id,originalName,patch) { return get().applyTypeFieldEdit('dataType',id,'update',{originalName,...patch}); },
    removeDataTypeField(id,name) { return get().applyTypeFieldEdit('dataType',id,'remove',{originalName:name}); },
    addEnumMember(id,name) { return get().applyTypeFieldEdit('dataType',id,'add',{name}); },
    updateEnumMember(id,originalName,name) { return get().applyTypeFieldEdit('dataType',id,'update',{originalName,name}); },
    removeEnumMember(id,name) { return get().applyTypeFieldEdit('dataType',id,'remove',{originalName:name}); },
    addCustomMessageType(serviceId, name) {
        const s = get().snapshot;
        const svc = s?.services.find(v => v.id === serviceId && v.source === 'custom');
        const trimmed = String(name ?? '').trim();
        if (!svc || !isValidIdlName(trimmed) || s.messages.some(m => m.name === trimmed && m.namespace === svc.namespace)) return false;
        const obj = { id: uuid(), name: trimmed, namespace: svc.namespace, source: 'custom',
            fields: [makeField('value', 'double')] };
        update(set, old => ({ ...old, messages: [...old.messages, obj] }));
        set({ selection: { kind: 'message', id: obj.id } });
        return true;
    },
    addCustomTopic(serviceId, name, messageTypeId) {
        const s = get().snapshot;
        const svc = s?.services.find(v => v.id === serviceId && v.source === 'custom');
        const msg = s?.messages.find(v => v.id === messageTypeId);
        const trimmed = String(name ?? '').trim();
        if (!svc || !msg || !isValidIdlName(trimmed) || s.topics.some(t => t.name === trimmed &&
            s.operations.some(o => o.topicId === t.id && o.serviceId === serviceId))) return false;
        const obj = { id: uuid(), name: trimmed, messageTypeId };
        update(set, old => ({ ...old, topics: [...old.topics, obj] }));
        set({ selection: { kind: 'topic', id: obj.id } });
        return true;
    },
    addCustomOperation(serviceId, name, topicId, action, actor, optionalConsumer = false) {
        const s = get().snapshot;
        const svc = s?.services.find(v => v.id === serviceId && v.source === 'custom');
        const trimmed = String(name ?? '').trim();
        if (!svc || !isValidIdlName(trimmed) || !s.topics.some(t => t.id === topicId) ||
            !['publish','subscribe','dispose'].includes(action) || !['provider','consumer'].includes(actor) ||
            s.operations.some(o => o.serviceId === serviceId && o.name === trimmed)) return false;
        const op = { id: uuid(), serviceId, name: trimmed, topicId, action, actor, optionalConsumer };
        update(set, old => ({ ...old, operations: [...old.operations, op],
            interfaces: old.interfaces.map(i => i.serviceId === serviceId ? { ...i, operationIds: [...i.operationIds, op.id] } : i) }));
        set({ selection: { kind: 'operation', id: op.id } });
        return true;
    },
    updateCustomOperationTopic(operationId, topicId) {
        const s=get().snapshot;
        const op=s?.operations.find(o=>o.id===operationId);
        const svc=s?.services.find(v=>v.id===op?.serviceId);
        const topic=s?.topics.find(t=>t.id===topicId);
        const type=s?.messages.find(m=>m.id===topic?.messageTypeId);
        if(!op || svc?.source!=='custom' || !topic || type?.source!=='custom' || type.namespace!==svc.namespace) return false;
        update(set, old=>({...old,operations:old.operations.map(o=>o.id===operationId?{...o,topicId}:o)}));
        return true;
    },
    removeCustomOperation(operationId) {
        const s=get().snapshot;
        const op=s?.operations.find(o=>o.id===operationId);
        if(!op || s?.services.find(x=>x.id===op.serviceId)?.source!=='custom')return false;
        update(set, old=>({...old,operations:old.operations.filter(o=>o.id!==operationId),interfaces:old.interfaces.map(i=>({...i,operationIds:i.operationIds.filter(id=>id!==operationId)}))}));
        return true;
    },
    addCustomService(name, flow, functionalArea = 'CUSTOM') {
        const s = get().snapshot;
        const trimmed = name.trim();
        if (!s || !/^[A-Za-z][A-Za-z0-9_]*$/.test(trimmed) || s.services.some(x => x.name.toLowerCase() === trimmed.toLowerCase()))
            return false;
        if (functionalArea !== 'CUSTOM' && !s.functionalAreas.some(a => a.id === functionalArea)) return false;
        const sid = uuid();
        const namespace = `ProjectCustom::${trimmed}`;
        const svc = { id: sid, name: trimmed, namespace, functionalArea, source: 'custom', version: '1.0', flowControl: flow, description: '사용자 정의 서비스 (UMAA 표준 서비스 아님)' };
        const messages = [];
        const topics = [];
        const operations = [];
        const make = (suffix, fields) => {
            const typeId = uuid();
            const topicId = uuid();
            const typeName = `${trimmed}${suffix}Type`;
            messages.push({ id: typeId, name: typeName, namespace, source: 'custom', fields });
            topics.push({ id: topicId, name: typeName, messageTypeId: typeId });
            return topicId;
        };
        if (flow === 'request-reply') {
            const t = make('Report', [makeField('entityId', 'string', true), makeField('value', 'double')]);
            operations.push({ id: uuid(), serviceId: sid, name: 'report' + trimmed, topicId: t, action: 'publish', actor: 'provider' });
            operations.push({ id: uuid(), serviceId: sid, name: 'query' + trimmed, topicId: t, action: 'subscribe', actor: 'consumer' });
        }
        else {
            const tCommand = make('Command', [makeField('sessionId', 'string', true), makeField('destinationId', 'string'), makeField('targetValue', 'double')]);
            const tStatus = make('CommandStatus', [makeField('sessionId', 'string', true), makeField('status', 'string'), makeField('reason', 'string')]);
            const tAck = make('CommandAckReport', [makeField('sessionId', 'string', true)]);
            const tExecution = make('ExecutionStatusReport', [makeField('sessionId', 'string', true), makeField('progress', 'double')]);
            operations.push({ id: uuid(), serviceId: sid, name: 'set' + trimmed, topicId: tCommand, action: 'publish', actor: 'consumer' });
            operations.push({ id: uuid(), serviceId: sid, name: 'report' + trimmed + 'CommandStatus', topicId: tStatus, action: 'publish', actor: 'provider' });
            operations.push({ id: uuid(), serviceId: sid, name: 'report' + trimmed + 'CommandAck', topicId: tAck, action: 'publish', actor: 'provider' });
            operations.push({ id: uuid(), serviceId: sid, name: 'query' + trimmed + 'CommandAck', topicId: tAck, action: 'subscribe', actor: 'consumer', optionalConsumer: true });
            operations.push({ id: uuid(), serviceId: sid, name: 'report' + trimmed + 'ExecutionStatus', topicId: tExecution, action: 'publish', actor: 'provider' });
            operations.push({ id: uuid(), serviceId: sid, name: 'query' + trimmed + 'ExecutionStatus', topicId: tExecution, action: 'subscribe', actor: 'consumer', optionalConsumer: true });
            operations.push({ id: uuid(), serviceId: sid, name: 'cancel' + trimmed + 'Command', topicId: tCommand, action: 'dispose', actor: 'consumer' });
        }
        update(set, old => ({ ...old,
            functionalAreas: functionalArea === 'CUSTOM' && !old.functionalAreas.some(a => a.id === 'CUSTOM')
                ? [...old.functionalAreas, { id: 'CUSTOM', name: 'Project Extensions', icd: 'Project-defined area — not UMAA standard', source: 'custom' }]
                : old.functionalAreas,
            services: [...old.services, svc],
            interfaces: [...old.interfaces, { id: uuid(), serviceId: sid, name: `${trimmed} · Operation Interface`,
                    description: 'Custom Service의 Operation 그룹', operationIds: operations.map(o => o.id) }],
            topics: [...old.topics, ...topics], messages: [...old.messages, ...messages], operations: [...old.operations, ...operations] }));
        set({ selection: { kind: 'service', id: sid } });
        return true;
    },
    addMessageField(id,name,type,options={}) { return get().applyTypeFieldEdit('message',id,'add',{name,type,...options}); },
    updateMessageField(id,originalName,patch) { return get().applyTypeFieldEdit('message',id,'update',{originalName,...patch}); },
    updateCustomTopicType(topicId, messageTypeId) {
        const s=get().snapshot;
        const topic=s?.topics.find(t=>t.id===topicId);
        const usedBy=s?.operations.filter(o=>o.topicId===topicId)??[];
        if(!topic || !s.messages.some(m=>m.id===messageTypeId) || usedBy.some(o=>s.services.find(v=>v.id===o.serviceId)?.source!=='custom')) return false;
        const priorType=s.messages.find(m=>m.id===topic.messageTypeId);
        const nextType=s.messages.find(m=>m.id===messageTypeId);
        if(priorType?.source!=='custom' || nextType?.source!=='custom' || priorType.namespace!==nextType.namespace) return false;
        update(set,old=>({...old,topics:old.topics.map(t=>t.id===topicId?{...t,messageTypeId}:t)}));
        return true;
    },
    removeMessageField(id,name) { return get().applyTypeFieldEdit('message',id,'remove',{originalName:name}); },
    connect(providerBindingId, consumerBindingId) {
        const s = get().snapshot;
        if (!s || !canConnect(s, providerBindingId, consumerBindingId))
            return false;
        updateTopology(set, old => ({ ...old, connections: [...old.connections, { id: uuid(), providerBindingId, consumerBindingId }] }));
        return true;
    },
    removeConnection(id) {
        updateTopology(set, s => ({ ...s, connections: s.connections.filter(c => c.id !== id) }));
        set({ selection: null });
    },
    moveComponent(componentId, position) {
        update(set, s => ({ ...s, positions: { ...s.positions, [componentId]: position } }));
    },
    setBehaviorDiagram(componentId, diagram) {
        const s=get().snapshot;
        if(!s?.components.some(c=>c.id===componentId) || !diagram || !Array.isArray(diagram.nodes) || !Array.isArray(diagram.edges)) return false;
        update(set,old=>({...old,behaviorDiagrams:{...(old.behaviorDiagrams??{}),[componentId]:{
            nodes:diagram.nodes.map(n=>({id:n.id,kind:n.kind,label:n.label,x:n.x,y:n.y})),
            edges:diagram.edges.map(e=>({id:e.id,source:e.source,target:e.target}))
        }}}));
        return true;
    },
    changePlatform(platform) { update(set, s => ({ ...s, project: { ...s.project, targetPlatform: platform } })); },
    changeVendor(vendor) { update(set, s => ({ ...s, project: { ...s.project, ddsVendor: vendor } })); },
}));
