# UMAA Development Studio — v0.8.3 Editable UML Types

## 변경 사항

- 기존 32개 Message Type과 17개 Common Data Type의 **ICD 기반 Mock을 편집 가능**하게 변경.
- 표준 `source: standard` 정체성과 최초 Mock Snapshot을 유지하고, 필드/타입 수정본만 `projectOverride: true`로 저장. Mock 원본 복원 지원.
- 직접 선언한 필드만 UML 클래스의 속성 구획에 표시. `baseType`이 있다면 상위 Struct를 **UML 일반화(빈 삼각형) 화살표** 위에 표시. 부모 Struct 클릭 이동.
- 오른쪽 Properties에서 Struct/Enum 이름·부모 타입 수정, 필드/Enum 추가·수정·삭제. 부모 필드는 부모 Struct를 통해 편집.
- Explorer의 Type 추가: Data Struct, Enum, 독립 Message Struct 생성 가능.
- 프로젝트 저장/불러오기 후에도 Override 유지. 이름 변경 시 하위 타입의 참조를 갱신하고 상속 순환 차단.
- 하단 패널은 **Output/Console 전용**으로 유지.
- 정적 검증은 프로젝트 Mock Override에 경고를 출력. 코드 생성의 `contracts/type-overrides.json`에 변경 사항을 기록하지만, **공식 IDL 파일이나 DDS TypeSupport에 자동 반영하지 않음**.

## 실행과 미리보기

- [독립 HTML UML Type Editor](preview/UMAA_Types_UML_Editor_v0.8.3.html): 실제 클릭 가능한 Type 편집 미리보기. 독립 브라우저 localStorage 사용 가능 시 변경 사항 유지; JSON Export 제공. React 앱의 실제 빌드 결과는 아님.
- [PREVIEW_UI.html](PREVIEW_UI.html): 위 미리보기 진입 링크.
- React 소스: `src/components/TypeWorkbench.jsx`, `TypeProperties.jsx`, `src/model/typeEditing.js`.

```
npm install
npm run test:core
npm run build
```

## 검증 결과

- `npm run test:core` 통과: 원래 모델/그래프/UI 정적 테스트, 새로운 Override 편집·복원·재로드·상속 순환 검사.
- 독립 HTML: Chromium 렌더링 테스트 및 필드 추가/수정, Type 이름 변경, Override 복원, 새 Message Type 생성, Console 탭 확인.
- JSX 파일: TypeScript JSX parser를 통한 구문 검사 통과.
- React 실제 설치/번들/브라우저 E2E는 의존성 미설치로 **미검증**.

## 공식 문서와 모델 차이

- 실제 표준 IDL 원본이 아니라 ICD 속성표를 기반으로 만든 Mock 구조입니다. `@key`, `@optional`, 상속 등 일부 속성이 포함되어도 **공식 DDS IDL 호환성이 보장되는 것은 아닙니다**.
- Studio는 Service 계약 전체가 아니라 Operation→DDS Action→Topic→MessageType의 **DDS Mapping View**를 주로 구현했습니다.
- [UMAA Service 구성 항목 및 현재 다이어그램 부족한 부분](docs/UMAA_SERVICE_CONTRACT_COVERAGE_V0_8_3.md) 참고.

과거 버전 HTML은 `preview/archive`에 보관했습니다.
