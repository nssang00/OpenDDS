# UI Review v0.8.3

1. `PREVIEW_UI.html` 또는 `preview/UMAA_Types_UML_Editor_v0.8.3.html` 열기.
2. GlobalPoseReportType: `UMAAStatus` 부모 Struct가 위에 위치하고 일반화 삼각형이 **부모를 향하는지** 확인.
3. UML Struct의 필드 선택 → 오른쪽 Properties의 이름/자료형 변경 → 저장 → `OVERRIDDEN` 표시 확인.
4. Field 추가 → 삭제 → `ICD Mock 원본 복원` 확인.
5. Type Definition에서 Type 이름 및 상속 구조 변경 → Explorer와 UML 박스에 동기화 확인.
6. 왼쪽 `+ New Project Type`: Struct/Enum/Message Struct 생성 확인.
7. 맨 아래는 `OUTPUT`과 `CONSOLE`만 있고, 상세 다이어그램/표는 존재하지 않아야 함.

`UMAA 6.0 ICD`에서 가져온 표준 Type이라도 **프로젝트 편집 가능**하지만, 원본 공식 IDL을 수정한다고 표시하면 안 됩니다.
