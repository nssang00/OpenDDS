const IDL_TYPE_MAP = {
  boolean: 'boolean',
  byte: 'octet',
  char8: 'char',
  char16: 'wchar',
  int8: 'int8',
  uint8: 'uint8',
  int16: 'short',
  uint16: 'unsigned short',
  int32: 'long',
  uint32: 'unsigned long',
  int64: 'long long',
  uint64: 'unsigned long long',
  float32: 'float',
  float64: 'double',
  float128: 'long double',
  string: 'string',
  wstring: 'wstring',
};

export function memberToIdl(member) {
  if (!member?.name) return '';

  const annotationPrefix = memberAnnotationsToIdl(member);
  const type = memberTypeToIdl(member);
  const name = memberNameToIdl(member);

  return `${annotationPrefix}${type} ${name};`;
}

export function memberTypeToIdl(member) {
  if (member.kind === 'string' || member.kind === 'wstring') {
    const bound = member.string_max_length ? `<${member.string_max_length}>` : '';
    return `${IDL_TYPE_MAP[member.kind]}${bound}`;
  }

  if (member.kind === 'sequence') {
    const bound = member.sequence_max_length ? `, ${member.sequence_max_length}` : '';
    return `sequence<${typeNameToIdl(member.type)}${bound}>`;
  }

  if (member.kind === 'array') {
    return typeNameToIdl(member.type);
  }

  return typeNameToIdl(member.type || member.kind);
}

export function memberNameToIdl(member) {
  if (member.kind !== 'array') return member.name;

  const dimensions = (member.array_dimensions || []).map((size) => `[${size}]`).join('');
  return `${member.name}${dimensions}`;
}

function memberAnnotationsToIdl(member) {
  const annotations = [];

  if (member.annotations?.key) {
    annotations.push('@key');
  }

  if (member.annotations?.optional) {
    annotations.push('@optional');
  }

  return annotations.length ? `${annotations.join(' ')} ` : '';
}

function typeNameToIdl(type) {
  return IDL_TYPE_MAP[type] || type || 'SelectType';
}
