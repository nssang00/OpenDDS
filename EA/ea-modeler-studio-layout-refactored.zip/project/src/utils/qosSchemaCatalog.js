const SECTION_DEFINITIONS = {
  domain_participant_qos: 'domainparticipantQos',
  topic_qos: 'topicQos',
  publisher_qos: 'publisherQos',
  subscriber_qos: 'subscriberQos',
  datawriter_qos: 'datawriterQos',
  datareader_qos: 'datareaderQos',
};

const SECTION_LABELS = {
  domain_participant_qos: 'domain participant',
  topic_qos: 'topic',
  publisher_qos: 'publisher',
  subscriber_qos: 'subscriber',
  datawriter_qos: 'datawriter',
  datareader_qos: 'datareader',
};

export function qosSectionCatalog(qosSchema) {
  return Object.entries(SECTION_DEFINITIONS).map(([key, definitionName]) => ({
    key,
    label: SECTION_LABELS[key],
    policies: qosPolicyCatalog(qosSchema, definitionName),
  }));
}

export function createQosPolicyValue(qosSchema, sectionKey, policyKey) {
  const section = qosSectionCatalog(qosSchema).find((item) => item.key === sectionKey);
  const policy = section?.policies.find((item) => item.key === policyKey);
  return policy ? buildDefaultValue(qosSchema, policy.schema) : {};
}

export function qosFieldMetadata(qosSchema, sectionKey, path) {
  const definitionName = SECTION_DEFINITIONS[sectionKey];
  if (!qosSchema || !definitionName) return {};

  const schema = schemaAtPath(
    qosSchema,
    resolveSchema(qosSchema, { $ref: `#/definitions/${definitionName}` }),
    path,
  );
  const resolved = resolveSchema(qosSchema, schema);

  if (!Object.keys(resolved).length) return {};

  return {
    description: resolved.description,
    inputType: resolved.enum?.length ? 'select' : normalizedType(resolved),
    options: resolved.enum?.map((value) => ({ label: value, value })),
  };
}

function qosPolicyCatalog(qosSchema, definitionName) {
  const schema = resolveSchema(qosSchema, { $ref: `#/definitions/${definitionName}` });
  return Object.entries(schema.properties ?? {})
    .filter(([key]) => key !== 'base_name')
    .map(([key, policySchema]) => ({
      key,
      label: key.replace(/_/g, ' '),
      schema: resolveSchema(qosSchema, policySchema),
    }));
}

function resolveSchema(qosSchema, schema, seen = new Set()) {
  if (!schema?.$ref) return schema ?? {};

  const ref = schema.$ref.replace('#/definitions/', '');
  if (seen.has(ref)) return {};
  seen.add(ref);

  return resolveSchema(qosSchema, qosSchema?.definitions?.[ref], seen);
}

function schemaAtPath(qosSchema, schema, path) {
  return String(path || '')
    .split('.')
    .filter((part) => part && Number.isNaN(Number(part)))
    .reduce((current, part) => {
      const resolved = resolveSchema(qosSchema, current);
      if (resolved.type === 'array') {
        return schemaAtPath(qosSchema, resolved.items, part);
      }
      return resolved.properties?.[part] ?? {};
    }, schema);
}

function normalizedType(schema) {
  const type = Array.isArray(schema.type) ? schema.type[0] : schema.type;
  return type;
}

function buildDefaultValue(qosSchema, schema) {
  const resolved = resolveSchema(qosSchema, schema);
  if (resolved.default !== undefined) return resolved.default;
  if (resolved.enum?.length) return resolved.enum[0];

  const type = Array.isArray(resolved.type) ? resolved.type[0] : resolved.type;
  if (type === 'object' || resolved.properties) {
    return Object.fromEntries(
      Object.entries(resolved.properties ?? {}).map(([key, child]) => [key, buildDefaultValue(qosSchema, child)])
    );
  }
  if (type === 'array') return [];
  if (type === 'boolean') return false;
  if (type === 'integer' || type === 'number') return resolved.minimum ?? 0;
  return '';
}
