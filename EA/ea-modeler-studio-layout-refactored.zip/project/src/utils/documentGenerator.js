export { getModelSummary as generateModelSummary } from '../model/modelSelectors.js';
