import { memberToIdl } from './memberIdl.js';

export function generateIdl(model) {
  const structs = Object.values(model.elementsById).filter((element) => element.type === 'Struct');

  return structs
    .map((struct) => {
      const members = struct.properties.members || [];
      const body = members.map((member) => `  ${memberToIdl(member)}`).join('\n');
      return `struct ${struct.name} {\n${body}\n};`;
    })
    .join('\n\n');
}
