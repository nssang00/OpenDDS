import { graphlib, layout } from '@dagrejs/dagre';

const GAP = 36;
const DEFAULT_WIDTH = 170;
const DEFAULT_HEIGHT = 68;
const NODE_SEP = 72;
const RANK_SEP = 120;
const MARGIN = 48;

export function layoutDiagram(nodes, edges, options = {}) {
  if (nodes.length < 2) return nodes;

  const graph = new graphlib.Graph()
    .setDefaultEdgeLabel(() => ({}))
    .setGraph({
      rankdir: options.direction ?? 'LR',
      nodesep: options.nodeSep ?? NODE_SEP,
      ranksep: options.rankSep ?? RANK_SEP,
      marginx: options.marginX ?? MARGIN,
      marginy: options.marginY ?? MARGIN,
    });

  const nodeIds = new Set(nodes.map((node) => node.id));
  nodes.forEach((node) => {
    graph.setNode(node.id, {
      width: nodeWidth(node),
      height: nodeHeight(node),
    });
  });
  edges.forEach((edge) => {
    if (nodeIds.has(edge.source) && nodeIds.has(edge.target)) {
      graph.setEdge(edge.source, edge.target);
    }
  });

  layout(graph);

  return nodes.map((node) => {
    const layouted = graph.node(node.id);
    if (!layouted) return node;

    return {
      ...node,
      position: {
        x: Math.round(layouted.x - nodeWidth(node) / 2),
        y: Math.round(layouted.y - nodeHeight(node) / 2),
      },
    };
  });
}

export function avoidNodeOverlaps(nodes) {
  const fixed = nodes.filter((node) => node.data?.isContainer);
  const movable = nodes
    .filter((node) => !node.data?.isContainer)
    .sort((a, b) => a.position.y - b.position.y || a.position.x - b.position.x);
  const placed = [];

  const positioned = movable.map((node) => {
    const next = { ...node, position: { ...node.position } };
    let collision;
    while ((collision = placed.find((item) => overlaps(next, item)))) {
      next.position.y = collision.position.y + nodeHeight(collision) + GAP;
    }
    placed.push(next);
    return next;
  });

  return [...fixed, ...positioned];
}

function overlaps(a, b) {
  return a.position.x < b.position.x + nodeWidth(b) + GAP
    && a.position.x + nodeWidth(a) + GAP > b.position.x
    && a.position.y < b.position.y + nodeHeight(b) + GAP
    && a.position.y + nodeHeight(a) + GAP > b.position.y;
}

function nodeWidth(node) { return node.width ?? DEFAULT_WIDTH; }
function nodeHeight(node) { return node.height ?? DEFAULT_HEIGHT; }
