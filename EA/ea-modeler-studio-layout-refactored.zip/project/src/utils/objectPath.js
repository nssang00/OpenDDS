export function readPath(source, path) {
  const parts = Array.isArray(path) ? path : String(path || '').split('.').filter(Boolean);
  return parts.reduce((value, key) => value?.[key], source);
}

export function updatePath(source, path, value) {
  const [key, ...rest] = Array.isArray(path) ? path : String(path || '').split('.').filter(Boolean);

  if (!key) return value;

  if (Array.isArray(source)) {
    const index = Number(key);
    const next = [...source];
    next[index] = rest.length > 0
      ? updatePath(source[index] ?? {}, rest, value)
      : value;
    return next;
  }

  return {
    ...source,
    [key]: rest.length > 0
      ? updatePath(source?.[key] ?? {}, rest, value)
      : value,
  };
}
