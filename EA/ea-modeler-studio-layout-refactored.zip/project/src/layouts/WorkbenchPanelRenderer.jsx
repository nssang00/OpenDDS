import { useEffect, useMemo, useState } from 'react';
import { Tabs } from 'antd';
import { useWorkbenchPanel } from '../hooks/useWorkbenchPanel.js';

export default function WorkbenchPanelRenderer({ panel }) {
  const { activeExplorerViewId, onActiveViewChange } = useWorkbenchPanel(panel.id);
  const items = useMemo(() => (
    panel.views
      .filter((view) => !view.visibleFor || view.visibleFor.includes(activeExplorerViewId))
      .map(({ component: View, id, label }) => ({
        key: id,
        label: typeof label === 'function' ? label(activeExplorerViewId) : label,
        children: <View />,
      }))
  ), [activeExplorerViewId, panel.views]);
  const defaultActiveKey = panel.defaultActiveView ?? items[0]?.key;
  const [activeKey, setActiveKey] = useState(defaultActiveKey);

  useEffect(() => {
    if (!items.some((item) => item.key === activeKey)) {
      setActiveKey(defaultActiveKey);
    }
  }, [activeKey, defaultActiveKey, items]);

  const handleChange = (key) => {
    setActiveKey(key);
    onActiveViewChange?.(key);
  };

  return (
    <Tabs
      activeKey={activeKey}
      className={`workbench-panel workbench-panel--${panel.id}`}
      onChange={handleChange}
      items={items}
    />
  );
}
