import { CloseOutlined, DownOutlined, LeftOutlined, UpOutlined } from '@ant-design/icons';
import { Button, Splitter } from 'antd';
import { useEffect } from 'react';
import { useBottomPanel } from '../hooks/useBottomPanel.js';
import { useInspectorPanel } from '../hooks/useInspectorPanel.js';
import { useEnsureProjectModel } from '../hooks/useEnsureProjectModel.js';
import { useProjects } from '../hooks/useProjects.js';
import { useUiStore } from '../stores/useUiStore.js';
import { workbenchPanelsConfig } from './workbenchPanels.config.js';
import WorkbenchPanelRenderer from './WorkbenchPanelRenderer.jsx';

export default function WorkbenchLayout() {
  const bottomPanelState = useBottomPanel(false);
  const inspectorPanelState = useInspectorPanel(true);
  const selectedElementId = useUiStore((state) => state.selectedElementId);
  const { currentProject } = useProjects();
  useEnsureProjectModel(currentProject?.id ?? 'project-vehicle');

  // Clicking an element (in the diagram or elsewhere) always brings the
  // properties panel back — it only stays hidden once the user explicitly
  // closes it, and the next selection re-opens it, same as VS Code's panels.
  useEffect(() => {
    if (selectedElementId) inspectorPanelState.open();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedElementId]);

  const [explorerPanel, workspacePanel, inspectorPanel, bottomPanel] = workbenchPanelsConfig.panels;

  return (
    <Splitter className="workbench-layout">
      <Splitter.Panel
        defaultSize={explorerPanel.defaultSize}
        min={explorerPanel.min}
        max={explorerPanel.max}
        className="workbench-layout__explorer"
      >
        <WorkbenchPanelRenderer panel={explorerPanel} />
      </Splitter.Panel>

      <Splitter.Panel min={workspacePanel.min + inspectorPanel.min}>
        <div className="workbench-main-stack">
          <Splitter layout="vertical" className="workbench-main-splitter">
            <Splitter.Panel min={360}>
              <Splitter className="workbench-main-content">
                <Splitter.Panel
                  min={workspacePanel.min}
                  className="workbench-layout__workspace"
                >
                  <div className="workbench-layout__workspace-inner">
                    <WorkbenchPanelRenderer panel={workspacePanel} />
                    {!inspectorPanelState.isOpen && (
                      <InspectorPanelDock onOpen={inspectorPanelState.open} />
                    )}
                  </div>
                </Splitter.Panel>

                {inspectorPanelState.isOpen && (
                  <Splitter.Panel
                    defaultSize={inspectorPanel.defaultSize}
                    min={inspectorPanel.min}
                    max={inspectorPanel.max}
                    className="workbench-layout__inspector"
                  >
                    <InspectorPanelFrame panel={inspectorPanel} onClose={inspectorPanelState.close} />
                  </Splitter.Panel>
                )}
              </Splitter>
            </Splitter.Panel>

            {bottomPanelState.isOpen && (
              <Splitter.Panel
                defaultSize={bottomPanel.defaultSize}
                min={bottomPanel.min}
                max={bottomPanel.max}
                className="workbench-layout__bottom"
              >
                <BottomPanelFrame panel={bottomPanel} onClose={bottomPanelState.close} />
              </Splitter.Panel>
            )}
          </Splitter>

          {!bottomPanelState.isOpen && (
            <BottomPanelDock onOpen={bottomPanelState.open} />
          )}
        </div>
      </Splitter.Panel>
    </Splitter>
  );
}

function InspectorPanelFrame({ onClose, panel }) {
  return (
    <div className="inspector-panel-frame">
      <div className="inspector-panel-header">
        <span className="inspector-panel-title">Properties</span>
        <Button
          aria-label="Close properties panel"
          className="inspector-panel-close"
          icon={<CloseOutlined />}
          size="small"
          type="text"
          onClick={onClose}
        />
      </div>
      <div className="inspector-panel-body">
        <WorkbenchPanelRenderer panel={panel} />
      </div>
    </div>
  );
}

function InspectorPanelDock({ onOpen }) {
  return (
    <div className="inspector-panel-dock">
      <Button
        aria-label="Open properties panel"
        className="inspector-panel-dock-button"
        icon={<LeftOutlined />}
        size="small"
        type="text"
        onClick={onOpen}
      >
        Properties
      </Button>
    </div>
  );
}

function BottomPanelFrame({ onClose, panel }) {
  return (
    <div className="bottom-panel-frame">
      <BottomPanelHandle
        ariaLabel="Close output panel"
        icon={<DownOutlined />}
        mode="open"
        onClick={onClose}
      />
      <WorkbenchPanelRenderer panel={panel} />
    </div>
  );
}

function BottomPanelDock({ onOpen }) {
  return (
    <div className="bottom-panel-dock">
      <BottomPanelHandle
        ariaLabel="Open output panel"
        icon={<UpOutlined />}
        mode="closed"
        onClick={onOpen}
      />
    </div>
  );
}

function BottomPanelHandle({ ariaLabel, icon, mode, onClick }) {
  return (
    <div className={`bottom-panel-handle bottom-panel-handle--${mode}`}>
      <Button
        className="bottom-panel-handle-button"
        type="text"
        size="small"
        icon={icon}
        aria-label={ariaLabel}
        onClick={onClick}
      />
    </div>
  );
}
