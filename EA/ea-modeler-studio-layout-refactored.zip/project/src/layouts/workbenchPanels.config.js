import TypesView from '../views/TypesView.jsx';
import QosExplorerView from '../views/QosExplorerView.jsx';
import DomainsView from '../views/DomainsView.jsx';
import DomainParticipantsView from '../views/DomainParticipantsView.jsx';
import DiagramView from '../views/DiagramView.jsx';
import IdlView from '../views/IdlView.jsx';
import ExplorerJsonView from '../views/ExplorerJsonView.jsx';
import ConsoleView from '../views/ConsoleView.jsx';
import OutputView from '../views/OutputView.jsx';
import PropertiesView from '../views/PropertiesView.jsx';
import { getExplorerJsonLabel } from '../model/explorerDocuments.js';

export const workbenchPanelsConfig = {
  panels: [
    {
      id: 'explorer',
      defaultSize: 300,
      min: 240,
      max: 480,
      defaultActiveView: 'types',
      views: [
        { id: 'types', label: 'Types', component: TypesView },
        { id: 'qos', label: 'QoS', component: QosExplorerView },
        { id: 'domains', label: 'Domains', component: DomainsView },
        { id: 'participants', label: 'Participants', component: DomainParticipantsView },
      ],
    },
    {
      id: 'workspace',
      min: 520,
      defaultActiveView: 'diagram',
      views: [
        { id: 'diagram', label: 'Diagram', component: DiagramView },
        { id: 'idl', label: 'IDL', component: IdlView, visibleFor: ['types'] },
        { id: 'explorerJson', label: getExplorerJsonLabel, component: ExplorerJsonView },
      ],
    },
    {
      id: 'inspector',
      defaultSize: 390,
      min: 320,
      max: 560,
      defaultActiveView: 'properties',
      views: [
        { id: 'properties', label: 'Properties', component: PropertiesView },
      ],
    },
    {
      id: 'bottom',
      defaultSize: 260,
      min: 160,
      max: 420,
      defaultActiveView: 'console',
      views: [
        { id: 'console', label: 'Console', component: ConsoleView },
        { id: 'output', label: 'Output', component: OutputView },
      ],
    },
  ],
};
