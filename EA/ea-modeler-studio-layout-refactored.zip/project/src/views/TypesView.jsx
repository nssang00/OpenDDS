import ElementTreeView from '../components/ElementTreeView.jsx';
import { useElementTree } from '../hooks/useElementTree.js';

const TYPE_EXPLORER_TYPES = [
  'Module',
  'Struct',
  'Union',
  'Enum',
  'Bitmask',
  'Typedef',
  'Annotation',
  'Const',
];

export default function TypesView() {
  const { filterPlaceholder, filterText, treeData, selectedKeys, hasModel, selectElement, setFilterText } = useElementTree({
    filterPlaceholder: 'Filter types',
    types: TYPE_EXPLORER_TYPES,
  });

  return (
    <ElementTreeView
      filterPlaceholder={filterPlaceholder}
      filterText={filterText}
      hasModel={hasModel}
      onFilterTextChange={setFilterText}
      selectedKeys={selectedKeys}
      treeData={treeData}
      onSelect={selectElement}
    />
  );
}
