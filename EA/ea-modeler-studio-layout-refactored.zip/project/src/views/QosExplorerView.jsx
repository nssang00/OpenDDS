import ElementTreeView from '../components/ElementTreeView.jsx';
import { useElementTree } from '../hooks/useElementTree.js';

export default function QosExplorerView() {
  const { filterPlaceholder, filterText, treeData, selectedKeys, hasModel, selectElement, setFilterText } = useElementTree({
    filterPlaceholder: 'Filter QoS',
    types: ['QosProfile', 'QosPolicy'],
  });

  return (
    <ElementTreeView
      filterPlaceholder={filterPlaceholder}
      filterText={filterText}
      hasModel={hasModel}
      onFilterTextChange={setFilterText}
      selectedKeys={selectedKeys}
      treeData={treeData}
      onSelect={selectElement}
    />
  );
}
