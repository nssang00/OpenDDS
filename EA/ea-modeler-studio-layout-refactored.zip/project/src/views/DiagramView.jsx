import ModelDiagram from '../components/ModelDiagram.jsx';
import { useDiagramModel } from '../hooks/useDiagramModel.js';

export default function DiagramView() {
  const { model, nodes, edges, hasModel, onNodesChange, onEdgesChange, selectElement, appendElementPath, removeElementPath, updateElement, updateElementPath, updateQosProperty } = useDiagramModel();

  return (
    <ModelDiagram
      edges={edges}
      hasModel={hasModel}
      model={model}
      nodes={nodes}
      onNodesChange={onNodesChange}
      onEdgesChange={onEdgesChange}
      onSelectElement={selectElement}
      onAppendElementPath={appendElementPath}
      onRemoveElementPath={removeElementPath}
      onUpdateElement={updateElement}
      onUpdateElementPath={updateElementPath}
      onUpdateQosProperty={updateQosProperty}
    />
  );
}
