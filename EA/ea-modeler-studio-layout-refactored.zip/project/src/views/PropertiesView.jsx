import MemberEditor from '../components/MemberEditor.jsx';
import PropertyForm from '../components/PropertyForm.jsx';
import { usePropertyPanel } from '../hooks/usePropertyPanel.js';

export default function PropertiesView() {
  const {
    element,
    model,
    sections,
    formProperties,
    editorProperties,
    hasMembers,
    members,
    updateElement,
    appendElementPath,
    removeElementPath,
    updateElementPath,
    updateProperty,
    qosFields,
    qosSections,
    updateSelectedQosProperty,
  } = usePropertyPanel();

  return (
    <PropertyForm
      editorProperties={editorProperties}
      element={element}
      model={model}
      sections={sections}
      formProperties={formProperties}
      hasMembers={hasMembers}
      memberEditor={<MemberEditor element={element} members={members} />}
      onAppendElementPath={appendElementPath}
      onUpdateElement={updateElement}
      onRemoveElementPath={removeElementPath}
      onUpdateElementPath={updateElementPath}
      onUpdateProperty={updateProperty}
      onUpdateQosProperty={updateSelectedQosProperty}
      qosFields={qosFields}
      qosSections={qosSections}
    />
  );
}
