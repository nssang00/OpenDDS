import { Empty } from 'antd';
import TextEditor from '../components/TextEditor.jsx';
import { useExplorerJsonDocument } from '../hooks/useExplorerJsonDocument.js';

export default function ExplorerJsonView() {
  const { emptyDescription, hasDocument, text } = useExplorerJsonDocument();

  if (!hasDocument) {
    return (
      <div className="workbench-view workbench-view--muted">
        <Empty description={emptyDescription} />
      </div>
    );
  }

  return (
    <div className="workbench-view workbench-view--muted">
      <TextEditor value={text} onChange={() => {}} />
    </div>
  );
}
