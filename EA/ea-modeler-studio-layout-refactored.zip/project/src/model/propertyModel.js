import { findAncestorByType } from './modelSelectors.js';
import { buildQosSections } from './diagram/sections.js';
import { sectionsFor } from './elementSectionSchema.js';
import { readPath } from '../utils/objectPath.js';
import { qosFieldMetadata } from '../utils/qosSchemaCatalog.js';

export function buildElementPropertyGroups(model, element) {
  const sections = sectionsFor(element?.type);
  const hasBasicSection = sections.includes('basic');
  const hasMembersSection = sections.includes('members');
  const hasQosSection = sections.includes('qos');
  const editableProperties = Object.entries(element?.properties || {})
    .filter(([key, value]) => key !== 'members' && !Array.isArray(value) && typeof value !== 'object');

  return {
    sections,
    editorProperties: hasQosSection ? [] : Object.entries(element?.properties || {}).filter(([key]) => key === 'qosJson'),
    formProperties: hasBasicSection ? editableProperties : [],
    hasMembers: hasMembersSection && Array.isArray(element?.properties?.members),
    members: element?.properties?.members,
    qosFields: hasQosSection ? buildQosFields(model, element) : [],
    qosSections: hasQosSection ? buildQosEditorSections(model, element) : [],
  };
}

function buildQosEditorSections(model, element) {
  const profile = findAncestorByType(model, element, 'QosProfile');
  if (!profile) return [];
  return buildQosSections(profile, model?.qosSchema);
}

function buildQosFields(model, element) {
  const profile = findAncestorByType(model, element, 'QosProfile');
  if (!profile) return [];
  const policyPath = element.properties?.policyPath ?? '';
  const source = policyPath ? readPath(profile.properties, policyPath) : qosSections(profile.properties);
  return flattenFields(source, policyPath, model?.qosSchema);
}

function qosSections(properties) {
  return Object.fromEntries(Object.entries(properties).filter(([key, value]) => key.endsWith('_qos') && value && typeof value === 'object'));
}

function flattenFields(value, prefix = '', qosSchema) {
  if (!value || typeof value !== 'object') return prefix ? [{ path: prefix, value }] : [];
  if (Array.isArray(value)) return [{ path: prefix, value }];
  return Object.entries(value).flatMap(([key, child]) => {
    const path = prefix ? `${prefix}.${key}` : key;
    if (child && typeof child === 'object') return flattenFields(child, path, qosSchema);
    return [{ path, value: child, ...qosFieldMetadataForPath(qosSchema, path) }];
  });
}

function qosFieldMetadataForPath(qosSchema, path) {
  const [sectionKey, ...rest] = path.split('.');
  if (!sectionKey || !rest.length) return {};
  return qosFieldMetadata(qosSchema, sectionKey, rest.join('.'));
}
