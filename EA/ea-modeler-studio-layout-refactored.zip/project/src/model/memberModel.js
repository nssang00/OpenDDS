export const PRIMITIVE_TYPE_KINDS = [
  'int8',
  'int16',
  'int32',
  'int64',
  'uint8',
  'uint16',
  'uint32',
  'uint64',
  'float32',
  'float64',
  'float128',
  'byte',
  'boolean',
  'char8',
  'char16',
];

export const STRING_TYPE_KINDS = ['string', 'wstring'];
export const COMPLEX_TYPE_KINDS = ['struct', 'enum', 'union', 'bitmask', 'bitset', 'typedef'];
export const CONTAINER_TYPE_KINDS = ['sequence', 'array'];

export const TYPE_KIND_OPTIONS = [
  ...PRIMITIVE_TYPE_KINDS,
  ...STRING_TYPE_KINDS,
  ...COMPLEX_TYPE_KINDS,
  ...CONTAINER_TYPE_KINDS,
].map((value) => ({ label: value, value }));

export function needsElementType(kind) {
  return ['array', 'sequence', ...COMPLEX_TYPE_KINDS].includes(kind);
}

export function needsStringMaxLength(kind) {
  return STRING_TYPE_KINDS.includes(kind);
}

export function needsSequenceMaxLength(kind) {
  return kind === 'sequence';
}

export function needsArrayDimensions(kind) {
  return kind === 'array';
}

export function needsMapTypes(kind) {
  return kind === 'map';
}

export function normalizeMemberKind(member, kind, defaultType = '') {
  const nextMember = {
    name: member.name,
    kind,
    ...(member.annotations ? { annotations: member.annotations } : {}),
  };

  if (kind === 'string' || kind === 'wstring') {
    nextMember.string_max_length = member.string_max_length ?? 255;
  }

  if (kind === 'array') {
    nextMember.type = defaultType || 'float32';
    nextMember.array_dimensions = member.array_dimensions || [4];
  }

  if (kind === 'sequence') {
    nextMember.type = defaultType || 'float32';
    nextMember.sequence_max_length = member.sequence_max_length ?? 32;
  }

  if (COMPLEX_TYPE_KINDS.includes(kind)) {
    nextMember.type = defaultType;
  }

  if (kind === 'map') {
    nextMember.key_type = member.key_type || 'string';
    nextMember.value_type = defaultType || 'string';
    nextMember.map_max_length = member.map_max_length;
  }

  return nextMember;
}

export function parseArrayDimensions(value) {
  return value
    .split(',')
    .map((item) => parseDimension(item.trim()))
    .filter((item) => item !== '');
}

function parseDimension(value) {
  if (!value) return '';
  const numberValue = Number(value);
  return Number.isNaN(numberValue) ? value : numberValue;
}

export function annotationValue(member, key) {
  return Boolean(member.annotations?.[key]);
}

export function patchAnnotation(member, key, value) {
  const annotations = { ...(member.annotations ?? {}) };

  if (value) annotations[key] = true;
  else delete annotations[key];

  return Object.keys(annotations).length ? { annotations } : { annotations: undefined };
}
