import { createQosPolicyValue, qosFieldMetadata, qosSectionCatalog } from '../../utils/qosSchemaCatalog.js';
import { buildJsonTreeRows, buildQosTreeRows } from './treeRows.js';

export function buildQosSections(profile, qosSchema) {
  const catalog = qosSchema ? qosSectionCatalog(qosSchema) : defaultQosSections();
  return catalog.map(({ key, label, policies }) => {
    const value = profile.properties?.[key];
    const activePolicies = qosActivePolicyKeys(value);
    return {
      key,
      label,
      count: activePolicies.size,
      tree: buildQosTreeRows(value, profile.id, key, '', (path) => qosFieldMetadata(qosSchema, key, path)),
      availablePolicies: Array.isArray(value) ? [] : policies
        .filter((policy) => !activePolicies.has(policy.key))
        .map((policy) => ({
          key: policy.key,
          label: policy.label,
          value: createQosPolicyValue(qosSchema, key, policy.key),
        })),
    };
  });
}

export function listSection(label, items, elementId, rootPath, summary, action, options = {}) {
  return {
    key: rootPath,
    label,
    count: items.length,
    action,
    items: items.map((item, index) => ({
      key: `${rootPath}.${index}`,
      elementId,
      title: summary(item),
      removable: true,
      removePath: rootPath,
      removeIndex: index,
      actions: nestedItemActions(rootPath, item, index, options),
      tree: buildJsonTreeRows(item, elementId, `${rootPath}.${index}`),
    })),
  };
}

export function treeSection(label, value, elementId, rootPath) {
  return {
    key: rootPath,
    label,
    tree: buildJsonTreeRows(value, elementId, rootPath),
  };
}

export function registerTypeSection(items, elementId) {
  return listSection(
    'register_types',
    items,
    elementId,
    'register_types',
    registerTypeSummary,
    addAction('Register Type', 'register_types', () => ({ name: nextName(items, 'NewType'), type_ref: 'TypeRef' })),
  );
}

export function topicSection(items, registerTypes, elementId) {
  return listSection(
    'topics',
    items,
    elementId,
    'topics',
    topicSummary,
    addAction('Topic', 'topics', () => ({ name: nextName(items, 'NewTopic'), register_type_ref: registerTypes[0]?.name ?? '' })),
  );
}

export function publisherSection(items, topics, elementId) {
  return listSection(
    'publishers',
    items,
    elementId,
    'publishers',
    publisherSummary,
    addAction('Publisher', 'publishers', () => ({ name: nextName(items, 'NewPublisher'), data_writers: [] })),
    { topicName: topics[0]?.name ?? '' },
  );
}

export function subscriberSection(items, topics, elementId) {
  return listSection(
    'subscribers',
    items,
    elementId,
    'subscribers',
    subscriberSummary,
    addAction('Subscriber', 'subscribers', () => ({ name: nextName(items, 'NewSubscriber'), data_readers: [] })),
    { topicName: topics[0]?.name ?? '' },
  );
}

export function registerTypeSummary(item) { return `${item.name ?? '(unnamed)'} -> ${item.type_ref ?? '-'}`; }
export function topicSummary(item) { return `${item.name ?? '(unnamed)'} : ${item.register_type_ref ?? '-'}`; }
export function publisherSummary(item) { return `${item.name ?? '(unnamed)'} (${item.data_writers?.length ?? 0} writers)`; }
export function subscriberSummary(item) { return `${item.name ?? '(unnamed)'} (${item.data_readers?.length ?? 0} readers)`; }
export function addAction(label, path, createValue) { return { label, path, value: createValue() }; }

export function nextName(items, baseName) {
  const names = new Set(items.map((item) => item.name));
  if (!names.has(baseName)) return baseName;
  let index = 2;
  while (names.has(`${baseName}${index}`)) index += 1;
  return `${baseName}${index}`;
}

function defaultQosSections() {
  return ['domain_participant_qos', 'topic_qos', 'publisher_qos', 'subscriber_qos', 'datawriter_qos', 'datareader_qos']
    .map((key) => ({ key, label: key.replace(/_qos$/, '').replace(/_/g, ' '), policies: [] }));
}

function qosActivePolicyKeys(value) {
  if (Array.isArray(value)) {
    return new Set(value.flatMap((item) => Object.keys(item ?? {})).filter((key) => key !== 'name' && key !== 'topic_filter' && key !== 'base_name'));
  }
  if (value && typeof value === 'object') {
    return new Set(Object.keys(value).filter((key) => key !== 'base_name'));
  }
  return new Set();
}

function nestedItemActions(rootPath, item, index, options = {}) {
  if (rootPath === 'publishers') {
    return [addAction('DataWriter', `${rootPath}.${index}.data_writers`, () => ({ name: nextName(item.data_writers ?? [], 'NewWriter'), topic_ref: options.topicName ?? '' }))];
  }
  if (rootPath === 'subscribers') {
    return [addAction('DataReader', `${rootPath}.${index}.data_readers`, () => ({ name: nextName(item.data_readers ?? [], 'NewReader'), topic_ref: options.topicName ?? '' }))];
  }
  return [];
}
