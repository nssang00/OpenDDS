export function buildEntityDiagram(items, config, context = {}) {
  return {
    nodes: items.map((item) => entityNode(item, config, context)),
    edges: config.getEdges?.(items, context) ?? [],
  };
}

function entityNode(item, config, context) {
  const sections = config.getSections(item, context);
  const id = config.getId?.(item, context) ?? item.id;
  return {
    id,
    nodeType: config.nodeType,
    position: config.getPosition?.(item, context) ?? { x: 60, y: 80 },
    width: config.width,
    height: config.getHeight(item, sections, context),
    data: {
      element: item,
      label: config.getLabel(item, context),
      type: config.getType(item, context),
      variant: config.variant,
      selectId: config.getSelectId?.(item, context) ?? id,
      sections,
      ...config.getMeta?.(item, context),
    },
  };
}
