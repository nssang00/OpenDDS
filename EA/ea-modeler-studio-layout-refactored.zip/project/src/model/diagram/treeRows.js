export function buildJsonTreeRows(value, elementId, path) {
  return buildTreeRows(value, {
    createBranch: ({ child, childPath, index, key }) => ({
      key: childPath,
      label: child?.name ?? key ?? `[${index}]`,
    }),
    createLeaf: ({ child, childPath, key }) => ({
      key: childPath,
      label: key,
      value: child,
      editable: true,
      elementId,
      path: childPath,
    }),
    path,
  });
}

export function buildQosTreeRows(value, profileId, entityKey, path = '', metadataForPath = () => ({})) {
  return buildTreeRows(value, {
    createBranch: ({ child, childPath, index, key }) => ({
      key: childPath,
      label: child?.name ?? key ?? `[${index}]`,
    }),
    createLeaf: ({ child, childPath, key }) => ({
      key: childPath,
      label: key,
      value: child,
      editable: true,
      profileId,
      entityKey,
      path: childPath,
      ...metadataForPath(childPath),
    }),
    metadataForPath,
    path,
    separator: '.',
    skipKeys: new Set(['name', 'topic_filter']),
  });
}

function buildTreeRows(value, options) {
  const { createBranch, createLeaf, metadataForPath, path, separator = '.', skipKeys = new Set() } = options;

  if (Array.isArray(value)) {
    return value.map((item, index) => {
      const childPath = appendPath(path, index, separator);
      return {
        ...createBranch({ child: item, childPath, index }),
        children: buildTreeRows(item, { ...options, metadataForPath, path: childPath }),
      };
    });
  }

  if (value && typeof value === 'object') {
    return Object.entries(value)
      .filter(([key]) => !skipKeys.has(key))
      .map(([key, child]) => {
        const childPath = appendPath(path, key, separator);
        if (child && typeof child === 'object') {
          return {
            ...createBranch({ child, childPath, key }),
            children: buildTreeRows(child, { ...options, metadataForPath, path: childPath }),
          };
        }
        return createLeaf({ child, childPath, key });
      });
  }

  return [];
}

function appendPath(path, key, separator) {
  return path ? `${path}${separator}${key}` : String(key);
}
