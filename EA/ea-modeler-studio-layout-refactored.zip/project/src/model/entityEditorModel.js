import { getElements } from './modelSelectors.js';

export function buildTypeRefOptions(model) {
  return getElements(model)
    .filter((element) => ['Struct', 'Enum', 'Union', 'Bitmask', 'Typedef'].includes(element.type))
    .map((element) => ({
      label: qualifiedName(model, element),
      value: qualifiedName(model, element),
    }))
    .sort((a, b) => a.label.localeCompare(b.label));
}

export function buildTopicRefOptions(model) {
  return getElements(model)
    .filter((element) => element.type === 'Domain')
    .flatMap((domain) => (domain.properties?.topics ?? []).map((topic) => ({
      label: `${domain.name} / ${topic.name}`,
      value: topic.name,
    })))
    .sort((a, b) => a.label.localeCompare(b.label));
}

export function registerTypeOptions(domain) {
  return (domain?.properties?.register_types ?? [])
    .filter((item) => item.name)
    .map((item) => ({ label: item.name, value: item.name }));
}

export function nextNamedItem(items, baseName) {
  const names = new Set((items ?? []).map((item) => item.name));
  if (!names.has(baseName)) return baseName;
  let index = 2;
  while (names.has(`${baseName}${index}`)) index += 1;
  return `${baseName}${index}`;
}

function qualifiedName(model, element) {
  const parts = [element.name];
  let parent = model?.elementsById?.[element.parentId];

  while (parent?.type === 'Module') {
    parts.unshift(parent.name);
    parent = model?.elementsById?.[parent.parentId];
  }

  return parts.join('::');
}
