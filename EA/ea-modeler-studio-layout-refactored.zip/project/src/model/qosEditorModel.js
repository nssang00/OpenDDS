const QOS_ENTITY_ORDER = [
  ['topic_qos', 'Topic'],
  ['datawriter_qos', 'Writer'],
  ['datareader_qos', 'Reader'],
  ['publisher_qos', 'Publisher'],
  ['subscriber_qos', 'Subscriber'],
  ['domain_participant_qos', 'Participant'],
];

export function buildQosTabsFromFields(fields) {
  const tabsByKey = new Map(QOS_ENTITY_ORDER.map(([key, label]) => [key, { key, label, policies: [] }]));

  fields.forEach((field) => {
    const [entityKey, policyKey, ...fieldPathParts] = field.path.split('.');
    if (!entityKey || !policyKey) return;

    const tab = tabsByKey.get(entityKey) ?? { key: entityKey, label: labelFromKey(entityKey), policies: [] };
    if (!tabsByKey.has(entityKey)) tabsByKey.set(entityKey, tab);

    let policy = tab.policies.find((item) => item.key === policyKey);
    if (!policy) {
      policy = { key: policyKey, label: labelFromKey(policyKey), fields: [] };
      tab.policies.push(policy);
    }

    policy.fields.push({
      ...field,
      label: fieldPathParts.join('.') || policyKey,
    });
  });

  return Array.from(tabsByKey.values()).filter((tab) => tab.policies.length > 0);
}

export function buildQosTabsFromSections(sections) {
  return sections.map((section) => ({
    key: section.key,
    label: section.label,
    actions: section.availablePolicies ?? [],
    policies: (section.tree ?? []).map((policy) => ({
      key: policy.key,
      label: policy.label ?? labelFromKey(policy.key),
      fields: flattenTreeFields(policy.children ?? [], policy.key),
    })),
  }));
}

export function labelFromKey(key) {
  return String(key ?? '')
    .replace(/_qos$/, '')
    .replace(/_/g, ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function flattenTreeFields(rows, policyKey) {
  return rows.flatMap((row) => {
    if (row.children) return flattenTreeFields(row.children, policyKey);
    return {
      ...row,
      label: relativePolicyPath(row.path ?? row.key, policyKey),
    };
  });
}

function relativePolicyPath(path, policyKey) {
  return String(path ?? '').replace(new RegExp(`^${escapeRegExp(policyKey)}\\.?`), '') || policyKey;
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}
