import { getElements } from './modelSelectors.js';
import { PRIMITIVE_TYPE_KINDS, STRING_TYPE_KINDS } from './memberModel.js';

const REFERENCE_TYPE_KIND_BY_ELEMENT_TYPE = {
  Struct: 'struct',
  Enum: 'enum',
  Union: 'union',
  Bitmask: 'bitmask',
  Bitset: 'bitset',
  Typedef: 'typedef',
};

export function buildMemberTypeOptions(model, kind) {
  if (isComplexKind(kind)) {
    return buildReferenceOptions(model).filter((option) => option.kind === kind);
  }

  if (kind === 'array' || kind === 'sequence') {
    return [
      ...primitiveTypeOptions(),
      ...stringTypeOptions(),
      ...buildReferenceOptions(model),
    ];
  }

  if (kind === 'map') {
    return [
      ...primitiveTypeOptions(),
      ...stringTypeOptions(),
      ...buildReferenceOptions(model),
    ];
  }

  return [];
}

export function firstTypeOptionValue(model, kind) {
  return buildMemberTypeOptions(model, kind)[0]?.value ?? '';
}

function buildReferenceOptions(model) {
  return getElements(model)
    .map((element) => {
      const kind = REFERENCE_TYPE_KIND_BY_ELEMENT_TYPE[element.type];
      if (!kind) return null;

      const value = qualifiedTypeName(model, element);
      return {
        label: `${element.type} / ${value}`,
        value,
        kind,
      };
    })
    .filter(Boolean)
    .sort((a, b) => a.label.localeCompare(b.label));
}

function primitiveTypeOptions() {
  return PRIMITIVE_TYPE_KINDS.map((value) => ({ label: value, value, kind: 'primitive' }));
}

function stringTypeOptions() {
  return STRING_TYPE_KINDS.map((value) => ({ label: value, value, kind: 'string' }));
}

function qualifiedTypeName(model, element) {
  const parts = [element.name];
  let parent = model?.elementsById?.[element.parentId];

  while (parent?.type === 'Module') {
    parts.unshift(parent.name);
    parent = model?.elementsById?.[parent.parentId];
  }

  return parts.join('::');
}

function isComplexKind(kind) {
  return ['struct', 'enum', 'union', 'bitmask', 'bitset', 'typedef'].includes(kind);
}
