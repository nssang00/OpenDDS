export function getElements(model) {
  return Object.values(model?.elementsById ?? {});
}

export function getElement(model, elementId) {
  return elementId && model ? model.elementsById[elementId] : null;
}

export function getElementsByType(model, type) {
  return getElements(model).filter((element) => element.type === type);
}

export function findAncestorByType(model, element, type) {
  let current = element;
  while (current) {
    if (current.type === type) return current;
    current = model?.elementsById[current.parentId];
  }
  return null;
}

export function simpleName(value) {
  return value?.split('::').pop();
}

export function getTypeDiagramScope(model, selectedElementId) {
  const selectedElement = getElement(model, selectedElementId);
  const scopeModule = selectedElement?.type === 'Module'
    ? selectedElement
    : findAncestorByType(model, selectedElement, 'Module');
  const scopeParentId = scopeModule?.id ?? null;
  const items = getElements(model).filter((element) => (
    isTypeExplorerElement(element) && (element.parentId ?? null) === scopeParentId
  ));

  return {
    scopeModule,
    scopeParentId,
    items,
  };
}

export function isTypeExplorerElement(element) {
  return ['Module', 'Struct', 'Union', 'Enum', 'Bitmask', 'Typedef', 'Annotation', 'Const'].includes(element?.type);
}

export function buildTreeData(elementsById, options = {}) {
  if (!elementsById) return [];

  const { filterText, types } = options;
  const typeSet = types ? new Set(types) : null;
  const sourceElements = Object.values(elementsById);
  const visibleElements = typeSet
    ? sourceElements.filter((element) => typeSet.has(element.type))
    : sourceElements;
  const visibleIds = new Set(visibleElements.map((element) => element.id));
  const childrenMap = new Map();

  visibleElements.forEach((element) => {
    const parentId = visibleIds.has(element.parentId) ? element.parentId : '__root__';
    if (!childrenMap.has(parentId)) childrenMap.set(parentId, []);
    childrenMap.get(parentId).push(element);
  });

  function buildNode(element) {
    const children = childrenMap.get(element.id) ?? [];
    return {
      key: element.id,
      title: element.name,
      children: children.map(buildNode),
    };
  }

  const treeData = (childrenMap.get('__root__') ?? []).map(buildNode);
  return filterTreeData(treeData, filterText);
}

function filterTreeData(treeData, filterText) {
  const normalizedFilter = filterText?.trim().toLowerCase();
  if (!normalizedFilter) return treeData;

  return treeData
    .map((node) => filterTreeNode(node, normalizedFilter))
    .filter(Boolean);
}

function filterTreeNode(node, normalizedFilter) {
  const children = (node.children ?? [])
    .map((child) => filterTreeNode(child, normalizedFilter))
    .filter(Boolean);
  const matches = String(node.title).toLowerCase().includes(normalizedFilter);

  if (!matches && children.length === 0) return null;

  return {
    ...node,
    children,
  };
}

export function getModelSummary(model) {
  const elements = getElements(model);
  return {
    topics: elements.filter((element) => element.type === 'Topic').length,
    structs: elements.filter((element) => element.type === 'Struct').length,
    qosProfiles: elements.filter((element) => element.type === 'QosProfile').length,
  };
}
