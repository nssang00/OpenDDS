export const ELEMENT_SECTIONS = {
  Struct: ['basic', 'members'],
  QosProfile: ['qos'],
  QosPolicy: ['qos'],
  QosValue: ['qos'],
  Domain: ['domain'],
  DomainParticipant: ['participant'],
};

export function sectionsFor(elementType) {
  return ELEMENT_SECTIONS[elementType] ?? ['basic'];
}
