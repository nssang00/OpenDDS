const EXPLORER_JSON_DOCUMENTS = {
  types: {
    label: 'Types JSON',
    emptyDescription: 'No Types JSON in this model.',
    read: (model) => model?.ddsJson?.types,
  },
  qos: {
    label: 'QoS JSON',
    emptyDescription: 'No QoS JSON in this model.',
    read: (model) => model?.ddsJson?.qos,
  },
  domains: {
    label: 'Domains JSON',
    emptyDescription: 'No Domains JSON in this model.',
    read: (model) => model?.ddsJson?.domains,
  },
  participants: {
    label: 'Participants JSON',
    emptyDescription: 'No Participants JSON in this model.',
    read: (model) => model?.ddsJson?.domainParticipants,
  },
};

export function getExplorerJsonDocument(model, explorerViewId) {
  const config = EXPLORER_JSON_DOCUMENTS[explorerViewId] ?? EXPLORER_JSON_DOCUMENTS.types;
  const value = config.read(model);

  return {
    emptyDescription: config.emptyDescription,
    hasDocument: value !== undefined && value !== null,
    label: config.label,
    text: value === undefined || value === null ? '' : JSON.stringify(value, null, 2),
  };
}

export function getExplorerJsonLabel(explorerViewId) {
  return (EXPLORER_JSON_DOCUMENTS[explorerViewId] ?? EXPLORER_JSON_DOCUMENTS.types).label;
}
