// Pure model -> diagram descriptions. XYFlow conversion and UI callbacks belong
// to useDiagramModel/ModelDiagram, not to this module.
import {
  buildQosSections,
  publisherSection,
  registerTypeSection,
  subscriberSection,
  topicSection,
  treeSection,
} from './diagram/sections.js';
import { buildEntityDiagram } from './diagram/entityDiagram.js';
import { getElementsByType, getTypeDiagramScope, simpleName } from './modelSelectors.js';

const builders = {
  types: buildTypeDiagram,
  qos: buildQosDiagram,
  domains: buildDomainDiagram,
  participants: buildParticipantDiagram,
};

export function buildDiagram(model, activeExplorerViewId, selectedElementId) {
  return (builders[activeExplorerViewId] ?? builders.types)(model, selectedElementId);
}

export function buildTypeDiagram(model, selectedElementId) {
  const { items } = getTypeDiagramScope(model, selectedElementId);
  const visibleIds = new Set(items.map((item) => item.id));
  const visibleTypes = items.filter((item) => item.type !== 'Module');
  const edges = [];
  const nodes = [
    ...items.filter((item) => item.type === 'Module').map((item) => moduleNode(item, 60, 80)),
    ...visibleTypes.map((item) => typeNode(item, 60, 80)),
  ];

  visibleTypes.filter((item) => ['Struct', 'Union'].includes(item.type)).forEach((item) => {
    typeReferences(item).forEach(({ name, type }) => {
      const target = findType(model, type);
      if (target && visibleIds.has(target.id)) {
        edges.push(edge(item.id, target.id, name, `qos-edge qos-edge--${variant(target.type)}`));
      }
    });
  });
  return { nodes, edges };
}

export function buildQosDiagram(model, selectedElementId) {
  const profiles = elementsOf(model, 'QosProfile');
  if (!profiles.length) return { nodes: [], edges: [] };

  return buildEntityDiagram(profiles, qosProfileConfig, { qosSchema: model?.qosSchema, selectedElementId });
}

export function buildDomainDiagram(model) {
  return buildEntityDiagram(elementsOf(model, 'Domain'), domainConfig);
}

export function buildParticipantDiagram(model) {
  return buildEntityDiagram(elementsOf(model, 'DomainParticipant'), participantConfig);
}

const qosProfileConfig = {
  nodeType: 'qosNode',
  variant: 'profile',
  width: 380,
  getLabel: (profile) => profile.name,
  getType: () => 'QoS Profile',
  getHeight: (_profile, sections) => Math.min(520, Math.max(170, 104 + sections.length * 46)),
  getSections: (profile, { qosSchema }) => buildQosSections(profile, qosSchema),
  getMeta: (profile) => ({
    baseProfile: profile.properties?.base_name,
  }),
  getEdges: (profiles) => {
    const edges = [];
    profiles.forEach((profile) => {
      const parent = findQosBaseProfile(profiles, profile.properties?.base_name);
      if (parent) edges.push(edge(parent.id, profile.id, 'inherits', 'qos-edge qos-edge--inherits'));
    });
    return edges;
  },
};

const domainConfig = {
  nodeType: 'jsonEntityNode',
  variant: 'domain',
  width: 410,
  getLabel: (domain) => domain.name,
  getType: (domain) => `Domain ID: ${domain.properties?.domain_id ?? '-'}`,
  getHeight: (domain) => {
    const registerTypes = domain.properties?.register_types ?? [];
    const topics = domain.properties?.topics ?? [];
    return Math.min(560, Math.max(190, 116 + registerTypes.length * 34 + topics.length * 40));
  },
  getSections: (domain) => {
    const registerTypes = domain.properties?.register_types ?? [];
    const topics = domain.properties?.topics ?? [];
    return [
      registerTypeSection(registerTypes, domain.id),
      topicSection(topics, registerTypes, domain.id),
    ];
  },
};

const participantConfig = {
  nodeType: 'jsonEntityNode',
  variant: 'participant',
  width: 430,
  getLabel: (participant) => participant.name,
  getType: (participant) => {
    const props = participant.properties ?? {};
    return props.domain_ref ? `Domain: ${props.domain_ref}` : `Domain ID: ${props.domain_id ?? '-'}`;
  },
  getHeight: (_participant, sections) => Math.min(620, Math.max(190, 124 + sections.length * 48)),
  getSections: (participant) => {
    const props = participant.properties ?? {};
    const registerTypes = props.register_types ?? [];
    const topics = props.topics ?? [];
    const sections = [
      registerTypeSection(registerTypes, participant.id),
      topicSection(topics, registerTypes, participant.id),
      publisherSection(props.publishers ?? [], topics, participant.id),
      subscriberSection(props.subscribers ?? [], topics, participant.id),
    ];
    if (props.domain_participant_qos) {
      sections.push(treeSection('domain_participant_qos', props.domain_participant_qos, participant.id, 'domain_participant_qos'));
    }
    return sections;
  },
};

function typeNode(item, x, y) {
  const node = entityNode(item.id, variant(item.type), item.type, item.name, x, y, typeRows(item), item.id);
  return {
    ...node,
    nodeType: 'typeNode',
    data: { ...node.data, stereotype: item.type.toLowerCase() },
  };
}
function moduleNode(item, x, y) {
  return {
    id: item.id,
    nodeType: 'moduleNode',
    position: { x, y },
    width: 230,
    height: 96,
    data: { label: item.name, type: 'Module', variant: 'module', selectId: item.id },
  };
}
function entityNode(id, kind, label, subtitle, x, y, fields, selectId) {
  const visibleFields = fields.filter((item) => item.value !== undefined);
  return { id, nodeType: 'qosNode', position: { x, y }, width: kind === 'library' || kind === 'profile' ? 220 : 310,
    height: Math.max(132, Math.min(360, 76 + visibleFields.length * 29)), data: { label, type: subtitle, variant: kind, selectId, fields: visibleFields } };
}
function edge(source, target, label, className) { return { id: `e-${source}-${target}-${label}`, source, target, label, className }; }
function row(key, value) { return { key, value, editable: false }; }
function elementsOf(model, type) { return getElementsByType(model, type); }
function typeElements(model) { return ['Struct', 'Union', 'Enum', 'Bitmask', 'Typedef', 'Annotation', 'Const'].flatMap((type) => elementsOf(model, type)); }
function variant(type) { return type.toLowerCase(); }
function typeRows(item) {
  if (item.type === 'Enum') return (item.properties?.enumerators ?? []).map((value) => row(value.name ?? String(value), value.value ?? ''));
  if (item.type === 'Bitmask') return (item.properties?.flags ?? item.properties?.values ?? []).map((value) => row(value.name ?? String(value), value.position ?? value.value ?? ''));
  if (item.type === 'Const') return [row('value', item.properties?.value), row('type', typeLabel(item.properties?.type))];
  const members = memberEntries(item);
  if (members.length) return members.map((member) => row(member.name, memberTypeLabel(member)));
  return [row('kind', item.properties?.kind), row('extensibility', item.properties?.annotations?.extensibility)];
}
function typeReferences(item) { return memberEntries(item).map((member) => ({ name: member.name, type: member.type?.name ?? member.type })).filter((item) => item.type); }
function findType(model, name) { return typeElements(model).find((item) => item.name === simpleName(name)); }
function findQosBaseProfile(profiles, baseName) { return profiles.find((profile) => profile.name === simpleName(baseName)); }
function memberEntries(item) {
  const members = item.properties?.members ?? item.properties?.cases ?? [];
  if (Array.isArray(members)) return members;
  return Object.entries(members).map(([name, value]) => ({ name, ...value }));
}
function memberTypeLabel(member) {
  if (member.type) return typeLabel(member.type);
  if (member.kind === 'array') return `${typeLabel(member.type ?? member.element_type ?? 'array')}[${(member.array_dimensions ?? []).join('][')}]`;
  if (member.kind === 'sequence') return `sequence<${typeLabel(member.type ?? member.element_type ?? '')}>`;
  if (member.kind === 'map') return `map<${typeLabel(member.key_type)}, ${typeLabel(member.value_type)}>`;
  return member.kind ?? member.default ?? '';
}
function typeLabel(value) {
  if (!value) return '';
  if (typeof value === 'string') return simpleName(value);
  return simpleName(value.name ?? value.type ?? value.kind);
}
