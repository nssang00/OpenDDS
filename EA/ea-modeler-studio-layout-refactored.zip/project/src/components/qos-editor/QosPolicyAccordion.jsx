import { useMemo, useState } from 'react';
import AccordionRow from '../editor-blocks/AccordionRow.jsx';
import SmartFieldControl from '../shared/SmartFieldControl.jsx';
import { useAccordionKeys } from '../../hooks/useAccordionKeys.js';

export default function QosPolicyAccordion({ onAppend, onChange, policies, actions = [], variant = 'panel' }) {
  const defaultOpenKeys = useMemo(() => {
    return policies.map((policy) => policy.key);
  }, [policies, variant]);
  const { isOpen, toggle } = useAccordionKeys(defaultOpenKeys);
  const [isAdding, setIsAdding] = useState(false);

  if (!policies.length && !actions.length) {
    return <div className="qos-editor-empty">No policies.</div>;
  }

  return (
    <div className={`qos-editor-policies qos-editor-policies--${variant}`}>
      {policies.map((policy) => {
        const open = isOpen(policy.key);
        return (
          <AccordionRow
            body={(
              <div className={`qos-editor-policy-body qos-editor-policy-body--${variant}`}>
                <div className={`qos-editor-fields qos-editor-fields--${variant}`}>
                  {policy.fields.map((field) => (
                    <label className="qos-editor-field" key={field.path ?? field.key} title={field.path ?? field.key}>
                      <span>{field.label}</span>
                      <SmartFieldControl
                        className={`qos-editor-control qos-editor-control--${variant} nodrag`}
                        options={field.options}
                        size={variant === 'diagram' ? 'small' : 'middle'}
                        value={field.value}
                        onChange={(value) => onChange(field, value)}
                      />
                    </label>
                  ))}
                </div>
              </div>
            )}
            caretClassName="qos-editor-policy-caret"
            className={`qos-editor-policy-row qos-editor-policy-row--${variant}`}
            headClassName="qos-editor-policy-head"
            key={policy.key}
            open={open}
            openClassName="qos-editor-policy-row--open"
            onToggle={() => toggle(policy.key)}
          >
              <span className="qos-editor-policy-label">
                <b>{policy.key}</b>
                <em>{policy.label}</em>
              </span>
              <small className="qos-editor-policy-count">{policy.fields.length}</small>
          </AccordionRow>
        );
      })}

      {actions.length > 0 && (
        <div className={`qos-editor-actions qos-editor-actions--${variant}`}>
          {isAdding ? (
            <div className="qos-editor-add-panel">
              <span>Add Policy</span>
              <div>
                {actions.map((action) => (
                  <button
                    className="qos-editor-add-chip nodrag"
                    key={action.key}
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      setIsAdding(false);
                      onAppend?.(action);
                    }}
                    onMouseDown={(event) => event.stopPropagation()}
                  >
                    + {action.key}
                  </button>
                ))}
              </div>
              <button
                className="qos-editor-cancel nodrag"
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  setIsAdding(false);
                }}
                onMouseDown={(event) => event.stopPropagation()}
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              className="qos-editor-add qos-editor-add--full nodrag"
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                setIsAdding(true);
              }}
              onMouseDown={(event) => event.stopPropagation()}
            >
              + Add Policy
            </button>
          )}
        </div>
      )}
    </div>
  );
}
