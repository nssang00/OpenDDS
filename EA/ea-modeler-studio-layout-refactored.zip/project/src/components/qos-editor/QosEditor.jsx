import { useMemo } from 'react';
import { Divider } from 'antd';
import { buildQosTabsFromFields, buildQosTabsFromSections } from '../../model/qosEditorModel.js';
import QosEntitySections from './QosEntitySections.jsx';

export default function QosEditor({
  fields,
  onAppend,
  onFieldChange,
  sections,
  title = 'QoS Properties',
  variant = 'panel',
}) {
  const tabs = useMemo(() => {
    if (sections) return buildQosTabsFromSections(sections);
    return buildQosTabsFromFields(fields ?? []);
  }, [fields, sections]);
  if (!tabs.length) return null;

  return (
    <div className={`qos-editor qos-editor--${variant}`}>
      {variant === 'panel' && <Divider orientation="left">{title}</Divider>}
      <QosEntitySections
        tabs={tabs}
        variant={variant}
        onAppend={onAppend}
        onChange={onFieldChange}
      />
    </div>
  );
}
