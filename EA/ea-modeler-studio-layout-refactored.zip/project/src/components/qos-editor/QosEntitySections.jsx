import { useMemo } from 'react';
import AccordionRow from '../editor-blocks/AccordionRow.jsx';
import QosPolicyAccordion from './QosPolicyAccordion.jsx';
import { useAccordionKeys } from '../../hooks/useAccordionKeys.js';

const ENTITY_COLORS = {
  topic_qos: '#d48806',
  datawriter_qos: '#0958d9',
  datareader_qos: '#c41d7f',
  publisher_qos: '#1677ff',
  subscriber_qos: '#eb2f96',
  domain_participant_qos: '#389e0d',
};

export default function QosEntitySections({ onAppend, onChange, tabs, variant = 'panel' }) {
  const defaultOpenKeys = useMemo(() => {
    const firstWithPolicies = tabs.find((tab) => tab.policies.length > 0);
    return [firstWithPolicies?.key ?? tabs[0]?.key].filter(Boolean);
  }, [tabs]);
  const { isOpen, toggle } = useAccordionKeys(defaultOpenKeys);

  return (
    <div className={`qos-editor-sections qos-editor-sections--${variant}`}>
      {tabs.map((tab) => {
        const color = ENTITY_COLORS[tab.key] ?? '#722ed1';
        const open = isOpen(tab.key);
        return (
          <AccordionRow
            body={(
              <div className="qos-editor-section-body">
                <QosPolicyAccordion
                  actions={tab.actions}
                  policies={tab.policies}
                  variant={variant}
                  onAppend={(action) => onAppend?.(tab, action)}
                  onChange={onChange}
                />
              </div>
            )}
            caretClassName="qos-editor-section-caret"
            className={`qos-editor-section qos-editor-section--${variant}`}
            headClassName="qos-editor-section-head"
            key={tab.key}
            open={open}
            style={{ '--qos-section-color': color }}
            onToggle={() => toggle(tab.key)}
          >
            <b>{tab.key}</b>
            <span>{tab.label}</span>
            {tab.policies.length > 0 && <small>{tab.policies.length}</small>}
          </AccordionRow>
        );
      })}
    </div>
  );
}
