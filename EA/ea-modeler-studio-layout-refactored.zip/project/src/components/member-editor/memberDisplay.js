import {
  COMPLEX_TYPE_KINDS,
  CONTAINER_TYPE_KINDS,
  PRIMITIVE_TYPE_KINDS,
  STRING_TYPE_KINDS,
} from '../../model/memberModel.js';
import { memberToIdl } from '../../utils/memberIdl.js';

export const KIND_SELECT_OPTIONS = [
  { label: 'Primitive', options: PRIMITIVE_TYPE_KINDS.map(kindOption) },
  { label: 'String', options: STRING_TYPE_KINDS.map(kindOption) },
  { label: 'Complex', options: COMPLEX_TYPE_KINDS.map(kindOption) },
  { label: 'Collection', options: CONTAINER_TYPE_KINDS.map(kindOption) },
];

export function memberTypeLabel(member) {
  if (!member) return '';

  if (isPrimitiveKind(member.kind)) return member.kind;

  if (isStringKind(member.kind)) {
    return member.string_max_length ? `${member.kind}<${member.string_max_length}>` : member.kind;
  }

  if (isComplexKind(member.kind)) return member.type || 'Select type';

  if (member.kind === 'sequence') {
    const bound = member.sequence_max_length ? `, ${member.sequence_max_length}` : '';
    return `sequence<${member.type || 'Select type'}${bound}>`;
  }

  if (member.kind === 'array') {
    return `${member.type || 'Select type'}${arraySuffix(member.array_dimensions)}`;
  }

  return member.kind;
}

export function buildMemberIdlPreview(member) {
  return memberToIdl(member);
}

export function kindGroupLabel(kind) {
  if (isPrimitiveKind(kind)) return 'Primitive';
  if (isStringKind(kind)) return 'String';
  if (isComplexKind(kind)) return 'Complex';
  if (CONTAINER_TYPE_KINDS.includes(kind)) return 'Collection';
  return 'Type';
}

function arraySuffix(dimensions) {
  if (!Array.isArray(dimensions) || dimensions.length === 0) return '';
  return dimensions.map((dimension) => `[${dimension}]`).join('');
}

function kindOption(value) {
  return { label: value, value };
}

function isPrimitiveKind(kind) {
  return PRIMITIVE_TYPE_KINDS.includes(kind);
}

function isStringKind(kind) {
  return STRING_TYPE_KINDS.includes(kind);
}

function isComplexKind(kind) {
  return COMPLEX_TYPE_KINDS.includes(kind);
}
