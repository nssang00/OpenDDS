import { Tag } from 'antd';
import { kindGroupLabel, memberTypeLabel } from './memberDisplay.js';

export default function MemberSummary({ member }) {
  return (
    <div className="member-summary">
      <div className="member-summary-main">
        <span className="member-summary-name">{member.name || 'unnamed'}</span>
        {member.annotations?.key && <Tag color="gold">key</Tag>}
      </div>
      <div className="member-summary-meta">
        <span>{memberTypeLabel(member)}</span>
        <span className="member-summary-dot">/</span>
        <span>{kindGroupLabel(member.kind)}</span>
      </div>
    </div>
  );
}
