import { Checkbox } from 'antd';
import { annotationValue, patchAnnotation } from '../../model/memberModel.js';

export default function MemberAnnotationFields({ member, onPatch }) {
  return (
    <div className="member-detail-field member-detail-field--inline">
      <span className="member-detail-label">Annotations</span>
      <Checkbox
        checked={annotationValue(member, 'key')}
        onChange={(event) => onPatch(patchAnnotation(member, 'key', event.target.checked))}
      >
        key
      </Checkbox>
      <Checkbox
        checked={annotationValue(member, 'optional')}
        onChange={(event) => onPatch(patchAnnotation(member, 'optional', event.target.checked))}
      >
        optional
      </Checkbox>
    </div>
  );
}
