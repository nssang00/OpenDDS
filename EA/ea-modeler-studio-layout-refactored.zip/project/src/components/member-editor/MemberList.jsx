import { Button, Space } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { useAccordionKeys } from '../../hooks/useAccordionKeys.js';
import MemberRow from './MemberRow.jsx';

export default function MemberList({
  getDefaultType,
  getTypeOptions,
  members,
  onAddMember,
  onPatchMember,
  onRemoveMember,
  onUpdateMember,
}) {
  const { isOpen, toggle, setOpenKeys } = useAccordionKeys([], { multiple: false });

  const handleAdd = () => {
    onAddMember();
    setOpenKeys([members.length]);
  };

  const handleRemove = (index) => {
    onRemoveMember(index);
    setOpenKeys((current) => {
      const [openIndex] = current;
      if (openIndex === undefined) return current;
      if (openIndex === index) return [];
      if (openIndex > index) return [openIndex - 1];
      return current;
    });
  };

  return (
    <Space className="member-list" direction="vertical" size={8}>
      <Button icon={<PlusOutlined />} onClick={handleAdd} block>
        Add member
      </Button>

      {members.map((member, index) => (
        <MemberRow
          key={`${member.name || 'member'}-${index}`}
          getDefaultType={getDefaultType}
          getTypeOptions={getTypeOptions}
          isOpen={isOpen(index)}
          member={member}
          onPatch={(patch) => onPatchMember(index, patch)}
          onRemove={() => handleRemove(index)}
          onToggle={() => toggle(index)}
          onUpdate={(nextMember) => onUpdateMember(index, nextMember)}
        />
      ))}
    </Space>
  );
}
