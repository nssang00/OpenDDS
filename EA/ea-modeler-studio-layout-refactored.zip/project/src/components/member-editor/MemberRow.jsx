import { Button, Popconfirm } from 'antd';
import { CloseOutlined } from '@ant-design/icons';
import AccordionRow from '../editor-blocks/AccordionRow.jsx';
import MemberDetailForm from './MemberDetailForm.jsx';
import MemberSummary from './MemberSummary.jsx';

export default function MemberRow({
  getDefaultType,
  getTypeOptions,
  isOpen,
  member,
  onPatch,
  onRemove,
  onToggle,
  onUpdate,
}) {
  return (
    <AccordionRow
      body={(
        <MemberDetailForm
          getDefaultType={getDefaultType}
          getTypeOptions={getTypeOptions}
          member={member}
          onPatch={onPatch}
          onUpdate={onUpdate}
        />
      )}
      caretClassName="member-row-caret"
      className="member-row"
      headClassName="member-row-header"
      open={isOpen}
      openClassName="member-row--open"
      onToggle={onToggle}
    >
      <MemberSummary member={member} />
      <Popconfirm title="Remove member?" onConfirm={onRemove}>
        <Button
          danger
          icon={<CloseOutlined />}
          onClick={(event) => event.stopPropagation()}
          size="small"
          type="text"
        />
      </Popconfirm>
    </AccordionRow>
  );
}
