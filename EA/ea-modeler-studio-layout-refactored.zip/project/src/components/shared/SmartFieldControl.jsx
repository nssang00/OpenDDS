import { Checkbox, Input, InputNumber, Select } from 'antd';

// Renders the right input for a field's value type: Select for enumerated
// options, Checkbox for booleans, and either an antd Input/InputNumber or a
// bare native <input> for everything else (useNativeInput picks which).
// This replaces two near-identical implementations that used to live in
// qos-editor/QosFieldControl.jsx and diagram/FieldEditor.jsx.
export default function SmartFieldControl({
  checkboxClassName,
  className = '',
  inputClassName,
  onChange,
  options,
  selectClassName,
  size = 'middle',
  useNativeInput = false,
  value,
}) {
  const stop = (event) => event.stopPropagation();
  const common = { onClick: stop, onMouseDown: stop };

  if (options?.length) {
    return (
      <Select
        {...common}
        className={selectClassName ?? className}
        options={options}
        popupMatchSelectWidth={false}
        size={size}
        value={value}
        onChange={onChange}
      />
    );
  }

  if (typeof value === 'boolean') {
    return (
      <Checkbox
        {...common}
        className={checkboxClassName ?? className}
        checked={value}
        onChange={(event) => onChange(event.target.checked)}
      />
    );
  }

  if (useNativeInput) {
    return (
      <input
        {...common}
        className={inputClassName ?? className}
        type={typeof value === 'number' ? 'number' : 'text'}
        value={String(value)}
        onChange={(event) => {
          const nextValue = typeof value === 'number' ? Number(event.target.value) : event.target.value;
          onChange(nextValue);
        }}
      />
    );
  }

  if (typeof value === 'number') {
    return (
      <InputNumber {...common} className={inputClassName ?? className} size={size} value={value} onChange={onChange} />
    );
  }

  return (
    <Input
      {...common}
      className={inputClassName ?? className}
      size={size}
      value={Array.isArray(value) ? value.join(', ') : String(value ?? '')}
      onChange={(event) => onChange(event.target.value)}
    />
  );
}
