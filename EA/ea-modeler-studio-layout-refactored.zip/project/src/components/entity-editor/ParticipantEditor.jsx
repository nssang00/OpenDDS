import { useState } from 'react';
import { Button, Input, InputNumber, Select } from 'antd';
import AccordionRow from '../editor-blocks/AccordionRow.jsx';
import AddActionButton from '../editor-blocks/AddActionButton.jsx';
import { EditorCard, EditorCardHeader, EditorCardList } from '../editor-blocks/EditorCard.jsx';
import EditorIdentityHeader from '../editor-blocks/EditorIdentityHeader.jsx';
import { buildTopicRefOptions, nextNamedItem } from '../../model/entityEditorModel.js';
import EntityDeleteButton from './shared/EntityDeleteButton.jsx';
import EditorSection from './shared/EditorSection.jsx';
import FieldRow from './shared/FieldRow.jsx';

export default function ParticipantEditor({ element, model, onAppendPath, onRemovePath, onUpdateElement, onUpdatePath, variant = 'panel' }) {
  const participant = element?.properties ?? {};
  const publishers = participant.publishers ?? [];
  const subscribers = participant.subscribers ?? [];
  const topicOptions = buildTopicRefOptions(model);
  const updateParticipantName = (value) => {
    onUpdatePath(element.id, 'name', value);
    onUpdateElement?.(element.id, { name: value });
  };

  return (
    <div className={`entity-editor entity-editor--participant entity-editor--${variant} nodrag`}>
      <EditorIdentityHeader
        icon="P"
        kind="participant"
        tone="participant"
        value={participant.name ?? element.name}
        onChange={updateParticipantName}
      />

      <div className="entity-editor-grid entity-editor-grid--domain-link">
        <FieldRow label="domain_ref">
          <Input value={participant.domain_ref} onChange={(event) => onUpdatePath(element.id, 'domain_ref', event.target.value)} />
        </FieldRow>
        <FieldRow label="domain_id">
          <InputNumber min={0} value={participant.domain_id} onChange={(value) => onUpdatePath(element.id, 'domain_id', value)} />
        </FieldRow>
      </div>

      <EditorSection
        title="publishers"
        count={publishers.length}
        tone="publisher"
        action={(
          <AddActionButton
            onClick={() => onAppendPath(element.id, 'publishers', { name: nextNamedItem(publishers, 'NewPublisher'), data_writers: [] })}
          >
            + Publisher
          </AddActionButton>
        )}
      >
        <EditorCardList>
          {publishers.map((publisher, index) => (
            <PublisherCard
              element={element}
              index={index}
              key={`publishers.${index}`}
              publisher={publisher}
              topicOptions={topicOptions}
              onAppendPath={onAppendPath}
              onRemovePath={onRemovePath}
              onUpdatePath={onUpdatePath}
            />
          ))}
        </EditorCardList>
      </EditorSection>

      <EditorSection
        title="subscribers"
        count={subscribers.length}
        tone="subscriber"
        action={(
          <AddActionButton
            onClick={() => onAppendPath(element.id, 'subscribers', { name: nextNamedItem(subscribers, 'NewSubscriber'), data_readers: [] })}
          >
            + Subscriber
          </AddActionButton>
        )}
      >
        <EditorCardList>
          {subscribers.map((subscriber, index) => (
            <SubscriberCard
              element={element}
              index={index}
              key={`subscribers.${index}`}
              subscriber={subscriber}
              topicOptions={topicOptions}
              onAppendPath={onAppendPath}
              onRemovePath={onRemovePath}
              onUpdatePath={onUpdatePath}
            />
          ))}
        </EditorCardList>
      </EditorSection>
    </div>
  );
}

function PublisherCard({ element, index, publisher, topicOptions, onAppendPath, onRemovePath, onUpdatePath }) {
  const writers = publisher.data_writers ?? [];
  return (
    <EditorCard className="entity-editor-card--publisher">
      <EditorCardHeader>
        <span className="entity-editor-card-icon">P</span>
        <Input
          className="entity-editor-card-name"
          placeholder="PublisherName"
          value={publisher.name}
          onChange={(event) => onUpdatePath(element.id, `publishers.${index}.name`, event.target.value)}
        />
        <EntityDeleteButton label="Delete publisher" onClick={() => onRemovePath(element.id, 'publishers', index)} />
      </EditorCardHeader>
      <EndpointList
        addLabel="+ DataWriter"
        basePath={`publishers.${index}.data_writers`}
        element={element}
        items={writers}
        itemLabel="writer"
        topicOptions={topicOptions}
        onAppendPath={onAppendPath}
        onRemovePath={onRemovePath}
        onUpdatePath={onUpdatePath}
      />
    </EditorCard>
  );
}

function SubscriberCard({ element, index, subscriber, topicOptions, onAppendPath, onRemovePath, onUpdatePath }) {
  const readers = subscriber.data_readers ?? [];
  return (
    <EditorCard className="entity-editor-card--subscriber">
      <EditorCardHeader>
        <span className="entity-editor-card-icon">S</span>
        <Input
          className="entity-editor-card-name"
          placeholder="SubscriberName"
          value={subscriber.name}
          onChange={(event) => onUpdatePath(element.id, `subscribers.${index}.name`, event.target.value)}
        />
        <EntityDeleteButton label="Delete subscriber" onClick={() => onRemovePath(element.id, 'subscribers', index)} />
      </EditorCardHeader>
      <EndpointList
        addLabel="+ DataReader"
        basePath={`subscribers.${index}.data_readers`}
        element={element}
        items={readers}
        itemLabel="reader"
        topicOptions={topicOptions}
        onAppendPath={onAppendPath}
        onRemovePath={onRemovePath}
        onUpdatePath={onUpdatePath}
      />
    </EditorCard>
  );
}

function EndpointList({ addLabel, basePath, element, items, itemLabel, topicOptions, onAppendPath, onRemovePath, onUpdatePath }) {
  return (
    <div className="entity-editor-endpoints">
      {items.map((item, index) => (
        <EndpointRow
          basePath={basePath}
          element={element}
          index={index}
          item={item}
          itemLabel={itemLabel}
          key={`${basePath}.${index}`}
          topicOptions={topicOptions}
          onRemovePath={onRemovePath}
          onUpdatePath={onUpdatePath}
        />
      ))}
      <Button
        block
        className="entity-editor-add entity-editor-add--nested nodrag"
        onClick={() => onAppendPath(element.id, basePath, { name: nextNamedItem(items, `New${capitalize(itemLabel)}`), topic_ref: topicOptions[0]?.value ?? '' })}
        onMouseDown={(event) => event.stopPropagation()}
      >
        {addLabel}
      </Button>
    </div>
  );
}

function EndpointRow({ basePath, element, index, item, itemLabel, topicOptions, onRemovePath, onUpdatePath }) {
  const [open, setOpen] = useState(false);
  const isReader = itemLabel === 'reader';

  return (
    <AccordionRow
      body={(
        <div className="entity-editor-endpoint-body">
          <div className="entity-editor-grid entity-editor-grid--endpoint">
            <FieldRow label="name">
              <Input value={item.name} onChange={(event) => onUpdatePath(element.id, `${basePath}.${index}.name`, event.target.value)} />
            </FieldRow>
            <FieldRow label="topic_ref">
              <Select options={topicOptions} value={item.topic_ref} onChange={(value) => onUpdatePath(element.id, `${basePath}.${index}.topic_ref`, value)} />
            </FieldRow>
          </div>
        </div>
      )}
      caretClassName="entity-editor-endpoint-caret"
      className={`entity-editor-endpoint-row entity-editor-endpoint-row--${itemLabel}`}
      headClassName="entity-editor-endpoint-head"
      open={open}
      openClassName="entity-editor-endpoint-row--open"
      onToggle={() => setOpen((value) => !value)}
    >
      <span className="entity-editor-endpoint-icon">{isReader ? 'R' : 'W'}</span>
      <b>{item.name || 'unnamed'}</b>
      <small>{isReader ? '<-' : '->'} {item.topic_ref || 'no topic'}</small>
      <EntityDeleteButton label={`Delete ${itemLabel}`} onClick={() => onRemovePath(element.id, basePath, index)} />
    </AccordionRow>
  );
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}
