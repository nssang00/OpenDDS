import { Input, InputNumber, Select } from 'antd';
import AddActionButton from '../editor-blocks/AddActionButton.jsx';
import { EditorCard, EditorCardList } from '../editor-blocks/EditorCard.jsx';
import EditorIdentityHeader from '../editor-blocks/EditorIdentityHeader.jsx';
import { nextNamedItem, registerTypeOptions, buildTypeRefOptions } from '../../model/entityEditorModel.js';
import EntityDeleteButton from './shared/EntityDeleteButton.jsx';
import EditorSection from './shared/EditorSection.jsx';
import FieldRow from './shared/FieldRow.jsx';

export default function DomainEditor({ element, model, onAppendPath, onRemovePath, onUpdateElement, onUpdatePath, variant = 'panel' }) {
  const domain = element?.properties ?? {};
  const registerTypes = domain.register_types ?? [];
  const topics = domain.topics ?? [];
  const typeOptions = buildTypeRefOptions(model);
  const registerOptions = registerTypeOptions(element);
  const updateDomainName = (value) => {
    onUpdatePath(element.id, 'name', value);
    onUpdateElement?.(element.id, { name: value });
  };

  return (
    <div className={`entity-editor entity-editor--domain entity-editor--${variant} nodrag`}>
      <EditorIdentityHeader
        icon="D"
        kind="domain"
        tone="domain"
        value={domain.name ?? element.name}
        onChange={updateDomainName}
      />

      <div className="entity-editor-grid entity-editor-grid--domain-meta">
        <FieldRow label="domain_id">
          <InputNumber
            min={0}
            value={domain.domain_id}
            onChange={(value) => onUpdatePath(element.id, 'domain_id', value)}
          />
        </FieldRow>
      </div>

      <EditorSection
        title="register_types"
        count={registerTypes.length}
        tone="domain"
        action={(
          <AddActionButton
            onClick={() => onAppendPath(element.id, 'register_types', {
              name: nextNamedItem(registerTypes, 'NewType'),
              type_ref: typeOptions[0]?.value ?? '',
            })}
          >
            + Register Type
          </AddActionButton>
        )}
      >
        <EditorCardList>
          {registerTypes.map((item, index) => (
            <EditorCard className="entity-editor-card--register-type" key={`register_types.${index}`}>
              <div className="entity-editor-grid entity-editor-grid--domain-item">
                <FieldRow label="name">
                  <Input
                    placeholder="RegisteredTypeName"
                    value={item.name}
                    onChange={(event) => onUpdatePath(element.id, `register_types.${index}.name`, event.target.value)}
                  />
                </FieldRow>
                <FieldRow label="type_ref">
                  <Select
                    showSearch
                    options={typeOptions}
                    optionFilterProp="label"
                    placeholder="Module::TypeName"
                    value={item.type_ref}
                    onChange={(value) => onUpdatePath(element.id, `register_types.${index}.type_ref`, value)}
                  />
                </FieldRow>
                <EntityDeleteButton label="Delete register type" onClick={() => onRemovePath(element.id, 'register_types', index)} />
              </div>
            </EditorCard>
          ))}
        </EditorCardList>
      </EditorSection>

      <EditorSection
        title="topics"
        count={topics.length}
        tone="topic"
        action={(
          <AddActionButton
            onClick={() => onAppendPath(element.id, 'topics', {
              name: nextNamedItem(topics, 'NewTopic'),
              register_type_ref: registerOptions[0]?.value ?? '',
              topic_qos: {},
            })}
          >
            + Topic
          </AddActionButton>
        )}
      >
        <EditorCardList>
          {topics.map((item, index) => (
            <EditorCard className="entity-editor-card--topic" key={`topics.${index}`}>
              <div className="entity-editor-grid entity-editor-grid--domain-item">
                <FieldRow label="name">
                  <Input
                    placeholder="TopicName"
                    value={item.name}
                    onChange={(event) => onUpdatePath(element.id, `topics.${index}.name`, event.target.value)}
                  />
                </FieldRow>
                <FieldRow label="register_type_ref">
                  <Select
                    options={registerOptions}
                    placeholder="select register type"
                    value={item.register_type_ref}
                    onChange={(value) => onUpdatePath(element.id, `topics.${index}.register_type_ref`, value)}
                  />
                </FieldRow>
                <EntityDeleteButton label="Delete topic" onClick={() => onRemovePath(element.id, 'topics', index)} />
              </div>
            </EditorCard>
          ))}
        </EditorCardList>
      </EditorSection>
    </div>
  );
}
