import { Collapse } from 'antd';

export default function EditorAccordion({ items }) {
  return (
    <Collapse
      className="entity-editor-accordion"
      size="small"
      items={items.map((item) => ({
        key: item.key,
        label: item.label,
        children: item.children,
      }))}
    />
  );
}
