export default function FieldRow({ children, label }) {
  return (
    <label className="entity-editor-field">
      <span>{label}</span>
      {children}
    </label>
  );
}
