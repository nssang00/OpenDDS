const SECTION_COLORS = {
  domain: '#1677ff',
  topic: '#d48806',
  publisher: '#1677ff',
  subscriber: '#eb2f96',
};

export default function EditorSection({ action, children, count, title, tone }) {
  return (
    <section
      className={`entity-editor-section ${tone ? `entity-editor-section--${tone}` : ''}`}
      style={tone ? { '--entity-section-color': SECTION_COLORS[tone] } : undefined}
    >
      <div className="entity-editor-section-head">
        <b>{title}</b>
        {count !== undefined && <small>{count}</small>}
        {action && <div className="entity-editor-section-action">{action}</div>}
      </div>
      {children}
    </section>
  );
}
