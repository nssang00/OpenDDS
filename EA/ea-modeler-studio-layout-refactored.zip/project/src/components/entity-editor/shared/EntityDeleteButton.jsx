import { CloseOutlined } from '@ant-design/icons';
import { Button } from 'antd';

export default function EntityDeleteButton({ label = 'Delete', onClick }) {
  return (
    <Button
      aria-label={label}
      className="entity-editor-delete nodrag"
      danger
      icon={<CloseOutlined />}
      onClick={onClick}
      onMouseDown={(event) => event.stopPropagation()}
      title={label}
      type="text"
    />
  );
}
