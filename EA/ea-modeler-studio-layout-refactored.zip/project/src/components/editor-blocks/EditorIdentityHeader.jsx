import { Input } from 'antd';

export default function EditorIdentityHeader({ icon, kind, tone, value, onChange }) {
  return (
    <div className={`entity-editor-identity entity-editor-identity--${tone}`}>
      <span className="entity-editor-identity-icon">{icon}</span>
      <Input
        className="entity-editor-name-input"
        value={value}
        onChange={(event) => onChange(event.target.value)}
      />
      <span className="entity-editor-kind-badge">{kind}</span>
    </div>
  );
}
