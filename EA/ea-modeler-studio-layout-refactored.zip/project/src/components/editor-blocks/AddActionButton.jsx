import { Button } from 'antd';

export default function AddActionButton({ children, className = '', onClick }) {
  return (
    <Button
      className={`entity-editor-add nodrag ${className}`.trim()}
      size="small"
      onClick={onClick}
      onMouseDown={(event) => event.stopPropagation()}
    >
      {children}
    </Button>
  );
}
