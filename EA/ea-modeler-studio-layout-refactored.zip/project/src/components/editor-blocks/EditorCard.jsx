export function EditorCardList({ children }) {
  return <div className="entity-editor-card-list">{children}</div>;
}

export function EditorCard({ children, className = '' }) {
  return (
    <div className={`entity-editor-card ${className}`.trim()}>
      {children}
    </div>
  );
}

export function EditorCardHeader({ children }) {
  return <div className="entity-editor-card-head">{children}</div>;
}
