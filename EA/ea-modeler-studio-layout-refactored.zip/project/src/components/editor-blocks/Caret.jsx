export default function Caret({ className = '', open = false }) {
  return (
    <span className={`${className} ${open ? `${className}--open` : ''}`.trim()}>
      {'>'}
    </span>
  );
}
