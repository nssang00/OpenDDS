import { Empty } from 'antd';
import MemberList from './member-editor/MemberList.jsx';
import { useMemberEditor } from '../hooks/useMemberEditor.js';

export default function MemberEditor({ emptyDescription = 'Selected element has no members.', element, members }) {
  const {
    addMember,
    getDefaultType,
    getTypeOptions,
    patchMember,
    removeMember,
    updateMember,
  } = useMemberEditor(element?.id, members ?? []);

  if (!Array.isArray(members)) {
    return <Empty description={emptyDescription} />;
  }

  return (
    <MemberList
      members={members}
      getDefaultType={getDefaultType}
      getTypeOptions={getTypeOptions}
      onAddMember={addMember}
      onPatchMember={patchMember}
      onRemoveMember={removeMember}
      onUpdateMember={updateMember}
    />
  );
}
