import { Typography } from 'antd';
import DomainEditor from './entity-editor/DomainEditor.jsx';
import ParticipantEditor from './entity-editor/ParticipantEditor.jsx';
import QosEditor from './qos-editor/QosEditor.jsx';
import TextEditor from './TextEditor.jsx';
import BasicPropertySection from './properties/BasicPropertySection.jsx';
import PropertySection from './properties/PropertySection.jsx';

const { Text } = Typography;

export default function PropertyForm({
  editorProperties,
  element,
  model,
  sections = [],
  formProperties,
  hasMembers,
  memberEditor,
  onUpdateElement,
  onAppendElementPath,
  onRemoveElementPath,
  onUpdateElementPath,
  onUpdateProperty,
  onUpdateQosProperty,
  qosFields,
  qosSections,
}) {
  if (!element) {
    return <div className="empty-state">Select an element.</div>;
  }

  return (
    <div className="workbench-view">
      <Text type="secondary">Selected ID: {element.id}</Text>

      {sections.map((section) => renderSection(section, {
        element,
        formProperties,
        hasMembers,
        memberEditor,
        model,
        onAppendElementPath,
        onUpdateElement,
        onRemoveElementPath,
        onUpdateElementPath,
        onUpdateProperty,
        onUpdateQosProperty,
        qosFields,
        qosSections,
      }))}

      {editorProperties.map(([key, value]) => (
        <PropertySection key={key} title={key}>
          <TextEditor
            value={value}
            onChange={(nextValue) => onUpdateProperty(element.id, key, nextValue)}
          />
        </PropertySection>
      ))}
    </div>
  );
}

function renderSection(section, props) {
  if (section === 'basic') {
    return (
      <PropertySection key="basic" title="Basic">
        <BasicPropertySection
          element={props.element}
          properties={props.formProperties}
          onUpdateElement={props.onUpdateElement}
          onUpdateProperty={props.onUpdateProperty}
        />
      </PropertySection>
    );
  }

  if (section === 'members' && props.hasMembers) {
    return (
      <PropertySection key="members" title="Struct Members">
        {props.memberEditor}
      </PropertySection>
    );
  }

  if (section === 'qos') {
    return (
      <QosEditor
        key="qos"
        fields={props.qosFields}
        sections={props.qosSections}
        variant="panel"
        onAppend={(tab, action) => props.onUpdateQosProperty(`${tab.key}.${action.key}`, action.value)}
        onFieldChange={(field, value) => props.onUpdateQosProperty(field.path, value)}
      />
    );
  }

  if (section === 'domain') {
    return (
      <PropertySection key="domain" title="Domain">
        <DomainEditor
          element={props.element}
          model={props.model}
          onAppendPath={props.onAppendElementPath}
          onRemovePath={props.onRemoveElementPath}
          onUpdateElement={props.onUpdateElement}
          onUpdatePath={props.onUpdateElementPath}
        />
      </PropertySection>
    );
  }

  if (section === 'participant') {
    return (
      <PropertySection key="participant" title="Domain Participant">
        <ParticipantEditor
          element={props.element}
          model={props.model}
          onAppendPath={props.onAppendElementPath}
          onRemovePath={props.onRemoveElementPath}
          onUpdateElement={props.onUpdateElement}
          onUpdatePath={props.onUpdateElementPath}
        />
      </PropertySection>
    );
  }

  return null;
}
