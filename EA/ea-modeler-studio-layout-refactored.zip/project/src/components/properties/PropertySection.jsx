import { Divider } from 'antd';

export default function PropertySection({ children, title }) {
  return (
    <>
      <Divider orientation="left">{title}</Divider>
      {children}
    </>
  );
}
