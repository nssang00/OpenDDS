import { Empty, Input, Tree } from 'antd';

const { DirectoryTree } = Tree;

export default function ElementTreeView({
  className = '',
  filterPlaceholder,
  filterText,
  hasModel,
  onFilterTextChange,
  onSelect,
  selectedKeys,
  treeData,
}) {
  const viewClassName = ['workbench-view', className].filter(Boolean).join(' ');

  if (!hasModel) {
    return (
      <div className={viewClassName}>
        <Empty description="No model loaded" />
      </div>
    );
  }

  return (
    <div className={viewClassName}>
      {onFilterTextChange && (
        <Input
          allowClear
          className="element-tree-filter"
          placeholder={filterPlaceholder}
          value={filterText}
          onChange={(event) => onFilterTextChange(event.target.value)}
        />
      )}
      <DirectoryTree
        key={filterText ? `filtered-${filterText}` : 'unfiltered'}
        blockNode
        defaultExpandAll
        selectedKeys={selectedKeys}
        treeData={treeData}
        onSelect={(keys) => keys[0] && onSelect(keys[0])}
      />
    </div>
  );
}
