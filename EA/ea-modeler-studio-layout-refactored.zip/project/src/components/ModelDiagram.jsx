import { Empty } from 'antd';
import { ReactFlow, Background, Controls, MiniMap } from '@xyflow/react';
import JsonEntityNode from './diagram/nodes/JsonEntityNode.jsx';
import ModelNode from './diagram/nodes/ModelNode.jsx';
import ModuleNode from './diagram/nodes/ModuleNode.jsx';
import QosNode from './diagram/nodes/QosNode.jsx';
import TypeNode from './diagram/nodes/TypeNode.jsx';

function DiagramGroup({ data }) {
  return (
    <div className="diagram-group">
      <div className="diagram-group-title">{data.label}</div>
    </div>
  );
}

const nodeTypes = {
  diagramGroup: DiagramGroup,
  jsonEntityNode: JsonEntityNode,
  modelNode: ModelNode,
  moduleNode: ModuleNode,
  qosNode: QosNode,
  typeNode: TypeNode,
};

export default function ModelDiagram({
  edges,
  hasModel,
  model,
  nodes,
  onNodesChange,
  onEdgesChange,
  onSelectElement,
  onAppendElementPath,
  onRemoveElementPath,
  onUpdateElement,
  onUpdateElementPath,
  onUpdateQosProperty,
}) {
  const diagramNodes = nodes.map((node) => ({
    ...node,
    data: {
      ...node.data,
      model,
      onAppendElementPath,
      onRemoveElementPath,
      onUpdateElement,
      onUpdateElementPath,
      onUpdateQosProperty,
    },
  }));

  if (!hasModel) {
    return (
      <div className="diagram-wrapper">
        <Empty description="Loading model..." />
      </div>
    );
  }

  return (
    <div className="diagram-wrapper">
      <ReactFlow
        nodes={diagramNodes}
        edges={edges}
        nodeTypes={nodeTypes}
        fitView
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onNodeClick={(_, node) => onSelectElement(node.data?.selectId ?? node.id)}
      >
        <Background />
        <Controls />
        <MiniMap
          nodeColor={(node) => miniMapNodeColor(node)}
          nodeStrokeColor={(node) => node.selected ? '#1677ff' : '#98a2b3'}
          nodeBorderRadius={6}
          maskColor="rgba(248, 250, 252, 0.72)"
          pannable
          zoomable
        />
      </ReactFlow>
    </div>
  );
}

function miniMapNodeColor(node) {
  if (node.type === 'typeNode') return '#6392c7';
  if (node.type === 'jsonEntityNode' && node.data?.variant === 'domain') return '#9bc6bb';
  if (node.type === 'jsonEntityNode' && node.data?.variant === 'participant') return '#f7a8b7';
  if (node.type !== 'qosNode') return '#ffffff';

  const colors = {
    profile: '#e6f4ff',
    topic: '#f9f0ff',
    participant: '#8bbbd0',
    publisher: '#d0af78',
    subscriber: '#b5a5d0',
    datawriter: '#9bb7da',
    datareader: '#9cc7ce',
    library: '#cbd5e1',
    module: '#cbd5e1',
    struct: '#9bb7da',
    union: '#b5a5d0',
    enum: '#d0af78',
    domain: '#9bc6bb',
    registerType: '#b5a5d0',
  };

  return colors[node.data?.variant] ?? '#ffffff';
}
