import SmartFieldControl from '../shared/SmartFieldControl.jsx';

export default function FieldEditor({ label, onChange, row }) {
  return (
    <div className={`qos-node-field ${row.editable ? 'qos-node-field--editable' : ''}`}>
      <span title={row.key}>{label ?? shortFieldLabel(row.key)}</span>
      {row.editable ? (
        <SmartFieldControl
          checkboxClassName="qos-node-field-checkbox nodrag"
          inputClassName="qos-node-field-input nodrag"
          options={row.options}
          selectClassName="qos-node-field-select nodrag"
          size="small"
          useNativeInput
          value={row.value}
          onChange={onChange}
        />
      ) : (
        <b>{String(row.value)}</b>
      )}
    </div>
  );
}

function shortFieldLabel(key) {
  return key.split('.').slice(-2).join('.');
}
