import { Handle, Position } from '@xyflow/react';

// Shared wrapper for every diagram node: source/target Handles + the
// selected-node class. Every node component used to reimplement this block
// by hand; now they just pass their own inner markup as children.
export default function NodeShell({ children, className, data, selected }) {
  const sourcePosition = data.sourcePosition ?? Position.Right;
  const targetPosition = data.targetPosition ?? Position.Left;

  return (
    <div className={`${className} ${selected ? 'selected-node' : ''}`}>
      <Handle className="flow-handle" type="target" position={targetPosition} />
      {children}
      <Handle className="flow-handle" type="source" position={sourcePosition} />
    </div>
  );
}
