import NodeShell from './NodeShell.jsx';

export default function ModelNode({ data, selected }) {
  return (
    <NodeShell className="model-node" data={data} selected={selected}>
      <strong>{data.label}</strong>
      <div className="model-node-type">{data.type}</div>
    </NodeShell>
  );
}
