import NodeShell from './NodeShell.jsx';

export default function TypeNode({ data, selected }) {
  return (
    <NodeShell className={`uml-type-node uml-type-node--${data.variant}`} data={data} selected={selected}>
      <div className="uml-type-node-header">
        <div className="uml-type-node-stereotype">&lt;&lt;{data.stereotype ?? data.label?.toLowerCase()}&gt;&gt;</div>
        <strong>{data.type}</strong>
      </div>
      <div className="uml-type-node-members">
        {data.fields?.length > 0 ? data.fields.map((field) => (
          <div className="uml-type-node-member" key={field.key}>
            <span>+ {field.key}</span>
            <b>{String(field.value ?? '')}</b>
          </div>
        )) : <span className="uml-type-node-empty">No members</span>}
      </div>
    </NodeShell>
  );
}
