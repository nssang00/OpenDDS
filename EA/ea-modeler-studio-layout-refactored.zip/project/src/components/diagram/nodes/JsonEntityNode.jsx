import DomainEditor from '../../entity-editor/DomainEditor.jsx';
import ParticipantEditor from '../../entity-editor/ParticipantEditor.jsx';
import NodeShell from './NodeShell.jsx';

// domainConfig/participantConfig (see model/diagramBuilders.js) are the only
// producers of nodeType 'jsonEntityNode', and both always set data.element,
// so this node only ever needs to embed one of the two entity editors.
const EDITORS_BY_VARIANT = {
  domain: DomainEditor,
  participant: ParticipantEditor,
};

export default function JsonEntityNode({ data, selected }) {
  const Editor = EDITORS_BY_VARIANT[data.variant];
  if (!Editor || !data.element) return null;

  return (
    <NodeShell className={`json-entity-node json-entity-node--${data.variant}`} data={data} selected={selected}>
      <div className="json-entity-node-type">{data.type}</div>
      <div className="json-entity-node-header">
        <strong>{data.label}</strong>
      </div>
      <Editor
        element={data.element}
        model={data.model}
        variant="diagram"
        onAppendPath={data.onAppendElementPath}
        onRemovePath={data.onRemoveElementPath}
        onUpdateElement={data.onUpdateElement}
        onUpdatePath={data.onUpdateElementPath}
      />
    </NodeShell>
  );
}
