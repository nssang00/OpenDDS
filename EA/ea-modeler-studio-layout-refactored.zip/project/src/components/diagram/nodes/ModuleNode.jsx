import NodeShell from './NodeShell.jsx';

export default function ModuleNode({ data, selected }) {
  return (
    <NodeShell className="module-node" data={data} selected={selected}>
      <div className="module-node-tab">module</div>
      <strong>{data.label}</strong>
      <small>{data.type}</small>
    </NodeShell>
  );
}
