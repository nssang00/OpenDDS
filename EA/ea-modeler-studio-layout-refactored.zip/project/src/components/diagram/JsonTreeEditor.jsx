import FieldEditor from './FieldEditor.jsx';

export default function JsonTreeEditor({ level = 0, onChange, rows }) {
  return (
    <div className="qos-tree" style={{ paddingLeft: 8 + level * 12 }}>
      {rows.map((row) => (
        <div className="qos-tree-row" key={row.key}>
          {row.children ? (
            <>
              <div className="qos-tree-group">{row.label}</div>
              <JsonTreeEditor level={level + 1} rows={row.children} onChange={onChange} />
            </>
          ) : (
            <FieldEditor
              label={row.label}
              row={{ ...row, key: row.label }}
              onChange={(value) => onChange?.(row, value)}
            />
          )}
        </div>
      ))}
    </div>
  );
}
