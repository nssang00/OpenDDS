import { useCallback } from 'react';
import { useElementProperties } from './useElementProperties.js';
import { findAncestorByType } from '../model/modelSelectors.js';

export function usePropertyPanel() {
  const properties = useElementProperties();

  const updateSelectedQosProperty = useCallback(
    (path, value) => {
      const profile = findAncestorByType(properties.model, properties.element, 'QosProfile');
      if (profile) properties.updateQosPath(profile.id, path, value);
    },
    [properties.element, properties.model, properties.updateQosPath],
  );

  return {
    ...properties,
    updateSelectedQosProperty,
  };
}
