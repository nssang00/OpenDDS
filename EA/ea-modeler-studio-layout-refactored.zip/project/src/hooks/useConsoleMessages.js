import { useMemo } from 'react';
import { useProjects } from './useProjects.js';
import { useWorkbenchModel } from './useWorkbenchModel.js';
import { useModelSummary } from './useModelSummary.js';
import { buildConsoleMessages } from '../model/workbenchMessages.js';

export function useConsoleMessages() {
  const { dirty } = useWorkbenchModel();
  const { currentProject } = useProjects();
  const summary = useModelSummary();

  return useMemo(() => (
    buildConsoleMessages({ currentProject, dirty, summary })
  ), [currentProject, dirty, summary]);
}
