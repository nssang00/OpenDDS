import { useMemo, useState } from 'react';
import { useWorkbenchModel } from './useWorkbenchModel.js';
import { buildTreeData } from '../model/modelSelectors.js';

export function useElementTree({ filterPlaceholder = 'Filter', types } = {}) {
  const { model, selectedElementId, selectElement } = useWorkbenchModel();
  const [filterText, setFilterText] = useState('');
  const elementsById = model?.elementsById;

  const treeData = useMemo(() => {
    return buildTreeData(elementsById, { filterText, types });
  }, [elementsById, filterText, types]);

  return {
    filterPlaceholder,
    filterText,
    treeData,
    selectedKeys: selectedElementId ? [selectedElementId] : [],
    hasModel: Boolean(model),
    selectElement,
    setFilterText,
  };
}
