import { useUiStore } from '../stores/useUiStore.js';

export function useWorkbenchPanel(panelId) {
  const activeExplorerViewId = useUiStore((state) => state.activeExplorerViewId);
  const setActiveExplorerView = useUiStore((state) => state.setActiveExplorerView);

  return {
    activeExplorerViewId,
    onActiveViewChange: panelId === 'explorer' ? setActiveExplorerView : undefined,
  };
}
