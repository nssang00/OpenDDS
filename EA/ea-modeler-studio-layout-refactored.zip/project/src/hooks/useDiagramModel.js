import { useCallback, useEffect, useMemo, useRef } from 'react';
import { applyEdgeChanges, applyNodeChanges, MarkerType, Position, useEdgesState, useNodesState } from '@xyflow/react';
import { useWorkbenchModel } from './useWorkbenchModel.js';
import { buildDiagram } from '../model/diagramBuilders.js';
import { layoutDiagram } from '../utils/diagramLayout.js';

export function useDiagramModel() {
  const { activeExplorerViewId, appendElementPath, model, removeElementPath, selectedElementId, selectElement, updateElement, updateElementPath, updateQosProperty } = useWorkbenchModel();
  const computedDiagram = useMemo(() => {
    if (!model) return { nodes: [], edges: [], layoutKey: 'empty' };
    const diagram = buildDiagram(model, activeExplorerViewId, selectedElementId);
    const direction = diagramLayoutDirection(activeExplorerViewId);
    const positions = flowHandlePositions(direction);
    const edges = diagram.edges.map((edge) => ({
      ...edge,
      type: edge.type ?? 'smoothstep',
      markerEnd: edge.markerEnd === undefined ? { type: MarkerType.ArrowClosed } : edge.markerEnd,
      animated: edge.source === selectedElementId || edge.target === selectedElementId,
    }));
    const nodes = layoutDiagram(
      diagram.nodes.map((node) => toFlowNode(node, model, selectedElementId, positions)),
      edges,
      { direction },
    );
    return { nodes, edges, layoutKey: diagramLayoutKey(activeExplorerViewId, diagram.nodes, diagram.edges) };
  }, [activeExplorerViewId, model, selectedElementId]);
  const [nodes, setNodes] = useNodesState(computedDiagram.nodes);
  const [edges, setEdges] = useEdgesState(computedDiagram.edges);
  const previousLayoutKeyRef = useRef(null);

  useEffect(() => {
    setNodes((current) => {
      const shouldPreservePositions = previousLayoutKeyRef.current === computedDiagram.layoutKey;
      previousLayoutKeyRef.current = computedDiagram.layoutKey;
      if (!shouldPreservePositions) return computedDiagram.nodes;

      const positions = Object.fromEntries(current.map((node) => [node.id, node.position]));
      return computedDiagram.nodes.map((node) => ({
        ...node,
        position: positions[node.id] ?? node.position,
      }));
    });
  }, [computedDiagram.nodes, setNodes]);

  const onNodesChange = useCallback((changes) => {
    setNodes((current) => applyNodeChanges(changes, current));
  }, [setNodes]);
  useEffect(() => setEdges(computedDiagram.edges), [computedDiagram.edges, setEdges]);
  const onEdgesChange = useCallback((changes) => setEdges((current) => applyEdgeChanges(changes, current)), [setEdges]);

  return { model, nodes, edges, hasModel: Boolean(model), onNodesChange, onEdgesChange, selectElement, appendElementPath, removeElementPath, updateElement, updateElementPath, updateQosProperty };
}

function diagramLayoutDirection(viewId) {
  return ['types', 'qos'].includes(viewId) ? 'TB' : 'LR';
}

function flowHandlePositions(direction) {
  if (direction === 'TB') {
    return { sourcePosition: Position.Bottom, targetPosition: Position.Top };
  }

  return { sourcePosition: Position.Right, targetPosition: Position.Left };
}

function diagramLayoutKey(viewId, nodes, edges) {
  const nodeKey = nodes.map((node) => node.id).sort().join('|');
  const edgeKey = edges.map((edge) => `${edge.source}>${edge.target}:${edge.label ?? edge.id}`).sort().join('|');
  return `${viewId}:${nodeKey}:${edgeKey}`;
}

function toFlowNode(node, model, selectedElementId, positions) {
  const element = model.elementsById[node.id];
  return {
    id: node.id,
    type: node.nodeType ?? 'modelNode',
    position: node.position,
    width: node.width ?? 170,
    height: node.height ?? 68,
    sourcePosition: positions.sourcePosition,
    targetPosition: positions.targetPosition,
    draggable: node.draggable ?? true,
    selectable: node.selectable ?? true,
    zIndex: node.zIndex ?? 1,
    selected: node.id === selectedElementId,
    data: {
      label: element?.name ?? node.id,
      type: element?.type ?? 'Unknown',
      sourcePosition: positions.sourcePosition,
      targetPosition: positions.targetPosition,
      ...node.data,
    },
  };
}
