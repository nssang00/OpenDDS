import { useMemo } from 'react';
import { useWorkbenchModel } from './useWorkbenchModel.js';
import { getModelSummary } from '../model/modelSelectors.js';

const EMPTY_SUMMARY = { topics: 0, structs: 0, qosProfiles: 0 };

export function useModelSummary() {
  const { model } = useWorkbenchModel();

  return useMemo(() => (
    model ? getModelSummary(model) : EMPTY_SUMMARY
  ), [model]);
}
