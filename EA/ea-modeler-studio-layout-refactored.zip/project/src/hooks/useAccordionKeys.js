import { useState } from 'react';

// Shared open/close state for a list of AccordionRow items. `multiple`
// controls whether more than one row can be open at once: QoS sections and
// policies allow several open simultaneously (multiple=true, the default),
// while a Types member list behaves like a classic single-open accordion
// (multiple=false).
export function useAccordionKeys(defaultOpenKeys = [], { multiple = true } = {}) {
  const [openKeys, setOpenKeys] = useState(defaultOpenKeys);

  const isOpen = (key) => openKeys.includes(key);

  const toggle = (key) => {
    setOpenKeys((current) => {
      if (current.includes(key)) return current.filter((item) => item !== key);
      return multiple ? [...current, key] : [key];
    });
  };

  return { openKeys, setOpenKeys, isOpen, toggle };
}
