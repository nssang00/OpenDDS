import { useCallback, useEffect } from 'react';
import { fetchProjectModel } from '../api/modelApi.js';
import { useProjectActivation } from './useProjectActivation.js';
import { useModelStore } from '../stores/useModelStore.js';
import { useUiStore } from '../stores/useUiStore.js';

export function useEnsureProjectModel(projectId) {
  const cachedModel = useModelStore((state) => projectId ? state.projectModels[projectId]?.model : null);
  const modelProjectId = useModelStore((state) => state.modelProjectId);
  const status = useModelStore((state) => projectId ? state.projectModels[projectId]?.status ?? 'idle' : 'idle');
  const activateProject = useProjectActivation();

  const load = useCallback(async () => {
    if (!projectId) return;

    const state = useModelStore.getState();
    const existingEntry = state.projectModels[projectId];
    const existingModel = existingEntry?.model;
    const existingStatus = existingEntry?.status;

    if (existingModel) {
      activateProject(projectId);
      return;
    }

    if (existingStatus === 'loading') {
      return;
    }

    state.setProjectModelStatus(projectId, 'loading');

    try {
      const nextModel = await fetchProjectModel(projectId);
      state.setProjectModel(projectId, nextModel);
      useUiStore.getState().selectElement(null);
    } catch (loadError) {
      state.setProjectModelStatus(projectId, 'error', loadError);
    }
  }, [activateProject, projectId]);

  useEffect(() => {
    if (!projectId) return;

    if (cachedModel && modelProjectId !== projectId) {
      activateProject(projectId);
      return;
    }

    if (!cachedModel && status !== 'loading') {
      load();
    }
  }, [activateProject, cachedModel, load, modelProjectId, projectId, status]);
}
