import { useCallback, useState } from 'react';

// Mirrors useBottomPanel.js: manual open/close state. WorkbenchLayout is
// responsible for calling `open()` when a diagram selection happens; this
// hook only tracks whether the panel is currently shown.
export function useInspectorPanel(initialOpen = true) {
  const [isOpen, setIsOpen] = useState(initialOpen);

  const open = useCallback(() => setIsOpen(true), []);
  const close = useCallback(() => setIsOpen(false), []);
  const toggle = useCallback(() => setIsOpen((prev) => !prev), []);

  return { isOpen, open, close, toggle };
}
