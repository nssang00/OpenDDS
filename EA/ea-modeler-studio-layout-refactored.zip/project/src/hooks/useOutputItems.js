import { useMemo } from 'react';
import { useWorkbenchModel } from './useWorkbenchModel.js';
import { useModelSummary } from './useModelSummary.js';
import { buildOutputItems } from '../model/workbenchMessages.js';

export function useOutputItems() {
  const { model } = useWorkbenchModel();
  const summary = useModelSummary();

  return useMemo(() => (
    buildOutputItems({ model, summary })
  ), [model, summary]);
}
