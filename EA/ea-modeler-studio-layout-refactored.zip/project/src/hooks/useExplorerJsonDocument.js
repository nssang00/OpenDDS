import { useMemo } from 'react';
import { getExplorerJsonDocument } from '../model/explorerDocuments.js';
import { useWorkbenchModel } from './useWorkbenchModel.js';

export function useExplorerJsonDocument() {
  const { activeExplorerViewId, model } = useWorkbenchModel();

  return useMemo(() => (
    getExplorerJsonDocument(model, activeExplorerViewId)
  ), [activeExplorerViewId, model]);
}
