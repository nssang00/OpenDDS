import { useMemo } from 'react';
import { useSelectedElement } from './useSelectedElement.js';
import { buildElementPropertyGroups } from '../model/propertyModel.js';

export function useElementProperties() {
  const {
    appendElementPath,
    model,
    element,
    removeElementPath,
    updateElement,
    updateElementPath,
    updateProperty,
    updateQosPath,
  } = useSelectedElement();

  const propertyGroups = useMemo(() => {
    return buildElementPropertyGroups(model, element);
  }, [element, model]);

  return {
    model,
    element,
    appendElementPath,
    removeElementPath,
    updateElement,
    updateElementPath,
    updateProperty,
    updateQosPath,
    ...propertyGroups,
  };
}
