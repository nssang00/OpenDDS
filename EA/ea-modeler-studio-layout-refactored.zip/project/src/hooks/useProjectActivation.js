import { useCallback } from 'react';
import { useModelStore } from '../stores/useModelStore.js';
import { useUiStore } from '../stores/useUiStore.js';

export function useProjectActivation() {
  const activateProjectModel = useModelStore((state) => state.activateProjectModel);
  const selectedElementId = useUiStore((state) => state.selectedElementId);
  const selectElement = useUiStore((state) => state.selectElement);

  return useCallback((projectId) => {
    const model = useModelStore.getState().projectModels[projectId]?.model;
    if (!model) return false;

    const hasSelectedElement = selectedElementId && model.elementsById[selectedElementId];
    const activated = activateProjectModel(projectId);

    if (activated && !hasSelectedElement) {
      selectElement(null);
    }

    return activated;
  }, [activateProjectModel, selectElement, selectedElementId]);
}
