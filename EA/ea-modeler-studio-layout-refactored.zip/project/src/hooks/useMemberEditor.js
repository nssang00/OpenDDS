import { useStructMembers } from './useStructMembers.js';
import { buildMemberTypeOptions, firstTypeOptionValue } from '../model/typeReferenceModel.js';

export function useMemberEditor(elementId, members) {
  const { model, updateMembers } = useStructMembers(elementId);

  const patchMember = (memberIndex, patch) => {
    updateMembers(
      elementId,
      members.map((member, index) => (index === memberIndex ? compactMember({ ...member, ...patch }) : member))
    );
  };

  const updateMember = (memberIndex, nextMember) => {
    updateMembers(
      elementId,
      members.map((member, index) => (index === memberIndex ? compactMember(nextMember) : member))
    );
  };

  const addMember = () => {
    const nextIndex = members.length + 1;
    updateMembers(elementId, [
      ...members,
      { name: `member${nextIndex}`, kind: 'string', string_max_length: 255 },
    ]);
  };

  const removeMember = (memberIndex) => {
    updateMembers(
      elementId,
      members.filter((_, index) => index !== memberIndex)
    );
  };

  return {
    addMember,
    getDefaultType: (kind) => firstTypeOptionValue(model, kind),
    getTypeOptions: (kind) => buildMemberTypeOptions(model, kind),
    patchMember,
    removeMember,
    updateMember,
  };
}

function compactMember(member) {
  return Object.fromEntries(Object.entries(member).filter(([, value]) => value !== undefined));
}
