import { useModelStore } from '../stores/useModelStore.js';
import { useUiStore } from '../stores/useUiStore.js';

export function useWorkbenchModel() {
  const model = useModelStore((state) => state.model);
  const modelProjectId = useModelStore((state) => state.modelProjectId);
  const dirty = useModelStore((state) => state.dirty);
  const appendElementPath = useModelStore((state) => state.appendElementPath);
  const removeElementPath = useModelStore((state) => state.removeElementPath);
  const updateElement = useModelStore((state) => state.updateElement);
  const updateElementPath = useModelStore((state) => state.updateElementPath);
  const updateQosProperty = useModelStore((state) => state.updateQosProperty);
  const selectedElementId = useUiStore((state) => state.selectedElementId);
  const activeExplorerViewId = useUiStore((state) => state.activeExplorerViewId);
  const selectElement = useUiStore((state) => state.selectElement);

  return {
    model,
    modelProjectId,
    dirty,
    selectedElementId,
    activeExplorerViewId,
    selectElement,
    appendElementPath,
    removeElementPath,
    updateElement,
    updateElementPath,
    updateQosProperty,
  };
}
