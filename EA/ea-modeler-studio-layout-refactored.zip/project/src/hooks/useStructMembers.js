import { useSelectedElement } from './useSelectedElement.js';
import { useModelStore } from '../stores/useModelStore.js';
import { getElement } from '../model/modelSelectors.js';

export function useStructMembers(elementId) {
  const { element, model } = useSelectedElement();
  const updateMembers = useModelStore((state) => state.updateMembers);
  const targetElement = elementId ? getElement(model, elementId) : element;

  return {
    element: targetElement,
    model,
    members: targetElement?.properties?.members,
    updateMembers,
  };
}
