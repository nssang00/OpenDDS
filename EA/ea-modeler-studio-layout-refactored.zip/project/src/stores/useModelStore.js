import { create } from 'zustand';
import {
  appendElementPath,
  removeElementPath,
  updateElement,
  updateElementPath,
  updateElementProperty,
  updateMembers,
  updateQosPath,
  updateQosProperty,
} from '../model/modelUpdates.js';

export const useModelStore = create((set, get) => ({
  model: null,
  modelProjectId: null,
  projectModels: {},
  dirty: false,

  setProjectModelStatus: (projectId, status, error = null) => {
    set((state) => ({
      projectModels: {
        ...state.projectModels,
        [projectId]: {
          ...state.projectModels[projectId],
          status,
          error,
        },
      },
    }));
  },

  setProjectModel: (projectId, model) => {
    set((state) => ({
      model,
      modelProjectId: projectId,
      projectModels: {
        ...state.projectModels,
        [projectId]: {
          model,
          status: 'loaded',
          error: null,
        },
      },
      dirty: false,
    }));
  },

  activateProjectModel: (projectId) => {
    const model = get().projectModels[projectId]?.model;
    if (!model) return false;

    set({
      model,
      modelProjectId: projectId,
      dirty: false,
    });

    return true;
  },

  updateElement: (id, patch) => applyModelUpdate(set, (model) => updateElement(model, id, patch)),
  updateProperty: (id, key, value) => applyModelUpdate(set, (model) => updateElementProperty(model, id, key, value)),
  updateElementPath: (id, path, value) => applyModelUpdate(set, (model) => updateElementPath(model, id, path, value)),
  appendElementPath: (id, path, value) => applyModelUpdate(set, (model) => appendElementPath(model, id, path, value)),
  removeElementPath: (id, path, index) => applyModelUpdate(set, (model) => removeElementPath(model, id, path, index)),
  updateQosProperty: (id, entityKey, path, value) => applyModelUpdate(set, (model) => updateQosProperty(model, id, entityKey, path, value)),
  updateQosPath: (profileId, path, value) => applyModelUpdate(set, (model) => updateQosPath(model, profileId, path, value)),
  updateMembers: (id, members) => applyModelUpdate(set, (model) => updateMembers(model, id, members)),
}));

function applyModelUpdate(set, updateModel) {
  set((state) => {
    if (!state.model) return state;
    const nextModel = updateModel(state.model);
    if (nextModel === state.model) return state;

    return {
      model: nextModel,
      projectModels: {
        ...state.projectModels,
        [state.modelProjectId]: {
          ...state.projectModels[state.modelProjectId],
          model: nextModel,
          status: 'loaded',
          error: null,
        },
      },
      dirty: true,
    };
  });
}
