import { create } from 'zustand';

export const useUiStore = create((set) => ({
  selectedElementId: null,
  activeExplorerViewId: 'types',

  selectElement: (id) => set({ selectedElementId: id }),
  setActiveExplorerView: (id) => set({ activeExplorerViewId: id }),
}));
