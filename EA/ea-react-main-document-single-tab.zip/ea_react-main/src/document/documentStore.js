import { create } from 'zustand';

const initialState = {
  templateFile: null,
  templateBuffer: null,
  templateName: '',
  detectedTags: [],
  validationResult: null,
  selectedTarget: null,
  selectedTag: null,
  selectedExistingTag: null,
  generatedBlob: null,
  generatedBuffer: null,
  previewMode: 'template',
};

export const useDocumentStore = create((set) => ({
  ...initialState,

  setTemplate: (file, buffer) => set({
    templateFile: file,
    templateBuffer: buffer,
    templateName: file?.name ?? '',
    generatedBlob: null,
    generatedBuffer: null,
    selectedTarget: null,
    selectedExistingTag: null,
    previewMode: 'template',
  }),
  setDetectedTags: (detectedTags) => set({ detectedTags }),
  setValidationResult: (validationResult) => set({ validationResult }),
  setSelectedTarget: (selectedTarget) => set({ selectedTarget }),
  setSelectedTag: (selectedTag) => set({ selectedTag }),
  setSelectedExistingTag: (selectedExistingTag) => set({ selectedExistingTag }),
  setGeneratedDocument: (generatedBlob, generatedBuffer) => set({ generatedBlob, generatedBuffer }),
  setPreviewMode: (previewMode) => set({ previewMode }),
  resetDocument: () => set(initialState),
}));
