import { useMemo, useState } from 'react';
import { Alert, Button, Empty, Segmented, Space, Tag, Tree, Typography } from 'antd';
import { useModelStore } from '../stores/useModelStore.js';
import { useUiStore } from '../stores/useUiStore.js';
import { useDocumentStore } from '../document/documentStore.js';
import { createDocumentData } from '../document/documentMapper.js';
import { insertTag, removeTag, replaceTag, scanTemplateTags, validateTemplate } from '../document/docxTemplate.js';

const { Text } = Typography;

export default function DocumentBindingView() {
  const model = useModelStore((state) => state.model);
  const activeWorkspaceViewId = useUiStore((state) => state.activeWorkspaceViewId);
  const [mode, setMode] = useState('tree');
  const documentData = useMemo(() => createDocumentData(model), [model]);
  const treeData = useMemo(() => toTreeData(documentData), [documentData]);

  const {
    templateBuffer,
    templateName,
    selectedTarget,
    selectedTag,
    selectedExistingTag,
    validationResult,
    setTemplate,
    setDetectedTags,
    setValidationResult,
    setSelectedTag,
    setSelectedExistingTag,
    previewMode,
  } = useDocumentStore();

  const isDocument = activeWorkspaceViewId === 'document';
  const isTemplate = isDocument && previewMode === 'template';

  const updateTemplate = (nextBuffer) => {
    setTemplate({ name: templateName }, nextBuffer);
    setDetectedTags(scanTemplateTags(nextBuffer));
    setValidationResult(validateTemplate(nextBuffer, documentData));
  };

  const handleInsert = () => {
    if (!isTemplate || !templateBuffer || !selectedTarget || !selectedTag) return;
    updateTemplate(insertTag(templateBuffer, selectedTarget, selectedTag));
  };

  const handleReplace = () => {
    if (!isTemplate || !templateBuffer || !selectedExistingTag || !selectedTag) return;
    updateTemplate(replaceTag(templateBuffer, selectedExistingTag, selectedTag));
    setSelectedExistingTag(null);
  };

  const handleRemove = () => {
    if (!isTemplate || !templateBuffer || !selectedExistingTag) return;
    updateTemplate(removeTag(templateBuffer, selectedExistingTag));
    setSelectedExistingTag(null);
  };

  if (!isDocument) {
    return <div className="document-binding-view"><Empty description="Binding is available in Document view" /></div>;
  }

  if (!templateBuffer) {
    return <div className="document-binding-view"><Empty description="Open a template to inspect binding data" /></div>;
  }

  return (
    <div className="document-binding-view">
      <Segmented block size="small" value={mode} options={[{ label: 'Tree', value: 'tree' }, { label: 'JSON', value: 'json' }]} onChange={setMode} />

      {mode === 'tree' ? (
        <Tree
          className="document-data-tree"
          treeData={treeData}
          defaultExpandAll
          onSelect={(keys, info) => {
            if (info.node?.tagPath) setSelectedTag(info.node.tagPath);
          }}
        />
      ) : (
        <pre className="document-data-json">{JSON.stringify(documentData, null, 2)}</pre>
      )}

      <div className="document-binding-actions">
        <Text strong>Selected target</Text>
        <div className="document-binding-value">{describeTarget(selectedTarget)}</div>

        <Text strong>Binding</Text>
        <div className="document-binding-value">
          {selectedTag ? <Tag color="gold">{`{${selectedTag}}`}</Tag> : 'None'}
        </div>

        {selectedExistingTag && (
          <>
            <Text strong>Existing tag</Text>
            <div className="document-binding-value"><Tag>{`{${selectedExistingTag}}`}</Tag></div>
          </>
        )}

        <Space wrap>
          <Button type="primary" disabled={!isTemplate || !selectedTarget || !selectedTag} onClick={handleInsert}>Insert</Button>
          <Button disabled={!isTemplate || !selectedExistingTag || !selectedTag} onClick={handleReplace}>Replace</Button>
          <Button danger disabled={!isTemplate || !selectedExistingTag} onClick={handleRemove}>Remove</Button>
        </Space>
      </div>

      {validationResult && (
        <Alert
          className="document-binding-validation"
          type={validationResult.valid ? (validationResult.warnings.length ? 'warning' : 'success') : 'error'}
          showIcon
          message={validationResult.valid ? 'Template valid' : 'Template has errors'}
          description={`${validationResult.detectedTags.length} tags · ${validationResult.errors.length} errors · ${validationResult.warnings.length} warnings`}
        />
      )}
    </div>
  );
}

function toTreeData(data) {
  return Object.entries(data).map(([key, value]) => buildNode(key, value, []));
}

function buildNode(key, value, scope) {
  if (Array.isArray(value)) {
    const first = value[0];
    const nextScope = [...scope, key];
    return {
      key: `collection:${nextScope.join('.')}`,
      title: `${key} [${value.length}]`,
      children: first && typeof first === 'object'
        ? Object.entries(first).map(([childKey, childValue]) => buildNode(childKey, childValue, nextScope))
        : [],
    };
  }

  if (value && typeof value === 'object') {
    return {
      key: `group:${[...scope, key].join('.')}`,
      title: key,
      children: Object.entries(value).map(([childKey, childValue]) => buildNode(childKey, childValue, [...scope, key])),
    };
  }

  const tagPath = scope.some((part) => ['structures', 'members', 'enumerations', 'values', 'unions', 'cases'].includes(part))
    ? key
    : [...scope, key].join('.');

  return {
    key: `tag:${[...scope, key].join('.')}`,
    title: `${key}: ${formatValue(value)}`,
    tagPath,
    isLeaf: true,
  };
}

function formatValue(value) {
  if (value === '' || value == null) return '—';
  if (typeof value === 'boolean') return String(value);
  return String(value).length > 30 ? `${String(value).slice(0, 30)}…` : String(value);
}

function describeTarget(target) {
  if (!target) return 'None';
  if (target.type === 'paragraph') return `Paragraph ${target.paragraphIndex + 1}`;
  return `Table ${target.tableIndex + 1} / Row ${target.rowIndex + 1} / Cell ${target.cellIndex + 1}`;
}
