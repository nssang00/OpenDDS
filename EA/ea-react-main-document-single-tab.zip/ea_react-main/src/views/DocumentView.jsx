import { useEffect, useMemo, useRef } from 'react';
import { Button, Empty, Segmented, Space, Tag, Typography, Upload, message } from 'antd';
import { CheckCircleOutlined, DownloadOutlined, FileWordOutlined, UploadOutlined } from '@ant-design/icons';
import { useModelStore } from '../stores/useModelStore.js';
import { useDocumentStore } from '../document/documentStore.js';
import { createDocumentData } from '../document/documentMapper.js';
import { loadDocxTemplate, scanTemplateTags, validateTemplate } from '../document/docxTemplate.js';
import { downloadDocx, previewDocx, renderDocx } from '../document/docxRenderer.js';

const { Text } = Typography;
const TAG_PATTERN = /\{([^{}]+)\}/g;

export default function DocumentView() {
  const model = useModelStore((state) => state.model);
  const previewRef = useRef(null);

  const {
    templateBuffer,
    templateName,
    validationResult,
    generatedBlob,
    generatedBuffer,
    previewMode,
    setTemplate,
    setDetectedTags,
    setValidationResult,
    setSelectedTarget,
    setSelectedTag,
    setSelectedExistingTag,
    setGeneratedDocument,
    setPreviewMode,
  } = useDocumentStore();

  const documentData = useMemo(() => createDocumentData(model), [model]);
  const previewSource = previewMode === 'generated' ? generatedBuffer : templateBuffer;

  useEffect(() => {
    if (!previewSource || !previewRef.current) return;

    previewDocx(previewSource, previewRef.current)
      .then(() => {
        if (previewMode !== 'template') return;

        highlightTemplateTags(previewRef.current, (tag) => {
          setSelectedExistingTag(tag);
          setSelectedTag(tag.replace(/^#/, '').replace(/^\//, ''));
        });
        bindPreviewSelection(previewRef.current, setSelectedTarget);
      })
      .catch((error) => message.error(error.message));
  }, [previewMode, previewSource, setSelectedExistingTag, setSelectedTag, setSelectedTarget]);

  const applyValidation = (buffer) => {
    const result = validateTemplate(buffer, documentData);
    setDetectedTags(scanTemplateTags(buffer));
    setValidationResult(result);
    return result;
  };

  const handleOpen = async (file) => {
    try {
      const buffer = await loadDocxTemplate(file);
      setTemplate(file, buffer);
      setPreviewMode('template');
      const result = applyValidation(buffer);
      message.success(result.valid
        ? `Template loaded: ${file.name}`
        : `Template loaded with ${result.errors.length} validation error(s)`);
    } catch (error) {
      message.error(error.message);
    }
    return false;
  };

  const handleGenerate = async () => {
    if (!templateBuffer) return;
    const result = applyValidation(templateBuffer);
    if (!result.valid) {
      message.error('Fix template validation errors before generating');
      return;
    }

    try {
      const generated = await renderDocx(templateBuffer, documentData);
      setGeneratedDocument(generated.generatedBlob, generated.generatedBuffer);
      setPreviewMode('generated');
      message.success('Document generated');
    } catch (error) {
      message.error(error.message);
    }
  };

  return (
    <div className="document-view">
      <div className="document-toolbar">
        <Space wrap>
          <Upload accept=".docxtpl,.docx" beforeUpload={handleOpen} showUploadList={false}>
            <Button icon={<UploadOutlined />}>Open Template</Button>
          </Upload>
          <Button
            icon={<CheckCircleOutlined />}
            disabled={!templateBuffer || previewMode !== 'template'}
            onClick={() => applyValidation(templateBuffer)}
          >
            Validate
          </Button>
          <Button
            type="primary"
            icon={<FileWordOutlined />}
            disabled={!templateBuffer}
            onClick={handleGenerate}
          >
            Generate
          </Button>
          <Button
            icon={<DownloadOutlined />}
            disabled={!generatedBlob}
            onClick={() => downloadDocx(generatedBlob, generatedName(templateName))}
          >
            Download
          </Button>
        </Space>

        <Space size="small" wrap>
          {templateName && <Text type="secondary">{templateName}</Text>}
          {validationResult && previewMode === 'template' && (
            <Tag color={validationResult.valid ? (validationResult.warnings.length ? 'gold' : 'green') : 'red'}>
              {validationResult.errors.length} errors · {validationResult.warnings.length} warnings
            </Tag>
          )}
          <Segmented
            size="small"
            value={previewMode}
            options={[
              { label: 'Template', value: 'template' },
              { label: 'Generated', value: 'generated', disabled: !generatedBuffer },
            ]}
            onChange={setPreviewMode}
          />
        </Space>
      </div>

      <div className="document-preview-panel">
        {!templateBuffer ? (
          <Empty description="Open a DOCX template (.docxtpl) to start" />
        ) : previewMode === 'generated' && !generatedBuffer ? (
          <Empty description="Generate the document to preview the result" />
        ) : (
          <div ref={previewRef} className="document-docx-preview" />
        )}
      </div>
    </div>
  );
}

function highlightTemplateTags(root, onTagClick) {
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
  const nodes = [];
  while (walker.nextNode()) nodes.push(walker.currentNode);

  nodes.forEach((textNode) => {
    const text = textNode.nodeValue ?? '';
    TAG_PATTERN.lastIndex = 0;
    if (!TAG_PATTERN.test(text)) return;

    TAG_PATTERN.lastIndex = 0;
    const fragment = document.createDocumentFragment();
    let cursor = 0;
    let match;

    while ((match = TAG_PATTERN.exec(text)) !== null) {
      if (match.index > cursor) {
        fragment.append(document.createTextNode(text.slice(cursor, match.index)));
      }

      const tag = match[1].trim();
      const marker = document.createElement('span');
      marker.className = 'document-template-tag';
      marker.textContent = match[0];
      marker.dataset.tag = tag;
      marker.title = `Binding: ${tag}`;
      marker.addEventListener('click', (event) => {
        event.stopPropagation();
        root.querySelectorAll('.document-template-tag--selected').forEach((node) => {
          node.classList.remove('document-template-tag--selected');
        });
        marker.classList.add('document-template-tag--selected');
        onTagClick(tag);
      });
      fragment.append(marker);
      cursor = match.index + match[0].length;
    }

    if (cursor < text.length) {
      fragment.append(document.createTextNode(text.slice(cursor)));
    }
    textNode.parentNode?.replaceChild(fragment, textNode);
  });
}

function bindPreviewSelection(root, onSelect) {
  root.querySelectorAll('p').forEach((node, paragraphIndex) => {
    node.classList.add('document-selectable');
    node.addEventListener('click', (event) => {
      if (event.target.closest('td') || event.target.closest('.document-template-tag')) return;
      clearSelection(root);
      node.classList.add('document-selected-target');
      onSelect({ type: 'paragraph', paragraphIndex });
    });
  });

  root.querySelectorAll('table').forEach((table, tableIndex) => {
    [...table.rows].forEach((row, rowIndex) => {
      [...row.cells].forEach((cell, cellIndex) => {
        cell.classList.add('document-selectable');
        cell.addEventListener('click', (event) => {
          if (event.target.closest('.document-template-tag')) return;
          event.stopPropagation();
          clearSelection(root);
          cell.classList.add('document-selected-target');
          onSelect({ type: 'tableCell', tableIndex, rowIndex, cellIndex });
        });
      });
    });
  });
}

function clearSelection(root) {
  root.querySelectorAll('.document-selected-target').forEach((node) => {
    node.classList.remove('document-selected-target');
  });
}

function generatedName(templateName) {
  if (!templateName) return 'generated-document.docx';
  return templateName.replace(/\.(docxtpl|docx)$/i, '-generated.docx');
}
