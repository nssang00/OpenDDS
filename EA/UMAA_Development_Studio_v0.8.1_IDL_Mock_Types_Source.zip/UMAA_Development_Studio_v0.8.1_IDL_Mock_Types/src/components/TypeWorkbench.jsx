import { useState } from 'react';
import { Alert, Button, Checkbox, Descriptions, Divider, Empty, Form, Input, Modal, Select, Space, Table, Tag, Typography, message } from 'antd';
import { DeleteOutlined, EditOutlined, PlusOutlined } from '@ant-design/icons';
import { useEditorStore } from '../stores/useEditorStore.js';
import { effectiveTypeFields } from '../model/mockIdlCatalog.js';
const {Text}=Typography;
const primitive=['boolean','octet','short','unsigned short','long','unsigned long','long long','unsigned long long','float','double','string','char'];
const validName=/^[A-Za-z_][A-Za-z0-9_]*$/;
export function renderIdlPreview(type) {
  if(type.source!=='custom') {
    const fieldLines=(type.fields??[]).map(f=>`  ${f.key?'@key ':''}${f.optional?'@optional ':''}${f.type} ${f.name};`).join('\n');
    return [
      '// ICD-DERIVED MOCK TYPE — NOT OFFICIAL UMAA IDL',
      '// Display-only pseudo-IDL. Do not compile or use for DDS interoperability.',
      `// Source: ${type.reference??'UMAA ICD 6.0 (external reference)'}`,
      `// Namespace: ${type.namespace}`,
      ...(type.baseType?[`// Common fields from: ${type.baseType}`]:[]),
      ...(type.mockNote?[`// Note: ${type.mockNote}`]:[]),
      `struct ${type.name} {`, fieldLines || '  // No additional fields in this ICD table.', '};',
    ].join('\n');
  }
  const ns=(type.namespace??'ProjectCustom').split('::').filter(Boolean);
  const prefix=ns.map((n,i)=>`${'  '.repeat(i)}module ${n} {`).join('\n');
  const suffix=ns.slice().reverse().map((_,i)=>`${'  '.repeat(ns.length-1-i)}};`).join('\n');
  const indent='  '.repeat(ns.length);
  let body='';
  if(type.kind==='enum')body=`${indent}enum ${type.name} {\n${type.members.map(v=>`${indent}  ${v}`).join(',\n')}\n${indent}};`;
  else body=`${indent}struct ${type.name} {\n${(type.fields??[]).map(f=>`${indent}  ${f.key?'@key ':''}${f.optional?'@optional ':''}${f.type} ${f.name};`).join('\n')}\n${indent}};`;
  return [`// PROJECT EXTENSION — NOT OFFICIAL UMAA IDL`,prefix,body,suffix].join('\n');
}
export function TypeWorkbench({ kind, id }) {
  const snapshot=useEditorStore(s=>s.snapshot);
  const select=useEditorStore(s=>s.select);
  const addField=useEditorStore(s=>s.addMessageField);
  const removeField=useEditorStore(s=>s.removeMessageField);
  const updateField=useEditorStore(s=>s.updateMessageField);
  const addTypeField=useEditorStore(s=>s.addDataTypeField);
  const removeTypeField=useEditorStore(s=>s.removeDataTypeField);
  const updateTypeField=useEditorStore(s=>s.updateDataTypeField);
  const addEnum=useEditorStore(s=>s.addEnumMember);
  const updateEnum=useEditorStore(s=>s.updateEnumMember);
  const removeEnum=useEditorStore(s=>s.removeEnumMember);
  const [editing,setEditing]=useState(null);
  const [form]=Form.useForm();
  const t=kind==='message'?snapshot?.messages.find(m=>m.id===id):snapshot?.dataTypes.find(m=>m.id===id);
  if(!t)return <Empty description="Type을 선택하세요"/>;
  const isCustom=t.source==='custom';
  const isEnum=t.kind==='enum';
  const rows=isEnum?(t.members??[]).map(name=>({name,type:'enumerator'})):(isCustom?t.fields??[]:effectiveTypeFields(snapshot,t));
  const types=[...primitive,...(snapshot?.dataTypes??[]).filter(x=>x.id!==id).map(x=>`${x.namespace}::${x.name}`),...(snapshot?.messages??[]).filter(x=>x.id!==id&&x.source==='custom').map(x=>`${x.namespace}::${x.name}`)];
  const openForm=(row=null)=>{
    const old=row?{...row}:null;
    setEditing({oldName:row?.name??null});
    form.setFieldsValue(row ? {name:row.name,type:row.type,key:Boolean(row.key),optional:Boolean(row.optional)} : {name:'',type:'double',key:false,optional:false});
  };
  const submit=async()=>{
    try {
      const values=await form.validateFields();
      if(values.key && values.optional){message.error('IDL의 @key와 @optional은 동시에 지정할 수 없습니다.');return;}
      const patch=isEnum?{name:values.name}:{name:values.name,type:values.type,key:!!values.key,optional:!!values.optional};
      let ok=false;
      if(isEnum)ok=editing.oldName?updateEnum(id,editing.oldName,values.name):addEnum(id,values.name);
      else if(kind==='message')ok=editing.oldName?updateField(id,editing.oldName,patch):addField(id,values.name,values.type,patch);
      else ok=editing.oldName?updateTypeField(id,editing.oldName,patch):addTypeField(id,values.name,values.type,patch);
      if(!ok){message.error('중복된 IDL 식별자 또는 올바르지 않은 필드 정의입니다.');return;}
      message.success('Custom IDL Type을 수정했습니다.');setEditing(null);form.resetFields();
    }catch{}
  };
  const remove=row=>Modal.confirm({title:`${row.name} 삭제`,content:'이 필드/열거자에 의존하는 사용자 코드가 있다면 별도 검토가 필요합니다.',onOk:()=>{
    if(isEnum)removeEnum(id,row.name); else if(kind==='message')removeField(id,row.name); else removeTypeField(id,row.name);
  }});
  const usedTopics=(snapshot?.topics??[]).filter(tpc=>tpc.messageTypeId===id);
  return <div className="center-workbench">
    <div className="editor-heading"><div><Text type="secondary" className="editor-eyebrow">IDL TYPE DESIGNER</Text><h2>{t.name}</h2>
      <Space wrap><Tag color={isCustom?'purple':'blue'}>{isCustom?'PROJECT EXTENSION':'ICD MOCK · READ ONLY'}</Tag><Tag>{isEnum?'Enum':kind==='message'?'Message Type':'Struct'}</Tag></Space></div>
      {isCustom&&<Button type="primary" icon={<PlusOutlined/>} onClick={()=>openForm()}>{isEnum?'Enumerator 추가':'Field 추가'}</Button>}
    </div>
    <Descriptions size="small" bordered column={1} style={{marginBottom:16}}><Descriptions.Item label="Namespace"><Text code>{t.namespace}</Text></Descriptions.Item><Descriptions.Item label="Origin">{isCustom?'Project Extension':'UMAA 6.0 ICD attribute table → curated mock (original .idl not loaded)'}</Descriptions.Item>{!isCustom&&<><Descriptions.Item label="Reference">{t.reference??'UMAA ICD 6.0'}</Descriptions.Item>{t.baseType&&<Descriptions.Item label="Common Fields"><Text code>{t.baseType}</Text></Descriptions.Item>}</>}</Descriptions>
    {!isCustom&&<Alert showIcon type="warning" message="ICD 기반 목 데이터 — 공식 IDL 아님" description="ICD 표의 필드명·타입·Key/Optional 정보 일부를 탐색용으로 구성했습니다. 원본 .idl의 typedef, bounds, annotations, union 및 완전한 DDS 호환성은 미검증입니다. 필드와 공통 필드 상속은 읽기 전용입니다." style={{marginBottom:16}}/>}
    {t.mockNote&&<Alert type="info" showIcon style={{marginBottom:12}} message={t.mockNote}/>}
    <h3>{isEnum?'Enumerators':'Fields'} {!isCustom&&<Text type="secondary" style={{fontSize:12}}>({t.fields?.length??0} declared · {rows.filter(r=>r.inherited).length} inherited)</Text>}</h3>
    <Table size="small" pagination={false} rowKey="name" dataSource={rows} locale={{emptyText:isCustom?'필드를 추가하세요':'ICD 목 데이터에 필드 정보 없음'}} columns={[
      {title:'Name',dataIndex:'name',width:'28%',render:(v,r)=><Space size={4}><Text>{v}</Text>{r.inherited&&<Tag>inherited</Tag>}</Space>},
      ...(!isEnum?[{title:'IDL Type',dataIndex:'type',render:v=><Text code>{v}</Text>},{title:'Annotations',render:(_,r)=><Space>{r.key&&<Tag color="blue">@key</Tag>}{r.optional&&<Tag color="purple">@optional</Tag>}</Space>}]:[]),
      ...(isCustom?[{title:'Edit',width:102,render:(_,row)=><Space><Button size="small" icon={<EditOutlined/>} onClick={()=>openForm(row)}/><Button size="small" danger icon={<DeleteOutlined/>} onClick={()=>remove(row)}/></Space>}]:[])
    ]}/>
    <h3>{isCustom?'IDL Source Preview':'ICD Mock Shape Preview (not compilable)'}</h3><pre className="idl-source-preview">{renderIdlPreview(t)}</pre>
    {usedTopics.length>0&&<><h3>Referenced by Topics</h3><Space wrap>{usedTopics.map(tp=><Button key={tp.id} onClick={()=>select({kind:'topic',id:tp.id})}>{tp.name}</Button>)}</Space></>}
    {isCustom&&<Alert type="warning" showIcon style={{marginTop:16}} message="IDL 구문 검증·TypeSupport 컴파일은 별도 단계입니다." description="이 편집기는 Struct/Enum과 단순 필드를 다룹니다. Union, typedef, bounded sequences 등 고급 IDL은 아직 완전 지원하지 않습니다."/>}
    <Modal title={editing?.oldName?'IDL 항목 수정':'IDL 항목 추가'} forceRender open={Boolean(editing)} onCancel={()=>setEditing(null)} onOk={submit} okText="적용" destroyOnClose>
      <Form form={form} layout="vertical" preserve={false}>
        <Form.Item name="name" label={isEnum?'Enumerator Name':'Field Name'} rules={[{required:true},{pattern:validName,message:'유효한 IDL 식별자를 입력하세요'}]}><Input/></Form.Item>
        {!isEnum&&<><Form.Item name="type" label="IDL Type" rules={[{required:true}]}><Select showSearch optionFilterProp="label" options={types.map(type=>({label:type,value:type}))}/></Form.Item><Space><Form.Item name="key" valuePropName="checked"><Checkbox>@key</Checkbox></Form.Item><Form.Item name="optional" valuePropName="checked"><Checkbox>@optional</Checkbox></Form.Item></Space></>}
      </Form>
    </Modal>
  </div>;
}
