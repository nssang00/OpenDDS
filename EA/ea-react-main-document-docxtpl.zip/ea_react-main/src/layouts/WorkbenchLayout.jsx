import { DownOutlined, UpOutlined } from '@ant-design/icons';
import { Button, Splitter } from 'antd';
import { useBottomPanel } from '../hooks/useBottomPanel.js';
import { useEnsureProjectModel } from '../hooks/useEnsureProjectModel.js';
import { useProjects } from '../hooks/useProjects.js';
import { workbenchPanelsConfig } from './workbenchPanels.config.js';
import WorkbenchPanelRenderer from './WorkbenchPanelRenderer.jsx';

export default function WorkbenchLayout() {
  const bottomPanelState = useBottomPanel(false);
  const { currentProject } = useProjects();
  useEnsureProjectModel(currentProject?.id ?? 'project-vehicle');

  const [explorerPanel, workspacePanel, inspectorPanel, bottomPanel] = workbenchPanelsConfig.panels;

  return (
    <Splitter className="workbench-layout" collapsible={{ motion: true }}>
      <Splitter.Panel
        defaultSize={explorerPanel.defaultSize}
        min={explorerPanel.min}
        max={explorerPanel.max}
        collapsible={{ end: true, showCollapsibleIcon: true }}
        className="workbench-layout__explorer"
      >
        <WorkbenchPanelRenderer panel={explorerPanel} />
      </Splitter.Panel>

      <Splitter.Panel min={workspacePanel.min}>
        <div className="workbench-main-stack">
          <Splitter layout="vertical" className="workbench-main-splitter">
            <Splitter.Panel min={360}>
              <Splitter className="workbench-main-content" collapsible={{ motion: true }}>
                <Splitter.Panel
                  min={workspacePanel.min}
                  className="workbench-layout__workspace"
                >
                  <WorkbenchPanelRenderer panel={workspacePanel} />
                </Splitter.Panel>

                <Splitter.Panel
                  defaultSize={inspectorPanel.defaultSize}
                  min={inspectorPanel.min}
                  max={inspectorPanel.max}
                  collapsible={{ start: true, showCollapsibleIcon: true }}
                  className="workbench-layout__inspector"
                >
                  <WorkbenchPanelRenderer panel={inspectorPanel} />
                </Splitter.Panel>
              </Splitter>
            </Splitter.Panel>

            {bottomPanelState.isOpen && (
              <Splitter.Panel
                defaultSize={bottomPanel.defaultSize}
                min={bottomPanel.min}
                max={bottomPanel.max}
                className="workbench-layout__bottom"
              >
                <BottomPanelFrame panel={bottomPanel} onClose={bottomPanelState.close} />
              </Splitter.Panel>
            )}
          </Splitter>

          {!bottomPanelState.isOpen && (
            <BottomPanelDock onOpen={bottomPanelState.open} />
          )}
        </div>
      </Splitter.Panel>
    </Splitter>
  );
}

function BottomPanelFrame({ onClose, panel }) {
  return (
    <div className="bottom-panel-frame">
      <BottomPanelHandle
        ariaLabel="Close output panel"
        icon={<DownOutlined />}
        mode="open"
        onClick={onClose}
      />
      <WorkbenchPanelRenderer panel={panel} />
    </div>
  );
}

function BottomPanelDock({ onOpen }) {
  return (
    <div className="bottom-panel-dock">
      <BottomPanelHandle
        ariaLabel="Open output panel"
        icon={<UpOutlined />}
        mode="closed"
        onClick={onOpen}
      />
    </div>
  );
}

function BottomPanelHandle({ ariaLabel, icon, mode, onClick }) {
  return (
    <div className={`bottom-panel-handle bottom-panel-handle--${mode}`}>
      <Button
        className="bottom-panel-handle-button"
        type="text"
        size="small"
        icon={icon}
        aria-label={ariaLabel}
        onClick={onClick}
      />
    </div>
  );
}
