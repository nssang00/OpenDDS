import { Checkbox, Input, InputNumber, Select } from 'antd';

export default function QosFieldControl({ field, onChange, variant = 'panel' }) {
  const commonProps = {
    className: `qos-editor-control qos-editor-control--${variant} nodrag`,
    onClick: stop,
    onMouseDown: stop,
  };

  if (field.options?.length) {
    return (
      <Select
        {...commonProps}
        options={field.options}
        popupMatchSelectWidth={false}
        size={variant === 'diagram' ? 'small' : 'middle'}
        value={field.value}
        onChange={onChange}
      />
    );
  }

  if (typeof field.value === 'boolean') {
    return (
      <Checkbox
        {...commonProps}
        checked={field.value}
        onChange={(event) => onChange(event.target.checked)}
      />
    );
  }

  if (typeof field.value === 'number') {
    return (
      <InputNumber
        {...commonProps}
        size={variant === 'diagram' ? 'small' : 'middle'}
        value={field.value}
        onChange={onChange}
      />
    );
  }

  return (
    <Input
      {...commonProps}
      size={variant === 'diagram' ? 'small' : 'middle'}
      value={Array.isArray(field.value) ? field.value.join(', ') : String(field.value ?? '')}
      onChange={(event) => onChange(event.target.value)}
    />
  );
}

function stop(event) {
  event.stopPropagation();
}
