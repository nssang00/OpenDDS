import { useMemo, useState } from 'react';
import AccordionRow from '../editor-blocks/AccordionRow.jsx';
import QosFieldControl from './QosFieldControl.jsx';

export default function QosPolicyAccordion({ onAppend, onChange, policies, actions = [], variant = 'panel' }) {
  const defaultOpenKeys = useMemo(() => {
    if (variant === 'diagram') return [];
    return policies.map((policy) => policy.key);
  }, [policies, variant]);
  const [openKeys, setOpenKeys] = useState(defaultOpenKeys);
  const [isAdding, setIsAdding] = useState(false);

  if (!policies.length && !actions.length) {
    return <div className="qos-editor-empty">No policies.</div>;
  }

  const togglePolicy = (key) => {
    setOpenKeys((current) => (
      current.includes(key)
        ? current.filter((item) => item !== key)
        : [...current, key]
    ));
  };

  return (
    <div className={`qos-editor-policies qos-editor-policies--${variant}`}>
      {policies.map((policy) => {
        const isOpen = openKeys.includes(policy.key);
        return (
          <AccordionRow
            body={(
              <div className={`qos-editor-policy-body qos-editor-policy-body--${variant}`}>
                <div className={`qos-editor-fields qos-editor-fields--${variant}`}>
                  {policy.fields.map((field) => (
                    <label className="qos-editor-field" key={field.path ?? field.key} title={field.path ?? field.key}>
                      <span>{field.label}</span>
                      <QosFieldControl
                        field={field}
                        variant={variant}
                        onChange={(value) => onChange(field, value)}
                      />
                    </label>
                  ))}
                </div>
              </div>
            )}
            caretClassName="qos-editor-policy-caret"
            className={`qos-editor-policy-row qos-editor-policy-row--${variant}`}
            headClassName="qos-editor-policy-head"
            key={policy.key}
            open={isOpen}
            openClassName="qos-editor-policy-row--open"
            onToggle={() => togglePolicy(policy.key)}
          >
              <span className="qos-editor-policy-label">
                <b>{policy.key}</b>
                <em>{policy.label}</em>
              </span>
              <small className="qos-editor-policy-count">{policy.fields.length}</small>
          </AccordionRow>
        );
      })}

      {actions.length > 0 && (
        <div className={`qos-editor-actions qos-editor-actions--${variant}`}>
          {isAdding ? (
            <div className="qos-editor-add-panel">
              <span>Add Policy</span>
              <div>
                {actions.map((action) => (
                  <button
                    className="qos-editor-add-chip nodrag"
                    key={action.key}
                    type="button"
                    onClick={(event) => {
                      event.stopPropagation();
                      setIsAdding(false);
                      onAppend?.(action);
                    }}
                    onMouseDown={(event) => event.stopPropagation()}
                  >
                    + {action.key}
                  </button>
                ))}
              </div>
              <button
                className="qos-editor-cancel nodrag"
                type="button"
                onClick={(event) => {
                  event.stopPropagation();
                  setIsAdding(false);
                }}
                onMouseDown={(event) => event.stopPropagation()}
              >
                Cancel
              </button>
            </div>
          ) : (
            <button
              className="qos-editor-add qos-editor-add--full nodrag"
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                setIsAdding(true);
              }}
              onMouseDown={(event) => event.stopPropagation()}
            >
              + Add Policy
            </button>
          )}
        </div>
      )}
    </div>
  );
}
