import { useMemo, useState } from 'react';
import Caret from '../editor-blocks/Caret.jsx';
import QosPolicyAccordion from './QosPolicyAccordion.jsx';

const ENTITY_COLORS = {
  topic_qos: '#d48806',
  datawriter_qos: '#0958d9',
  datareader_qos: '#c41d7f',
  publisher_qos: '#1677ff',
  subscriber_qos: '#eb2f96',
  domain_participant_qos: '#389e0d',
};

export default function QosEntitySections({ onAppend, onChange, tabs, variant = 'panel' }) {
  const defaultOpenKeys = useMemo(() => {
    if (variant === 'diagram') return [];
    const firstWithPolicies = tabs.find((tab) => tab.policies.length > 0);
    return [firstWithPolicies?.key ?? tabs[0]?.key].filter(Boolean);
  }, [tabs, variant]);
  const [openKeys, setOpenKeys] = useState(defaultOpenKeys);

  const toggleSection = (key) => {
    setOpenKeys((current) => (
      current.includes(key)
        ? current.filter((item) => item !== key)
        : [...current, key]
    ));
  };

  return (
    <div className={`qos-editor-sections qos-editor-sections--${variant}`}>
      {tabs.map((tab) => {
        const color = ENTITY_COLORS[tab.key] ?? '#722ed1';
        const isOpen = openKeys.includes(tab.key);
        return (
          <section
            className={`qos-editor-section qos-editor-section--${variant}`}
            key={tab.key}
            style={{ '--qos-section-color': color }}
          >
            <button
              className="qos-editor-section-head nodrag"
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                toggleSection(tab.key);
              }}
              onMouseDown={(event) => event.stopPropagation()}
            >
              <b>{tab.key}</b>
              <span>{tab.label}</span>
              {tab.policies.length > 0 && <small>{tab.policies.length}</small>}
              <Caret className="qos-editor-section-caret" open={isOpen} />
            </button>

            {isOpen && (
              <div className="qos-editor-section-body">
                <QosPolicyAccordion
                  actions={tab.actions}
                  policies={tab.policies}
                  variant={variant}
                  onAppend={(action) => onAppend?.(tab, action)}
                  onChange={onChange}
                />
              </div>
            )}
          </section>
        );
      })}
    </div>
  );
}
