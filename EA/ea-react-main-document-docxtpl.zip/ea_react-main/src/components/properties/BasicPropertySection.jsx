import { useEffect } from 'react';
import { Form, Input, InputNumber, Select } from 'antd';

const RELIABILITY_OPTIONS = [
  { label: 'RELIABLE', value: 'RELIABLE' },
  { label: 'BEST_EFFORT', value: 'BEST_EFFORT' },
];

const DURABILITY_OPTIONS = [
  { label: 'VOLATILE', value: 'VOLATILE' },
  { label: 'TRANSIENT_LOCAL', value: 'TRANSIENT_LOCAL' },
  { label: 'TRANSIENT', value: 'TRANSIENT' },
  { label: 'PERSISTENT', value: 'PERSISTENT' },
];

export default function BasicPropertySection({ element, properties, onUpdateElement, onUpdateProperty }) {
  const [form] = Form.useForm();

  useEffect(() => {
    if (!element) return;
    form.setFieldsValue({ name: element.name, type: element.type, ...element.properties });
  }, [element, form]);

  return (
    <Form
      className="basic-property-form"
      form={form}
      layout="vertical"
      onValuesChange={(changed) => {
        const [key, value] = Object.entries(changed)[0];
        if (key === 'name') onUpdateElement(element.id, { name: value });
        else if (key !== 'type') onUpdateProperty(element.id, key, value);
      }}
    >
      <div className="basic-property-grid">
        <Form.Item className="basic-property-field basic-property-field--name" label="name" name="name"><Input /></Form.Item>
        <Form.Item className="basic-property-field basic-property-field--type" label="type" name="type"><Input disabled /></Form.Item>

        {properties.map(([key, value]) => (
          <Form.Item className="basic-property-field" key={key} label={key} name={key}>{fieldInputFor(key, value)}</Form.Item>
        ))}
      </div>
    </Form>
  );
}

function fieldInputFor(key, value) {
  if (key === 'reliability') return <Select options={RELIABILITY_OPTIONS} />;
  if (key === 'durability') return <Select options={DURABILITY_OPTIONS} />;
  if (typeof value === 'number') return <InputNumber style={{ width: '100%' }} />;
  return <Input />;
}
