import { useState } from 'react';
import { Button, Space } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import MemberRow from './MemberRow.jsx';

export default function MemberList({
  getDefaultType,
  getTypeOptions,
  members,
  onAddMember,
  onPatchMember,
  onRemoveMember,
  onUpdateMember,
}) {
  const [openIndex, setOpenIndex] = useState(null);

  const handleAdd = () => {
    onAddMember();
    setOpenIndex(members.length);
  };

  const handleRemove = (index) => {
    onRemoveMember(index);
    setOpenIndex((current) => {
      if (current === index) return null;
      if (current > index) return current - 1;
      return current;
    });
  };

  return (
    <Space className="member-list" direction="vertical" size={8}>
      <Button icon={<PlusOutlined />} onClick={handleAdd} block>
        Add member
      </Button>

      {members.map((member, index) => (
        <MemberRow
          key={`${member.name || 'member'}-${index}`}
          getDefaultType={getDefaultType}
          getTypeOptions={getTypeOptions}
          isOpen={openIndex === index}
          member={member}
          onPatch={(patch) => onPatchMember(index, patch)}
          onRemove={() => handleRemove(index)}
          onToggle={() => setOpenIndex(openIndex === index ? null : index)}
          onUpdate={(nextMember) => onUpdateMember(index, nextMember)}
        />
      ))}
    </Space>
  );
}
