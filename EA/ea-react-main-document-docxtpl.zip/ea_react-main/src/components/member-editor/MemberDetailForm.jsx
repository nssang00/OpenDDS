import { Checkbox, Input, Select } from 'antd';
import {
  KIND_SELECT_OPTIONS,
  buildMemberIdlPreview,
} from './memberDisplay.js';
import {
  needsArrayDimensions,
  needsElementType,
  needsSequenceMaxLength,
  needsStringMaxLength,
  normalizeMemberKind,
  parseArrayDimensions,
  annotationValue,
  patchAnnotation,
} from '../../model/memberModel.js';

export default function MemberDetailForm({
  getDefaultType,
  getTypeOptions,
  member,
  onPatch,
  onUpdate,
}) {
  return (
    <div className="member-detail">
      <div className="member-detail-grid">
        <label className="member-detail-field">
          <span className="member-detail-label">Name</span>
          <Input
            value={member.name}
            onChange={(event) => onPatch({ name: event.target.value })}
          />
        </label>

        <label className="member-detail-field">
          <span className="member-detail-label">Kind</span>
          <Select
            options={KIND_SELECT_OPTIONS}
            value={member.kind}
            onChange={(kind) => onUpdate(normalizeMemberKind(member, kind, getDefaultType(kind)))}
            style={{ width: '100%' }}
          />
        </label>

        {needsElementType(member.kind) && (
          <label className="member-detail-field member-detail-field--wide">
            <span className="member-detail-label">Type</span>
            <Select
              showSearch
              options={getTypeOptions(member.kind)}
              optionFilterProp="label"
              value={member.type}
              onChange={(type) => onPatch({ type })}
              style={{ width: '100%' }}
            />
          </label>
        )}

        {needsStringMaxLength(member.kind) && (
          <label className="member-detail-field">
            <span className="member-detail-label">String Max Length</span>
            <Input
              value={member.string_max_length}
              onChange={(event) => onPatch({ string_max_length: boundValue(event.target.value) })}
            />
          </label>
        )}

        {needsSequenceMaxLength(member.kind) && (
          <label className="member-detail-field">
            <span className="member-detail-label">Sequence Max Length</span>
            <Input
              value={member.sequence_max_length}
              onChange={(event) => onPatch({ sequence_max_length: boundValue(event.target.value) })}
            />
          </label>
        )}

        {needsArrayDimensions(member.kind) && (
          <label className="member-detail-field">
            <span className="member-detail-label">Array Dimensions</span>
            <Input
              value={(member.array_dimensions ?? []).join(',')}
              onChange={(event) => onPatch({ array_dimensions: parseArrayDimensions(event.target.value) })}
            />
          </label>
        )}

        <MemberAnnotationFields member={member} onPatch={onPatch} />
      </div>

      <div className="member-idl-preview">
        <span className="member-detail-label">IDL Preview</span>
        <code>{buildMemberIdlPreview(member) || 'Complete the member name to preview IDL.'}</code>
      </div>
    </div>
  );
}

function boundValue(value) {
  const trimmed = value.trim();
  if (!trimmed) return undefined;
  const numberValue = Number(trimmed);
  return Number.isNaN(numberValue) ? trimmed : numberValue;
}

function MemberAnnotationFields({ member, onPatch }) {
  return (
    <div className="member-detail-field member-detail-field--inline">
      <span className="member-detail-label">Annotations</span>
      <Checkbox
        checked={annotationValue(member, 'key')}
        onChange={(event) => onPatch(patchAnnotation(member, 'key', event.target.checked))}
      >
        key
      </Checkbox>
      <Checkbox
        checked={annotationValue(member, 'optional')}
        onChange={(event) => onPatch(patchAnnotation(member, 'optional', event.target.checked))}
      >
        optional
      </Checkbox>
    </div>
  );
}
