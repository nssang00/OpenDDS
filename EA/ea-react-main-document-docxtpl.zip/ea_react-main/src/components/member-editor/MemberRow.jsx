import { Button, Popconfirm, Tag } from 'antd';
import { CloseOutlined } from '@ant-design/icons';
import AccordionRow from '../editor-blocks/AccordionRow.jsx';
import MemberDetailForm from './MemberDetailForm.jsx';
import { kindGroupLabel, memberTypeLabel } from './memberDisplay.js';

export default function MemberRow({
  getDefaultType,
  getTypeOptions,
  isOpen,
  member,
  onPatch,
  onRemove,
  onToggle,
  onUpdate,
}) {
  return (
    <AccordionRow
      body={(
        <MemberDetailForm
          getDefaultType={getDefaultType}
          getTypeOptions={getTypeOptions}
          member={member}
          onPatch={onPatch}
          onUpdate={onUpdate}
        />
      )}
      caretClassName="member-row-caret"
      className="member-row"
      headClassName="member-row-header"
      open={isOpen}
      openClassName="member-row--open"
      onToggle={onToggle}
    >
        <MemberSummary member={member} />
        <Popconfirm title="Remove member?" onConfirm={onRemove}>
          <Button
            danger
            icon={<CloseOutlined />}
            onClick={(event) => event.stopPropagation()}
            size="small"
            type="text"
          />
        </Popconfirm>
    </AccordionRow>
  );
}

function MemberSummary({ member }) {
  return (
    <div className="member-summary">
      <div className="member-summary-main">
        <span className="member-summary-name">{member.name || 'unnamed'}</span>
        {member.annotations?.key && <Tag color="gold">key</Tag>}
        {member.annotations?.optional && <Tag color="blue">optional</Tag>}
      </div>
      <div className="member-summary-meta">
        <span>{memberTypeLabel(member)}</span>
        <span className="member-summary-dot">/</span>
        <span>{kindGroupLabel(member.kind)}</span>
      </div>
    </div>
  );
}
