import { Checkbox, Select } from 'antd';

export default function JsonTreeEditor({ level = 0, onChange, rows }) {
  return (
    <div className="qos-tree" style={{ paddingLeft: 8 + level * 12 }}>
      {rows.map((row) => (
        <div className="qos-tree-row" key={row.key}>
          {row.children ? (
            <>
              <div className="qos-tree-group">{row.label}</div>
              <JsonTreeEditor level={level + 1} rows={row.children} onChange={onChange} />
            </>
          ) : (
            <FieldEditor
              label={row.label}
              row={{ ...row, key: row.label }}
              onChange={(value) => onChange?.(row, value)}
            />
          )}
        </div>
      ))}
    </div>
  );
}

function FieldEditor({ label, onChange, row }) {
  return (
    <div className={`qos-node-field ${row.editable ? 'qos-node-field--editable' : ''}`}>
      <span title={row.key}>{label ?? shortFieldLabel(row.key)}</span>
      {row.editable ? (
        <FieldControl row={row} onChange={onChange} />
      ) : (
        <b>{String(row.value)}</b>
      )}
    </div>
  );
}

function FieldControl({ onChange, row }) {
  if (row.options?.length) {
    return (
      <Select
        className="qos-node-field-select nodrag"
        options={row.options}
        popupMatchSelectWidth={false}
        size="small"
        value={row.value}
        onChange={onChange}
        onClick={(event) => event.stopPropagation()}
        onMouseDown={(event) => event.stopPropagation()}
      />
    );
  }

  if (typeof row.value === 'boolean') {
    return (
      <Checkbox
        checked={row.value}
        className="qos-node-field-checkbox nodrag"
        onChange={(event) => onChange(event.target.checked)}
        onClick={(event) => event.stopPropagation()}
        onMouseDown={(event) => event.stopPropagation()}
      />
    );
  }

  return (
    <input
      className="qos-node-field-input nodrag"
      type={typeof row.value === 'number' ? 'number' : 'text'}
      value={String(row.value)}
      onChange={(event) => {
        const nextValue = typeof row.value === 'number' ? Number(event.target.value) : event.target.value;
        onChange(nextValue);
      }}
      onClick={(event) => event.stopPropagation()}
      onMouseDown={(event) => event.stopPropagation()}
    />
  );
}

function shortFieldLabel(key) {
  return key.split('.').slice(-2).join('.');
}
