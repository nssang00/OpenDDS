import { Handle, Position } from '@xyflow/react';
import SectionList from '../SectionList.jsx';

export default function EntityFrame({
  bodyClassName,
  className,
  emptyMessage,
  headerClassName,
  renderSection,
  sectionClassName,
  sections,
  selected,
  title,
  toggleClassName,
  type,
  typeClassName,
  wrapperClassName,
  subtitle,
  sourcePosition = Position.Right,
  targetPosition = Position.Left,
}) {
  return (
    <div className={`${className} ${selected ? 'selected-node' : ''}`}>
      <Handle className="flow-handle" type="target" position={targetPosition} />
      <div className={typeClassName}>{type}</div>
      <div className={headerClassName}>
        <strong>{title}</strong>
        {subtitle && <small>{subtitle}</small>}
      </div>
      <SectionList
        bodyClassName={bodyClassName}
        emptyMessage={emptyMessage}
        renderBody={renderSection}
        sectionClassName={sectionClassName}
        sections={sections}
        toggleClassName={toggleClassName}
        wrapperClassName={wrapperClassName}
      />
      <Handle className="flow-handle" type="source" position={sourcePosition} />
    </div>
  );
}
