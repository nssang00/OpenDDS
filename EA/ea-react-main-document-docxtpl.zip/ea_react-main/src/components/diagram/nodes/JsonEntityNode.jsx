import { Handle, Position } from '@xyflow/react';
import EditableSectionBody from '../EditableSectionBody.jsx';
import DomainEditor from '../../entity-editor/DomainEditor.jsx';
import ParticipantEditor from '../../entity-editor/ParticipantEditor.jsx';
import EntityFrame from './EntityFrame.jsx';

export default function JsonEntityNode({ data, selected }) {
  if (data.variant === 'domain' && data.element) {
    return (
      <JsonEntityEditorFrame data={data} selected={selected}>
        <DomainEditor
          element={data.element}
          model={data.model}
          variant="diagram"
          onAppendPath={data.onAppendElementPath}
          onRemovePath={data.onRemoveElementPath}
          onUpdateElement={data.onUpdateElement}
          onUpdatePath={data.onUpdateElementPath}
        />
      </JsonEntityEditorFrame>
    );
  }

  if (data.variant === 'participant' && data.element) {
    return (
      <JsonEntityEditorFrame data={data} selected={selected}>
        <ParticipantEditor
          element={data.element}
          model={data.model}
          variant="diagram"
          onAppendPath={data.onAppendElementPath}
          onRemovePath={data.onRemoveElementPath}
          onUpdateElement={data.onUpdateElement}
          onUpdatePath={data.onUpdateElementPath}
        />
      </JsonEntityEditorFrame>
    );
  }

  return (
    <EntityFrame
      bodyClassName="json-entity-section-body"
      className={`json-entity-node json-entity-node--${data.variant}`}
      headerClassName="json-entity-node-header"
      renderSection={(section) => renderJsonEntitySection(data, section)}
      sectionClassName="json-entity-section"
      sections={data.sections}
      selected={selected}
      title={data.label}
      toggleClassName="json-entity-section-toggle"
      type={data.type}
      typeClassName="json-entity-node-type"
      wrapperClassName="json-entity-sections"
      sourcePosition={data.sourcePosition}
      targetPosition={data.targetPosition}
    />
  );
}

function JsonEntityEditorFrame({ children, data, selected }) {
  const sourcePosition = data.sourcePosition ?? Position.Right;
  const targetPosition = data.targetPosition ?? Position.Left;

  return (
    <div className={`json-entity-node json-entity-node--${data.variant} ${selected ? 'selected-node' : ''}`}>
      <Handle className="flow-handle" type="target" position={targetPosition} />
      <div className="json-entity-node-type">{data.type}</div>
      <div className="json-entity-node-header">
        <strong>{data.label}</strong>
      </div>
      {children}
      <Handle className="flow-handle" type="source" position={sourcePosition} />
    </div>
  );
}

function renderJsonEntitySection(data, section) {
  return (
    <EditableSectionBody
      addButtonClassName="json-add-button"
      section={section}
      onAppend={(action, item) => data.onAppendElementPath?.(item?.elementId ?? data.selectId, action.path, action.value)}
      onChange={(row, value) => data.onUpdateElementPath?.(row.elementId, row.path, value)}
      onRemove={(item) => data.onRemoveElementPath?.(item.elementId, item.removePath, item.removeIndex)}
    />
  );
}
