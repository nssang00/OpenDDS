import { Handle, Position } from '@xyflow/react';

export default function ModelNode({ data, selected }) {
  const sourcePosition = data.sourcePosition ?? Position.Right;
  const targetPosition = data.targetPosition ?? Position.Left;

  return (
    <div className={`model-node ${selected ? 'selected-node' : ''}`}>
      <Handle className="flow-handle" type="target" position={targetPosition} />
      <strong>{data.label}</strong>
      <div className="model-node-type">{data.type}</div>
      <Handle className="flow-handle" type="source" position={sourcePosition} />
    </div>
  );
}
