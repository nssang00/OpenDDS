import { useState } from 'react';
import { Handle, Position } from '@xyflow/react';
import QosEditor from '../../qos-editor/QosEditor.jsx';
import JsonTreeEditor from '../JsonTreeEditor.jsx';

export default function QosNode({ data, selected }) {
  const [collapsed, setCollapsed] = useState(false);
  const sourcePosition = data.sourcePosition ?? Position.Right;
  const targetPosition = data.targetPosition ?? Position.Left;

  if (data.sections) {
    return (
      <div className={`qos-node qos-node--${data.variant} ${selected ? 'selected-node' : ''}`}>
        <Handle className="flow-handle" type="target" position={targetPosition} />
        <div className="qos-node-type">{data.type}</div>
        <div className="qos-node-header">
          <strong>{data.label}</strong>
          {data.baseProfile && <small>Base: {data.baseProfile}</small>}
        </div>
        <QosEditor
          sections={data.sections}
          variant="diagram"
          onAppend={(tab, action) => data.onUpdateQosProperty?.(data.selectId, tab.key, action.key, action.value)}
          onFieldChange={(row, value) => data.onUpdateQosProperty?.(row.profileId, row.entityKey, row.path, value)}
        />
        <Handle className="flow-handle" type="source" position={sourcePosition} />
      </div>
    );
  }

  return (
    <div className={`qos-node qos-node--${data.variant} ${collapsed ? 'qos-node--collapsed' : ''} ${selected ? 'selected-node' : ''}`}>
      <Handle className="flow-handle" type="target" position={targetPosition} />
      <div className="qos-node-type">{data.type}</div>
      <div className="qos-node-header">
        <strong>{data.label}</strong>
        {data.fields?.length > 0 && (
          <button
            className="qos-node-collapse nodrag"
            type="button"
            onClick={(event) => {
              event.stopPropagation();
              setCollapsed((value) => !value);
            }}
            onMouseDown={(event) => event.stopPropagation()}
            title={collapsed ? 'Expand' : 'Collapse'}
          >
            {collapsed ? '+' : '-'}
          </button>
        )}
      </div>
      {!collapsed && data.fields?.length > 0 && (
        <div className="qos-node-fields">
          {data.fields.map((row) => (
            <JsonTreeEditor
              key={row.key}
              rows={[row]}
              onChange={(field, value) => data.onUpdateQosProperty?.(field.profileId, field.entityKey, field.key, value)}
            />
          ))}
        </div>
      )}
      <Handle className="flow-handle" type="source" position={sourcePosition} />
    </div>
  );
}
