import { Handle, Position } from '@xyflow/react';

export default function ModuleNode({ data, selected }) {
  const sourcePosition = data.sourcePosition ?? Position.Right;
  const targetPosition = data.targetPosition ?? Position.Left;

  return (
    <div className={`module-node ${selected ? 'selected-node' : ''}`}>
      <Handle className="flow-handle" type="target" position={targetPosition} />
      <div className="module-node-tab">module</div>
      <strong>{data.label}</strong>
      <small>{data.type}</small>
      <Handle className="flow-handle" type="source" position={sourcePosition} />
    </div>
  );
}
