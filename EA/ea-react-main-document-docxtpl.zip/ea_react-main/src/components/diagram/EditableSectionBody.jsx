import { useState } from 'react';
import JsonTreeEditor from './JsonTreeEditor.jsx';

export default function EditableSectionBody({
  addButtonClassName,
  actions = [],
  actionsClassName,
  emptyMessage = 'No items',
  onAppend,
  onChange,
  onRemove,
  section,
}) {
  if (!section.items) {
    return (
      <>
        <JsonTreeEditor
          rows={section.tree ?? []}
          onChange={onChange}
        />
        <SectionActions
          actions={actions}
          actionsClassName={actionsClassName}
          addButtonClassName={addButtonClassName}
          onAppend={onAppend}
        />
      </>
    );
  }

  return (
    <>
      {section.items.length > 0 ? section.items.map((item) => (
        <InlineEditableCard
          addButtonClassName={addButtonClassName}
          item={item}
          key={item.key}
          onAppend={onAppend}
          onRemove={onRemove}
          onChange={onChange}
        />
      )) : <div className="json-entity-empty">{emptyMessage}</div>}
      {section.action && (
        <ActionButton
          className={addButtonClassName}
          label={section.action.label}
          onClick={() => onAppend?.(section.action)}
        />
      )}
      <SectionActions
        actions={actions}
        actionsClassName={actionsClassName}
        addButtonClassName={addButtonClassName}
        onAppend={onAppend}
      />
    </>
  );
}

function SectionActions({ actions, actionsClassName, addButtonClassName, onAppend }) {
  if (!actions.length) return null;

  return (
    <div className={actionsClassName}>
      {actions.map((action) => (
        <ActionButton
          className={addButtonClassName}
          key={action.key ?? action.path}
          label={action.label}
          onClick={() => onAppend?.(action)}
        />
      ))}
    </div>
  );
}

function InlineEditableCard({ addButtonClassName, item, onAppend, onChange, onRemove }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="json-inline-card">
      <button
        className="json-inline-card-head nodrag"
        type="button"
        onClick={(event) => {
          event.stopPropagation();
          setOpen((value) => !value);
        }}
        onMouseDown={(event) => event.stopPropagation()}
      >
        <span>{open ? '-' : '+'}</span>
        <b>{item.title}</b>
      </button>
      {item.removable && (
        <button
          className="json-remove-button nodrag"
          type="button"
          onClick={(event) => {
            event.stopPropagation();
            onRemove?.(item);
          }}
          onMouseDown={(event) => event.stopPropagation()}
          title="Remove"
        >
          x
        </button>
      )}
      {open && (
        <>
          <JsonTreeEditor
            rows={item.tree ?? []}
            onChange={onChange}
          />
          {item.actions?.length > 0 && (
            <div className="json-card-actions">
              {item.actions.map((action) => (
                <ActionButton
                  className={addButtonClassName}
                  key={action.path}
                  label={action.label}
                  onClick={() => onAppend?.(action, item)}
                />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}

function ActionButton({ className, label, onClick }) {
  return (
    <button
      className={`${className} nodrag`}
      type="button"
      onClick={(event) => {
        event.stopPropagation();
        onClick();
      }}
      onMouseDown={(event) => event.stopPropagation()}
    >
      + {label}
    </button>
  );
}
