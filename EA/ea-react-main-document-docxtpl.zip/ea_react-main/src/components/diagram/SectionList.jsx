import { useState } from 'react';

export default function SectionList({
  bodyClassName,
  emptyMessage,
  renderBody,
  sectionClassName,
  sections = [],
  toggleClassName,
  wrapperClassName,
}) {
  const [expandedSections, setExpandedSections] = useState(() => new Set());

  const toggleSection = (key) => {
    setExpandedSections((current) => {
      const next = new Set(current);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  return (
    <div className={wrapperClassName}>
      {sections.map((section) => {
        const expanded = expandedSections.has(section.key);
        const empty = section.count === 0;
        return (
          <div className={`${sectionClassName} ${empty ? `${sectionClassName}--empty` : ''}`} key={section.key}>
            <button
              className={`${toggleClassName} nodrag`}
              type="button"
              onClick={(event) => {
                event.stopPropagation();
                toggleSection(section.key);
              }}
              onMouseDown={(event) => event.stopPropagation()}
            >
              <span>{expanded ? '-' : '+'}</span>
              <b>{section.label}</b>
              {section.count !== undefined && <small>{section.count}</small>}
            </button>
            {expanded && (
              <div className={bodyClassName ?? undefined}>
                {renderBody(section)}
              </div>
            )}
          </div>
        );
      })}
      {!sections.length && <div className="qos-node-empty">{emptyMessage}</div>}
    </div>
  );
}
