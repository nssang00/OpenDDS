import Caret from './Caret.jsx';

export default function AccordionRow({
  body,
  caretClassName,
  children,
  className = '',
  headClassName,
  open,
  openClassName,
  onToggle,
}) {
  const rowClassName = [className, open && openClassName].filter(Boolean).join(' ');

  return (
    <div className={rowClassName}>
      <button
        className={`${headClassName} nodrag`}
        type="button"
        onClick={(event) => {
          event.stopPropagation();
          onToggle();
        }}
        onMouseDown={(event) => event.stopPropagation()}
      >
        {children}
        <Caret className={caretClassName} open={open} />
      </button>
      {open && body}
    </div>
  );
}
