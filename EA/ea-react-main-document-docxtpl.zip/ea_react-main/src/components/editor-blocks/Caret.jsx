import { RightOutlined } from '@ant-design/icons';

export default function Caret({ className = '', open = false }) {
  return (
    <RightOutlined className={`${className} ${open ? `${className}--open` : ''}`.trim()} />
  );
}
