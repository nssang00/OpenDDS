import { generateIdl } from '../utils/idlGenerator.js';

export function buildConsoleMessages({ currentProject, dirty, summary }) {
  return [
    {
      level: 'info',
      message: currentProject
        ? `Project loaded: ${currentProject.name}`
        : 'Default model loaded',
    },
    {
      level: dirty ? 'warning' : 'success',
      message: dirty ? 'Model has unsaved changes' : 'Model state is clean',
    },
    {
      level: 'info',
      message: `Model summary: ${summary.topics} topics, ${summary.structs} struct types, ${summary.qosProfiles} QoS profiles`,
    },
  ];
}

export function buildOutputItems({ model, summary }) {
  return [
    {
      id: 'idl',
      name: 'OMG IDL',
      status: summary.structs > 0 ? 'ready' : 'empty',
      detail: `${model ? generateIdl(model).length : 0} characters generated from ${summary.structs} structs`,
    },
    {
      id: 'document',
      name: 'Model Document',
      status: model ? 'ready' : 'empty',
      detail: model ? 'DOCX template workspace is available' : 'Load a model to generate DOCX documents',
    },
  ];
}
