import { create } from 'zustand';

const initialState = {
  templateFile: null,
  templateBuffer: null,
  templateName: '',
  detectedTags: [],
  validationResult: null,
  selectedTarget: null,
  selectedTag: null,
  generatedBlob: null,
  generatedBuffer: null,
  previewMode: 'template',
};

export const useDocumentStore = create((set) => ({
  ...initialState,

  setTemplate: (file, buffer) => set({
    templateFile: file,
    templateBuffer: buffer,
    templateName: file?.name ?? '',
    generatedBlob: null,
    generatedBuffer: null,
    previewMode: 'template',
    selectedTarget: null,
  }),
  setDetectedTags: (detectedTags) => set({ detectedTags }),
  setValidationResult: (validationResult) => set({ validationResult }),
  setSelectedTarget: (selectedTarget) => set({ selectedTarget }),
  setSelectedTag: (selectedTag) => set({ selectedTag }),
  setGeneratedDocument: (generatedBlob, generatedBuffer) => set({
    generatedBlob,
    generatedBuffer,
    previewMode: 'generated',
  }),
  setPreviewMode: (previewMode) => set({ previewMode }),
  resetDocument: () => set(initialState),
}));
