const TYPE_MAP = {
  Struct: 'structures',
  Enum: 'enumerations',
  Union: 'unions',
  Alias: 'aliases',
  Constant: 'constants',
};

export function createDocumentData(model) {
  const elements = Object.values(model?.elementsById ?? {});
  const rootModule = elements.find((element) => element.type === 'Module');

  const result = {
    document: {
      title: `${rootModule?.name ?? 'Model'} Interface Specification`,
      version: '1.0',
      author: 'Architecture Team',
      date: new Date().toISOString().slice(0, 10),
      description: rootModule?.properties?.description ?? '',
    },
    model: {
      name: rootModule?.name ?? 'Model',
      version: model?.ddsJson?.version ?? '',
      namespace: rootModule?.name ?? '',
    },
    modules: [],
    structures: [],
    enumerations: [],
    unions: [],
    aliases: [],
    constants: [],
  };

  elements.forEach((element) => {
    if (element.type === 'Module') {
      result.modules.push(mapCommon(element));
      return;
    }

    const target = TYPE_MAP[element.type];
    if (!target) return;

    if (element.type === 'Struct') result[target].push(mapStructure(element));
    else if (element.type === 'Enum') result[target].push(mapEnumeration(element));
    else if (element.type === 'Union') result[target].push(mapUnion(element));
    else result[target].push(mapCommon(element));
  });

  return result;
}

export function getDocumentTagGroups() {
  return [
    {
      label: 'Document',
      tags: ['document.title', 'document.version', 'document.author', 'document.date', 'document.description'],
    },
    {
      label: 'Model',
      tags: ['model.name', 'model.version', 'model.namespace'],
    },
    {
      label: 'Structure',
      collection: 'structures',
      tags: ['name', 'qualifiedName', 'description'],
    },
    {
      label: 'Member',
      collection: 'members',
      tags: ['name', 'type', 'typeKind', 'multiplicity', 'isKey', 'description'],
    },
    {
      label: 'Enumeration',
      collection: 'enumerations',
      tags: ['name', 'description'],
    },
    {
      label: 'Union',
      collection: 'unions',
      tags: ['name', 'description'],
    },
  ];
}

function mapStructure(element) {
  return {
    ...mapCommon(element),
    members: (element.properties?.members ?? []).map((member) => ({
      name: member.name ?? '',
      type: member.type ?? member.kind ?? '',
      typeKind: member.kind ?? '',
      multiplicity: member.array_dimensions?.length ? member.array_dimensions.join(' x ') : '1',
      isKey: Boolean(member.annotations?.key),
      description: member.description ?? '',
      maxLength: member.string_max_length ?? member.sequence_max_length ?? null,
      arraySize: member.array_dimensions?.join(' x ') ?? '',
    })),
  };
}

function mapEnumeration(element) {
  return {
    ...mapCommon(element),
    values: (element.properties?.enumerators ?? element.properties?.values ?? []).map((value) => (
      typeof value === 'string' ? { name: value } : { name: value.name ?? '', value: value.value ?? '' }
    )),
  };
}

function mapUnion(element) {
  return {
    ...mapCommon(element),
    discriminator: element.properties?.discriminator ?? null,
    cases: (element.properties?.cases ?? []).map((item) => ({
      name: item.name ?? '',
      labels: item.labels ?? [],
      type: item.type ?? item.kind ?? '',
      typeKind: item.kind ?? '',
    })),
  };
}

function mapCommon(element) {
  const parentName = element.parentId ? element.parentId.replace(/^pkg-/, '') : '';
  return {
    name: element.name ?? '',
    qualifiedName: parentName ? `${parentName}::${element.name}` : element.name ?? '',
    description: element.properties?.description ?? '',
    type: element.type ?? '',
    stereotype: element.properties?.stereotype ?? '',
    alias: element.properties?.alias ?? '',
    version: element.properties?.version ?? '',
    status: element.properties?.status ?? '',
    source: {
      tool: 'Sparx Enterprise Architect',
      guid: element.properties?.guid ?? '',
      package: parentName,
      stereotype: element.properties?.stereotype ?? '',
    },
  };
}
