import PizZip from 'pizzip';

const TAG_PATTERN = /\{([^{}]+)\}/g;

export async function loadDocxTemplate(file) {
  if (!file) throw new Error('DOCX template file is required');
  const name = file.name?.toLowerCase() ?? '';
  if (!name.endsWith('.docxtpl') && !name.endsWith('.docx')) {
    throw new Error('Only .docxtpl or .docx template files are supported');
  }
  return file.arrayBuffer();
}

export function scanTemplateTags(buffer) {
  const zip = new PizZip(buffer);
  const text = getDocumentText(zip);
  const tags = [];
  let match;

  TAG_PATTERN.lastIndex = 0;
  while ((match = TAG_PATTERN.exec(text)) !== null) {
    const raw = match[1].trim();
    if (!raw || raw.startsWith('/')) continue;
    tags.push(raw);
  }

  return [...new Set(tags)];
}

export function validateTemplate(buffer, documentData) {
  const zip = new PizZip(buffer);
  const text = getDocumentText(zip);
  const errors = [];
  const warnings = [];
  const detectedTags = [];
  const loopStack = [];
  let match;

  TAG_PATTERN.lastIndex = 0;
  while ((match = TAG_PATTERN.exec(text)) !== null) {
    const raw = match[1].trim();
    if (!raw) continue;

    if (raw.startsWith('#')) {
      const name = raw.slice(1).trim();
      loopStack.push(name);
      detectedTags.push(raw);
      if (resolveInScope(documentData, name, loopStack.slice(0, -1)) === undefined) {
        errors.push(issue('UNKNOWN_TAG', raw, `Unknown collection: ${name}`));
      }
      continue;
    }

    if (raw.startsWith('/')) {
      const name = raw.slice(1).trim();
      const current = loopStack.pop();
      if (current !== name) {
        errors.push(issue('INVALID_LOOP', raw, `Loop closing tag does not match ${current ?? 'any opening tag'}`));
      }
      continue;
    }

    detectedTags.push(raw);
    if (!isTagResolvable(documentData, raw, loopStack)) {
      errors.push(issue('UNKNOWN_TAG', raw, `Unknown tag: ${raw}`));
    }
  }

  while (loopStack.length) {
    const name = loopStack.pop();
    errors.push(issue('INVALID_LOOP', `#${name}`, `Missing closing tag: {/${name}}`));
  }

  [...new Set(detectedTags)].filter((tag) => !tag.startsWith('#')).forEach((tag) => {
    const value = resolveForValidation(documentData, tag);
    if (value === '' || value == null || (Array.isArray(value) && value.length === 0)) {
      warnings.push(issue('EMPTY_VALUE', tag, `No current top-level value for: ${tag}`));
    }
  });

  return {
    valid: errors.length === 0,
    detectedTags: [...new Set(detectedTags)],
    errors,
    warnings,
  };
}

export function insertTag(buffer, target, tag) {
  return editDocumentXml(buffer, (xml) => {
    const tagText = `{${tag}}`;

    if (target?.type === 'tableCell') {
      return updateTableCell(xml, target, (cellXml) => appendTextToContainer(cellXml, tagText));
    }

    if (target?.type === 'paragraph') {
      return updateNthBlock(xml, 'w:p', target.paragraphIndex, (paragraphXml) => appendRun(paragraphXml, tagText));
    }

    throw new Error('Select a paragraph or table cell before inserting a tag');
  });
}

export function replaceTag(buffer, oldTag, newTag) {
  return editDocumentXml(buffer, (xml) => replaceAcrossTextNodes(xml, `{${oldTag}}`, `{${newTag}}`));
}

export function removeTag(buffer, tag) {
  return editDocumentXml(buffer, (xml) => replaceAcrossTextNodes(xml, `{${tag}}`, ''));
}

function editDocumentXml(buffer, edit) {
  const zip = new PizZip(buffer);
  const file = zip.file('word/document.xml');
  if (!file) throw new Error('word/document.xml was not found');
  const xml = file.asText();
  zip.file('word/document.xml', edit(xml));
  return zip.generate({ type: 'arraybuffer' });
}

function getDocumentText(zip) {
  const xmlFiles = Object.keys(zip.files)
    .filter((name) => /^word\/(document|header\d+|footer\d+)\.xml$/.test(name));

  return xmlFiles.map((name) => extractText(zip.file(name)?.asText() ?? '')).join('\n');
}

function extractText(xml) {
  return [...xml.matchAll(/<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g)]
    .map((match) => decodeXml(match[1]))
    .join('');
}

function replaceAcrossTextNodes(xml, search, replacement) {
  const nodes = [...xml.matchAll(/<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g)];
  const text = nodes.map((match) => decodeXml(match[1])).join('');
  const start = text.indexOf(search);
  if (start < 0) throw new Error(`Tag ${search} was not found in the main document body`);

  const end = start + search.length;
  let offset = 0;
  let replaced = false;

  return xml.replace(/<w:t\b([^>]*)>([\s\S]*?)<\/w:t>/g, (full, attrs, encoded) => {
    const nodeText = decodeXml(encoded);
    const nodeStart = offset;
    const nodeEnd = offset + nodeText.length;
    offset = nodeEnd;

    if (nodeEnd <= start || nodeStart >= end) return full;

    const before = nodeText.slice(0, Math.max(0, start - nodeStart));
    const after = nodeText.slice(Math.max(0, end - nodeStart));
    const middle = replaced ? '' : replacement;
    replaced = true;
    return `<w:t${attrs}>${encodeXml(before + middle + after)}</w:t>`;
  });
}

function updateTableCell(xml, target, transform) {
  return updateNthBlock(xml, 'w:tbl', target.tableIndex, (tableXml) => (
    updateNthBlock(tableXml, 'w:tr', target.rowIndex, (rowXml) => (
      updateNthBlock(rowXml, 'w:tc', target.cellIndex, transform)
    ))
  ));
}

function updateNthBlock(xml, tagName, index, transform) {
  if (!Number.isInteger(index) || index < 0) throw new Error(`Invalid ${tagName} index`);
  const pattern = new RegExp(`<${tagName}\\b[\\s\\S]*?<\\/${tagName}>`, 'g');
  let current = 0;
  let found = false;
  const next = xml.replace(pattern, (block) => {
    if (current++ !== index) return block;
    found = true;
    return transform(block);
  });
  if (!found) throw new Error(`Selected ${tagName} could not be mapped to DOCX XML`);
  return next;
}

function appendTextToContainer(containerXml, text) {
  const paragraphPattern = /<w:p\b[\s\S]*?<\/w:p>/g;
  const paragraphs = [...containerXml.matchAll(paragraphPattern)];
  if (!paragraphs.length) {
    return containerXml.replace('</w:tc>', `<w:p>${createRun(text)}</w:p></w:tc>`);
  }
  const last = paragraphs.at(-1)[0];
  return containerXml.replace(last, appendRun(last, text));
}

function appendRun(paragraphXml, text) {
  return paragraphXml.replace('</w:p>', `${createRun(text)}</w:p>`);
}

function createRun(text) {
  return `<w:r><w:t xml:space="preserve">${encodeXml(` ${text}`)}</w:t></w:r>`;
}

function isTagResolvable(data, tag, loopStack) {
  return resolveInScope(data, tag, loopStack) !== undefined;
}

function resolveInScope(data, path, loopStack) {
  const direct = resolvePath(data, path);
  if (direct !== undefined) return direct;

  let scope = data;
  for (const collectionName of loopStack) {
    const collection = resolvePath(scope, collectionName) ?? resolvePath(data, collectionName);
    scope = Array.isArray(collection) ? collection[0] : collection;
    if (!scope) return undefined;
  }

  return resolvePath(scope, path);
}

function resolveForValidation(data, tag) {
  const direct = resolvePath(data, tag);
  if (direct !== undefined) return direct;
  return undefined;
}

function resolvePath(object, path) {
  if (!path) return object;
  return path.split('.').reduce((value, key) => value?.[key], object);
}

function issue(type, tag, message) {
  return { type, tag, message };
}

function encodeXml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function decodeXml(value) {
  return String(value)
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&amp;/g, '&');
}
