import { useEffect, useMemo, useRef, useState } from 'react';
import { Alert, Button, Card, Divider, Empty, Input, Segmented, Space, Tag, Typography, Upload, message } from 'antd';
import { UploadOutlined, CheckCircleOutlined, FileWordOutlined, DownloadOutlined } from '@ant-design/icons';
import { useModelStore } from '../stores/useModelStore.js';
import { useDocumentStore } from '../document/documentStore.js';
import { createDocumentData, getDocumentTagGroups } from '../document/documentMapper.js';
import {
  insertTag,
  loadDocxTemplate,
  removeTag,
  replaceTag,
  scanTemplateTags,
  validateTemplate,
} from '../document/docxTemplate.js';
import { downloadDocx, previewDocx, renderDocx } from '../document/docxRenderer.js';

const { Text, Title } = Typography;

export default function DocumentView() {
  const model = useModelStore((state) => state.model);
  const previewRef = useRef(null);
  const [replaceValue, setReplaceValue] = useState('');

  const {
    templateBuffer,
    templateName,
    detectedTags,
    validationResult,
    selectedTarget,
    selectedTag,
    generatedBlob,
    generatedBuffer,
    previewMode,
    setTemplate,
    setDetectedTags,
    setValidationResult,
    setSelectedTarget,
    setSelectedTag,
    setGeneratedDocument,
    setPreviewMode,
  } = useDocumentStore();

  const documentData = useMemo(() => createDocumentData(model), [model]);
  const tagGroups = useMemo(() => getDocumentTagGroups(), []);
  const previewSource = previewMode === 'generated' ? generatedBuffer : templateBuffer;

  useEffect(() => {
    if (!previewSource || !previewRef.current) return;
    previewDocx(previewSource, previewRef.current).then(() => {
      bindPreviewSelection(previewRef.current, setSelectedTarget);
    }).catch((error) => message.error(error.message));
  }, [previewSource, setSelectedTarget]);

  const applyValidation = (buffer) => {
    const result = validateTemplate(buffer, documentData);
    setDetectedTags(scanTemplateTags(buffer));
    setValidationResult(result);
    return result;
  };

  const handleOpen = async (file) => {
    try {
      const buffer = await loadDocxTemplate(file);
      setTemplate(file, buffer);
      applyValidation(buffer);
      message.success(`Template loaded: ${file.name}`);
    } catch (error) {
      message.error(error.message);
    }
    return false;
  };

  const updateTemplate = (nextBuffer) => {
    setTemplate({ name: templateName }, nextBuffer);
    applyValidation(nextBuffer);
    setPreviewMode('template');
  };

  const handleInsert = () => {
    if (!templateBuffer || !selectedTarget || !selectedTag) return;
    try {
      updateTemplate(insertTag(templateBuffer, selectedTarget, selectedTag));
      message.success(`Inserted {${selectedTag}}`);
    } catch (error) {
      message.error(error.message);
    }
  };

  const handleReplace = () => {
    if (!templateBuffer || !replaceValue || !selectedTag) return;
    try {
      updateTemplate(replaceTag(templateBuffer, replaceValue, selectedTag));
      setReplaceValue('');
      message.success(`Replaced {${replaceValue}} with {${selectedTag}}`);
    } catch (error) {
      message.error(error.message);
    }
  };

  const handleRemove = () => {
    if (!templateBuffer || !replaceValue) return;
    try {
      updateTemplate(removeTag(templateBuffer, replaceValue));
      setReplaceValue('');
      message.success(`Removed {${replaceValue}}`);
    } catch (error) {
      message.error(error.message);
    }
  };

  const handleGenerate = async () => {
    if (!templateBuffer) return;
    const result = applyValidation(templateBuffer);
    if (!result.valid) {
      message.error('Fix template validation errors before generating');
      return;
    }

    try {
      const generated = await renderDocx(templateBuffer, documentData);
      setGeneratedDocument(generated.generatedBlob, generated.generatedBuffer);
      message.success('Document generated');
    } catch (error) {
      message.error(error.message);
    }
  };

  return (
    <div className="document-view">
      <div className="document-toolbar">
        <Space wrap>
          <Upload accept=".docxtpl,.docx" beforeUpload={handleOpen} showUploadList={false}>
            <Button icon={<UploadOutlined />}>Open Template</Button>
          </Upload>
          <Button
            icon={<CheckCircleOutlined />}
            disabled={!templateBuffer}
            onClick={() => applyValidation(templateBuffer)}
          >
            Validate
          </Button>
          <Button type="primary" icon={<FileWordOutlined />} disabled={!templateBuffer} onClick={handleGenerate}>
            Generate
          </Button>
          <Button icon={<DownloadOutlined />} disabled={!generatedBlob} onClick={() => downloadDocx(generatedBlob, generatedName(templateName))}>
            Download
          </Button>
        </Space>
        <Space>
          {templateName && <Text type="secondary">{templateName}</Text>}
          <Segmented
            size="small"
            value={previewMode}
            options={[
              { label: 'Template', value: 'template' },
              { label: 'Generated', value: 'generated', disabled: !generatedBuffer },
            ]}
            onChange={setPreviewMode}
          />
        </Space>
      </div>

      <div className="document-content">
        <div className="document-preview-panel">
          {!templateBuffer ? (
            <Empty description="Open a DOCX template (.docxtpl) to start" />
          ) : (
            <div ref={previewRef} className="document-docx-preview" />
          )}
        </div>

        <div className="document-binding-panel">
          <Title level={5}>Model Tags</Title>
          <Text type="secondary">Select a paragraph or table cell, then choose a tag.</Text>

          <Card size="small" className="document-selection-card">
            <Text strong>Selected location</Text>
            <div>{describeTarget(selectedTarget)}</div>
            {selectedTag && <Tag className="document-selected-tag">{`{${selectedTag}}`}</Tag>}
            <Button block type="primary" disabled={!selectedTarget || !selectedTag || previewMode !== 'template'} onClick={handleInsert}>
              Insert Tag
            </Button>
          </Card>

          <div className="document-tag-groups">
            {tagGroups.map((group) => (
              <div key={group.label} className="document-tag-group">
                <Text strong>{group.collection ? `${group.label} (${group.collection}[])` : group.label}</Text>
                <div className="document-tag-list">
                  {group.tags.map((tag) => (
                    <Tag.CheckableTag
                      key={`${group.label}-${tag}`}
                      checked={selectedTag === tag}
                      onChange={() => setSelectedTag(tag)}
                    >
                      {tag}
                    </Tag.CheckableTag>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <Divider />
          <Text strong>Existing tag</Text>
          <Input
            value={replaceValue}
            placeholder="e.g. document.title"
            onChange={(event) => setReplaceValue(stripBraces(event.target.value))}
          />
          <Space className="document-existing-tag-actions">
            <Button disabled={!replaceValue || !selectedTag || previewMode !== 'template'} onClick={handleReplace}>Replace</Button>
            <Button danger disabled={!replaceValue || previewMode !== 'template'} onClick={handleRemove}>Remove</Button>
          </Space>

          <Divider />
          <ValidationSummary result={validationResult} tags={detectedTags} />
        </div>
      </div>
    </div>
  );
}

function ValidationSummary({ result, tags }) {
  if (!result) return <Text type="secondary">Validation has not run yet.</Text>;
  const type = result.valid ? (result.warnings.length ? 'warning' : 'success') : 'error';
  return (
    <Alert
      type={type}
      showIcon
      message={result.valid ? 'Template valid' : 'Template has errors'}
      description={`${tags.length} tags · ${result.errors.length} errors · ${result.warnings.length} warnings`}
    />
  );
}

function bindPreviewSelection(root, onSelect) {
  root.querySelectorAll('p').forEach((node, paragraphIndex) => {
    node.classList.add('document-selectable');
    node.addEventListener('click', (event) => {
      if (event.target.closest('td')) return;
      clearSelection(root);
      node.classList.add('document-selected-target');
      onSelect({ type: 'paragraph', paragraphIndex });
    });
  });

  root.querySelectorAll('table').forEach((table, tableIndex) => {
    [...table.rows].forEach((row, rowIndex) => {
      [...row.cells].forEach((cell, cellIndex) => {
        cell.classList.add('document-selectable');
        cell.addEventListener('click', (event) => {
          event.stopPropagation();
          clearSelection(root);
          cell.classList.add('document-selected-target');
          onSelect({ type: 'tableCell', tableIndex, rowIndex, cellIndex });
        });
      });
    });
  });
}

function clearSelection(root) {
  root.querySelectorAll('.document-selected-target').forEach((node) => node.classList.remove('document-selected-target'));
}

function describeTarget(target) {
  if (!target) return 'None';
  if (target.type === 'paragraph') return `Paragraph ${target.paragraphIndex + 1}`;
  return `Table ${target.tableIndex + 1} / Row ${target.rowIndex + 1} / Cell ${target.cellIndex + 1}`;
}

function stripBraces(value) {
  return value.replace(/^\{/, '').replace(/\}$/, '').trim();
}

function generatedName(templateName) {
  if (!templateName) return 'generated-document.docx';
  return templateName.replace(/\.(docxtpl|docx)$/i, '-generated.docx');
}
