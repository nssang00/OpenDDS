/** Semantic CSS mapping; the browser remains responsible for layout measurement. */
export function frameStyle(layout){
  const {type,gap=0,padding=0,columns=2,align='stretch',background='transparent'}=layout;
  const result={minWidth:0,gap,padding,background,alignItems:align};
  if(type==='grid'){return {...result,display:'grid',gridTemplateColumns:`repeat(${columns}, minmax(0, 1fr))`};}
  if(type==='overlay'){return {...result,display:'grid',gridTemplateColumns:'minmax(0, 1fr)',gap:0};}
  return {...result,display:'flex',flexDirection:type==='column'?'column':'row',flexWrap:type==='wrap'?'wrap':'nowrap'};
}
