/** Pure editor commands. Every command produces a validated v6 document. */
import {literal, validateDocument} from '../schema/index.js';
export const FRAME_TYPES=['column','row','grid','wrap','overlay'];
export function pageRoot(doc,pageId='main'){
  if(pageId.startsWith('definition:')){const id=pageId.slice('definition:'.length);if(!doc.definitions[id])throw Error(`없는 Definition: ${id}`);return doc.definitions[id].root;}
  const page=doc.pages[pageId];if(!page)throw Error(`없는 페이지: ${pageId}`);return page.root;
}
export function locateNode(root,id,parent=null){
  if(root.id===id)return {node:root,parent,index:-1};
  for(let i=0;i<(root.children||[]).length;i++){
    const child=root.children[i];if(child.id===id)return {node:child,parent:root,index:i};
    const found=locateNode(child,id,root);if(found)return found;
  }
  for(const children of Object.values(root.slots||{})){
    for(let i=0;i<children.length;i++){
      const child=children[i];if(child.id===id)return {node:child,parent:root,index:i,slotChildren:children};
      const found=locateNode(child,id,root);if(found)return found;
    }
  }
  return null;
}
// IDs are not derived from array indexes; moving nodes preserves ID and runtime binding addresses.
export function allocateNodeId(doc,prefix='node'){
  const used=new Set();const visit=node=>{used.add(node.id);for(const child of node.children||[])visit(child);for(const fill of Object.values(node.slots||{}))for(const child of fill)visit(child);};
  for(const page of Object.values(doc.pages))visit(page.root);
  for(const def of Object.values(doc.definitions))visit(def.root);
  for(let i=1;i<100000;i++){const id=`${prefix}_${i}`;if(!used.has(id))return id;}
  throw Error('노드 ID 공간이 부족합니다');
}
export function createEditorNode(doc,typeId,registry){
  const id=allocateNodeId(doc);
  if(typeId.startsWith('layout/')){
    const type=typeId.slice(7);if(!FRAME_TYPES.includes(type))throw Error(`지원하지 않는 레이아웃: ${type}`);
    return {id,kind:'frame',name:type[0].toUpperCase()+type.slice(1),layout:{type,gap:8,padding:8,...(type==='grid'?{columns:2}:{})},children:[]};
  }
  if(typeId.startsWith('module/')){
    const definitionId=typeId.slice(7);if(!doc.definitions[definitionId])throw Error('없는 사용자 컴포넌트');
    return {id,kind:'instance',name:definitionId,definitionId,props:{},bindings:{},overrides:{}};
  }
  const control=registry.get(typeId);if(!control)throw Error(`등록되지 않은 컨트롤: ${typeId}`);
  // Default values are resolved by Property System, not stored redundantly.
  return {id,kind:'component',name:control.displayName,typeId,props:{}};
}
function touchDefinition(doc,scope){if(scope.startsWith('definition:'))doc.definitions[scope.slice('definition:'.length)].revision=(doc.definitions[scope.slice('definition:'.length)].revision||0)+1;}
export function insertEditorNode(doc,parentId,index,node,registry,pageId='main'){
  const next=structuredClone(doc),root=pageRoot(next,pageId),location=locateNode(root,parentId);
  if(!location||location.node.kind!=='frame')throw Error('대상은 Frame이어야 합니다');
  if(locateNode(root,node.id))throw Error('중복 노드 ID');
  const children=location.node.children;
  children.splice(Math.max(0,Math.min(children.length,index)),0,structuredClone(node));
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
export function removeEditorNode(doc,id,registry,pageId='main'){
  const next=structuredClone(doc),location=locateNode(pageRoot(next,pageId),id);
  if(!location?.parent)throw Error('루트는 삭제할 수 없습니다');
  (location.slotChildren||location.parent.children).splice(location.index,1);
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
/** Return the chain from the editable root to an item, including nodes in instance slots. */
export function editorSelectionPath(root,id){
  function visit(node,trail){
    const current=[...trail,{id:node.id,name:node.name,kind:node.kind}];
    if(node.id===id)return current;
    for(const child of node.children||[]) {const found=visit(child,current);if(found)return found;}
    for(const children of Object.values(node.slots||{}))for(const child of children){const found=visit(child,current);if(found)return found;}
    return null;
  }
  return visit(root,[])||[];
}
/** Duplicate beside the selected node, retaining values but allocating fresh IDs for all descendants.
 * Works in pages, definitions, and instance slot arrays; the source remains unchanged.
 */
export function duplicateEditorNode(doc,id,registry,pageId='main'){
  const next=structuredClone(doc),source=locateNode(pageRoot(next,pageId),id);
  if(!source?.parent)throw Error('루트는 복제할 수 없습니다');
  const used=new Set();
  const collect=n=>{used.add(n.id);for(const c of n.children||[])collect(c);for(const items of Object.values(n.slots||{}))for(const c of items)collect(c);};
  for(const page of Object.values(next.pages))collect(page.root);
  for(const definition of Object.values(next.definitions))collect(definition.root);
  let cursor=1;
  const nextId=()=>{while(used.has(`node_${cursor}`))cursor++;const candidate=`node_${cursor++}`;used.add(candidate);return candidate;};
  const copied=structuredClone(source.node),remapped=new Map();
  const assignIds=n=>{const old=n.id;n.id=nextId();remapped.set(old,n.id);for(const c of n.children||[])assignIds(c);for(const items of Object.values(n.slots||{}))for(const c of items)assignIds(c);};
  assignIds(copied);
  // Only remap references to nodes that were duplicated (never external targets).
  const rewriteReferences=value=>{
    if(!value||typeof value!=='object')return;
    if(!Array.isArray(value)&&typeof value.nodeId==='string'&&remapped.has(value.nodeId))value.nodeId=remapped.get(value.nodeId);
    for(const child of Object.values(value))rewriteReferences(child);
  };
  rewriteReferences(copied);
  const fallback=source.node.kind==='component'?registry.get(source.node.typeId)?.displayName:source.node.kind==='instance'?source.node.definitionId:source.node.kind==='frame'?source.node.layout.type:'Element';
  copied.name=`${copied.name||fallback||'Element'} Copy`;
  const siblings=source.slotChildren||source.parent.children;
  siblings.splice(source.index+1,0,copied);
  touchDefinition(next,pageId);
  return {document:validateDocument(next,registry),id:copied.id};
}
export function moveEditorNode(doc,id,parentId,index,registry,pageId='main'){
  const next=structuredClone(doc),root=pageRoot(next,pageId);
  const source=locateNode(root,id),target=locateNode(root,parentId);
  if(!source?.parent)throw Error('루트는 이동할 수 없습니다');
  if(!target||target.node.kind!=='frame')throw Error('대상은 Frame이어야 합니다');
  if(id===parentId||source.node.kind==='frame'&&locateNode(source.node,parentId))throw Error('자기 자신 또는 자손으로 이동할 수 없습니다');
  (source.slotChildren||source.parent.children).splice(source.index,1);
  const actual=source.parent===target.node&&source.index<index?index-1:index;
  target.node.children.splice(Math.max(0,Math.min(target.node.children.length,actual)),0,source.node);
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
/** Pure, predictable hierarchy editing actions for keyboard/buttons.
 * Sibling operations also work for instance slot contents. Indenting only
 * targets an existing preceding Frame; outdenting only targets a Frame's parent.
 */
export function editorMoveOptions(root,id){
  const loc=locateNode(root,id);
  if(!loc?.parent)return {up:false,down:false,indent:false,outdent:false};
  const siblings=loc.slotChildren||loc.parent.children;
  const parentLoc=locateNode(root,loc.parent.id);
  return {
    up:loc.index>0,
    down:loc.index<siblings.length-1,
    indent:loc.index>0&&siblings[loc.index-1].kind==='frame',
    outdent:!loc.slotChildren&&loc.parent.kind==='frame'&&parentLoc?.parent?.kind==='frame'&&!parentLoc.slotChildren,
  };
}
export function moveEditorRelative(doc,id,direction,registry,pageId='main'){
  if(!['up','down','indent','outdent'].includes(direction))throw Error('알 수 없는 이동 방향');
  const next=structuredClone(doc),root=pageRoot(next,pageId),loc=locateNode(root,id);
  const allowed=editorMoveOptions(root,id);
  if(!allowed[direction])throw Error(`이 방향으로 이동할 수 없습니다: ${direction}`);
  const siblings=loc.slotChildren||loc.parent.children;
  if(direction==='up'||direction==='down'){
    const offset=direction==='up'?-1:1;
    [siblings[loc.index],siblings[loc.index+offset]]=[siblings[loc.index+offset],siblings[loc.index]];
  }else if(direction==='indent'){
    const preceding=siblings[loc.index-1];
    preceding.children.push(siblings.splice(loc.index,1)[0]);
  }else{
    const parentLoc=locateNode(root,loc.parent.id);
    const removed=siblings.splice(loc.index,1)[0];
    parentLoc.parent.children.splice(parentLoc.index+1,0,removed);
  }
  touchDefinition(next,pageId);
  return validateDocument(next,registry);
}
/** A multi-selection is a single sibling array, never a parent and its descendant.
 *  Slot contents are a separate array; cross-slot/cross-parent edits are rejected.
 */
export function editorSiblingSelection(root,ids){
  if(!Array.isArray(ids)||!ids.length||new Set(ids).size!==ids.length)throw Error('선택한 요소가 유효하지 않습니다');
  const locations=ids.map(id=>locateNode(root,id));
  if(locations.some(loc=>!loc?.parent))throw Error('루트나 존재하지 않는 요소는 그룹 선택할 수 없습니다');
  const first=locations[0],siblings=first.slotChildren||first.parent.children;
  if(locations.some(loc=>(loc.slotChildren||loc.parent.children)!==siblings))throw Error('동일한 부모의 형제 요소만 다중 선택할 수 있습니다');
  const selected=new Set(ids);
  return {parent:first.parent,siblings,indices:locations.map(loc=>loc.index),ids:siblings.filter(n=>selected.has(n.id)).map(n=>n.id)};
}
/** Ctrl/Cmd toggles siblings; Shift extends a range in the same array. */
export function chooseEditorSelection(root,selection,id,{toggle=false,range=false,anchor=null}={}){
  const loc=locateNode(root,id);if(!loc)return [];
  if(!toggle&&!range)return [id];
  if(!loc.parent)return [id];
  const siblings=loc.slotChildren||loc.parent.children;
  if(range){
    const start=anchor&&locateNode(root,anchor),startSiblings=start&&(start.slotChildren||start.parent?.children);
    if(startSiblings!==siblings)return [id];
    const from=Math.min(start.index,loc.index),to=Math.max(start.index,loc.index);
    return siblings.slice(from,to+1).map(n=>n.id);
  }
  const old=selection.filter(x=>{const at=locateNode(root,x);return at?.parent&&(at.slotChildren||at.parent.children)===siblings;});
  const next=new Set(old);if(next.has(id))next.delete(id);else next.add(id);
  return next.size?siblings.filter(n=>next.has(n.id)).map(n=>n.id):[id];
}
/** Move a sibling selection as a single ordered block to a Frame.
 *  The insertion index refers to the original target array, before removal.
 */
export function moveEditorGroup(doc,ids,parentId,index,registry,pageId='main'){
  const next=structuredClone(doc),root=pageRoot(next,pageId);
  const group=editorSiblingSelection(root,ids),dest=locateNode(root,parentId);
  if(!dest||dest.node.kind!=='frame')throw Error('대상은 Frame이어야 합니다');
  if(group.ids.some(id=>id===parentId||locateNode(locateNode(root,id).node,parentId)))throw Error('자기 자신이나 자손으로 이동할 수 없습니다');
  if(!Number.isInteger(index)||index<0||index>dest.node.children.length)throw Error('삽입 위치가 유효하지 않습니다');
  if(group.siblings===dest.node.children){
    const remaining=group.siblings.filter(n=>!ids.includes(n.id));
    const adjusted=index-group.indices.filter(i=>i<index).length;
    const positions=group.siblings.filter(n=>ids.includes(n.id));
    group.siblings.splice(0,group.siblings.length,...remaining.slice(0,adjusted),...positions,...remaining.slice(adjusted));
  }else{
    const moving=group.siblings.filter(n=>ids.includes(n.id));
    group.siblings.splice(0,group.siblings.length,...group.siblings.filter(n=>!ids.includes(n.id)));
    dest.node.children.splice(index,0,...moving);
  }
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
export function editorGroupMoveOptions(root,ids){
  try{const group=editorSiblingSelection(root,ids),selected=new Set(group.ids);
    return {up:group.indices.some(i=>i>0&&!selected.has(group.siblings[i-1].id)),down:group.indices.some(i=>i<group.siblings.length-1&&!selected.has(group.siblings[i+1].id))};
  }catch{return {up:false,down:false};}
}
/** Move selected siblings one position, preserving relative order and adjacency. */
export function moveEditorGroupRelative(doc,ids,direction,registry,pageId='main'){
  if(direction!=='up'&&direction!=='down')throw Error('알 수 없는 그룹 이동 방향');
  const next=structuredClone(doc),group=editorSiblingSelection(pageRoot(next,pageId),ids);
  if(!editorGroupMoveOptions(pageRoot(next,pageId),ids)[direction])throw Error('그룹을 더 이동할 수 없습니다');
  const selected=new Set(ids),siblings=group.siblings;
  if(direction==='up')for(let i=1;i<siblings.length;i++){
    if(selected.has(siblings[i].id)&&!selected.has(siblings[i-1].id))[siblings[i-1],siblings[i]]=[siblings[i],siblings[i-1]];
  }else for(let i=siblings.length-2;i>=0;i--){
    if(selected.has(siblings[i].id)&&!selected.has(siblings[i+1].id))[siblings[i],siblings[i+1]]=[siblings[i+1],siblings[i]];
  }
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
export function removeEditorGroup(doc,ids,registry,pageId='main'){
  const next=structuredClone(doc),group=editorSiblingSelection(pageRoot(next,pageId),ids),chosen=new Set(ids);
  group.siblings.splice(0,group.siblings.length,...group.siblings.filter(n=>!chosen.has(n.id)));
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
/** Alignment and spacing operate on the shared parent Frame (Flex/Grid semantics),
 *  not on individual nodes. Selection must come from one Frame children array.
 */
export function alignEditorGroup(doc,ids,{align,gap},registry,pageId='main'){
  const next=structuredClone(doc),group=editorSiblingSelection(pageRoot(next,pageId),ids);
  if(group.siblings!==group.parent.children||group.parent.kind!=='frame')throw Error('Frame 자식 요소만 정렬할 수 있습니다');
  if(align!==undefined&&!['stretch','start','center','end'].includes(align))throw Error('정렬 옵션이 유효하지 않습니다');
  if(gap!==undefined&&(!Number.isFinite(gap)||gap<0||gap>500))throw Error('간격이 유효하지 않습니다');
  if(align===undefined&&gap===undefined)throw Error('변경할 레이아웃 설정이 없습니다');
  group.parent.layout={...group.parent.layout,...(align===undefined?{}:{align}),...(gap===undefined?{}:{gap})};
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
export function patchEditorNode(doc,id,patch,registry,pageId='main'){
  const next=structuredClone(doc),location=locateNode(pageRoot(next,pageId),id);
  if(!location)throw Error('노드 없음');
  const updated=patch(structuredClone(location.node));
  if(!updated||updated.id!==id||updated.kind!==location.node.kind)throw Error('노드 ID / 종류 변경 불가');
  if(location.parent)(location.slotChildren||location.parent.children)[location.index]=updated;
  else if(pageId.startsWith('definition:'))next.definitions[pageId.slice('definition:'.length)].root=updated;
  else next.pages[pageId].root=updated;
  touchDefinition(next,pageId);return validateDocument(next,registry);
}
export function setEditorProperty(doc,id,key,provider,registry,pageId='main'){
  return patchEditorNode(doc,id,node=>{
    if(node.kind!=='component')throw Error('Control 속성만 변경할 수 있습니다');
    node.props={...node.props,[key]:provider};return node;
  },registry,pageId);
}
export function setEditorLayout(doc,id,layoutPatch,registry,pageId='main'){
  return patchEditorNode(doc,id,node=>{
    if(node.kind!=='frame')throw Error('Frame에만 적용되는 속성입니다');
    node.layout={...node.layout,...layoutPatch};return node;
  },registry,pageId);
}
/** Validate a pointer destination *before* displaying a valid drop guide.
 * Index is expressed in the unmodified target child array. This is essential
 * when the dragged item already occupies a position in that array.
 * Invalid/no-op drops never create an undo entry in the Studio.
 */
export function editorDropCandidate(root,{parentId,index,sourceIds=[],kind='move'}={}){
  const target=locateNode(root,parentId);
  if(!target||target.node.kind!=='frame')return {valid:false,reason:'Frame에만 놓을 수 있습니다'};
  const children=target.node.children;
  if(!Number.isInteger(index)||index<0||index>children.length)return {valid:false,reason:'잘못된 삽입 위치'};
  if(kind==='new')return {valid:true,parentId,index};
  if(kind!=='move'||!Array.isArray(sourceIds)||!sourceIds.length)return {valid:false,reason:'이동할 요소가 없습니다'};
  let group;
  try{group=editorSiblingSelection(root,sourceIds);}catch{return {valid:false,reason:'같은 부모의 요소만 함께 이동할 수 있습니다'};}
  for(const id of group.ids){
    const source=locateNode(root,id);
    if(id===parentId||source?.node.kind==='frame'&&locateNode(source.node,parentId))
      return {valid:false,reason:'자기 자신 또는 자손 Frame으로 이동할 수 없습니다'};
  }
  if(group.siblings===children){
    const chosen=new Set(group.ids);
    const remaining=children.filter(n=>!chosen.has(n.id));
    const adjusted=index-group.indices.filter(i=>i<index).length;
    const moving=children.filter(n=>chosen.has(n.id));
    const result=[...remaining.slice(0,adjusted),...moving,...remaining.slice(adjusted)];
    if(result.every((n,i)=>n===children[i]))return {valid:false,reason:'현재 위치와 동일합니다'};
  }
  return {valid:true,parentId,index};
}
/** Small, bounded scroll increments while pointer-dragging inside scroll panes.
 * Pure calculation prevents scroll jumps beyond the visible edge.
 */
export function editorAutoScrollDelta(rect,point,{margin=36,speed=18}={}){
  if(!rect||point.x<rect.left||point.x>rect.right||point.y<rect.top||point.y>rect.bottom)return 0;
  const top=point.y-rect.top,bottom=rect.bottom-point.y;
  if(top<margin)return -Math.max(1,Math.ceil(speed*(margin-top)/margin));
  if(bottom<margin)return Math.max(1,Math.ceil(speed*(margin-bottom)/margin));
  return 0;
}
/** Layout-independent geometric insertion model, shared by canvas/tree pointer UI. */
export function geometryInsertion(children,pointer,mode,columns=2){
  if(!children.length)return {index:0,edge:'empty'};
  if(mode==='grid'){
    // Use geometric child centres; this respects responsive CSS Grid positions.
    for(let i=0;i<children.length;i++){
      const r=children[i];if(pointer.y<r.top+r.height/2||(pointer.y<r.bottom&&pointer.x<r.left+r.width/2))return {index:i,edge:'before'};
    }
    return {index:children.length,edge:'after'};
  }
  const axis=mode==='column'?'y':'x';
  if(mode==='wrap'){
    for(let i=0;i<children.length;i++){
      const r=children[i];if(pointer.y<r.top+r.height/2||(pointer.y<r.bottom&&pointer.x<r.left+r.width/2))return {index:i,edge:'before'};
    }
    return {index:children.length,edge:'after'};
  }
  for(let i=0;i<children.length;i++){
    const r=children[i];if((axis==='y'?pointer.y<r.top+r.height/2:pointer.x<r.left+r.width/2))return {index:i,edge:'before'};
  }
  return {index:children.length,edge:'after'};
}
export function bindableFields(doc){
  const found=[];
  function walk(value,path,depth){if(depth>5||found.length>120)return;if(value!==null&&typeof value==='object'&&!Array.isArray(value)){for(const [key,v] of Object.entries(value)){if(['__proto__','constructor','prototype'].includes(key))continue;walk(v,[...path,key],depth+1);}return;}
    found.push({path,value});}
  walk(doc.data.state,[],0);return found;
}
/** Converts one Frame into a reusable reference without flattening its internal tree. */
export function extractDefinition(doc,frameId,registry,pageId='main'){
  const next=structuredClone(doc),location=locateNode(pageRoot(next,pageId),frameId);
  if(!location?.parent||location.node.kind!=='frame')throw Error('하위 Frame을 선택하세요');
  if(location.slotChildren)throw Error('Slot 내부 Frame은 먼저 밖으로 이동해야 합니다');
  const cleaned=String(location.node.name||'Component').replace(/[^a-zA-Z0-9_]/g,'_').replace(/^_+|_+$/g,'');
  const suggested=cleaned&&/^[a-zA-Z]/.test(cleaned)?cleaned[0].toUpperCase()+cleaned.slice(1):'Component'+(cleaned||'');
  let definitionId=suggested,idx=2;while(Object.hasOwn(next.definitions,definitionId))definitionId=`${suggested}_${idx++}`;
  const instanceId=allocateNodeId(next,'instance');
  const root=structuredClone(location.node);
  next.definitions[definitionId]={id:definitionId,name:location.node.name||definitionId,version:'1.0.0',revision:1,root,publicProps:{},publicEvents:{},overridePolicy:{}};
  location.parent.children[location.index]={id:instanceId,kind:'instance',name:location.node.name||definitionId,definitionId,props:{},bindings:{},overrides:{}};
  touchDefinition(next,pageId);return {document:validateDocument(next,registry),definitionId,instanceId};
}
/** Defines a public API contract. Existing internal literal becomes the public default. */
export function exposeDefinitionProperty(doc,definitionId,nodeId,property,publicName,registry){
  const next=structuredClone(doc),def=next.definitions[definitionId];if(!def)throw Error('없는 Definition');
  const node=locateNode(def.root,nodeId)?.node,meta=node?.kind==='component'?registry.get(node.typeId)?.properties[property]:node?.kind==='instance'?next.definitions[node.definitionId]?.publicProps?.[property]:null;
  if(!meta)throw Error('등록되지 않은 공개 속성');
  if(!/^[a-zA-Z_][a-zA-Z0-9_]{0,63}$/.test(publicName)||def.publicProps?.[publicName])throw Error('공개 Property 이름이 중복이거나 유효하지 않습니다');
  if(Object.values(def.publicProps||{}).some(x=>x.target?.nodeId===nodeId&&x.target?.property===property))throw Error('이미 공개된 속성입니다');
  const configured=node.bindings?.[property]||node.props?.[property];
  def.publicProps[publicName]={type:meta.type,defaultValue:configured?.kind==='literal'?configured.value:meta.defaultValue,bindable:!!meta.bindable,twoWay:!!meta.twoWay,target:{nodeId,property}};
  def.revision=(def.revision||0)+1;
  return validateDocument(next,registry);
}
export function exposeDefinitionEvent(doc,definitionId,nodeId,event,publicName,registry){
  const next=structuredClone(doc),def=next.definitions[definitionId];if(!def)throw Error('없는 Definition');
  const node=locateNode(def.root,nodeId)?.node,meta=node?.kind==='component'?registry.get(node.typeId)?.events[event]:node?.kind==='instance'?next.definitions[node.definitionId]?.publicEvents?.[event]:null;
  if(!meta)throw Error('등록되지 않은 이벤트');
  if(!/^[a-zA-Z_][a-zA-Z0-9_]{0,63}$/.test(publicName)||def.publicEvents?.[publicName])throw Error('공개 이벤트 이름이 중복이거나 유효하지 않습니다');
  def.publicEvents[publicName]={nodeId,event};if(node.kind==='component')node.events={...node.events,[event]:{kind:'emit',event:publicName}};
  def.revision=(def.revision||0)+1;
  return validateDocument(next,registry);
}
export function allowInstanceOverride(doc,definitionId,nodeId,property,registry){
  const next=structuredClone(doc),def=next.definitions[definitionId];if(!def)throw Error('없는 Definition');
  const node=locateNode(def.root,nodeId)?.node;
  if(!node||node.kind!=='component'||!registry.get(node.typeId)?.properties[property])throw Error('속성을 찾을 수 없습니다');
  if(Object.values(def.publicProps||{}).some(x=>x.target?.nodeId===nodeId&&x.target?.property===property))throw Error('공개 속성에 Override를 허용할 수 없습니다');
  const keys=new Set(def.overridePolicy[nodeId]||[]);keys.add(property);def.overridePolicy[nodeId]=[...keys];
  def.revision=(def.revision||0)+1;return validateDocument(next,registry);
}

/** Publish a Definition-scoped property used by dynamic repeat/condition/graphics.
 * Unlike a mapped property, this has no internal Control target. Controls and
 * behaviors can refer to it as props.<name> through the existing Binding Engine.
 */
export function addDefinitionProperty(doc,definitionId,name,type,defaultValue,registry){
  if(!/^[A-Za-z_][A-Za-z0-9_]*$/.test(name))throw Error('공개 속성 이름이 유효하지 않습니다');
  if(!['string','number','boolean','array','object'].includes(type))throw Error('지원하지 않는 공개 속성 타입');
  const next=structuredClone(doc),definition=next.definitions[definitionId];
  if(!definition)throw Error('Definition을 찾을 수 없습니다');
  if(Object.hasOwn(definition.publicProps||{},name))throw Error('공개 속성 이름이 중복됩니다');
  definition.publicProps={...definition.publicProps,[name]:{type,defaultValue:structuredClone(defaultValue),bindable:true,twoWay:false}};
  definition.revision=(definition.revision||0)+1;
  return validateDocument(next,registry);
}
