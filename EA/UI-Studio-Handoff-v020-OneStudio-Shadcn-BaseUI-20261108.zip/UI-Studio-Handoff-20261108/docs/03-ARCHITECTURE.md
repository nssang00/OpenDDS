# 아키텍처 — 현재 구현과 불변 조건

## 현행 구현 (v0.20 소스에서 직접 확인)

```text
src/main.jsx  →  src/App.jsx  →  src/framework/UnifiedStudio.jsx
                                  ↓
                  packages/core/* + packages/schema/*
                                  ↓
            canonical schemaVersion=6 문서/State/Binding/Action
                                  ↓
             Preview / React Runtime / Exporter
                                  ↓
              packages/renderer-antd/index.jsx
```

- `src/App.jsx`는 React `ConfigProvider(antd)`와 단일 `UnifiedStudio`를 사용한다.
- `package.json` 실제 의존성: `antd ^6.6.5`, `react ^19.2.0`, `react-dom ^19.2.0`; Vite, Playwright.
- `packages/renderer-antd/index.jsx`: `createAntdRenderer()` 및 `core/Button`, `core/Input`, `core/Text`, `core/Checkbox`, `core/Select`, `core/Table`, `core/Card`, `core/Divider`, `core/Tag` 등록.
- `src/framework/runtimeSources.js`: React Export에서 사용할 스키마/Runtime/AntD 렌더러 등 코드를 원본 소스로 묶는다.
- `npm run export:v014`는 **현재 실제로** `tools/export-v013.mjs`를 호출하는 역사적 별칭이다. 이름만 보고 v0.20 전용 Export로 오해하지 말 것.
- v5 JSON은 사용자 진입 화면을 유지하지 않고 `migrateV5ToV6`를 통해 가져오기 시 마이그레이션한다.

## 반드시 지킬 불변조건

1. **Canonical JSON v6 단일 원본:** Canvas, Inspector, Preview, Export가 같은 문서를 반영해야 한다.
2. **렌더러 격리:** AntD/shadcn/Base UI의 컴포넌트 API를 영속 문서 표준으로 직접 저장하지 않는다.
3. **State·Binding·Action 의미 보존:** TwoWay 입력 업데이트, 클릭 이벤트, 조건·반복·컴포넌트 인스턴스/Slot 의미가 어댑터에 따라 달라져서는 안 된다.
4. **Undo/Redo 안정성:** 구조 편집·속성 변경·상태 연결이 한 문서 트랜잭션 안에서 일관되게 복구되어야 한다.
5. **내보내기 독립성:** 사용자에게 제공한 React 패키지는 UI Studio 앱 자체의 실행 환경 없이 설치·빌드·실행돼야 한다.
6. **하위 호환:** 검증되지 않은 v5/v6 문서 자동 변환이나 AntD 문서 파괴적 마이그레이션은 금지한다.
7. **보안:** 스키마 설정을 arbitrary JS 코드 실행으로 바꾸지 않으며 데이터·이벤트 평가의 허용 목록을 유지한다.

## 구조 변경 권장

```
packages/renderer-antd/           # 기존 문서/프로젝트 호환 유지
packages/renderer-shadcn-baseui/  # 앞으로 추가할 신규 어댑터 (미구현)
packages/schema/                  # renderer-neutral 문서 계약
packages/core/                    # 독립적인 편집/상태/명령
packages/runtime-react/           # 실행 의미
packages/exporter-react/          # 각 렌더러의 의존성·스타일 동봉
```

위 `renderer-shadcn-baseui` 경로는 **설계 제안**, 현재 포함된 소스 폴더가 아니다.
