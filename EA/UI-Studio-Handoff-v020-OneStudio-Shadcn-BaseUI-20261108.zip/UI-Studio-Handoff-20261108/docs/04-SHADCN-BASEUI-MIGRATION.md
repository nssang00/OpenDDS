# 새 기술 결정 — shadcn/ui + Base UI 기반

## 결론

**신규 개발의 목표 기본 기술은 `shadcn/ui + Base UI`**. 스타일은 Tailwind CSS + CSS 변수/디자인 토큰을 우선 검토한다. 이 구조는 사용자에게 선택 메뉴로 제공하지 않는다. 기존 AntD 렌더러는 호환성 유지용으로 남긴다.

**중요:** 이것은 최신 제품 전략 결정이며 **v0.20 소스에 이 렌더러가 이미 구현됐다는 뜻은 아니다**. 현재 `package.json`과 `packages/renderer-antd/`는 Ant Design을 사용한다.

## 전환 순서(안)

| 단계 | 구현 목표 | 실제 완료 증거 |
|---|---|---|
| P0 | **v0.20 Chrome/Consumer CI 정상화** | 6개 v0.20 Studio E2E + 독립 Consumer E2E + 전체 Actions success |
| P1 | 신규 shadcn/Base UI 렌더러 PoC | Button/Input/Card/Select/Dialog 계약·테스트; AntD와 renderer-neutral 값 매핑 |
| P2 | Preview와 Export 동등성 | 같은 JSON, 상태 바인딩·이벤트·접근성, 화면 결과 및 독립 설치 테스트 |
| P3 | Form/Table/Tabs/Menu/Popover 확장 | 반복/조건/포커스/키보드/테이블 고급 동작 회귀 검사 |
| P4 | Studio 자체 UI 단계적 전환 | AntD 편집기 UI 의존성 분리; 단일 편집 화면 유지 |
| P5 | 신규 프로젝트 기본 렌더러 변경 | 새 기본값으로 E2E 성공, 이전 AntD 문서 계속 정상 열림 |
| P6 | v1.0 품질 검증 | 사용자 관찰 연구, WCAG 관련 검사, 퍼포먼스/대형 문서/오류 복구/배포 |

P0 완료 없이 P1 기능을 default로 바꾸지 않는 것이 합리적이다.

## 기술·제품 트레이드오프

- shadcn/ui: 컴포넌트 소스를 직접 소유·수정하기 쉬움. 반면 프로젝트별 코드·스타일·의존성 동기화 비용이 늘어난다.
- Base UI: 포커스·오버레이·키보드 상호작용의 헤드리스 프리미티브. 실제 `aria-*`, 접근 가능한 이름, 전체 시나리오 검증은 여전히 책임져야 한다.
- Tailwind/CSS 변수: 디자인 토큰 통제가 쉬워지지만 생성물에서 CSS 누락·Tailwind 빌드 문제를 예방해야 한다.
- Select/Dialog/Popover: 포털, controlled/uncontrolled 값, 키보드 탐색, 포커스 복귀 등의 차이를 adapter 수준에서 명시적으로 흡수해야 한다.
- Table: AntD의 완제품 기능을 그대로 대체하기 어렵다. TanStack Table 등 별도 구성이 필요할 수 있고 실제 지원 범위 테스트가 선행돼야 한다.
- 패키지 버전과 공식 가이드는 구현 시작 시 최신 자료를 다시 확인한다. 여기에는 **버전 설치나 검증 완료를 주장하지 않는다**.

## 권장 데이터 계약 실험

- `core/Button`: `text`, `variant`, `disabled`, `click` 액션
- `core/Input`: `value`, `placeholder`, `disabled`, TwoWay 변경 반영/blur
- `core/Card`: `title`, `description`, Slot/children
- `core/Select`: `options`, `value`, `label`, 변경 이벤트/키보드 접근성
- `core/Dialog`: 현재 문서 모델 범위에 맞는 신규 또는 확장 타입 설계(기존 지원을 가정하지 않음)

단일 canonical JSON fixture를 AntD와 신규 어댑터 양쪽에 넣고, 각각 `Preview`/독립 Export에서 값·이벤트·키보드/ARIA가 일치하는지 비교한다.
