# 구현·검증 상태 — 사실과 계획 구분

## 버전별 상태

| 버전 | 범위 | Core | Studio Chrome E2E | 독립 Consumer E2E | 출처·판정 |
|---|---|---:|---:|---:|---|
| v0.14 | Visual-First 문서/상태/바인딩/행동 | 183/183 | 11/11 | 1/1 | [성공 CI](https://github.com/nssang00/chatgpt-write-test/actions/runs/40063374176) |
| v0.15 | Breadcrumb/복제/Undo/Redo | 188/188 | 13/13 | 1/1 | [성공 CI](https://github.com/nssang00/chatgpt-write-test/actions/runs/40076981416) |
| v0.16 | Canvas 계층 이동·간격·정렬 | 195/195 | 15/15 | 1/1 | [성공 CI](https://github.com/nssang00/chatgpt-write-test/actions/runs/40095158555) |
| v0.17 | 다중 선택/그룹 이동·삭제 | 204/204 | 17/17 | 1/1 | [성공 CI](https://github.com/nssang00/chatgpt-write-test/actions/runs/40161208899) |
| v0.18 | 드롭 판정/삽입 가이드/정밀 Drag & Drop | 210/210 | 20/20 | 1/1 | [성공 CI](https://github.com/nssang00/chatgpt-write-test/actions/runs/40168783803) |
| **v0.19** | 기본/고급 노출 분리(Simple First) | **210/210** | **24/24** | **1/1** | **마지막 전체 CI 성공** [#40348229963](https://github.com/nssang00/chatgpt-write-test/actions/runs/40348229963) |
| **v0.20** | **One Studio 단일 편집기** | **210/210** | **미실행/미확인 (6개 시나리오)** | **미실행/미확인** | **후보**, 로컬 Node 검증만 통과 |

수치는 해당 버전별 기존 기록 및 첨부 검증 문서에 보고된 결과다. v0.20 로컬 210/210은 **이번 인계 생성 시 별도 재실행**했다.

## v0.20에서 현재 확인된 내용

- `src/App.jsx`: 오직 `UnifiedStudio`를 렌더링하고 `ConfigProvider`를 사용한다. 과거 v5 진입 탭은 노출하지 않는다.
- `playwright.config.js`: `one-studio-v020.spec.js`만 선택하도록 `testMatch`를 제한한다. 총 **6개 Chrome 테스트가 작성되어 있으나 성공 실행 증거는 없다**.
- `V020-VERIFICATION.md`: 로컬 Core/구문/Runtime 통과와 Chrome·독립 Consumer 미실행을 명시한다.
- 로컬 재실행 결과: `verification/HANDOFF-CORE.log`, `HANDOFF-SYNTAX.log`, `HANDOFF-RUNTIME.log`.
- v0.20 소스 ZIP SHA-256: `eb2460da40dab144c132014668b6a462dd23eacdc515bc0d92d3ebb9a3ab5909`.
- v0.19 검증 기준선 SHA-256: `f467ebf53820c49c16b809b12c94cbefe6f05ea62f810f5b6d391bac8ac35a11`.

## 확인되지 않은 부분

- v0.20의 실제 Chrome, export된 React 소비자 설치·빌드·E2E, GitHub Actions green 결과
- 사용자 대상 관찰 연구, 클릭 수·소요시간·초보 사용자 성공률 측정
- 실제 shadcn/ui + Base UI 렌더러 코드 및 기존 AntD 문서에 대한 신규 렌더러 호환성
- 모든 모바일·보조기술·키보드 사용자 접근성 검증
- 정식 제품명 및 상표·도메인 사용 가능성

## GitHub 컨텍스트

- Repo: `nssang00/chatgpt-write-test`
- 마지막 전체 검증 v0.19 브랜치: `ci/ui-studio-v019-simple-first-20261027`
- v0.19 성공 커밋: `485d734a323f47816c85fa0ebba730b7b0758d40`
- v0.20 준비 브랜치: `ci/ui-studio-v020-one-studio-20261027`; v0.20 소스/CI 성공이 이 브랜치에 반영됐다는 근거는 없다. 이 인계 ZIP의 최신 후보 소스를 출발점으로 사용할 것.
- `main`은 검증 작업의 대상이 아니었으며, 자동 병합을 전제하지 않는다.
