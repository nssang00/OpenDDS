# 실행·검증·재현 Runbook

## 사용 환경

- Node.js **22** 권장. npm 레지스트리 접근 가능해야 의존성 설치 가능.
- 실제 E2E: 시스템 Google Chrome(`UI_STUDIO_USE_SYSTEM_CHROME=1`) 또는 Playwright에서 지원하는 Chromium.
- 저장소: `nssang00/chatgpt-write-test`; v0.20의 소스는 이 ZIP의 `source/ui-studio-v020/`에 있음.

## 개발 서버 실행

```bash
cd source/ui-studio-v020
npm install --no-audit --no-fund
npm run dev
# Vite 개발 서버: http://127.0.0.1:5173 (환경에 따라 출력 확인)
```

## 현재 실행 가능한 로컬 검증 (이번 인계에서 PASS)

```bash
cd source/ui-studio-v020
npm test
node tools/verify-syntax.mjs
npm run verify:runtime
```

이번 인계 생성 시 Node.js 22.16.0으로 **210/210**, 구문 **56+3 / 오류 0**, Runtime PASS. 로그는 루트의 `verification/` 참고.

## 아직 실행해 통과해야 하는 검증

```bash
cd source/ui-studio-v020
npm run build
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npm run test:e2e
npm run export:v014
# tools/export-v013.mjs를 호출하는 오래된 별칭에 유의
mkdir -p tests/component-v014
unzip -q -o examples/CustomerBrowser-react-component-v0.13.zip -d tests/component-v014
(cd tests/component-v014 && npm install --no-audit --no-fund && npm run build && npm pack --pack-destination ../consumer-v013)
(cd tests/consumer-v013 && npm install --no-audit --no-fund && npm run build)
CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npx playwright test --config=e2e/consumer-v013.config.js
```

**주의:** 위 명령들은 권장 검증 절차이며, 이 인계 생성 시 v0.20 브라우저·Consumer·빌드는 재실행하지 않았다. 해당 절차를 완료하기 전에는 PASS라고 기록하지 말 것. Python 등 패키징 도구가 실행한 것은 테스트를 대신하지 않는다.

## 원본 재구성

- `archives/ui-studio-v019-verified-baseline-20261027.zip`은 원본의 마지막 전체 CI 검증 기준선이다.
- `archives/ui-studio-v020-one-studio-candidate-20261027.zip`은 최신 후보 원본 ZIP이다.
- `tools/v020-reproduce.py`는 이전 작업에서 사용한 v0.19 기준선 기반 재구성 스크립트(원본 그대로 보존). 입력 경로는 현재 환경에 맞춰 확인해야 한다.
- 번거롭게 재구성할 필요 없이 `source/ui-studio-v020/`를 그대로 사용할 수 있으며, 동일 바이트 무결성은 `SHA256SUMS.txt`로 확인한다.

## 패키지 검증

```bash
python tools/verify_handoff.py .
# ZIP을 풀어서 루트에서 실행. 파일의 해시와 소스 자체 manifest 확인.
```

## 브라우저 실패 시

- `test-results/`, `playwright-report/` 및 trace를 보존한 뒤 실패한 assertion과 제품 동작을 분리한다.
- 오래된 UI 선택자가 v0.20의 제거된 Legacy/Advanced 요소를 찾는지 우선 검사한다.
- 실제 동작의 결함을 테스트 기대값 수정만으로 덮지 않는다.
- 재현 테스트를 추가하고 Core/Chrome/Consumer 전체를 다시 돌린다.
