# 다음 담당자의 실행 순서 (P0 먼저)

## P0. v0.20을 정식 Baseline으로 확정

1. `source/ui-studio-v020`에서 `npm install --no-audit --no-fund` 후 `npm test`, 구문 검사, Runtime, Vite build를 재실행한다.
2. `CI=true UI_STUDIO_USE_SYSTEM_CHROME=1 npm run test:e2e`로 **새 단일 편집기 Playwright 6개**를 Google Chrome에서 확인한다.
3. `npm run export:v014` 후 생성된 독립 React 패키지를 `tests/consumer-v013` 소비자 프로젝트에 설치·빌드하고 Consumer E2E를 통과시킨다.
4. 기존 v0.19 브라우저 테스트 중 **제품 설계가 변경된 v5/Advanced 모드 테스트는 폐기 또는 대체하고**, 핵심 편집·동작·Export 회귀를 별도 테스트에 유지한다. 단순 `testMatch` 변경만으로 회귀를 감춘 것으로 처리하지 않는다.
5. 검증 브랜치에서 GitHub Actions를 녹색으로 만들고 commit SHA, run URL, 체크섬, 브라우저 증거를 남긴다.
6. 그때만 `v0.20 verified baseline`으로 승격한다. `main` 병합은 명시적인 승인 시에만 수행한다.

**이 P0가 완료되었다는 현재 증거는 없다.**

## P1. 신 렌더러 PoC

1. 현재 실제 스키마/renderer contract를 먼저 문서화한다.
2. `Button`, `Input`, `Card`를 우선 만들어 바인딩과 이벤트·Slot을 확인한다.
3. `Select`, `Dialog`에 대해 접근성/포털/동기화/키보드 시나리오를 추가한다.
4. 단일 JSON fixture로 두 렌더러 간 runtime 행태를 비교한다.
5. 독립 React Export 안에 component source, runtime, 스타일, dependencies가 동봉되는지 실제 consumer로 검증한다.
6. 기존 AntD 문서는 변환 강제 없이 계속 열리도록 한다.

## P2. UI 복잡도 실사용 검증

- 처음 방문한 사용자에게 `추가 → 선택·수정 → 동작 연결 → 미리보기` 과제를 제공한다.
- 안내 없이 과제를 끝낸 비율, 소요시간, 과제 중 막힌 구간, 메뉴·설정 탐색 횟수 측정.
- 실패 구간에 대해 UI를 수정한 뒤 같은 과제를 재검증한다.
- 기능 수보다 **가시적 선택지 수와 작업 완료 성공률**을 우선한다.

## 모든 작업의 Done 조건

- 수정된 소스·테스트가 패키지에 반영되고 재현 명령 제공
- 기존 Core, 구문 검사, Runtime 및 Vite build 모두 PASS
- 실제 Chrome Studio 새 기능 E2E 및 독립 React Consumer E2E PASS
- 기존 스키마/설계와의 호환성 회귀 PASS
- SHA-256 체크섬, 실제 CI run/commit, ZIP 무결성 검증
- 미검증 영역·제약을 명시(단위 테스트 성공만으로 전체 완료 선언 금지)
