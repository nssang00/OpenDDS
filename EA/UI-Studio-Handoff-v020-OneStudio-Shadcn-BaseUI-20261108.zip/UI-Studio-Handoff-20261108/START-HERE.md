# UI Studio — 개발 인계 패키지

**작성 기준일: 2026-11-08**  
**가장 중요한 구분: v0.19 = 전체 CI 검증 완료 / v0.20 = 로컬 검증 완료 후보**

## 30초 요약

- 제품 목표: **설명 없이 사용할 수 있는, 하나뿐인 시각적 React UI 제작 환경(One Studio UX)**. 개발자 용어와 도구 선택은 사용자에게 강요하지 않는다.
- 가장 최신 구현: **v0.20 One Studio 후보**. v5/v6 선택 및 Simple/Advanced 모드 선택 화면을 제거하고 단일 canonical v6 편집기에 진입하도록 변경했다.
- 마지막 전체 CI 성공: **v0.19**, Core 210/210, Chrome Studio 24/24, 독립 React Consumer 1/1, 빌드/Runtime 통과. [GitHub Actions](https://github.com/nssang00/chatgpt-write-test/actions/runs/40348229963).
- v0.20 로컬 검증: 이번 인계 생성 시 **Core 210/210, 구문 오류 0, Runtime 통과**를 재실행 확인. **Chrome E2E 6개 및 독립 Consumer E2E 결과는 미확인**. v0.19의 성공을 v0.20의 성공으로 대체하지 말 것.
- **새로 결정된 장기 기술 방향:** `shadcn/ui + Base UI`(디자인/상호작용), Tailwind + 디자인 토큰. 현재 v0.20 **실제 구현은 Ant Design 6**. 신규 렌더러 개발·기본값 변경·편집기 UI 마이그레이션은 앞으로 진행할 계획이며 구현 완료가 아니다.
- 기존 JSON v6, State/Binding/Action, Runtime, React Export를 유지하고 AntD 기존 문서는 호환성을 확보해야 한다.
- 제품 이름은 확정되지 않았다. PLYRA / MODARO 등은 **단순 후보**이며 상표·도메인을 확인하지 않았다. 코드/문서의 임시 명칭은 UI Studio를 유지한다.

## 이 패키지에서 먼저 볼 파일

1. `docs/01-STATUS-AND-EVIDENCE.md` — 검증된 사실·미검증·CI 링크
2. `docs/02-ONE-STUDIO-UX.md` — 단일 편집기 UX 제품 원칙
3. `docs/03-ARCHITECTURE.md` — 현재 기술 구조와 변경 불변조건
4. `docs/04-SHADCN-BASEUI-MIGRATION.md` — 새로 합의한 기술 전략·순서
5. `docs/05-NEXT-ACTIONS-AND-ACCEPTANCE.md` — 즉시 진행할 작업 및 Done 기준
6. `docs/06-LOCAL-AND-CI-RUNBOOK.md` — 실행, 테스트, 오류 대응
7. `source/ui-studio-v020/` — 최신 **후보** 소스, 즉시 개발 시작 가능
8. `archives/ui-studio-v019-verified-baseline-20261027.zip` — 마지막 전체 CI 성공 기준선
9. `archives/ui-studio-v020-one-studio-candidate-20261027.zip` — 원본 후보 ZIP 바이트 보존
10. `tools/v020-reproduce.py` — v0.19 → v0.20 재구성·검사 원본 스크립트

## 새 세션에 전달할 권장 지시

> `START-HERE.md`부터 읽고 `source/ui-studio-v020/` 기준으로 개발을 이어가라. v0.20은 **정식 Baseline이 아니라 후보**다. 먼저 실제 Chrome E2E 6개, 독립 React Consumer, 전체 CI를 통과시켜 기준선을 확정하라. 다음으로 `shadcn/ui + Base UI` 렌더러를 기존 canonical JSON v6의 별도 어댑터로 구현하라. AntD 호환을 유지하며 사용자에게 라이브러리 선택을 노출하지 말 것. 오류를 재현·수정·재실행하고 SHA-256/CI 링크로 결과를 입증하라.

## 주의

- `source/ui-studio-v020/README.md`와 과거 내장 `.github/workflows/`에는 이전 버전 문구가 남아 있다. **인계 문서와 v0.20의 V020-SCOPE/VERIFICATION이 우선**한다.
- 역사적 스냅샷을 현재 기술 결정으로 오해하지 말 것. 아카이브는 근거 및 롤백용이다.
- GitHub 검증 브랜치에서만 작업되었고 **main 병합은 확인되지 않았다**.
- 브라우저 증거 아티팩트는 보관기간이 만료될 수 있다. GitHub Run 링크와 소스 ZIP, 문서의 해시도 함께 보존한다.
