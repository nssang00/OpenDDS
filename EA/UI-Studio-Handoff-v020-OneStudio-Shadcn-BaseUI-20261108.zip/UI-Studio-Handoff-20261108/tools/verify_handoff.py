#!/usr/bin/env python3
"""Check SHA-256 integrity for this extracted handoff directory."""
from pathlib import Path
from hashlib import sha256
import re,sys
root=Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
manifest=root/'SHA256SUMS.txt'
if not manifest.exists():raise SystemExit('ERROR: SHA256SUMS.txt missing')
seen=set()
for line in manifest.read_text(encoding='utf-8').splitlines():
    match=re.fullmatch(r'([a-f0-9]{64})  (.+)',line)
    if not match:raise SystemExit(f'ERROR: malformed manifest line {line!r}')
    p=(root/match.group(2)).resolve()
    if not p.is_relative_to(root) or not p.is_file():raise SystemExit(f'ERROR: unsafe or absent {p}')
    h=sha256(p.read_bytes()).hexdigest()
    if h!=match.group(1):raise SystemExit(f'ERROR: SHA-256 mismatch {p}')
    seen.add(p)
source=root/'source'/'ui-studio-v020'
source_manifest=source/'SHA256SUMS.txt'
if not source_manifest.exists():raise SystemExit('ERROR: source manifest missing')
verified=0
for line in source_manifest.read_text(encoding='utf-8').splitlines():
    match=re.fullmatch(r'([a-f0-9]{64})  (.+)',line)
    if not match:raise SystemExit('ERROR: bad source manifest line')
    p=(source/match.group(2)).resolve()
    if not p.is_relative_to(source) or not p.is_file() or sha256(p.read_bytes()).hexdigest()!=match.group(1):
        raise SystemExit('ERROR: source manifest mismatch '+str(p))
    verified+=1
actual={p.resolve() for p in root.rglob('*') if p.is_file()}
# The one source manifest is included in outer manifest; only the top-level manifest is excluded.
actual={p for p in actual if p != (root/'SHA256SUMS.txt').resolve()}
if seen != actual:
    raise SystemExit(f'ERROR: file inventory mismatch, missing={len(actual-seen)}, extra={len(seen-actual)}')
print(f'PASS: {len(seen)} handoff file hashes and {verified} v0.20 source hashes verified')
