
#include "Repository.hpp"

bool Repository::load(const std::string& qeaFile)
{
    m_fileName = qeaFile;

    if(!loadPackages()) return false;
    if(!loadElements()) return false;
    if(!loadAttributes()) return false;
    if(!loadConnectors()) return false;
    if(!loadStereotypes()) return false;
    if(!loadTaggedValues()) return false;

    return resolveReferences();
}
