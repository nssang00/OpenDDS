
# QEA DDS Repository Design

목표
- Sparx EA Add-In 스타일 API
- DDS/OMG IDL 생성
- Web 모델 탐색
- QEA(SQLite) 기반

핵심 테이블
- t_package
- t_object
- t_attribute
- t_connector
- t_xref
- t_objectproperties

의도적으로 제외
- t_operation
- t_operationparams
- 대부분의 다이어그램 관련 세부 테이블
