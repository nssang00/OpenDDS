
#pragma once
#include <string>
#include <vector>

class Element;
class TaggedValue;

class Attribute
{
public:
    Attribute();

    long getId() const;
    const std::string& getName() const;
    const std::string& getType() const;

    bool isKey() const;
    bool isOptional() const;

    Element* getReferencedElement() const;

private:
    long m_id;
    std::string m_name;
    std::string m_type;

    bool m_isKey;
    bool m_isOptional;

    Element* m_referencedElement;
};
