
#pragma once
#include <string>

class Element;

class Connector
{
public:
    Connector();

    long getId() const;

    Element* getClient() const;
    Element* getSupplier() const;

    bool isAssociation() const;
    bool isInheritance() const;

private:
    long m_id;

    std::string m_type;

    Element* m_client;
    Element* m_supplier;
};
