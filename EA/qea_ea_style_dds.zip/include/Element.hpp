
#pragma once
#include <string>
#include <vector>

#include "Stereotype.hpp"
#include "TaggedValue.hpp"

class Package;
class Attribute;
class Connector;

class Element
{
public:
    Element();

    long getId() const;
    const std::string& getGuid() const;
    const std::string& getName() const;
    const std::string& getType() const;

    Package* getPackage() const;

    const std::vector<Attribute*>& getAttributes() const;
    const std::vector<Connector*>& getConnectors() const;

    const std::vector<Stereotype>& getStereotypes() const;
    const std::vector<TaggedValue>& getTaggedValues() const;

    bool hasStereotype(const std::string& name) const;

    bool isTopic() const;
    bool isStruct() const;
    bool isEnum() const;

private:
    long m_id;

    std::string m_guid;
    std::string m_name;
    std::string m_type;

    Package* m_package;

    std::vector<Attribute*> m_attributes;
    std::vector<Connector*> m_connectors;

    std::vector<Stereotype> m_stereotypes;
    std::vector<TaggedValue> m_taggedValues;
};
