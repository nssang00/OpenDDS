
#pragma once
#include <string>
#include <vector>

class Element;

class Diagram
{
public:
    const std::string& getName() const;
    const std::vector<Element*>& getElements() const;

private:
    std::string m_name;
    std::vector<Element*> m_elements;
};
