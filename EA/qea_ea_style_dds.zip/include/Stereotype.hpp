
#pragma once
#include <string>

class Stereotype
{
public:
    Stereotype();
    explicit Stereotype(const std::string& name);

    const std::string& getName() const;

private:
    std::string m_name;
};
