
#pragma once
#include <string>
#include <vector>

class Package;
class Element;
class Diagram;

class Package
{
public:
    Package();

    long getId() const;
    const std::string& getGuid() const;
    const std::string& getName() const;

    Package* getParent() const;

    const std::vector<Package*>& getPackages() const;
    const std::vector<Element*>& getElements() const;
    const std::vector<Diagram*>& getDiagrams() const;

private:
    long m_id;

    std::string m_guid;
    std::string m_name;

    Package* m_parent;

    std::vector<Package*> m_packages;
    std::vector<Element*> m_elements;
    std::vector<Diagram*> m_diagrams;
};
