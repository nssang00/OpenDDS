
#pragma once
#include <string>
#include <vector>
#include <map>
#include <memory>

class Package;
class Element;
class Connector;
class Diagram;

class Repository
{
public:
    bool load(const std::string& qeaFile);

    const std::vector<Package*>& getModels() const;

    Package* getPackageById(long id);
    Element* getElementById(long id);

    Element* findElement(const std::string& name);

private:
    bool loadPackages();
    bool loadElements();
    bool loadAttributes();
    bool loadConnectors();
    bool loadStereotypes();
    bool loadTaggedValues();

    bool resolveReferences();

private:
    std::vector<std::shared_ptr<Package> > m_packages;
    std::vector<std::shared_ptr<Element> > m_elements;
    std::vector<std::shared_ptr<Connector> > m_connectors;
    std::vector<std::shared_ptr<Diagram> > m_diagrams;

    std::vector<Package*> m_models;

    std::map<long, Package*> m_packageMap;
    std::map<long, Element*> m_elementMap;

    std::string m_fileName;
};
