
#pragma once
#include <string>

class TaggedValue
{
public:
    TaggedValue();
    TaggedValue(const std::string& name,const std::string& value);

    const std::string& getName() const;
    const std::string& getValue() const;

private:
    std::string m_name;
    std::string m_value;
};
