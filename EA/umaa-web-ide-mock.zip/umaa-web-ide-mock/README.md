# UMAA Web IDE — Mock 기반 초기 MVP

**React + TypeScript + Ant Design + React Flow + Zustand**를 사용한 실행형 시제품입니다. 서버/PostgreSQL 없이 `MockProjectRepository`의 지연 응답 + 브라우저 `localStorage`로 동작합니다.

## 실행

Node.js 20 이상 환경에서:

```bash
npm install
npm run dev
# http://localhost:5173
```

브라우저에서 **저장**을 누르면 Mock 설계 모델이 `localStorage`에 저장됩니다. **초기화**를 누르면 기본 샘플로 돌아갑니다.

## 기본 제공 Mock 시나리오

- `USV Navigation`: `GlobalPoseStatus` Provider
- `Autopilot`: `GlobalPoseStatus` Consumer, `GlobalVectorControl` Provider
- `Mission Executor`: `GlobalPoseStatus` Consumer, `GlobalVectorControl` Consumer
- `GlobalPoseStatus` — `reportGlobalPose` 발행 / `queryGlobalPose`는 DDS 구독 (별도의 Request Topic을 만들지 않음)
- `GlobalVectorControl` — `setGlobalVector`, Status, Ack, ExecutionStatus, Cancel(Dispose) Operation

두 서비스의 Operation/Topic 이름은 UMAA 6.0 ICD 공개본을 기반으로 구성했습니다. **표준 메시지 필드 목록은 완전한 공식 IDL을 확보해야 하므로 Mock에서 임의로 작성하지 않았습니다.**

## 실행 흐름

1. 좌측 **Project** 트리에서 Component를 선택해 우측 패널에서 Service Binding을 추가합니다.
2. Service Catalog에서 표준/Custom Service의 Operation 및 메시지 구조를 확인합니다.
3. 캔버스에서 **Provider(P)** 오른쪽 Handle을 **같은 Service의 Consumer(C)** 왼쪽 Handle에 드래그해 연결합니다.
4. 하단 **Validation**, **DDS Endpoint Matrix**, **Mock Flow Simulation**에서 연결 구조와 개념적 메시지 흐름을 확인합니다.
5. 상단 **코드 생성**에서 Component 또는 전체를 선택하고 CMake/C++/IDL 생성 파일을 미리봅니다.
6. **ZIP 다운로드**로 생성된 소스 트리를 저장합니다.
7. ZIP 내부 Component 폴더에서 `cmake -S . -B build && cmake --build build`로 **공유 라이브러리 골격**을 빌드합니다.

### Custom Service 흐름

1. 상단 `Custom Service`를 추가합니다. 이름과 `request-reply` 또는 `command-response`를 선택합니다.
2. Mock 생성기가 Custom Message/Topic/Operation 기본 템플릿을 만듭니다.
3. 좌측 Services에서 Service 선택 → 우측 Messages에서 Message 선택 → Field 추가/삭제가 가능합니다.
4. Component에 이 Custom Service를 Provider 또는 Consumer로 연결합니다.
5. 생성 ZIP의 `idl/custom/*.idl`에 IDL 구조가 출력됩니다.

> Custom Command/Response 템플릿은 설계 흐름을 실험하기 위한 최소형입니다. 실제 UMAA CommandState·GUID·세션·표준 데이터 타입 및 QoS를 구현한 것이 아닙니다.

## 생성기 한계 — 중요

- **빌드 가능한 DLL/SO 골격은 생성**되지만, DDS SDK 없이 실제 DataWriter/DataReader를 실행하지 않습니다.
- `generated/endpoints.hpp`와 `component.manifest.json`에 실제 SDK 바인딩을 구현할 수 있는 정확한 *의도(Writer/Reader, Topic, Type)*가 기록됩니다.
- UMAA **표준 IDL 원본은 새로 생성하지 않고** `idl/standard/README.md`에서 필요한 외부 배포 파일을 참조합니다.
- Custom IDL만 모델에서 생성합니다. IDL 컴파일/타입 생성은 추후 선택한 DDS 벤더 도구를 연결합니다.
- 이 MVP는 **UMAA Compliance 인증을 하지 않으며**, 정적 구조 검사만 수행합니다.
- `large collections` 및 `generalization/specialization` 동기화 구현은 후속 단계입니다.
- Windows DLL 빌드는 Windows 컴파일러로, Linux SO 빌드는 Linux 컴파일러로 수행해야 합니다. 단순 설정 변경만으로 크로스컴파일되지 않습니다.

## 모듈 구성

```text
src/
  model/types.ts, seed.ts             # 도메인 스키마/샘플 데이터
  repository/ProjectRepository.ts    # PostgreSQL API로 전환할 계약
  repository/mockRepository.ts       # Mock 저장소
  stores/useEditorStore.ts           # Zustand 편집 상태
  logic/validation.ts                # 설계 구조 검사
  logic/endpoints.ts                 # Binding→DDS Endpoint 계산
  logic/codegen.ts                   # Mock CMake/CPP/IDL 생성
  logic/mockRuntime.ts              # DDS 없는 흐름 시뮬레이션
  components/Diagram.tsx             # React Flow 관계도
  components/Inspector.tsx           # Ant Design 상세 설계
  components/ServiceCatalog.tsx      # Service 정의 조회
  components/GenerationPanel.tsx     # 코드 미리보기/ZIP
```

## PostgreSQL 전환 시 변경 지점

`src/repository/ProjectRepository.ts`의 `load/save/reset` 인터페이스를 그대로 사용합니다.

```ts
export interface ProjectRepository {
  load(projectId: string): Promise<WorkspaceSnapshot>;
  save(projectId: string, snapshot: WorkspaceSnapshot): Promise<void>;
  reset(projectId: string): Promise<WorkspaceSnapshot>;
}
```

실제 운영에는 `reset` 대신 새 버전 생성·가져오기·이력 조회 API를 두는 것을 권장합니다.
Zustand와 React Flow는 저장소 종류를 알 필요가 없습니다. `HttpProjectRepository`를 구현해 현재 `repository` 인스턴스를 대체하고 서버 측 validation/version lock을 추가합니다.

참고용 정규화 모델은 `docs/postgresql-schema.sql`에 있습니다. 이 SQL은 **설계 초안**이며 운영용 마이그레이션이 아닙니다.
