import { seedWorkspace } from '../model/seed';
import type { WorkspaceSnapshot } from '../model/types';
import type { ProjectRepository } from './ProjectRepository';

const storageKey = (projectId: string) => `umaa-mock-v1:${projectId}`;
const wait = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));
const clone = <T,>(v: T): T => structuredClone(v);

export class MockProjectRepository implements ProjectRepository {
  async load(projectId: string): Promise<WorkspaceSnapshot> {
    await wait(160);
    const saved = localStorage.getItem(storageKey(projectId));
    if (!saved) return clone(seedWorkspace);
    try { return JSON.parse(saved) as WorkspaceSnapshot; }
    catch { return clone(seedWorkspace); }
  }
  async save(projectId: string, snapshot: WorkspaceSnapshot): Promise<void> {
    await wait(130);
    localStorage.setItem(storageKey(projectId), JSON.stringify(snapshot));
  }
  async reset(projectId: string): Promise<WorkspaceSnapshot> {
    await wait(100);
    localStorage.removeItem(storageKey(projectId));
    return clone(seedWorkspace);
  }
}

export const repository: ProjectRepository = new MockProjectRepository();
