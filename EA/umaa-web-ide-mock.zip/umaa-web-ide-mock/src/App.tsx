import { useEffect, useMemo, useState } from 'react';
import { Alert, Badge, Button, ConfigProvider, Divider, Flex, Form, Input, Layout, Modal, Select, Space, Spin, Table, Tabs, Tag, Tooltip, Typography, message } from 'antd';
import { AppstoreOutlined, CloudDownloadOutlined, DatabaseOutlined, FileAddOutlined, PlusOutlined, ReloadOutlined, SaveOutlined, SafetyCertificateOutlined, ShareAltOutlined } from '@ant-design/icons';
import { Diagram } from './components/Diagram';
import { GenerationPanel } from './components/GenerationPanel';
import { Inspector } from './components/Inspector';
import { ProjectExplorer } from './components/ProjectExplorer';
import { ServiceCatalog } from './components/ServiceCatalog';
import { FlowSimulationPanel } from './components/FlowSimulationPanel';
import { deriveEndpoints } from './logic/endpoints';
import { validateWorkspace } from './logic/validation';
import type { FlowControl } from './model/types';
import { useEditorStore } from './stores/useEditorStore';
import './styles.css';

const { Header, Sider, Content } = Layout;
const { Text, Title } = Typography;

function BottomPanel() {
  const snapshot = useEditorStore(s => s.snapshot);
  const select = useEditorStore(s => s.select);
  const issues = useMemo(() => snapshot ? validateWorkspace(snapshot) : [], [snapshot]);
  const endpoints = useMemo(() => snapshot?.components.flatMap(c => deriveEndpoints(snapshot, c.id).map(e => ({ ...e, componentName: c.name, id: `${e.bindingId}:${e.topicName}:${e.direction}` }))) ?? [], [snapshot]);
  return <div className="bottom-panel"><Tabs defaultActiveKey="validation" size="small" items={[
    { key: 'validation', label: <span><SafetyCertificateOutlined /> Validation <Badge size="small" count={issues.length} style={{ backgroundColor: issues.some(i => i.severity === 'error') ? '#cf5656' : '#738ca3' }} /></span>, children:
      issues.length === 0 ? <Alert type="success" showIcon message="Mock 모델 구조 검사를 통과했습니다. (UMAA Compliance 인증이 아닙니다)" /> :
      <div className="issue-list">{issues.map((i, index) => <div key={`${i.code}-${index}`} className="issue-row">
        <Tag color={i.severity === 'error' ? 'red' : 'gold'}>{i.severity.toUpperCase()}</Tag>
        <Text>{i.message}</Text>
        {i.entityId && <Button size="small" type="link" onClick={() => {
          if (!snapshot) return;
          const kind = snapshot.bindings.some(b => b.id === i.entityId) ? 'binding'
            : snapshot.connections.some(c => c.id === i.entityId) ? 'connection'
            : snapshot.services.some(s => s.id === i.entityId) ? 'service'
            : snapshot.messages.some(m => m.id === i.entityId) ? 'message' : null;
          if (kind) select({ kind, id: i.entityId! });
        }}>이동</Button>}
      </div>)}</div> },
    { key: 'simulation', label: <span><ShareAltOutlined /> Mock Flow Simulation</span>, children: <FlowSimulationPanel /> },
    { key: 'matrix', label: <span><DatabaseOutlined /> DDS Endpoint Matrix <Tag>{endpoints.length}</Tag></span>, children: <Table size="small" pagination={{ pageSize: 4 }} rowKey="id" scroll={{ x: 700 }} dataSource={endpoints} columns={[
      { title: 'Component', dataIndex: 'componentName', width: 160 },
      { title: 'Service', dataIndex: 'serviceName', width: 185 },
      { title: 'Role', dataIndex: 'role', width: 100 },
      { title: 'Endpoint', dataIndex: 'direction', width: 95, render: (x: string) => <Tag color={x === 'writer' ? 'blue' : 'orange'}>{x}</Tag> },
      { title: 'Topic / Message Type', dataIndex: 'topicName', width: 220 },
    ]} /> },
  ]} /></div>;
}

function AddCustomServiceModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [form] = Form.useForm();
  const createService = useEditorStore(s => s.addCustomService);
  return <Modal title="Custom Service 생성" open={open} okText="생성" onCancel={onClose} destroyOnClose onOk={async () => {
    try {
      const v = await form.validateFields() as { name: string; flow: FlowControl };
      if (createService(v.name, v.flow)) { message.success('Custom Service 및 메시지 정의를 생성했습니다.'); form.resetFields(); onClose(); }
      else message.error('서비스명 중복 또는 식별자 형식 오류');
    } catch { /* validation */ }
  }}>
    <Alert type="info" showIcon message="Custom Service는 UMAA 표준 Service가 아닙니다." description="생성되는 IDL은 프로젝트 정의이며, 규격 준수는 별도 검토해야 합니다." style={{ marginBottom: 16 }} />
    <Form layout="vertical" form={form} initialValues={{ flow: 'request-reply' }}>
      <Form.Item name="name" label="Service Name" rules={[{ required: true }, { pattern: /^[A-Za-z][A-Za-z0-9_]*$/, message: '영문자로 시작하는 이름을 사용하세요' }]}><Input placeholder="CustomSensorStatus" /></Form.Item>
      <Form.Item name="flow" label="Flow Control"><Select options={[{ label: 'Request / Reply (구독 기반 조회 템플릿)', value: 'request-reply' }, { label: 'Command / Response (명령/상태 템플릿)', value: 'command-response' }]} /></Form.Item>
    </Form>
  </Modal>;
}

export default function App() {
  const snapshot = useEditorStore(s => s.snapshot);
  const loading = useEditorStore(s => s.loading);
  const saving = useEditorStore(s => s.saving);
  const dirty = useEditorStore(s => s.dirty);
  const load = useEditorStore(s => s.load);
  const save = useEditorStore(s => s.save);
  const reset = useEditorStore(s => s.reset);
  const addComponent = useEditorStore(s => s.addComponent);
  const changeVendor = useEditorStore(s => s.changeVendor);
  const changePlatform = useEditorStore(s => s.changePlatform);
  const [componentModal, setComponentModal] = useState(false);
  const [serviceModal, setServiceModal] = useState(false);
  const [generationOpen, setGenerationOpen] = useState(false);
  const [componentForm] = Form.useForm();
  const issues = useMemo(() => snapshot ? validateWorkspace(snapshot) : [], [snapshot]);
  useEffect(() => { void load(); }, [load]);

  return <ConfigProvider theme={{ token: { colorPrimary: '#3267ad', borderRadius: 8, colorBgLayout: '#f3f6fa', fontSize: 13 } }}>
    <Layout className="app-shell">
      <Header className="app-header">
        <Flex justify="space-between" align="center" gap={14} style={{ height: '100%' }}>
          <Space size={12} align="center"><div className="app-logo"><ShareAltOutlined /></div><div><div className="app-title">UMAA Web IDE</div><div className="app-subtitle">Mock MVP · React / Ant Design / React Flow / Zustand</div></div></Space>
          <Space size={8} wrap>
            <Tag color="processing">{snapshot?.project.standardVersion ?? 'UMAA 6.0'}</Tag>
            {dirty ? <Tag color="gold">Unsaved</Tag> : <Tag color="green">Saved</Tag>}
            <Tooltip title="로컬 저장소의 Mock 상태를 초기화합니다"><Button size="small" icon={<ReloadOutlined />} disabled={!snapshot} onClick={() => Modal.confirm({ title: 'Mock 데이터 초기화', content: '저장된 편집 내용을 삭제하고 기본 샘플로 되돌릴까요?', okText: '초기화', cancelText: '취소', onOk: async () => { await reset(); message.success('초기화했습니다.'); } })}>초기화</Button></Tooltip>
            <Button size="small" icon={<SaveOutlined />} loading={saving} disabled={!snapshot} onClick={async () => { await save(); message.success('브라우저 Mock 저장소에 저장했습니다.'); }}>저장</Button>
            <Button type="primary" size="small" icon={<CloudDownloadOutlined />} disabled={!snapshot} onClick={() => setGenerationOpen(true)}>코드 생성</Button>
          </Space>
        </Flex>
      </Header>
      {!snapshot || loading ? <Content className="loading-content"><Spin size="large" tip="Mock 프로젝트 로딩 중"><div style={{ width: 300, height: 160 }} /></Spin></Content> : <Layout className="main-layout">
        <Sider width={280} theme="light" className="side-pane left-pane">
          <div className="pane-toolbar"><Text strong>Project Explorer</Text><Space><Tooltip title="Component 추가"><Button size="small" icon={<PlusOutlined />} onClick={() => setComponentModal(true)}/></Tooltip><Tooltip title="Custom Service 추가"><Button size="small" icon={<FileAddOutlined />} onClick={() => setServiceModal(true)}/></Tooltip></Space></div>
          <Tabs className="explorer-tabs" size="small" defaultActiveKey="project" items={[
            { key: 'project', label: <span><AppstoreOutlined /> Project</span>, children: <ProjectExplorer /> },
            { key: 'catalog', label: <span><DatabaseOutlined /> Services</span>, children: <ServiceCatalog /> },
          ]} />
          <div className="side-footer"><Text type="secondary">로컬 Mock Repository</Text><br/><Text type="secondary" style={{ fontSize: 11 }}>PostgreSQL 미연결 · Save 시 localStorage 저장</Text></div>
        </Sider>
        <Content className="workspace-pane">
          <div className="workspace-toolbar">
            <div><Title level={5} style={{ margin: 0 }}>Component Assembly</Title><Text type="secondary">Provider → Consumer 포트를 드래그하여 동일 Service를 연결</Text></div>
            <Space><Button icon={<PlusOutlined />} onClick={() => setComponentModal(true)}>Component</Button><Button icon={<FileAddOutlined />} onClick={() => setServiceModal(true)}>Custom Service</Button></Space>
          </div>
          <div className="canvas-section"><Diagram /></div>
          <div className="workspace-bottom"><BottomPanel /></div>
        </Content>
        <Sider width={358} theme="light" className="side-pane right-pane">
          <Inspector />
          <Divider style={{ margin: '10px 0' }}/>
          <div className="project-settings"><Text strong>Build Target (Mock)</Text><div style={{ marginTop: 10 }}><Text type="secondary">Platform</Text><Select style={{ width: '100%', marginTop: 4 }} value={snapshot.project.targetPlatform} onChange={changePlatform} options={[{ label: 'Linux (.so)', value: 'linux' }, { label: 'Windows (.dll)', value: 'windows' }]}/></div>
            <div style={{ marginTop: 10 }}><Text type="secondary">DDS Vendor (메타데이터만)</Text><Select style={{ width: '100%', marginTop: 4 }} value={snapshot.project.ddsVendor} onChange={changeVendor} options={[{ label: 'eProsima Fast DDS', value: 'fastdds' }, { label: 'RTI Connext DDS', value: 'connext' }]}/></div>
            <div style={{ marginTop: 14 }}><Badge status={issues.some(i => i.severity === 'error') ? 'error' : issues.length ? 'warning' : 'success'} text={<Text type="secondary">정적 모델 검사 {issues.filter(v => v.severity === 'error').length} errors / {issues.filter(v => v.severity === 'warning').length} warnings</Text>} /></div>
          </div>
        </Sider>
      </Layout>}
    </Layout>
    <Modal title="Component 추가" open={componentModal} okText="추가" destroyOnClose onCancel={() => setComponentModal(false)} onOk={async () => {
      try { const v = await componentForm.validateFields() as { name: string }; addComponent(v.name); setComponentModal(false); componentForm.resetFields(); message.success('Component를 추가했습니다.'); }
      catch { /* validation */ }
    }}><Form form={componentForm} layout="vertical"><Form.Item name="name" label="Component Name" rules={[{ required: true, message: '이름을 입력하세요' }]}><Input placeholder="Sensor Fusion" /></Form.Item></Form></Modal>
    <AddCustomServiceModal open={serviceModal} onClose={() => setServiceModal(false)} />
    <GenerationPanel open={generationOpen} onClose={() => setGenerationOpen(false)} />
  </ConfigProvider>;
}
