# Mock MVP 변경 내역

## 바뀐 점

- C++ 서버, SQLite Application DB 및 QEA 읽기 로직을 ZIP에서 제거했습니다.
- `fetch('/api/...')` 대신 `src/lib/api.js`의 비동기 Mock API로 교체했습니다.
- `src/lib/mockData.js`에 합성 EA/UMAA 데모를 분리했습니다.
- 사용자 수정·프로젝트 정보는 브라우저 localStorage에 저장합니다.
- QEA Import는 가상 Snapshot 생성/합성 모델 재로드 시뮬레이션만 수행합니다. 파일 내용은 읽지 않습니다.
- IDL/Markdown/C++ Handler 초안은 프런트엔드에서 Blob 다운로드로 생성합니다.
- TopicBinding의 MessageType 선택값을 타입 이름이 아닌 **요소 ID**로 수정했고, Field 타입 선택은 이름을 사용하도록 분리했습니다.
- Node 내장 테스트 러너로 CRUD/Import/Validation/Generation을 검증했습니다.

## 남겨 둔 화면

Model / Component / Gateway의 3개 작업 모드에 필수 모델·Gateway 편집기를 배치했습니다. Model Source JSON, Component Diagram/Details, Gateway Field Mapping/JSON만 보조 탭으로 유지합니다.

## 의도적으로 없는 기능

- 실제 QEA 파일 분석 및 Sparx EA 전용 Profile/MDG 해석
- Server, REST, SQL, 회원 권한, 동시 편집
- 전체 UMAA ICD/IDL/Compliance Specification 적용 및 적합성 인증
- DOCX, PDF, 실 DDS TypeSupport/서비스 구현 코드 생성

## 이후 실제 Backend 연동

`api` 메서드별 결과 형식을 유지하는 어댑터를 만들어 교체하는 방식이 적합합니다. Mock 데이터를 공식 UMAA 규격이라고 간주하면 안 됩니다.


## 정적 배포

이 복사본은 Vite 대신 esbuild IIFE 번들을 사용하며, `frontend/index.html`을 `file://`로 직접 열 수 있도록 상대 경로를 사용합니다. `dist/`는 npm 의존성 설치 후 생성합니다. 브라우저 정책에 따라 file URL의 localStorage 지속 여부가 달라질 수 있습니다.

## JSON Gateway Designer (added in v0.4)

- Project-specific JSON field mapping, two synthetic direction templates, localStorage persistence.
- Structural/semantic validation for supported primitive packet fields and mappings.
- Synthetic DDS→Binary Packet Hex preview only; no real DDS or socket I/O.
- Reverse JSON template is editable/validated/exportable, but reverse runtime decoding is not implemented.
- Generated C++ file is a declaration/comment scaffold, not a working transport adapter or UMAA-conformant wrapper.
- The JSON schema is project-defined and **not** an RTI Gateway configuration format; RTI Gateway concepts were used only as architecture references.

## IDE Workbench UI (v0.5)

- 기존 `ea_react`의 네 영역 구성(`Explorer | Workspace | Properties`, 하단 `Console/Output`)을 참고하여 새 독립 Mock 복사본에 구현했습니다. 원본 저장소를 수정하거나 원본 컴포넌트를 통째로 복사한 것은 아닙니다.
- `src/layouts/workbenchPanels.config.js`에서 Explorer/Workspace 탭과 Splitter 크기를 선언하고, `WorkbenchLayout.jsx`에서 반응형 패널을 구성합니다.
- Gateway JSON과 우측 TCP/UDP 속성 폼은 동일한 브라우저 상태를 편집합니다. 저장 버튼을 눌러야 Mock 프로젝트 데이터가 갱신됩니다.
- 하단 Console에는 실제 사용자 실행 결과와 Mock Import 진단/기본 검증 메시지만 표시합니다. 실제 DDS 로그가 아닙니다.

## Focused Workbench UI (v0.6)

- **3개 작업 모드(Model / Component / Gateway)**로 통합: 모드 전환 시 Explorer / Workspace / Inspector가 함께 바뀝니다.
- 중앙 화면은 모드마다 2개 탭만 제공합니다. QEA Snapshot은 별도 Modal로 이동했습니다.
- 검증/생성은 상단 공통 명령으로 통합하고 하단은 결과 표시 전용입니다.
- 하단 Console/Output은 초기 상태에서 닫혀 있습니다.
- Gateway Field Mapping 테이블과 JSON 탭은 하나의 상태를 공유하며 변경된 JSON은 저장 전에도 탭 전환 시 유지됩니다.
- Protocol이 TCP로 바뀌면 지원되는 기본 프레이밍 옵션을 자동 지정합니다. 전송 방향은 단순 스위치가 아닌 매핑 구조 변경이 필요하므로 Inspector에서 읽기 전용으로 표시합니다.
