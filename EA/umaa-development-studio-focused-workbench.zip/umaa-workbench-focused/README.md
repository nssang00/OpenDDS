# UMAA Development Studio — Focused IDE Workbench (Mock v0.6)

기존 IDE형 UMAA Mock 시제품(v0.5)을 복사해, **3개 작업 모드(Model / Component / Gateway) 중심으로 간소화**했습니다. 기존 GitHub `ea_react` 또는 참조용 `umaa-kit`를 수정하지 않았습니다. 원본 `ea_react`의 전체 소스 복사본은 아니며, 이전에 제공한 Mock Workbench의 후속 버전입니다.

## 핵심 변경사항

| 모드 | 좌측 Explorer | 중앙 기본 탭 | 중앙 보조 탭 | 우측 Inspector |
|---|---|---|---|---|
| **Model** | Service / Type / EA Other가 하나로 묶인 검색 트리 | Editor (선택된 서비스/타입 정보) | Source JSON (읽기 전용) | 선택 모델 속성 및 편집 |
| **Component** | Component 목록 | Provider/Consumer Diagram | Details | 선택 Component 속성/역할 편집 |
| **Gateway** | 현재 Gateway JSON 설정 | Field Mapping 표·Hex Preview | JSON 직접 편집 | TCP/UDP 및 Direction 설정 |

- 기존 `5개 Explorer 탭 + 8개 Workspace 탭` 대신 **상단 3개 작업 모드 + 각 모드당 2개 탭**만 사용합니다.
- Explorer / Workspace / Properties의 Ant Design Splitter는 유지하며, **Console/Output은 기본 닫힘**입니다.
- 검증과 코드/문서 생성은 상단의 **Validate / Generate** 명령으로 단일화했습니다. 결과는 필요할 때 하단 Output 패널에 나타납니다.
- QEA Snapshot / Import 진단은 Model Explorer 하단 버튼 또는 `···` 메뉴에서 확인할 수 있습니다.
- **Gateway Field Mapping을 기본 편집기로 제공**하며 JSON 원본과 우측 Transport Inspector가 하나의 부모 상태를 공유합니다. 중앙 탭을 이동해도 저장 전 JSON 입력이 소실되지 않습니다.
- Project Extension 편집, Provider/Consumer 구성, 기존 Mock QEA Import, IDL/문서/C++ 골격 및 Gateway Preview/JSON 다운로드 기능을 유지합니다.

## 정적 빌드 / 서버 없이 실행

Windows에서는 `frontend/build-and-open.bat`를 실행합니다.

```bash
cd frontend
npm install
npm run build
```

생성된 `frontend/dist/main.js`, `frontend/dist/main.css`를 상대 경로로 읽으므로 `frontend/index.html`을 **더블클릭해서 실행**합니다. `npm run watch`는 파일 변경 시 다시 빌드만 수행합니다. Vite, HTTP 서버, C++ 백엔드 및 DB 서버는 필요하지 않습니다.

**배포 ZIP에는 `node_modules/`와 `dist/`가 없습니다. 최초 빌드 시 Node.js/npm 및 의존성 다운로드가 필요합니다.** `file://` 환경에서 `localStorage` 지속성은 브라우저에 따라 차이가 있을 수 있습니다.

## 데이터 및 코드 생성 범위

- 실제 QEA 파일을 파싱하는 대신 합성 EA 모델을 읽습니다. 업로드한 QEA는 파일 내용 분석에 사용되지 않습니다.
- 브라우저 Mock API 및 localStorage가 프로젝트, QEA Snapshot 시뮬레이션, Gateway JSON을 저장합니다.
- 검증은 기본 모델 참조·필드 규칙에 한정되며, 공식 UMAA 규격 적합성 시험이 아닙니다.
- C++ `Component Handler` 및 `Gateway Packet` 생성은 선언·TODO 중심의 골격입니다. **실제 DDS, TCP/UDP 소켓, Codec/Mapper 실행 코드가 아닙니다.**
- Gateway JSON 스키마는 RTI Gateway의 Adapter / Transformation / Processor 구조를 참고한 **자체 형식**이며 RTI 설정 파일과 호환되지 않습니다.

## 주요 코드

```text
frontend/
  index.html                       로컬 file:// 실행용 진입 파일
  package.json                     esbuild IIFE 빌드
  src/
    App.jsx                        3개 작업 모드, 단일 명령, Mock 모델 상태
    layouts/
      WorkbenchLayout.jsx         Explorer / Workspace / Properties / 접이식 Bottom
      workbenchPanels.config.js   작업 모드·2개 보조 탭·Explorer 분류
    components/
      GatewayDesigner.jsx         Field Mapping 표 및 JSON 탭·검증·미리보기
      GatewayTransportInspector.jsx  JSON과 동기화되는 TCP/UDP 폼
      ElementInspector.jsx        Service/Type/Component 세부 속성 편집
      ComponentGraph.jsx          Provider/Consumer React Flow 그래프
    lib/
      api.js                       서버 없는 Promise 기반 Mock API
      gateway/                     JSON Schema, 샘플 및 생성/검증
  tests/                            Node 내장 테스트
```

## 검증

```bash
cd frontend
npm test
```

Mock API, Gateway JSON, 패킷 Hex, 모델 선택, 3모드 레이아웃, 정적 진입 파일에 관한 **14개 Node 테스트를 통과**했습니다. 전역 TypeScript 파서로 JSX 구문 검사도 통과했습니다. 이 작업 환경은 npm 의존성이 없고 다운로드가 제한될 수 있어 실제 esbuild 전체 번들 및 브라우저 렌더링은 별도 실행 환경에서 확인해야 합니다.
