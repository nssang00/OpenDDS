#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if [ ! -d node_modules/esbuild ]; then
  npm install
fi
npm run build
printf '\nStatic bundle ready. Open: %s/index.html\n' "$(pwd)"
