import test from 'node:test';
import assert from 'node:assert/strict';
import { api } from '../src/lib/api.js';

const mem=new Map();
globalThis.localStorage = {
  getItem(k){return mem.get(k)??null},
  setItem(k,v){mem.set(k,v)},
  removeItem(k){mem.delete(k)}
};

test('seed contains synthetic QEA and project elements; no backend',async()=>{
  await api.resetDemo();
  const {projects}=await api.projects();
  assert.equal(projects[0].id,'demo');
  const m=await api.model('demo');
  assert.ok(m.elements.some(e=>e.origin==='qea'&&e.semanticType==='ServiceInterface'));
  assert.ok(m.elements.some(e=>e.origin==='project'&&e.semanticType==='Component'));
  assert.equal((await api.health()).backend,false);
});

test('project edits persist and imported elements are immutable',async()=>{
  await api.resetDemo();
  const p=(await api.createProject('UMAA test')).project;
  let model=await api.model(p.id);
  assert.equal(model.elements.length,0);
  let el=(await api.createElement(p.id,{
    semanticType:'DataType',name:'NewStatus',properties:{fields:[{name:'healthy',type:'boolean'}]}
  })).element;
  await api.updateElement(p.id,el.id,{name:'UpdatedStatus'});
  model=await api.model(p.id);
  assert.equal(model.elements[0].name,'UpdatedStatus');
  assert.equal((await api.projects()).projects.length,2);
  await api.importQea(p.id,{name:'user-real-qea.qea'});
  model=await api.model(p.id);
  assert.equal(model.elements.find(e=>e.id===el.id).name,'UpdatedStatus');
  assert.ok(model.snapshots[0].filename.includes('NOT PARSED'));
  const imported=model.elements.find(e=>e.origin==='qea');
  await assert.rejects(api.updateElement(p.id,imported.id,{name:'No'}),/읽기 전용/);
  await assert.rejects(api.deleteElement(p.id,imported.id),/읽기 전용/);
  await api.importQea(p.id,{name:'new_version.qea'});
  const again=await api.model(p.id);
  assert.equal(again.snapshots.length,2);
  assert.ok(again.elements.some(e=>e.id===el.id));
  await api.deleteElement(p.id,el.id);
  assert.ok(!(await api.model(p.id)).elements.some(e=>e.id===el.id));
  assert.ok(mem.size>0);
});

test('basic validation and local draft downloads',async()=>{
  await api.resetDemo();
  const valid=await api.validate('demo');
  assert.equal(valid.passed,true);
  assert.ok(valid.issues.some(x=>x.level==='warning'));
  const idl=await api.generate('demo','idl');
  assert.ok(idl.includes('struct PlatformHealthType'));
  assert.ok(idl.includes('struct PlatformHealthReport'));
  assert.ok(!idl.includes('struct DemoEngineCommand'));
  const imported=await api.generate('demo','idl',true);
  assert.ok(imported.includes('struct DemoEngineCommand'));
  assert.ok((await api.generate('demo','document')).includes('UMAA Model Inventory'));
  assert.ok((await api.generate('demo','cpp')).includes('struct HealthMonitorHandler'));
  const e=(await api.createElement('demo',{
    semanticType:'TopicBinding',name:'InvalidBinding',properties:{serviceId:'missing',messageTypeId:'missing',topicName:''}
  })).element;
  const invalid=await api.validate('demo');
  assert.equal(invalid.passed,false);
  assert.ok(invalid.issues.some(i=>i.elementId===e.id&&i.level==='error'));
});
