import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { api } from '../src/lib/api.js';
import { DDS_TO_UDP, UDP_TO_DDS, validateGateway, previewPacket, generateGatewayCppDraft } from '../src/lib/gateway/gateway.js';

const mem = new Map();
globalThis.localStorage = {getItem:k=>mem.get(k)||null,setItem:(k,v)=>mem.set(k,v)};

test('both JSON example configs are valid and match project format',()=>{
  for(const file of ['dds-to-udp.example.json','udp-to-dds.example.json']){
    const json=JSON.parse(readFileSync(new URL(`../src/lib/gateway/${file}`,import.meta.url),'utf8'));
    assert.equal(validateGateway(json).passed,true);
  }
  assert.equal(validateGateway(DDS_TO_UDP).passed,true);
  assert.equal(validateGateway(UDP_TO_DDS).passed,true);
});

test('deterministic DDS example encodes a 12 byte big-endian packet',()=>{
  const p=previewPacket(DDS_TO_UDP);
  assert.equal(p.byteLength,12);
  assert.ok(p.hex.startsWith('03 E9 '));
  assert.equal(p.rows.find(r=>r.name==='latitudeE7').value,375665000);
  assert.equal(p.rows.find(r=>r.name==='longitudeE7').value,1269780000);
  assert.equal(p.rows.find(r=>r.name==='speedCmps').value,525);
  assert.ok(generateGatewayCppDraft(DDS_TO_UDP).includes('struct GeneratedGatewayPacket'));
  assert.throws(()=>previewPacket(UDP_TO_DDS),/역방향/);
});

test('invalid and unsafe mapping fails closed',()=>{
  const bad=structuredClone(DDS_TO_UDP);
  bad.fieldMappings[1].source='missing.latitude';
  assert.equal(validateGateway(bad).passed,false);
  const missing=structuredClone(DDS_TO_UDP);
  missing.fieldMappings.pop();
  assert.equal(validateGateway(missing).passed,false);
  const overflow=structuredClone(DDS_TO_UDP);
  overflow.fieldMappings[1].transform.factor=1e20;
  assert.throws(()=>previewPacket(overflow),/범위를 벗어났습니다/);
  const tcp=structuredClone(DDS_TO_UDP);
  tcp.transport.protocol='tcp';
  assert.equal(validateGateway(tcp).passed,false);
  tcp.transport.tcpFraming='length_prefix_u32_be';
  assert.equal(validateGateway(tcp).passed,true);
});

test('gateway JSON per-project persistence and exports use mock API',async()=>{
  await api.resetDemo();
  const original=(await api.getGateway('demo')).config;
  assert.equal(original.transport.protocol,'udp');
  const modified=structuredClone(original);
  modified.name='Test route changed';
  await api.saveGateway('demo',modified);
  assert.equal((await api.getGateway('demo')).config.name,'Test route changed');
  const json=await api.exportGateway('demo','json',modified);
  assert.ok(json.includes('"fieldMappings"'));
  const cpp=await api.exportGateway('demo','cpp',modified);
  assert.ok(cpp.includes('TODO:'));
  const bad=structuredClone(modified);bad.transport.port=99999;
  await assert.rejects(api.saveGateway('demo',bad),/transport/);
  assert.equal((await api.getGateway('demo')).config.name,'Test route changed');
  const second=(await api.createProject('second')).project;
  assert.equal((await api.getGateway(second.id)).config.name,DDS_TO_UDP.name);
  assert.equal((await api.getGateway('demo')).config.name,'Test route changed');
  await api.resetDemo();
  assert.equal((await api.getGateway('demo')).config.name,DDS_TO_UDP.name);
});
