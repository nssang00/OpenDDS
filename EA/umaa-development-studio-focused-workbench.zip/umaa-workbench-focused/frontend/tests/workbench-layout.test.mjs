import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {workbenchModes, modeViews, defaultViews, groupModelElements, compatibleSelection, modeOfElement} from '../src/layouts/workbenchPanels.config.js';

const read=p=>readFileSync(new URL(`../src/${p}`,import.meta.url),'utf8');
const layout=read('layouts/WorkbenchLayout.jsx');
const app=read('App.jsx');
const gateway=read('components/GatewayDesigner.jsx');
const inspector=read('components/GatewayTransportInspector.jsx');

test('resizable IDE shell retains Explorer / Workspace / Properties and optional bottom console',()=>{
  assert.match(layout,/<Splitter/);
  assert.match(layout,/layout="vertical"/);
  for(const cls of ['ide-explorer','ide-workspace','ide-inspector','ide-bottom'])assert.ok(layout.includes(cls));
  assert.match(layout,/bottomOpen &&/);
  assert.match(layout,/onBottomOpenChange/);
  assert.match(app,/useState\(false\)/);
});

test('exactly three modes and two contextual views per mode',()=>{
  assert.deepEqual(workbenchModes.map(m=>m.key),['model','component','gateway']);
  for(const mode of workbenchModes){
    assert.equal(modeViews[mode.key].length,2);
    assert.ok(modeViews[mode.key].some(v=>v.key===defaultViews[mode.key]));
  }
  assert.match(layout,/<Segmented/);
  assert.doesNotMatch(layout,/explorerViews|activeExplorer|onExplorerChange/);
  assert.doesNotMatch(app,/setSection|setWorkspaceTab|OverviewPage|GenerationPage|ValidationPage/);
});

test('model explorer groups all model semantic types without duplicating items and preserves selection by mode',()=>{
  const elements=[
    {id:'s',name:'EngineControl',semanticType:'Service'},
    {id:'dt',name:'EngineStatus',semanticType:'DataType'},
    {id:'c',name:'ControlUnit',semanticType:'Component'},
    {id:'p',name:'EO',semanticType:'Package'},
    {id:'op',name:'setEngine',semanticType:'Operation'}
  ];
  const groups=groupModelElements(elements);
  assert.deepEqual(groups.map(g=>g.key),['group:services','group:types','group:other']);
  const ids=groups.flatMap(g=>g.children.map(c=>c.key));
  assert.equal(ids.length,4);
  assert.equal(new Set(ids).size,ids.length);
  assert.ok(!ids.includes('c'));
  assert.deepEqual(groupModelElements(elements,'engine').flatMap(g=>g.children.map(c=>c.key)).sort(),['dt','op','s']);
  assert.equal(compatibleSelection(elements,'model','c'),'s');
  assert.equal(compatibleSelection(elements,'component','s'),'c');
  assert.equal(modeOfElement('Component'),'component');
  assert.equal(modeOfElement('TopicBinding'),'model');
});

test('Gateway mapping editor and raw JSON share one controlled parent state across tabs',()=>{
  assert.match(app,/jsonValue=\{gatewayJson\}/);
  assert.match(app,/onJsonChange=\{setGatewayJson\}/);
  assert.match(app,/savedJson=\{savedGatewayJson\}/);
  assert.match(app,/GatewayTransportInspector json=\{gatewayJson\} onChange=\{setGatewayJson\}/);
  assert.match(gateway,/view==='json'/);
  assert.match(gateway,/onJsonChange\(next\)/);
  assert.match(gateway,/patchMapping=/);
  assert.match(inspector,/JSON\.stringify\(next,null,2\)/);
});

test('single global Validate / Generate actions and contextual results, not redundant workspace tabs',()=>{
  assert.match(app,/const actions=<>/);
  assert.match(app,/const generationMenu=/);
  assert.match(app,/const outputContent=/);
  assert.match(app,/setBottomOpen\(true\)/);
  assert.ok(!Object.values(modeViews).flat().some(v=>['validation','generation','overview','explorerJson'].includes(v.key)));
});
