import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const index = readFileSync(resolve(root, 'index.html'), 'utf8');
const packageJson = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));
const main = readFileSync(resolve(root, 'src/main.jsx'), 'utf8');

test('static entry references relative esbuild files and no ES module script', () => {
  assert.match(index, /href="\.\/dist\/main\.css"/);
  assert.match(index, /src="\.\/dist\/main\.js"/);
  assert.doesNotMatch(index, /type="module"|src="\/|href="\//);
});

test('esbuild IIFE build does not require a web server', () => {
  assert.match(packageJson.scripts.build, /^esbuild /);
  assert.match(packageJson.scripts.build, /--format=iife/);
  assert.match(packageJson.scripts.build, /--bundle/);
  assert.doesNotMatch(packageJson.scripts.build, /--serve|--servedir|vite/);
  assert.equal(packageJson.devDependencies.vite, undefined);
  assert.ok(packageJson.devDependencies.esbuild);
  assert.equal(existsSync(resolve(root, 'vite.config.js')), false);
  assert.match(main, /import '\@xyflow\/react\/dist\/style\.css'|import '@xyflow\/react\/dist\/style\.css'/);
});
