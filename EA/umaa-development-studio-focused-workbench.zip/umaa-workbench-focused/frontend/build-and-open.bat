@echo off
setlocal
cd /d "%~dp0"
where npm >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Node.js/npm is required to build this bundle.
  pause
  exit /b 1
)
if not exist "node_modules\esbuild" (
  echo Installing npm dependencies for build...
  call npm install
  if errorlevel 1 (pause & exit /b 1)
)
echo Building static application (no web server)...
call npm run build
if errorlevel 1 (pause & exit /b 1)
start "" "index.html"
echo Opened index.html. No server is running.
