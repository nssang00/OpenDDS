import React, {useCallback, useEffect, useMemo, useState} from 'react';
import {
  Alert, Button, Dropdown, Empty, Form, Input, Modal, Select, Space, Spin,
  Table, Tag, Tooltip, Tree, Typography, Descriptions, Divider, Upload, message, Result
} from 'antd';
import {
  CloudUploadOutlined, CodeOutlined, FolderOpenOutlined, MoreOutlined,
  PlusOutlined, ReloadOutlined, SafetyCertificateOutlined
} from '@ant-design/icons';
import ElementInspector from './components/ElementInspector.jsx';
import ComponentGraph from './components/ComponentGraph.jsx';
import GatewayDesigner from './components/GatewayDesigner.jsx';
import GatewayTransportInspector from './components/GatewayTransportInspector.jsx';
import {QeaSummary, ElementDetails, ConsoleView} from './components/WorkbenchViews.jsx';
import WorkbenchLayout from './layouts/WorkbenchLayout.jsx';
import {defaultViews, modeOfElement, groupModelElements, compatibleSelection} from './layouts/workbenchPanels.config.js';
import {api} from './lib/api.js';
import {byType, editableTypes, lookup, typeColor} from './lib/model.js';
import {prettyJson} from './lib/gateway/gateway.js';

const {Title,Text,Paragraph}=Typography;
function OriginTag({e}){return <Tag color={e.origin==='project'?'blue':'default'}>{e.origin==='project'?'Project':'QEA'}</Tag>;}
function TypeTag({type}){return <Tag color={typeColor(type)}>{type}</Tag>;}
function EmptyMessage({text}){return <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description={text}/>;}

function ServiceContent({model,selectedId,onSelect}) {
  const elements=model.elements||[];const chosen=lookup(elements,selectedId);
  const bindings=byType(elements,'TopicBinding').filter(x=>x.properties?.serviceId===selectedId);
  const operations=byType(elements,'Operation').filter(x=>x.parentId===selectedId);
  return <div className="service-content"><div className="pane-head">Service Contract</div>
    {chosen && ['Service','ServiceInterface'].includes(chosen.semanticType)?<div className="service-contract">
      <Space><TypeTag type={chosen.semanticType}/><OriginTag e={chosen}/></Space>
      <Title level={4} style={{margin:'12px 0 6px'}}>{chosen.name}</Title><Paragraph type="secondary">{chosen.description||'서비스 설명이 없습니다.'}</Paragraph>
      <Descriptions size="small" bordered column={1} items={[{key:'i',label:'ICD / Source',children:chosen.properties?.icd||'-'},{key:'p',label:'Protocol',children:chosen.properties?.protocol||'규칙 검토 필요'},{key:'g',label:'EA GUID',children:chosen.sourceGuid||'-'}]}/>
      <Divider orientation="left">Operation / Topic Binding</Divider>
      <Table size="small" pagination={false} rowKey="id" dataSource={bindings} columns={[
        {title:'Operation',dataIndex:['properties','operationName'],render:x=>x||'-'},
        {title:'DDS Topic',dataIndex:['properties','topicName'],ellipsis:true},
        {title:'Message Type',render:(_,r)=>lookup(elements,r.properties?.messageTypeId)?.name||'Unresolved'},
        {title:'Direction',dataIndex:['properties','bindingKind']}
      ]} locale={{emptyText:'웹에서 명시적인 TopicBinding을 추가할 수 있습니다.'}}/>
      <Divider orientation="left">EA Operations</Divider>
      {operations.length?operations.map(o=><Tag key={o.id} onClick={()=>onSelect(o.id)} style={{cursor:'pointer'}}>{o.name}</Tag>):<Text type="secondary">연결된 EA Operation이 없거나 아직 해석되지 않았습니다.</Text>}
      <div className="notice-inline">Operation마다 실제 DDS Topic이 존재하지는 않습니다. Query / Cancel의 구현 방식은 ICD 규칙과 확인해야 합니다.</div>
    </div>:<div style={{padding:32}}><EmptyMessage text="서비스를 선택하면 계약과 Topic 연결을 볼 수 있습니다."/></div>}
  </div>;
}
export default function App() {
  const [projects,setProjects]=useState([]);
  const [projectId,setProjectId]=useState('');
  const [model,setModel]=useState(null);
  const [mode,setMode]=useState('model');
  const [activeView,setActiveView]=useState(defaultViews.model);
  const [selectedByMode,setSelectedByMode]=useState({model:'',component:''});
  const [search,setSearch]=useState('');
  const [gatewayJson,setGatewayJson]=useState('');
  const [savedGatewayJson,setSavedGatewayJson]=useState('');
  const [consoleEntries,setConsoleEntries]=useState([]);
  const [lastGenerated,setLastGenerated]=useState('');
  const [bottomOpen,setBottomOpen]=useState(false);
  const [bottomTab,setBottomTab]=useState('console');
  const [loaded,setLoaded]=useState(false);
  const [busy,setBusy]=useState('');
  const [summaryOpen,setSummaryOpen]=useState(false);
  const [createProjectOpen,setCreateProjectOpen]=useState(false);
  const [createElementOpen,setCreateElementOpen]=useState(false);
  const [projectForm]=Form.useForm();
  const [elementForm]=Form.useForm();
  const [issueResult,setIssueResult]=useState(null);
  const [apiError,setApiError]=useState('');
  const [msg,contextHolder]=message.useMessage();

  const log=(text,level='info')=>setConsoleEntries(xs=>[...xs,{
    time:new Date().toLocaleTimeString('ko-KR',{hour12:false}),level,message:text
  }].slice(-70));
  const notify=error=>{const text=error?.message||String(error);msg.error(text);log(text,'error');};
  const reloadProjects=useCallback(async()=>{
    const {projects:next}=await api.projects();
    setProjects(next);
    setProjectId(prev=>prev&&next.some(p=>p.id===prev)?prev:(next[0]?.id||''));
  },[]);
  const reloadModel=useCallback(async id=>{
    if(!id)return;
    const next=await api.model(id);setModel(next);
  },[]);

  useEffect(()=>{let live=true;(async()=>{
    try{await reloadProjects();if(live)setApiError('');}
    catch(e){if(live)setApiError(e.message);}
    finally{if(live)setLoaded(true);}
  })();return()=>{live=false;};},[reloadProjects]);
  useEffect(()=>{
    let live=true;
    setModel(null);setIssueResult(null);setLastGenerated('');setGatewayJson('');setSavedGatewayJson('');
    setSelectedByMode({model:'',component:''});
    if(projectId){
      reloadModel(projectId).catch(e=>{if(live)setApiError(e.message);});
      api.getGateway(projectId).then(({config})=>{
        if(live){const txt=prettyJson(config)+'\n';setGatewayJson(txt);setSavedGatewayJson(txt);}
      }).catch(e=>{if(live)setApiError(e.message);});
    }
    return()=>{live=false;};
  },[projectId,reloadModel]);

  const run=async(kind,fn,reload=true)=>{
    setBusy(kind);
    try{
      const result=await fn();
      if(reload&&projectId)await reloadModel(projectId);
      log(`${kind} 완료 (Mock)`);
      return result;
    }catch(e){notify(e);return null;}
    finally{setBusy('');}
  };
  const changeMode=next=>{if(next===mode)return;setMode(next);setActiveView(defaultViews[next]);setSearch('');};
  const addProject=async values=>{
    const res=await run('project',()=>api.createProject(values.name),false);
    if(!res)return;
    setCreateProjectOpen(false);projectForm.resetFields();await reloadProjects();setProjectId(res.project.id);
    changeMode('model');msg.success('프로젝트를 생성했습니다.');
  };
  const addElement=async values=>{
    const props={};
    if(['DataType','MessageType'].includes(values.semanticType))props.fields=[];
    if(values.semanticType==='Enum')props.values=[];
    if(values.semanticType==='Component')props.services=[];
    if(values.semanticType==='TopicBinding')Object.assign(props,{serviceId:'',messageTypeId:'',topicName:'',bindingKind:'publish'});
    const res=await run('element',()=>api.createElement(projectId,{...values,properties:props}));
    if(!res)return;
    setCreateElementOpen(false);elementForm.resetFields();
    const destination=modeOfElement(res.element.semanticType);
    setSelectedByMode(prev=>({...prev,[destination]:res.element.id}));
    setMode(destination);setActiveView(destination==='component'?'details':'editor');
    msg.success('프로젝트 요소를 추가했습니다.');
  };
  const saveElement=async(id,patch)=>{const res=await run('save',()=>api.updateElement(projectId,id,patch));if(res)msg.success('저장했습니다.');};
  const deleteElement=async id=>{const res=await run('delete',()=>api.deleteElement(projectId,id));if(res)msg.success('삭제했습니다.');};
  const importFile=file=>{Modal.confirm({
    title:'QEA Import — Mock 시뮬레이션',
    content:`${file.name}: 파일 내용은 파싱하지 않습니다. 미리 정의된 합성 QEA 모델을 불러올까요?`,
    okText:'합성 예제 불러오기',cancelText:'취소',
    onOk:async()=>{
      const res=await run('import',()=>api.importQea(projectId,file));
      if(res){changeMode('model');setSummaryOpen(true);msg.warning('합성 QEA 데이터를 불러왔습니다. 실제 QEA 파싱 결과는 아닙니다.');}
    }
  });return false;};
  const validate=async()=>{
    const result=await run('validate',()=>api.validate(projectId),false);
    if(result){setIssueResult(result);setBottomTab('output');setBottomOpen(true);}
  };
  const download=async(kind,includeImported=false)=>{
    const result=await run(kind,()=>api.generate(projectId,kind,includeImported),false);
    if(result!==null){setLastGenerated(kind);setBottomTab('output');setBottomOpen(true);msg.success('Mock 산출물을 다운로드했습니다.');}
  };
  const resetMock=()=>Modal.confirm({
    title:'Mock 데이터 초기화',content:'브라우저 프로젝트와 편집 내용을 삭제하고 초기 합성 모델로 되돌립니다. 되돌릴 수 없습니다.',
    okText:'초기화',okButtonProps:{danger:true},
    onOk:async()=>{
      await api.resetDemo();setMode('model');setActiveView('editor');setSearch('');
      setProjectId('demo');setIssueResult(null);setSelectedByMode({model:'',component:''});
      await reloadProjects();await reloadModel('demo');
      const {config}=await api.getGateway('demo');const txt=prettyJson(config)+'\n';setGatewayJson(txt);setSavedGatewayJson(txt);
      msg.success('Mock 데이터를 초기화했습니다.');
    }
  });

  const elements=model?.elements||[];
  const selectedId=mode==='gateway'?'':compatibleSelection(elements,mode,selectedByMode[mode]);
  const selected=lookup(elements,selectedId);
  const activeProject=projects.find(p=>p.id===projectId);
  const selectElement=id=>{
    const el=lookup(elements,id);if(!el)return;
    const target=modeOfElement(el.semanticType);
    setSelectedByMode(prev=>({...prev,[target]:id}));
    if(target!==mode){setMode(target);setActiveView(defaultViews[target]);setSearch('');}
    else if(mode==='model')setActiveView('editor');
  };
  const categorized=useMemo(()=>groupModelElements(elements,search),[elements,search]);
  const treeSections=categorized.map(group=>({...group,
    title:<strong className="focus-tree-group">{group.title}</strong>,
    children:group.children.map(item=>({...item,title:<span className="focus-tree-item">
      <span>{item.title}</span><span className="focus-tree-type">{item.semanticType}{item.origin==='qea'?' · QEA':''}</span>
    </span>}))
  }));

  const explorerContent=mode==='model'?<div className="focus-explorer">
    <Input.Search size="small" placeholder="Service, Type, EA 요소 검색" value={search}
      allowClear onChange={e=>setSearch(e.target.value)}/>
    <div className="focus-explorer-scroll"><Tree blockNode defaultExpandAll
      defaultExpandedKeys={['group:services','group:types','group:other']}
      showLine={false} selectedKeys={selectedId?[selectedId]:[]}
      treeData={treeSections} onSelect={keys=>{if(keys[0])selectElement(keys[0]);}}/>
    </div>
    <Button block size="small" type="text" icon={<FolderOpenOutlined/>} onClick={()=>setSummaryOpen(true)}>
      QEA Snapshot / Import 정보
    </Button>
  </div>:mode==='component'?<div className="focus-explorer">
    <Input.Search size="small" placeholder="Component 검색" value={search} allowClear
      onChange={e=>setSearch(e.target.value)}/>
    <div className="focus-explorer-scroll">
      {byType(elements,'Component').filter(e=>e.name.toLowerCase().includes(search.toLowerCase())).map(e=><button
        className={'model-list-item '+(e.id===selectedId?'active':'')} key={e.id} onClick={()=>selectElement(e.id)}>
        <div className="model-list-top"><span className="model-list-name">{e.name}</span></div>
        <span className="model-list-type">{(e.properties?.services||[]).length} Service roles · {e.origin==='project'?'Project':'QEA'}</span>
      </button>)}
    </div>
    <div className="ide-explorer-tip">Component를 선택하면 제공·소비 Service와 다이어그램을 확인할 수 있습니다.</div>
  </div>:<div className="focus-explorer">
    <div className="model-list-item active">
      <div className="model-list-top"><span className="model-list-name">{(()=>{try{return JSON.parse(gatewayJson)?.name||'Gateway Mapping';}catch{return 'Gateway Mapping';}})()}</span></div>
      <span className="model-list-type">JSON · DDS ↔ TCP/UDP</span>
    </div>
    <div className="ide-explorer-tip">Gateway 설정은 JSON 하나를 기준으로 저장합니다. 중앙 Field Mapping과 우측 Transport 설정이 동기화됩니다.</div>
  </div>;

  const modelEditor=['Service','ServiceInterface'].includes(selected?.semanticType)?
    <ServiceContent model={model} selectedId={selectedId} onSelect={selectElement}/>:
    <ElementDetails element={selected} elements={elements}/>;
  const workspaceContent=mode==='model'?(
    activeView==='source'?<div className="ide-document"><div className="ide-document-head"><strong>Source / Element JSON</strong><Tag>READ ONLY</Tag></div>
      <pre className="ide-json-document">{JSON.stringify(selected?{element:selected,relations:(model.relations||[]).filter(r=>r.source===selected.id||r.target===selected.id)}:{project:model.project},null,2)}</pre>
      <Alert type="info" showIcon message="프로젝트 모델 변경은 우측 Properties에서 수행합니다. QEA 원본은 읽기 전용입니다."/>
    </div>:modelEditor
  ):mode==='component'?(
    activeView==='details'?<ElementDetails element={selected} elements={elements}/>:
      <div className="ide-diagram-wrapper"><div className="ide-diagram-toolbar">
        <span>Component ↔ Service Provider / Consumer</span><Tag color="gold">Mock</Tag></div>
        <ComponentGraph elements={elements} selectedComponentId={selectedId} onSelect={selectElement}/></div>
  ):<GatewayDesigner projectId={projectId} jsonValue={gatewayJson} onJsonChange={setGatewayJson}
    savedJson={savedGatewayJson} onSaved={text=>{setGatewayJson(text);setSavedGatewayJson(text);log('Gateway Mapping 저장 완료 (Mock)');}}
    view={activeView}/>;
  const inspectorContent=mode==='gateway'?<GatewayTransportInspector json={gatewayJson} onChange={setGatewayJson}/>:
    <ElementInspector element={selected} elements={elements} onSave={saveElement} onDelete={deleteElement} saving={busy==='save'}/>;
  const outputContent=<div className="focus-output">
    <strong>Result / Output</strong>
    {issueResult?<Alert style={{margin:'10px 0'}} showIcon type={issueResult.passed?'success':'error'}
      message={`기본 모델 검사: 오류 ${issueResult.issues.filter(i=>i.level==='error').length}건, 주의 ${issueResult.issues.filter(i=>i.level==='warning').length}건`}
      description="UMAA 규격 적합성 인증이 아닙니다."/>:<Text type="secondary">상단 Validate로 모델을 검사할 수 있습니다.</Text>}
    {issueResult?.issues?.map((issue,i)=><div key={i} className="focus-issue"><Tag color={issue.level==='error'?'red':'orange'}>{issue.level}</Tag>{issue.message} {issue.elementId&&<code>{issue.elementId}</code>}</div>)}
    {lastGenerated&&<Alert type="info" showIcon style={{marginTop:8}} message={`${lastGenerated.toUpperCase()} Mock 초안 다운로드됨`}/>}
    <div className="muted-small">실제 QEA 파싱, 공식 UMAA 적합성 검증, DDS 실행 코드는 제공하지 않습니다.</div>
  </div>;
  const extraMenu={items:[
    {key:'refresh',label:'모델 다시 불러오기'},
    {key:'reset',label:'Mock 데이터 초기화',danger:true}
  ],onClick:({key})=>{
    if(key==='refresh')reloadModel(projectId).catch(notify);
    if(key==='reset')resetMock();
  }};
  const generationMenu={items:[
    {key:'idl',label:'IDL 초안 (.idl)'},
    {key:'document',label:'모델 목록 (.md)'},
    {key:'cpp',label:'Component C++ 골격 (.hpp)'}
  ],onClick:({key})=>download(key)};
  const actions=<>
    <Button size="small" onClick={()=>setCreateElementOpen(true)} icon={<PlusOutlined/>}
      disabled={!projectId||mode==='gateway'}>요소 추가</Button>
    <Button size="small" icon={<SafetyCertificateOutlined/>} onClick={validate} disabled={!projectId} loading={busy==='validate'}>Validate</Button>
    <Dropdown menu={generationMenu} disabled={!projectId} trigger={['click']}><Button size="small" icon={<CodeOutlined/>}>Generate ▾</Button></Dropdown>
    <Upload accept=".qea,.qeax,.sqlite,.db" showUploadList={false} beforeUpload={importFile} disabled={!projectId||busy==='import'}>
      <Button size="small" type="primary" icon={<CloudUploadOutlined/>} loading={busy==='import'}>QEA Import (Mock)</Button>
    </Upload>
    <Dropdown menu={extraMenu} trigger={['click']}><Button size="small" type="text" aria-label="More actions" icon={<MoreOutlined/>}/></Dropdown>
  </>;
  const filteredTypes=editableTypes.filter(x=>mode==='component'?x.value==='Component':x.value!=='Component');

  return <>{contextHolder}
    {!loaded?<div className="ide-loading"><Spin size="large"/></div>:
      apiError?<Result status="warning" title="Mock 데이터 오류" subTitle={apiError}
        extra={<Button onClick={()=>{setApiError('');reloadProjects().catch(notify);}}>다시 불러오기</Button>}/>:
      !model?<div className="ide-loading"><Spin size="large"/></div>:
      <WorkbenchLayout projects={projects} projectId={projectId} onProjectChange={setProjectId}
        onAddProject={()=>setCreateProjectOpen(true)} actions={actions}
        mode={mode} onModeChange={changeMode} activeView={activeView} onViewChange={setActiveView}
        explorerContent={explorerContent} workspaceContent={workspaceContent} inspectorContent={inspectorContent}
        consoleContent={<ConsoleView logs={consoleEntries} diagnostics={model.diagnostics||[]} issues={issueResult?.issues||[]}/>}
        outputContent={outputContent} bottomOpen={bottomOpen} onBottomOpenChange={setBottomOpen}
        bottomTab={bottomTab} onBottomTabChange={setBottomTab}
        statusText={`${activeProject?.name||projectId} · ${elements.length} elements · ${mode}`}/>}
    <Modal title="QEA Source / Import 정보" width={760} open={summaryOpen} footer={null} onCancel={()=>setSummaryOpen(false)}>
      {model&&<QeaSummary model={model}/>}
    </Modal>
    <Modal title="새 프로젝트" open={createProjectOpen} onCancel={()=>setCreateProjectOpen(false)}
      onOk={()=>projectForm.submit()} confirmLoading={busy==='project'} destroyOnHidden>
      <Form form={projectForm} layout="vertical" onFinish={addProject}>
        <Form.Item label="Project Name" name="name" rules={[{required:true}]}><Input placeholder="UMAA Integration Project"/></Form.Item>
        <Paragraph type="secondary">모델과 Gateway 설정은 브라우저 Mock 저장소에 저장됩니다.</Paragraph>
      </Form>
    </Modal>
    <Modal title="프로젝트 요소 추가" open={createElementOpen} onCancel={()=>setCreateElementOpen(false)}
      onOk={()=>elementForm.submit()} confirmLoading={busy==='element'} destroyOnHidden>
      <Alert type="info" showIcon style={{marginBottom:12}} message="QEA 원본은 수정하지 않고 Project Extension으로 생성합니다."/>
      <Form form={elementForm} layout="vertical" onFinish={addElement}>
        <Form.Item label="Model Type" name="semanticType" rules={[{required:true}]}>
          <Select options={filteredTypes} placeholder="유형 선택"/>
        </Form.Item>
        <Form.Item label="Name" name="name" rules={[{required:true}]}><Input placeholder="ProjectModel"/></Form.Item>
        <Form.Item label="Description" name="description"><Input.TextArea rows={2}/></Form.Item>
      </Form>
    </Modal>
  </>;
}
