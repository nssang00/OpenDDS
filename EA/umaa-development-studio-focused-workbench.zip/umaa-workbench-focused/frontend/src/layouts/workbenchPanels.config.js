/** Context-first Workbench: one task mode, one explorer, one inspector. */
export const workbenchModes = [
  { key: 'model', label: 'Model', description: 'Service · Operation · DataType' },
  { key: 'component', label: 'Component', description: 'Provider / Consumer assembly' },
  { key: 'gateway', label: 'Gateway', description: 'DDS ↔ TCP/UDP mapping' }
];

export const modeViews = {
  model: [
    { key: 'editor', label: 'Editor' },
    { key: 'source', label: 'Source JSON' }
  ],
  component: [
    { key: 'diagram', label: 'Diagram' },
    { key: 'details', label: 'Details' }
  ],
  gateway: [
    { key: 'mapping', label: 'Field Mapping' },
    { key: 'json', label: 'JSON' }
  ]
};

export const defaultViews = {
  model: 'editor',
  component: 'diagram',
  gateway: 'mapping'
};

export const panelDimensions = {
  explorer: { defaultSize: 275, min: 220, max: 390 },
  inspector: { defaultSize: 325, min: 260, max: 470 },
  bottom: { defaultSize: 180, min: 120, max: 340 }
};

const serviceTypes = new Set(['Service','ServiceInterface','Interface','Operation','ServiceParticipant','Port','TopicBinding']);
const dataTypes = new Set(['DataType','MessageType','Enum','Field']);
export const modeOfElement = type => type === 'Component' ? 'component' : 'model';

export function groupModelElements(elements, query = '') {
  const groups = [
    { key:'services', title:'Services / Interfaces', matches:e=>serviceTypes.has(e.semanticType) },
    { key:'types', title:'Data / Message Types', matches:e=>dataTypes.has(e.semanticType) },
    { key:'other', title:'EA Packages / Other', matches:e=>!serviceTypes.has(e.semanticType) && !dataTypes.has(e.semanticType) && e.semanticType !== 'Component' }
  ];
  const q = query.trim().toLowerCase();
  return groups.map(group=>({
    key: `group:${group.key}`,
    title: group.title,
    selectable: false,
    children: elements.filter(e => group.matches(e) && (!q || `${e.name} ${e.semanticType} ${e.stereotype||''}`.toLowerCase().includes(q)))
      .map(e=>({key:e.id,title:e.name||'(unnamed)',semanticType:e.semanticType,origin:e.origin}))
      .sort((a,b)=>a.title.localeCompare(b.title,'en'))
  })).filter(group=>group.children.length);
}

export function compatibleSelection(elements, mode, id) {
  const list = mode === 'component'
    ? elements.filter(e=>e.semanticType==='Component')
    : elements.filter(e=>e.semanticType!=='Component');
  return list.some(e=>e.id===id) ? id : (mode === 'model' ? list.find(e=>e.semanticType==='Service')?.id || list.find(e=>e.semanticType==='ServiceInterface')?.id : undefined) || list[0]?.id || ''; 
}
