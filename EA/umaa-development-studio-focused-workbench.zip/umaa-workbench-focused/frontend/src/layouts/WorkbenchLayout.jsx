import React from 'react';
import {Button, Segmented, Select, Space, Splitter, Tabs, Tag, Tooltip} from 'antd';
import {
  CaretDownOutlined, CaretUpOutlined, CodeOutlined,
  FolderAddOutlined, PartitionOutlined, SettingOutlined, AppstoreOutlined
} from '@ant-design/icons';
import {workbenchModes, modeViews, panelDimensions} from './workbenchPanels.config.js';

/** Three focused modes share a familiar resizable IDE shell. */
export default function WorkbenchLayout({
  projects, projectId, onProjectChange, onAddProject, actions,
  mode, onModeChange, activeView, onViewChange,
  explorerContent, workspaceContent, inspectorContent,
  consoleContent, outputContent, statusText,
  bottomOpen, onBottomOpenChange, bottomTab, onBottomTabChange
}) {
  const viewItems = modeViews[mode] || modeViews.model;
  return <div className="ide-shell">
    <header className="ide-header ide-header-focused">
      <div className="ide-brand"><span className="ide-brand-symbol"><PartitionOutlined/></span><strong>UMAA Studio</strong><span className="ide-brand-sub">Workbench</span></div>
      <div className="ide-project-selector">
        <span className="ide-subtle-label">PROJECT</span>
        <Select size="small" value={projectId||undefined} onChange={onProjectChange} style={{minWidth:155,maxWidth:215}}
          options={projects.map(p=>({value:p.id,label:p.name}))} placeholder="프로젝트 선택" showSearch optionFilterProp="label"/>
        <Tooltip title="프로젝트 추가"><Button size="small" onClick={onAddProject} icon={<FolderAddOutlined/>}/></Tooltip>
      </div>
      <span className="ide-header-spacer"/>
      <Space size={5} className="ide-actions">{actions}</Space>
    </header>
    <div className="focus-modebar" role="navigation" aria-label="Workspace mode">
      <Segmented value={mode} onChange={onModeChange}
        options={workbenchModes.map(v=>({value:v.key,label:v.label}))} size="large"/>
      <span className="focus-mode-description">{workbenchModes.find(v=>v.key===mode)?.description}</span>
      <Tag color="gold" bordered={false}>MOCK · STATIC</Tag>
    </div>
    <div className="ide-body">
      <Splitter className="ide-horizontal" collapsible={{motion:true}}>
        <Splitter.Panel defaultSize={panelDimensions.explorer.defaultSize}
          min={panelDimensions.explorer.min} max={panelDimensions.explorer.max}
          collapsible={{end:true,showCollapsibleIcon:true}}>
          <section className="ide-panel ide-explorer" aria-label="Model Explorer">
            <div className="ide-panel-header"><span><AppstoreOutlined/> EXPLORER</span><span className="ide-muted">{mode.toUpperCase()}</span></div>
            <div className="ide-explorer-content">{explorerContent}</div>
          </section>
        </Splitter.Panel>
        <Splitter.Panel min={510}>
          <div className="ide-workstack">
            <Splitter layout="vertical" className="ide-vertical">
              <Splitter.Panel min={320}>
                <Splitter className="ide-workarea" collapsible={{motion:true}}>
                  <Splitter.Panel min={320}>
                    <main className="ide-panel ide-workspace" aria-label="Workspace">
                      <Tabs size="small" className="ide-workspace-tabs" activeKey={activeView}
                        onChange={onViewChange} items={viewItems.map(v=>({key:v.key,label:v.label}))}/>
                      <div className="ide-workspace-content">{workspaceContent}</div>
                    </main>
                  </Splitter.Panel>
                  <Splitter.Panel defaultSize={panelDimensions.inspector.defaultSize}
                    min={panelDimensions.inspector.min} max={panelDimensions.inspector.max}
                    collapsible={{start:true,showCollapsibleIcon:true}}>
                    <aside className="ide-panel ide-inspector" aria-label="Properties">
                      <div className="ide-panel-header"><span><SettingOutlined/> PROPERTIES</span><span className="ide-muted">{mode.toUpperCase()}</span></div>
                      <div className="ide-inspector-content">{inspectorContent}</div>
                    </aside>
                  </Splitter.Panel>
                </Splitter>
              </Splitter.Panel>
              {bottomOpen && <Splitter.Panel defaultSize={panelDimensions.bottom.defaultSize}
                  min={panelDimensions.bottom.min} max={panelDimensions.bottom.max}>
                <section className="ide-panel ide-bottom" aria-label="Console and output">
                  <Tabs size="small" className="ide-bottom-tabs" activeKey={bottomTab}
                    onChange={onBottomTabChange} items={[{key:'console',label:'Console'},{key:'output',label:'Output'}]}
                    tabBarExtraContent={<Tooltip title="하단 패널 닫기"><Button size="small" type="text"
                      icon={<CaretDownOutlined/>} onClick={()=>onBottomOpenChange(false)}/></Tooltip>}/>
                  <div className="ide-bottom-content">{bottomTab==='console'?consoleContent:outputContent}</div>
                </section>
              </Splitter.Panel>}
            </Splitter>
            {!bottomOpen && <div className="ide-bottom-dock"><Button size="small" type="text" icon={<CaretUpOutlined/>}
              onClick={()=>onBottomOpenChange(true)}>Console / Output</Button></div>}
          </div>
        </Splitter.Panel>
      </Splitter>
    </div>
    <footer className="ide-statusbar"><span className="ide-status-pulse"/> {statusText||'Local mock'}
      <span className="ide-status-sep">|</span> QEA: synthetic only
      <span className="ide-status-sep">|</span> No backend / DDS runtime
      <span className="ide-status-spacer"/><CodeOutlined/> esbuild · file://</footer>
  </div>;
}
