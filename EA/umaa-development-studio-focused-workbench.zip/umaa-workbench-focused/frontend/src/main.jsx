import React from 'react';
import { createRoot } from 'react-dom/client';
import { ConfigProvider } from 'antd';
import koKR from 'antd/locale/ko_KR';
import App from './App';
import 'antd/dist/reset.css';
import '@xyflow/react/dist/style.css';
import './styles.css';

createRoot(document.getElementById('root')).render(
  <ConfigProvider locale={koKR} theme={{token:{colorPrimary:'#1a5ea8',borderRadius:8,fontFamily:'Inter, Pretendard, "Noto Sans KR", system-ui, sans-serif', colorText:'#1b283c'},components:{Layout:{headerBg:'#fff'},Menu:{darkItemBg:'#101e31',darkSubMenuItemBg:'#101e31',darkItemSelectedBg:'#1e456f'}}}}><App/></ConfigProvider>
);
