import React, { useMemo } from 'react';
import { Background, Controls, MiniMap, ReactFlow, MarkerType } from '@xyflow/react';
import { byType, lookup } from '../lib/model';

export default function ComponentGraph({ elements, selectedComponentId, onSelect }) {
  const { nodes, edges } = useMemo(() => {
    const comps = byType(elements, 'Component');
    const serviceIds = new Set(comps.flatMap(c => (c.properties?.services || []).map(r => r.serviceId)));
    const services = elements.filter(e => serviceIds.has(e.id));
    const nodes = [
      ...comps.map((c,i)=>({id:c.id, position:{x:40,y:50+i*115}, data:{label:`▣  ${c.name}`},
         style:{background:c.id===selectedComponentId?'#e6f1ff':'#fff',border:'1.5px solid #8db4e5',borderRadius:10,width:215,padding:10,fontWeight:600,boxShadow:'0 3px 12px #1c427015'}})),
      ...services.map((s,i)=>({id:s.id, position:{x:380,y:50+i*115},data:{label:`◈  ${s.name}`},
         style:{background:'#f5f9fc',border:'1px solid #aabed2',borderRadius:10,width:215,padding:10}}))
    ];
    const edges=comps.flatMap(c=>(c.properties?.services||[]).filter(r=>lookup(elements,r.serviceId)).map((r,i)=>({
      id:`${c.id}-${r.serviceId}-${i}`,source:r.role==='provider'?c.id:r.serviceId,target:r.role==='provider'?r.serviceId:c.id,
      label:r.role,labelStyle:{fontSize:10,fill:'#4c647a'},type:'smoothstep',markerEnd:{type:MarkerType.ArrowClosed,color:r.role==='provider'?'#3b82c4':'#8898a9'},
      style:{stroke:r.role==='provider'?'#3b82c4':'#8898a9',strokeWidth:1.5}
    })));
    return {nodes,edges};
  },[elements,selectedComponentId]);
  return <div className="component-graph"><ReactFlow nodes={nodes} edges={edges} fitView nodesDraggable={false} nodesConnectable={false} onNodeClick={(_,node)=>onSelect(node.id)} proOptions={{hideAttribution:true}}><Background color="#eef3f8" gap={18}/><Controls showInteractive={false}/><MiniMap nodeColor="#9abce5" pannable zoomable/></ReactFlow></div>;
}
