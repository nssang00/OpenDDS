import React from 'react';
import { Alert, Button, Descriptions, Empty, Input, List, Space, Table, Tag, Typography } from 'antd';
import { CodeOutlined, FileTextOutlined, ReloadOutlined, SafetyCertificateOutlined } from '@ant-design/icons';
import { lookup, typeColor } from '../lib/model.js';

const {Text,Title} = Typography;

export function QeaSummary({model}) {
  const elements=model?.elements||[];
  const counts=Object.entries(elements.reduce((all,element)=>(all[element.semanticType]=(all[element.semanticType]||0)+1,all),{}));
  return <div className="ide-document">
    <div className="ide-document-head"><strong>QEA Snapshot / Import Summary</strong><Tag color="gold">SYNTHETIC MOCK</Tag></div>
    <Alert showIcon type="warning" message="실제 QEA 내용을 분석하지 않습니다."
      description="파일 선택 시 미리 정의한 합성 UML 예제로 교체됩니다. EA GUID 및 Stereotype 처리는 실제 QEA 파서가 아닙니다."/>
    <Title level={5}>Semantic classification</Title>
    <Space wrap>{counts.map(([name,count])=><Tag key={name} color={typeColor(name)}>{name}: {count}</Tag>)}</Space>
    <Title level={5}>QEA snapshots</Title>
    <List size="small" bordered dataSource={model?.snapshots||[]} locale={{emptyText:'가져오기 이력이 없습니다.'}}
      renderItem={s=><List.Item><List.Item.Meta title={s.filename} description={`${s.createdAt} / ${s.elements} elements / ${s.relations} connectors`}/></List.Item>}/>
    <Title level={5}>Import diagnostics</Title>
    {(model?.diagnostics||[]).map((d,i)=><Alert key={i} style={{marginBottom:8}} showIcon type={d.severity==='warning'?'warning':'info'} message={d.message}/>)}
  </div>;
}

export function ElementDetails({element,elements=[]}) {
  if(!element)return <div className="ide-empty"><Empty description="좌측 Explorer에서 요소를 선택하세요."/></div>;
  const p=element.properties||{};
  const type=['DataType','MessageType','Enum','Field','UnmappedClass'].includes(element.semanticType);
  const fields=Array.isArray(p.fields)&&p.fields.length?p.fields:elements.filter(x=>x.parentId===element.id && x.semanticType==='Field').map(x=>({name:x.name,type:x.properties?.fieldType||'',optional:false}));
  return <div className="ide-document">
    <div className="ide-document-head"><div><Text type="secondary">{element.semanticType}</Text><Title level={4} style={{margin:'4px 0'}}>{element.name}</Title></div><Tag color={element.origin==='project'?'blue':'default'}>{element.origin==='project'?'PROJECT EXTENSION':'QEA SNAPSHOT'}</Tag></div>
    <Text type="secondary">{element.description||'설명이 없습니다.'}</Text>
    {type && <>
      <Title level={5} style={{marginTop:22}}>Data definition</Title>
      {element.semanticType==='Enum'?<Table size="small" pagination={false} rowKey={(v,i)=>i}
        dataSource={(p.values||[]).map(v=>typeof v==='string'?{name:v}:v)} columns={[{title:'Enum value',dataIndex:'name'}]}/>
       :<Table size="small" pagination={false} rowKey={(v,i)=>i} dataSource={fields}
          columns={[{title:'Field',dataIndex:'name'},{title:'Type',dataIndex:'type'},{title:'Optional',dataIndex:'optional',render:v=>v?'Yes':'—'}]}
          locale={{emptyText:'정의된 필드가 없습니다.'}}/>}
    </>}
    {element.semanticType==='Component' && <>
      <Title level={5} style={{marginTop:22}}>Service provider / consumer</Title>
      <Table size="small" rowKey={(_,i)=>i} pagination={false} dataSource={p.services||[]} columns={[
        {title:'Service',render:(_,r)=>lookup(elements,r.serviceId)?.name||`Unresolved (${r.serviceId})`},
        {title:'Role',dataIndex:'role',render:v=><Tag color={v==='provider'?'green':'purple'}>{v||'?'}</Tag>}
      ]} locale={{emptyText:'서비스 역할이 없습니다. 우측 Properties에서 추가할 수 있습니다.'}}/>
    </>}
    {element.semanticType==='TopicBinding' && <>
      <Title level={5} style={{marginTop:22}}>Operation / Topic binding</Title>
      <Descriptions size="small" bordered column={1} items={[
        {key:'service',label:'Service',children:lookup(elements,p.serviceId)?.name||'Unresolved'},
        {key:'operation',label:'Operation',children:p.operationName||'-'},
        {key:'topic',label:'DDS Topic',children:p.topicName||'-'},
        {key:'type',label:'Message Type',children:lookup(elements,p.messageTypeId)?.name||'Unresolved'},
        {key:'kind',label:'Binding kind',children:p.bindingKind||'-'}
      ]}/>
    </>}
    {element.semanticType==='UnmappedClass' && <Alert style={{marginTop:18}} type="warning" showIcon message="UMAA Stereotype 매핑이 정의되지 않은 UML 요소입니다."/>}
    <Title level={5} style={{marginTop:24}}>Model provenance</Title>
    <Descriptions size="small" bordered column={1} items={[
      {key:'source',label:'EA GUID',children:element.sourceGuid||'Project generated'},
      {key:'stereotype',label:'Stereotype',children:element.stereotype||'—'},
      {key:'type',label:'EA element type',children:element.eaType||'—'},
      {key:'id',label:'Model ID',children:element.id}
    ]}/>
  </div>;
}

export function ConsoleView({logs=[],diagnostics=[],issues=[]}) {
  return <div className="ide-console-lines" role="log" aria-label="Workbench console">
    <div className="ide-console-line"><span className="ide-console-info">INFO</span> UMAA Studio Mock Workbench / backend 없음 / QEA 합성 데이터</div>
    {logs.map((l,i)=><div className="ide-console-line" key={`${l.time}-${i}`}><span className="ide-console-time">{l.time}</span><span className={`ide-console-${l.level||'info'}`}>{String(l.level||'info').toUpperCase()}</span> {l.message}</div>)}
    {diagnostics.map((d,i)=><div className="ide-console-line" key={`diag${i}`}><span className={`ide-console-${d.severity==='warning'?'warn':'info'}`}>{d.severity.toUpperCase()}</span> {d.message}</div>)}
    {issues.map((issue,i)=><div className="ide-console-line" key={`issue${i}`}><span className={`ide-console-${issue.level==='error'?'error':'warn'}`}>{issue.level.toUpperCase()}</span> {issue.message} {issue.elementId||''}</div>)}
  </div>;
}

export function OutputView({onValidate,onDownload,loading,issueResult}) {
  return <div className="ide-output-content">
    <Space wrap size={6}>
      <Button size="small" icon={<SafetyCertificateOutlined/>} loading={loading==='validate'} onClick={onValidate}>Validate</Button>
      <Button size="small" icon={<CodeOutlined/>} onClick={()=>onDownload('idl')}>IDL 초안</Button>
      <Button size="small" icon={<FileTextOutlined/>} onClick={()=>onDownload('document')}>Model 문서</Button>
      <Button size="small" onClick={()=>onDownload('cpp')}>C++ 골격</Button>
    </Space>
    {issueResult && <Alert style={{marginTop:10}} showIcon type={issueResult.passed?'success':'warning'} message={`기본 정적 검사: ${issueResult.issues.length}건 (규격 적합성 인증 아님)`}/>}
    <Text type="secondary" style={{fontSize:11,display:'block',marginTop:9}}>브라우저에서 생성하는 Mock 초안입니다. 실제 DDS/C++ Wrapper 런타임 구현이 아닙니다.</Text>
  </div>;
}
