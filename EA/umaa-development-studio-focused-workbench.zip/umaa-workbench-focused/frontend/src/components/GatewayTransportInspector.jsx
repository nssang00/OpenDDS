import React, { useMemo } from 'react';
import { Alert, Descriptions, Divider, Form, Input, InputNumber, Select, Space, Tag, Typography } from 'antd';

/** Editing the transport properties updates exactly the same JSON text used by the Gateway editor. */
export default function GatewayTransportInspector({json, onChange}) {
  const {config,error} = useMemo(()=>{
    try { const value=JSON.parse(json); return value&&typeof value==='object'&&!Array.isArray(value)?{config:value,error:''}:{config:null,error:'최상위 JSON은 객체여야 합니다.'}; }
    catch(e) { return {config:null,error:e.message}; }
  },[json]);
  const transport=config?.transport||{};
  const changeProtocol=protocol=>{
    if(!config)return;
    const next=structuredClone(config);
    next.transport={...next.transport,protocol};
    if(protocol==='tcp')next.transport.tcpFraming ||= 'length_prefix_u32_be';
    else delete next.transport.tcpFraming;
    onChange(JSON.stringify(next,null,2)+'\n');
  };
  const patch=(section,key,value)=>{
    if(!config) return;
    const next=structuredClone(config);
    next[section]={...(next[section]||{}),[key]:value};
    onChange(JSON.stringify(next,null,2)+'\n');
  };
  if(error) return <div className="ide-inspector-form"><Alert type="warning" showIcon message="JSON 구문 오류" description="중앙 Gateway Mapping 탭에서 JSON을 수정해야 속성 편집이 가능합니다."/></div>;
  return <div className="ide-inspector-form">
    <Typography.Title level={5} style={{marginTop:0}}>Gateway Route</Typography.Title>
    <Space wrap><Tag color="geekblue">{config?.direction||'direction?'}</Tag><Tag>{transport.protocol?.toUpperCase()||'TCP/UDP'}</Tag></Space>
    <Divider orientation="left">Transport Properties</Divider>
    <Form layout="vertical" size="small">
      <Form.Item label="Direction"><Input value={config?.direction==='dds_to_socket'?'DDS → TCP/UDP':'TCP/UDP → DDS'} readOnly/></Form.Item>
      <Form.Item label="Protocol"><Select value={transport.protocol} onChange={changeProtocol} options={[{value:'tcp',label:'TCP'},{value:'udp',label:'UDP'}]}/></Form.Item>
      {transport.protocol==='tcp' && <Form.Item label="TCP Framing"><Select value={transport.tcpFraming||'length_prefix_u32_be'} onChange={v=>patch('transport','tcpFraming',v)} options={[{value:'length_prefix_u32_be',label:'Length Prefix (u32 BE)'},{value:'fixed_length',label:'Fixed Length'}]}/></Form.Item>}
      <Form.Item label="Host"><Input value={transport.host??''} onChange={e=>patch('transport','host',e.target.value)} placeholder="192.0.2.10"/></Form.Item>
      <Form.Item label="Port"><InputNumber style={{width:'100%'}} min={1} max={65535} value={transport.port} onChange={value=>patch('transport','port',value)}/></Form.Item>
    </Form>
    <Alert type="info" showIcon message="JSON이 원본 설정" description="Protocol·Host·Port 변경은 JSON과 동기화됩니다. 방향 변경은 Field Mapping의 예제를 다시 선택하거나 JSON 매핑 전체를 수정해야 합니다."/>
    <Divider orientation="left">Packet / Mapping</Divider>
    <Descriptions size="small" column={1} items={[
      {key:'packet',label:'Packet',children:config?.packet?.name||'-'},
      {key:'endianness',label:'Byte order',children:config?.packet?.byteOrder||'-'},
      {key:'mapping',label:'Mappings',children:config?.fieldMappings?.length??0}
    ]}/>
    <Typography.Text type="secondary" style={{fontSize:11}}>실제 네트워크 소켓 또는 DDS Endpoint는 생성하지 않습니다.</Typography.Text>
  </div>;
}
