import React, {useMemo, useState} from 'react';
import {Alert, Button, Divider, Input, InputNumber, Select, Space, Table, Tag, Typography, Upload, message} from 'antd';
import {CheckCircleOutlined, CodeOutlined, DownloadOutlined, ImportOutlined, PlusOutlined, ReloadOutlined, SaveOutlined, DeleteOutlined} from '@ant-design/icons';
import {api} from '../lib/api.js';
import {getExample, prettyJson, previewPacket, validateGateway} from '../lib/gateway/gateway.js';
const {Text} = Typography;
const HAS=(m,k)=>Object.prototype.hasOwnProperty.call(m,k);

/** Both views edit a single parent-owned JSON draft; switching tabs cannot discard changes. */
export default function GatewayDesigner({projectId, jsonValue, onJsonChange, savedJson, onSaved, view='mapping'}) {
  const [busy,setBusy]=useState(false);
  const [issues,setIssues]=useState(null);
  const [preview,setPreview]=useState(null);
  const [messageApi,holder]=message.useMessage();
  const json=jsonValue||'';
  const parsed=useMemo(()=>{
    try{const value=JSON.parse(json);return value&&typeof value==='object'&&!Array.isArray(value)?{config:value,error:''}:{config:null,error:'최상위 JSON은 객체여야 합니다.'};}
    catch(e){return {config:null,error:e.message};}
  },[json]);
  const config=parsed.config;
  const mappings=Array.isArray(config?.fieldMappings)?config.fieldMappings:[];
  const fields=Array.isArray(config?.packet?.fields)?config.packet.fields:[];
  const editable=Array.isArray(config?.fieldMappings)&&Array.isArray(config?.packet?.fields)&&Array.isArray(config?.ddsEndpoints);
  const dirty=json.trim()!==(savedJson||'').trim();
  const updateText=next=>{onJsonChange(next);setIssues(null);setPreview(null);};
  const updateCfg=fn=>{
    if(!editable)return;
    const updated=structuredClone(config);fn(updated);updateText(prettyJson(updated)+'\n');
  };
  const patchMapping=(index,fn)=>updateCfg(next=>{
    const mappings=next.fieldMappings;
    fn(mappings[index]);
  });
  const check=()=>{
    if(parsed.error){setIssues([{level:'error',message:`JSON 구문 오류: ${parsed.error}`}]);return false;}
    const result=validateGateway(config);setIssues(result.issues);
    if(!result.passed)messageApi.warning('Gateway JSON 검증 오류를 확인하세요.');
    return result.passed;
  };
  const save=async()=>{
    if(!check())return;
    setBusy(true);
    try {await api.saveGateway(projectId,config);onSaved?.(prettyJson(config)+'\n');messageApi.success('Gateway Mapping 저장 완료 (Mock)');}
    catch(e){messageApi.error(e.message);}finally{setBusy(false);}
  };
  const exportFile=async type=>{
    if(!check())return;
    try {await api.exportGateway(projectId,type,config);messageApi.success(type==='json'?'JSON 내보내기 완료':'C++ 골격 초안 다운로드');}
    catch(e){messageApi.error(e.message);}
  };
  const previewExample=()=>{
    if(!check())return;
    try{setPreview(previewPacket(config));messageApi.success('합성 입력값으로 Hex를 생성했습니다.');}
    catch(e){setPreview(null);messageApi.warning(e.message);}
  };
  const loadExample=direction=>{
    if(dirty&&!window.confirm('저장되지 않은 Gateway 변경을 버리고 예제를 불러올까요?'))return;
    updateText(prettyJson(getExample(direction))+'\n');
  };
  const importFile=async file=>{
    try{const text=await file.text();updateText(prettyJson(JSON.parse(text))+'\n');messageApi.info('JSON 파일을 불러왔습니다. 검증 후 저장하세요.');}
    catch(e){messageApi.error('JSON 파일을 열 수 없습니다: '+e.message);}
    return false;
  };
  const direction=config?.direction;
  const sourceToPacket=direction==='dds_to_socket';
  const addMapping=()=>updateCfg(next=>{
    if(sourceToPacket){
      const unused=next.packet.fields.find(f=>!next.fieldMappings.some(m=>m.target===f.name));
      next.fieldMappings.push({target:unused?.name||'newField',constant:0});
    }else{
      next.fieldMappings.push({source:`packet.${next.packet.fields[0]?.name||'field'}`,target:`${next.ddsEndpoints[0]?.id||'endpoint'}.field`});
    }
  });
  const columns=[
    {title:'Target',key:'target',width:'26%',render:(_,m,index)=>sourceToPacket?<Select size="small" style={{width:'100%'}}
      value={m.target} options={fields.map(f=>({value:f.name,label:`${f.name} (${f.type})`}))}
      onChange={v=>patchMapping(index,item=>{item.target=v;})}/>:
      <Input size="small" aria-label={`Mapping ${index+1} target`} value={m.target} onChange={e=>patchMapping(index,item=>{item.target=e.target.value;})}/>},
    {title:'Input',key:'input',width:'35%',render:(_,m,index)=><Space.Compact style={{width:'100%'}}>
      <Select size="small" style={{width:95,flex:'none'}} value={HAS(m,'constant')?'constant':'source'}
        onChange={kind=>patchMapping(index,item=>{
          delete item.source;delete item.constant;
          if(kind==='constant')item.constant=0;
          else item.source=sourceToPacket?(config.ddsEndpoints[0]?.id||'position')+'.field':'packet.'+(fields[0]?.name||'field');
        })} options={[{value:'source',label:'Field'},{value:'constant',label:'Constant'}]}/>
      {HAS(m,'constant')?<InputNumber size="small" style={{width:'100%'}} value={m.constant}
        onChange={v=>patchMapping(index,item=>{item.constant=v;})}/>:
        <Input size="small" value={m.source||''} onChange={e=>patchMapping(index,item=>{item.source=e.target.value;})}
          aria-label={`Mapping ${index+1} source`}/>}
    </Space.Compact>},
    {title:'Transform',key:'transform',width:'28%',render:(_,m,index)=><Space.Compact style={{width:'100%'}}>
      <Select size="small" value={m.transform?.kind||'identity'} style={{minWidth:96}}
        options={[{value:'identity',label:'Direct'},{value:'scale',label:'Scale'},{value:'scale_round',label:'Scale+round'}]}
        onChange={kind=>patchMapping(index,item=>{if(kind==='identity')delete item.transform;else item.transform={kind,factor:item.transform?.factor||1};})}/>
      {m.transform&&<InputNumber size="small" style={{width:'100%'}} value={m.transform.factor}
        onChange={value=>patchMapping(index,item=>{item.transform.factor=value;})}/>}
    </Space.Compact>},
    {title:'',key:'delete',width:37,render:(_,m,index)=><Button size="small" danger type="text" aria-label={`Delete mapping ${index+1}`}
      icon={<DeleteOutlined/>} onClick={()=>updateCfg(next=>next.fieldMappings.splice(index,1))}/>}
  ];
  return <div className="gateway-focused">{holder}
    <div className="gateway-focus-head">
      <div><strong>Gateway Mapping</strong> <Tag>{config?.direction||'JSON 설정'}</Tag>
        <Tag color={dirty?'orange':'green'}>{dirty?'Unsaved':'Saved'}</Tag>
        <div className="muted-small">RTI Gateway의 Adapter / Transformation / Processor 개념 참조 · 자체 JSON 스키마</div></div>
      <Space wrap size={5}>
        <Button size="small" icon={<CheckCircleOutlined/>} onClick={check}>검증</Button>
        <Button size="small" type="primary" icon={<SaveOutlined/>} loading={busy} onClick={save}>저장</Button>
        <Button size="small" icon={<DownloadOutlined/>} onClick={()=>exportFile('json')}>JSON</Button>
        <Button size="small" icon={<CodeOutlined/>} onClick={()=>exportFile('cpp')}>C++ 초안</Button>
      </Space>
    </div>
    {parsed.error&&<Alert type="error" showIcon style={{margin:'12px 0'}} message={'JSON 구문 오류: '+parsed.error}/>}
    {view==='json'?<div className="gateway-focus-editor">
      <div className="gateway-focus-row"><Text type="secondary">JSON 직접 편집 — 변경 시 Field Mapping과 Properties에 동기화됩니다.</Text>
        <Upload accept=".json,application/json" beforeUpload={importFile} showUploadList={false}>
          <Button size="small" icon={<ImportOutlined/>}>파일 불러오기</Button></Upload></div>
      <Input.TextArea aria-label="Gateway field mapping JSON" value={json} spellCheck={false}
        onChange={e=>updateText(e.target.value)} className="gateway-json-editor gateway-code-editor"/>
    </div>:<div className="gateway-focus-editor">
      <div className="gateway-focus-row">
        <Space wrap size={6}>
          <Button size="small" onClick={()=>loadExample('dds_to_socket')}>DDS → UDP 예제</Button>
          <Button size="small" onClick={()=>loadExample('socket_to_dds')}>UDP → DDS 예제</Button>
        </Space>
        <Button size="small" type="dashed" icon={<PlusOutlined/>} onClick={addMapping} disabled={!editable}>매핑 추가</Button>
      </div>
      <div className="gateway-route-meta">
        <Tag color="blue">{direction||'—'}</Tag>
        <Tag>{config?.transport?.protocol?.toUpperCase()||'—'}</Tag>
        <Tag>{config?.packet?.name||'Packet'}</Tag>
        <Text type="secondary">{mappings.length} mappings · {fields.length} packet fields</Text>
      </div>
      {editable?<Table size="small" pagination={false} rowKey={(_,i)=>i} columns={columns}
        dataSource={mappings} scroll={{x:600}} locale={{emptyText:'매핑이 없습니다. 매핑 추가를 누르세요.'}}/>:
        <Alert type="warning" message="JSON 탭에서 누락되거나 잘못된 설정을 먼저 수정하세요."/>}
      <Divider orientation="left">Packet Preview</Divider>
      <Space><Button size="small" icon={<ReloadOutlined/>} onClick={previewExample} disabled={!config}>합성 입력 → Hex 생성</Button>
        <Text type="secondary">실제 DDS/TCP/UDP 통신은 수행하지 않습니다.</Text></Space>
      {preview&&<div style={{marginTop:10}}><Text strong>{preview.byteLength} bytes</Text>
        <pre className="gateway-hex">{preview.hex}</pre>
        <Table size="small" pagination={false} rowKey="name" dataSource={preview.rows}
          columns={[{title:'Field',dataIndex:'name'},{title:'Value',dataIndex:'value'},{title:'Offset',dataIndex:'offset'}]}/></div>}
      {!preview&&<div className="muted-small" style={{marginTop:8}}>DDS→패킷 방향만 합성 Hex 미리보기를 지원합니다. 역방향은 JSON 검증·내보내기만 가능합니다.</div>}
    </div>}
    {issues!==null&&<div className="gateway-issues">
      {issues.length?issues.map((issue,i)=><Alert key={i} type={issue.level==='error'?'error':'warning'} showIcon message={issue.message} style={{marginBottom:5}}/>):
        <Alert type="success" showIcon message="기본 Gateway JSON 검증 통과 — UMAA 적합성 인증 아님"/>}
    </div>}
  </div>;
}
