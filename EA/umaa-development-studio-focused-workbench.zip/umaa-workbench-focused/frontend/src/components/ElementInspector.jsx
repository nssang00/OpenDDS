import React, { useEffect, useState } from 'react';
import { Button, Descriptions, Divider, Empty, Form, Input, Popconfirm, Select, Space, Table, Tag, Typography, Alert, Switch } from 'antd';
import { DeleteOutlined, SaveOutlined, PlusOutlined } from '@ant-design/icons';
import { typeColor, byType } from '../lib/model';

const { Text } = Typography;
const PRIMITIVES = ['boolean', 'string', 'char', 'byte', 'int16', 'int32', 'int64', 'uint16', 'uint32', 'uint64', 'float32', 'float64', 'float', 'double'];

export default function ElementInspector({ element, elements, onSave, onDelete, saving }) {
  const [form] = Form.useForm();
  const [fields, setFields] = useState([]);
  const [values, setValues] = useState([]);
  const [roles, setRoles] = useState([]);
  useEffect(() => {
    form.setFieldsValue({ name: element?.name, description: element?.description,
      icd: element?.properties?.icd || '', protocol: element?.properties?.protocol || '',
      serviceId: element?.properties?.serviceId || '', messageTypeId: element?.properties?.messageTypeId || '',
      operationName: element?.properties?.operationName || '', topicName: element?.properties?.topicName || '',
      bindingKind: element?.properties?.bindingKind || 'publish', returnType: element?.properties?.returnType || '' });
    setFields(structuredClone(element?.properties?.fields || (elements || []).filter(x => x.parentId === element?.id && x.semanticType === 'Field').map(x => ({name:x.name,type:x.properties?.fieldType || ''}))));
    setValues(structuredClone(element?.properties?.values || []));
    setRoles(structuredClone(element?.properties?.services || []));
  }, [element?.id, element?.properties, element?.name, element?.description, form]);
  if (!element) return <Empty description="왼쪽에서 모델 요소를 선택해 주세요." style={{ paddingTop: 75 }} />;
  const readOnly = element.origin !== 'project';
  const type = element.semanticType;
  const isData = ['DataType', 'MessageType'].includes(type);
  const properties = element.properties || {};
  const save = vals => {
    let newProps = { ...properties };
    if (isData) newProps.fields = fields;
    if (type === 'Enum') newProps.values = values;
    if (type === 'Component') newProps.services = roles;
    if (['Service', 'ServiceInterface'].includes(type)) { newProps.icd = vals.icd; newProps.protocol = vals.protocol; }
    if (type === 'TopicBinding') for (const k of ['serviceId','messageTypeId','operationName','topicName','bindingKind']) newProps[k] = vals[k];
    if (type === 'Operation') newProps.returnType = vals.returnType;
    onSave(element.id, { name: vals.name, description: vals.description, properties: newProps });
  };
  const updateField = (index, key, v) => setFields(f => f.map((x,i) => i === index ? {...x, [key]: v} : x));
  const serviceOptions = byType(elements, 'Service', 'ServiceInterface').map(e=>({value:e.id,label:`${e.name} (${e.origin})`}));
  const msgOptions = byType(elements, 'MessageType', 'DataType').map(e=>({value:e.id,label:`${e.name} (${e.origin})`}));
  const typeOptions = byType(elements, 'MessageType', 'DataType', 'Enum').map(e=>({value:e.name,label:`${e.name} (${e.origin})`}));
  return <div className="inspector-content">
    <Space style={{marginBottom:12}} wrap><Tag color={typeColor(type)}>{type}</Tag><Tag color={readOnly ? 'default':'processing'}>{readOnly ? 'QEA source · 읽기 전용' : 'Project extension'}</Tag></Space>
    <Form form={form} layout="vertical" onFinish={save} disabled={readOnly} initialValues={{name:element.name,description:element.description}}>
      <Form.Item label="Name" name="name" rules={[{required:true}]}><Input/></Form.Item>
      <Form.Item label="Description" name="description"><Input.TextArea rows={3}/></Form.Item>
      {isData && <>
        <Divider orientation="left">Fields</Divider>
        <div className="inspector-fields">
          {fields.map((f, i) => <div className="field-row" key={i}>
            <Input disabled={readOnly} placeholder="Field name" value={f.name} onChange={e=>updateField(i,'name',e.target.value)}/>
            <Select disabled={readOnly} showSearch value={f.type} placeholder="Type" onChange={v=>updateField(i,'type',v)}
              options={[...PRIMITIVES.map(x=>({value:x,label:x})),...typeOptions]}/>
            <Switch disabled={readOnly} checked={!!f.optional} checkedChildren="Opt" unCheckedChildren="Req" onChange={v=>updateField(i,'optional',v)}/>
            {!readOnly && <Button danger icon={<DeleteOutlined/>} onClick={()=>setFields(x=>x.filter((_,j)=>i!==j))}/>}
          </div>)}
          {!readOnly && <Button block type="dashed" icon={<PlusOutlined/>} onClick={()=>setFields(x=>[...x,{name:'',type:'string'}])}>필드 추가</Button>}
        </div>
      </>}
      {type === 'Enum' && <>
        <Divider orientation="left">Enumerators</Divider>
        {values.map((v,i)=><Space key={i} style={{display:'flex',marginBottom:8}}><Input disabled={readOnly} value={typeof v === 'string' ? v : v.name} onChange={e=>setValues(x=>x.map((y,j)=>j===i?e.target.value:y))}/>{!readOnly&&<Button icon={<DeleteOutlined/>} onClick={()=>setValues(x=>x.filter((_,j)=>j!==i))}/>}</Space>)}
        {!readOnly&&<Button block type="dashed" onClick={()=>setValues(x=>[...x,'NEW_VALUE'])}>열거값 추가</Button>}
      </>}
      {['Service','ServiceInterface'].includes(type)&&<>
        <Form.Item label="ICD / Source" name="icd"><Input placeholder="예: EO / PROJECT-EXTENSION"/></Form.Item>
        <Form.Item label="Protocol (예: Command/Report)" name="protocol"><Select allowClear options={['Command','Report','Collection','RequestReply','Other'].map(v=>({value:v,label:v}))}/></Form.Item>
      </>}
      {type === 'TopicBinding'&&<>
        <Form.Item label="Service" name="serviceId" rules={[{required:true}]}><Select showSearch optionFilterProp="label" options={serviceOptions}/></Form.Item>
        <Form.Item label="Message Type" name="messageTypeId" rules={[{required:true}]}><Select showSearch optionFilterProp="label" options={msgOptions}/></Form.Item>
        <Form.Item label="Operation" name="operationName"><Input placeholder="reportX / setX"/></Form.Item>
        <Form.Item label="DDS Topic qualified name" name="topicName" rules={[{required:true}]}><Input/></Form.Item>
        <Form.Item label="Data flow from this endpoint" name="bindingKind"><Select options={[{value:'publish',label:'publish'},{value:'subscribe',label:'subscribe'},{value:'dispose',label:'dispose'},{value:'none',label:'no topic'}]}/></Form.Item>
      </>}
      {type === 'Operation'&&<Form.Item label="Return Type" name="returnType"><Input/></Form.Item>}
      {type === 'Component'&&<>
        <Divider orientation="left">Service roles</Divider>
        {roles.map((role,i)=><div key={i} className="role-row">
          <Select style={{flex:1}} disabled={readOnly} showSearch optionFilterProp="label" value={role.serviceId} options={serviceOptions} placeholder="Service" onChange={v=>setRoles(x=>x.map((r,j)=>j===i?{...r,serviceId:v}:r))}/>
          <Select disabled={readOnly} value={role.role} style={{width:125}} onChange={v=>setRoles(x=>x.map((r,j)=>j===i?{...r,role:v}:r))} options={[{value:'provider',label:'Provider'},{value:'consumer',label:'Consumer'}]}/>
          {!readOnly&&<Button icon={<DeleteOutlined/>} onClick={()=>setRoles(x=>x.filter((_,j)=>j!==i))}/>}
        </div>)}
        {!readOnly&&<Button block type="dashed" onClick={()=>setRoles(x=>[...x,{serviceId:undefined,role:'provider'}])}>서비스 추가</Button>}
      </>}
      {!readOnly&&<Space style={{marginTop:16}}><Button type="primary" loading={saving} htmlType="submit" icon={<SaveOutlined/>}>저장</Button><Popconfirm title="프로젝트 확장 요소를 삭제할까요?" onConfirm={()=>onDelete(element.id)}><Button danger icon={<DeleteOutlined/>}>삭제</Button></Popconfirm></Space>}
    </Form>
    {readOnly&&<Alert showIcon type="info" style={{marginTop:12}} message="QEA 원본은 수정하지 않습니다." description="모델 확장이 필요한 경우 프로젝트 요소를 새로 만드세요."/>}
    <Divider orientation="left">EA / Source metadata</Divider>
    <Descriptions size="small" column={1} bordered items={[
      {key:1,label:'EA GUID',children:<Text copyable={!!element.sourceGuid} ellipsis>{element.sourceGuid||'-'}</Text>},
      {key:2,label:'EA Type',children:element.eaType||'-'},
      {key:3,label:'Stereotype',children:element.stereotype||'-'},
      {key:4,label:'Parent ID',children:<Text ellipsis>{element.parentId||'-'}</Text>}
    ]}/>
    {readOnly&&<><Divider orientation="left">Imported properties (read-only)</Divider><pre className="json-sample">{JSON.stringify(properties, null, 2).slice(0,5000)}</pre></>}
  </div>;
}
