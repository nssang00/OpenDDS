DDS-oriented Sparx EA QEA design skeleton.
Focus tables:
t_package
t_object
t_attribute
t_connector
t_xref
t_objectproperties

No auto keyword used.
C++11 compatible.
