#pragma once
#include <string>

class TaggedValue
{
public:
    const std::string& getName() const { return m_name; }
    const std::string& getValue() const { return m_value; }

private:
    std::string m_name;
    std::string m_value;
};
