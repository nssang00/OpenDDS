#pragma once
#include <string>
#include <vector>

class Element;

class Package
{
public:
    long getId() const { return m_id; }
    const std::string& getName() const { return m_name; }

    const std::vector<Package*>& getPackages() const
    {
        return m_packages;
    }

    const std::vector<Element*>& getElements() const
    {
        return m_elements;
    }

private:
    long m_id;
    std::string m_name;

    Package* m_parent;

    std::vector<Package*> m_packages;
    std::vector<Element*> m_elements;
};
