#pragma once
#include <string>

class Stereotype
{
public:
    const std::string& getName() const { return m_name; }

private:
    std::string m_name;
};
