#pragma once
#include <string>
#include <vector>
#include "Attribute.hpp"
#include "Connector.hpp"
#include "Stereotype.hpp"
#include "TaggedValue.hpp"

class Package;

enum ElementType
{
    ELEMENT_CLASS,
    ELEMENT_ENUM,
    ELEMENT_INTERFACE,
    ELEMENT_COMPONENT,
    ELEMENT_UNKNOWN
};

class Element
{
public:
    long getId() const { return m_id; }
    const std::string& getName() const { return m_name; }

    const std::vector<Attribute*>& getAttributes() const
    {
        return m_attributes;
    }

private:
    long m_id;
    std::string m_name;
    ElementType m_type;
    Package* m_package;

    std::vector<Attribute*> m_attributes;
    std::vector<Connector*> m_connectors;
    std::vector<Stereotype> m_stereotypes;
    std::vector<TaggedValue> m_taggedValues;
};
