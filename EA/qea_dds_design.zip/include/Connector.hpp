#pragma once

class Element;

enum ConnectorType
{
    CONNECTOR_ASSOCIATION,
    CONNECTOR_AGGREGATION,
    CONNECTOR_COMPOSITION,
    CONNECTOR_GENERALIZATION,
    CONNECTOR_DEPENDENCY
};

class Connector
{
public:
    long getId() const { return m_id; }
    Element* getSource() const { return m_source; }
    Element* getTarget() const { return m_target; }

private:
    long m_id;
    ConnectorType m_type;
    Element* m_source;
    Element* m_target;
};
