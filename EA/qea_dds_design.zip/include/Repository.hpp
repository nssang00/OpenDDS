#pragma once
#include <string>
#include <vector>
#include <map>
#include <memory>

class Package;
class Element;
class Connector;

class Repository
{
public:
    bool load(const std::string& file);

    const std::vector<Package*>& getModels() const
    {
        return m_models;
    }

    Package* getPackageById(long id);
    Element* getElementById(long id);

private:
    void loadPackages();
    void loadElements();
    void loadAttributes();
    void loadConnectors();
    void loadTaggedValues();
    void loadStereotypes();

private:
    std::vector<std::shared_ptr<Package> > m_packages;
    std::vector<std::shared_ptr<Element> > m_elements;
    std::vector<std::shared_ptr<Connector> > m_connectors;

    std::vector<Package*> m_models;

    std::map<long, Package*> m_packageMap;
    std::map<long, Element*> m_elementMap;
};
