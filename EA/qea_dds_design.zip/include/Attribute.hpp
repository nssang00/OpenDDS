#pragma once
#include <string>
#include <vector>
#include "TaggedValue.hpp"

class Attribute
{
public:
    long getId() const { return m_id; }
    const std::string& getName() const { return m_name; }
    const std::string& getType() const { return m_type; }
    bool isKey() const { return m_isKey; }

private:
    long m_id;
    std::string m_name;
    std::string m_type;
    bool m_isKey;
    std::vector<TaggedValue> m_taggedValues;
};
