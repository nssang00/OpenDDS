# IDL to EA Mapping

This project maps OMG IDL constructs to standard Enterprise Architect UML elements.
Where UML has no dedicated IDL construct, a UML element plus stereotype/tagged values is used to preserve IDL semantics.

| IDL construct | EA UML element | Stereotype / representation |
|---|---|---|
| `module` | Package | Package hierarchy |
| `struct` | Class | Fields become Attributes |
| `enum` | Enumeration | Enum literals become enumeration Attributes |
| `interface` | Interface | Base interfaces become Generalization connectors |
| `typedef` | DataType | Underlying type stored as `idl.*` tagged values |
| `union` | Class | `<<IDLUnion>>`; discriminator/case metadata stored as tagged values |
| `const` | DataType | `<<IDLConstant>>`; type/value stored as tagged values |
| annotation | TaggedValue | Original annotation plus canonical UMAA tags where applicable |
| struct/interface inheritance | Generalization | Child element → parent element |
| IDL source file | Artifact | `<<IDLFile>>` under the `IDL Sources` package tree |

## Notes

- `union`, `typedef`, and `const` do not use a dedicated EA IDL creation API. They are project mapping policies built on standard UML element types, stereotypes, and tagged values.
- Named field references are connected through the EA Attribute `ClassifierID`.
- Generalization relationships are created only when the parser/resolver successfully resolves the base type to an IDL symbol.
- Interface operations/parameters are parsed and resolved by Core but are not currently emitted to EA; current relationship support covers interface inheritance.
